import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'package:supabase_flutter/supabase_flutter.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Today at a glance: money, who is on duty, what needs the admin, and every vehicle on the map.
class DashboardPage extends StatefulWidget {
  final void Function(String page) go;
  const DashboardPage({super.key, required this.go});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final _l = Lookup();
  double _collected = 0;
  int _trips = 0;
  int _onDuty = 0;
  int _waitingCash = 0;
  int _pendingDocs = 0;
  int _waitingPeople = 0;
  int _pendingChanges = 0;
  int _newBookings = 0;
  int _meetings = 0;
  List<AppAlert> _alerts = [];
  List<Map<String, dynamic>> _late = [];
  List<TruckLocation> _locations = [];
  bool _loading = true;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
    // every truck moves on the map the moment its phone reports a new position
    _channel = db
        .channel('admin-live-trucks')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'truck_locations',
          callback: (payload) {
            final row = payload.newRecord;
            if (row.isEmpty || !mounted) return;
            final loc = TruckLocation.fromMap(row);
            setState(() {
              _locations = [..._locations.where((l) => l.truckId != loc.truckId), loc];
            });
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    final c = _channel;
    if (c != null) db.removeChannel(c);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await db.rpc('run_checks');
    } catch (_) {}
    try {
      await _l.load();
      final today = isoUtc(periodStart(Period.today));
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('trips').select('total').neq('status', 'cancelled').gte('started_at', today),
        db.from('shifts').select('id').eq('status', 'on_duty'),
        db.from('hand_ins').select('id').isFilter('received', null),
        db.from('documents').select('id').eq('status', 'pending'),
        db.from('truck_changes').select('id').eq('status', 'pending'),
        db.from('alerts').select().eq('resolved', false).order('created_at', ascending: false).limit(12),
        db.from('truck_locations').select(),
        db.from('bookings').select('id').eq('status', 'requested'),
        db.from('driver_matches').select('id').eq('status', 'invited'),
      ]);
      var late = <Map<String, dynamic>>[];
      try {
        late = List<Map<String, dynamic>>.from(await db.rpc('late_pickups', params: {'p_min': 15}) as List);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _late = late;
        _collected = r[0].fold<double>(0, (s, x) => s + toDouble(x['total']));
        _trips = r[0].length;
        _onDuty = r[1].length;
        _waitingCash = r[2].length;
        _pendingDocs = r[3].length;
        _pendingChanges = r[4].length;
        _alerts = r[5].map(AppAlert.fromMap).toList();
        _locations = r[6].map(TruckLocation.fromMap).toList();
        _newBookings = r[7].length;
        _meetings = r[8].length;
        _waitingPeople = _l.people.where((p) => !p.active).length;
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        toast(context, friendlyError(e));
      }
    }
  }

  Widget _todo(String text, int count, String page, IconData icon) => ListTile(
        leading: Icon(icon, color: count > 0 ? AppColors.warning : AppColors.lime600),
        title: Text(text),
        trailing: count > 0 ? Pill('$count', color: AppColors.warning) : const Pill('0', color: AppColors.lime600),
        onTap: () => widget.go(page),
      );

  @override
  Widget build(BuildContext context) {
    final points = [
      for (final l in _locations)
        if (_l.truck(l.truckId)?.active ?? false) l,
    ];
    return PageFrame(
      title: 'Dashboard',
      subtitle: dayLabelLong(DateTime.now()),
      onRefresh: _load,
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Collected today', money(_collected), dark: true),
          Stat('Trips today', '$_trips'),
          Stat('On duty now', '$_onDuty of ${_l.trucks.where((t) => t.active).length} vehicles'),
          Stat('Drivers', '${_l.drivers.where((d) => d.active).length}'),
        ]),
        const SizedBox(height: 16),
        LayoutBuilder(builder: (context, box) {
          final todo = Panel(
            title: 'Needs you',
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(children: [
              _todo('New bookings to assign', _newBookings, 'Bookings', Icons.confirmation_number_outlined),
              _todo('Drivers waiting for a vehicle', _l.drivers.where((d) => d.active && d.truckId == null).length,
                  'Drivers & matching', Icons.handshake_outlined),
              _todo('Office meetings set', _meetings, 'Drivers & matching', Icons.event_outlined),
              _todo('Vehicles sent by owners', _l.trucks.where((t) => t.pending).length, 'Vehicles', Icons.local_shipping_outlined),
              _todo('People waiting for approval', _waitingPeople, 'People', Icons.person_add_alt),
              _todo('Documents to check', _pendingDocs, 'Documents', Icons.badge_outlined),
              _todo('Truck changes waiting', _pendingChanges, 'Shifts & trips', Icons.swap_horiz),
              _todo('Cash not received yet', _waitingCash, 'Cash hand-ins', Icons.payments_outlined),
            ]),
          );
          final map = Panel(
            title: 'Vehicles now',
            padding: const EdgeInsets.all(8),
            child: SizedBox(
              height: 320,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: FlutterMap(
                  options: MapOptions(
                    initialCenter: points.isEmpty ? const LatLng(-14.4783, 35.2645) : LatLng(points.first.lat, points.first.lng),
                    initialZoom: points.isEmpty ? 11 : 10,
                    initialCameraFit: points.length < 2
                        ? null
                        : CameraFit.coordinates(
                            coordinates: [for (final p in points) LatLng(p.lat, p.lng)],
                            padding: const EdgeInsets.all(40),
                          ),
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'mw.efulogistix.admin',
                    ),
                    MarkerLayer(markers: [
                      for (final p in points)
                        Marker(
                          point: LatLng(p.lat, p.lng),
                          width: 110,
                          height: 30,
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: p.tripId != null ? AppColors.lime : AppColors.navy,
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: Text(_l.truck(p.truckId)?.plate ?? '',
                                style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    color: p.tripId != null ? AppColors.navy : Colors.white)),
                          ),
                        ),
                    ]),
                    const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
                  ],
                ),
              ),
            ),
          );
          if (box.maxWidth < 900) return Column(children: [todo, map]);
          return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 2, child: todo),
            const SizedBox(width: 16),
            Expanded(flex: 3, child: map),
          ]);
        }),
        Panel(
          title: 'Late pickups',
          padding: const EdgeInsets.symmetric(vertical: 4),
          actions: [
            TextButton(
              onPressed: () => attempt(context, () async {
                final n = await db.rpc('run_reminders');
                await db.rpc('run_owner_digests');
                if (context.mounted) toast(context, 'Reminders sent: $n. Owner summaries sent.');
              }),
              child: const Text('Send reminders now'),
            ),
          ],
          child: _late.isEmpty
              ? const Padding(padding: EdgeInsets.all(16), child: Text('No late pickups.'))
              : Column(children: [
                  for (final b in _late)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.schedule, color: AppColors.danger),
                      title: Text('#${b['booking_no']} · ${b['passenger']} · ${b['pickup_name']}',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${b['minutes_late']} min late · ${b['plate'] ?? ''} · ${b['driver'] ?? ''} ${b['driver_phone'] ?? ''}'),
                    ),
                ]),
        ),
        Panel(
          title: 'Open alerts',
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: _alerts.isEmpty
              ? const Padding(padding: EdgeInsets.all(16), child: Text('All quiet.'))
              : Column(children: [
                  for (final a in _alerts)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.warning_amber, color: AppColors.warning),
                      title: Text(a.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text([
                        if (a.detail != null) a.detail!,
                        if (a.truckId != null) _l.plate(a.truckId),
                        '${shortDate(a.createdAt)} ${clock(a.createdAt)}',
                      ].join(' · ')),
                      trailing: TextButton(
                        onPressed: () async {
                          if (await attempt(context,
                              () => db.from('alerts').update({'resolved': true, 'seen': true}).eq('id', a.id))) {
                            _load();
                          }
                        },
                        child: const Text('Mark done'),
                      ),
                    ),
                ]),
        ),
      ],
    );
  }
}

String dayLabelLong(DateTime d) {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  return '${days[d.weekday - 1]} ${shortDate(d)} ${d.year}';
}
