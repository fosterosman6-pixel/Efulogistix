# ko!ngo test checklist (2 phones + admin on the laptop)

Phone A = customer, Phone B = driver. Tick each line. If one fails, write what you saw.

## Setup
- [ ] Run step32 and step33 SQL, redeploy ride-push, rebuild both apps with the new files
- [ ] Both phones logged in once (so push tokens are saved)

## Rides
- [ ] A books a ride; B's phone rings (also with the screen locked)
- [ ] B accepts; A sees the driver moving and the driver photo
- [ ] Pickup code: B cannot start the trip before the code is entered
- [ ] Trip finishes; both see it as completed and it cannot be changed

## Orders
- [ ] A places a shop order; the driver sees it under Marketplace
- [ ] Delivered / returned orders disappear from A's home screen

## Calls and chat
- [ ] A calls B from the trip screen; B answers; both hear each other
- [ ] Same on mobile data (not the same Wi-Fi) — if it fails, TURN is needed
- [ ] Trip chat message arrives

## Admin → phone
- [ ] Broadcast to drivers, customers, shoppers, merchants: arrives on the phone
- [ ] "Send message" on a user page arrives as a phone notification
- [ ] Top-up rejected: the user gets a notification
- [ ] "Sign out everywhere": that phone returns to login within about a minute
- [ ] User page shows the person's documents

## Admin permissions
- [ ] Create a second admin; restrict him to Orders only
- [ ] He does not see Admin access, Wallet, Payouts or Finance
- [ ] Logged in as him, "Adjust wallet" on a user is refused
- [ ] He cannot change the main admin
- [ ] Main admin can still do everything

## Prices and settings
- [ ] Change a price in admin; the phone shows the new price without reinstalling

## Added in the latest round (test on a phone after the build)
- Passenger home: map shows your blue dot and place name; tap the map to open it full screen; "centre on me" button works.
- Passenger with an assigned car: car icon (matches vehicle type) moves live on the home map and on "Track the car".
- Driver home: "Today at a glance" tiles, map with numbered pickups, "Start a new trip" form.
- Driver: "Use my current location" and "Type a place" under FROM (rank).
- Owner home: glance tiles (on a trip, trips, cash waiting, alerts); tapping cash/alerts jumps to those tabs; fleet map shows car icons, tap opens full screen.
- Owner Cash tab: "Still waiting from earlier days" shows old unconfirmed hand-ins.
- Send goods / Book seat / Hire a car: the bottom button is fully visible above the phone's navigation bar.
- Admin dashboard: a vehicle moves on the map without refreshing.
- Language switch: Chichewa on all new texts (check CHICHEWA_REVIEW.txt with a speaker).
