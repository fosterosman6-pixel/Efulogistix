import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'format.dart';
import 'geo.dart';
import 'here.dart';
import 'theme.dart';
import 'widgets.dart';

/// Map on top, the form in a rounded panel below (like the hire screen).
/// [wide] gives the map more room (first step).
class MapPanel extends StatelessWidget {
  final Widget map;
  final List<Widget> children;
  final bool wide;
  const MapPanel({super.key, required this.map, required this.children, this.wide = false});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        flex: wide ? 5 : 4,
        child: Stack(children: [
          Positioned.fill(child: map),
        ]),
      ),
      Expanded(
        flex: wide ? 5 : 6,
        child: Container(
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
            boxShadow: [BoxShadow(color: Color(0x140A2253), blurRadius: 14, offset: Offset(0, -4))],
          ),
          child: ListView(padding: EdgeInsets.fromLTRB(16, 10, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
            Center(
              child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2))),
            ),
            ...children,
          ]),
        ),
      ),
    ]);
  }
}

/// The route from one place to another on the map, with "km · min" on top.
/// With nothing chosen yet it just shows where the person is.
class RouteMapView extends StatefulWidget {
  final LatLng? from;
  final String fromName;
  final LatLng? to;
  final String toName;
  const RouteMapView({super.key, this.from, this.fromName = '', this.to, this.toName = ''});

  @override
  State<RouteMapView> createState() => _RouteMapViewState();
}

class _RouteMapViewState extends State<RouteMapView> {
  RouteInfo? _route;
  String _key = '';

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  @override
  void didUpdateWidget(covariant RouteMapView old) {
    super.didUpdateWidget(old);
    _fetch();
  }

  Future<void> _fetch() async {
    final a = widget.from, b = widget.to;
    final key = a == null || b == null ? '' : '${a.latitude},${a.longitude}>${b.latitude},${b.longitude}';
    if (key == _key) return;
    _key = key;
    if (key.isEmpty) {
      if (mounted) setState(() => _route = null);
      return;
    }
    final r = await getRoute(a!, b!);
    if (mounted && key == _key) setState(() => _route = r);
  }

  @override
  Widget build(BuildContext context) {
    const top = 0.0; // the title bar already clears the status bar
    final r = _route;
    return Stack(children: [
      Positioned.fill(
        child: ValueListenableBuilder<LatLng?>(
          valueListenable: Here.instance.point,
          builder: (context, me, _) => FleetMap(
            me: me,
            route: r?.points,
            end: widget.to,
            endLabel: widget.toName,
            stops: [if (widget.from != null && widget.to != null) MapStop(widget.from!, widget.fromName, 0)],
            topPadding: top + 70,
            bottomPadding: 40,
          ),
        ),
      ),
      if (r != null)
        Positioned(
          top: top + 16,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
              child: Text('${kmText(r.km)} · ${durationText(r.minutes)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          ),
        ),
    ]);
  }
}
