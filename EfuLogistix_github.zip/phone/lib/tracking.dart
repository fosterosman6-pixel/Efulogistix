import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:shared_preferences/shared_preferences.dart';

import 'app_state.dart';
import 'geo.dart';
import 'location.dart';
import 'outbox.dart';

/// Follows the truck for the whole shift, also with the phone locked (Android shows a
/// "Tracking" notification while it runs). Sends the position every 30 s, adds GPS distance to the
/// shift, and keeps the km driven since the last mileage photo (the database compares it with
/// the typed mileage).
///
/// Every point is also kept on the phone ([GpsTrail]) and uploaded in batches, so the full route
/// of the day reaches the office even after hours without signal. If GPS is switched off during
/// the shift, the office gets a "Tracking stopped" alert.
class Tracking {
  Tracking._();
  static final instance = Tracking._();

  static const _sendEvery = Duration(seconds: 30);
  static const _sinceKey = 'gps_since_last_reading';

  final position = ValueNotifier<LatLng?>(null);
  final speedKmh = ValueNotifier<double>(0);
  String? _tripId;
  double _tripKm = 0;
  double _sinceReadingKm = 0;
  double _unsentShiftKm = 0;
  LatLng? _last;
  DateTime _lastSent = DateTime.fromMillisecondsSinceEpoch(0);
  StreamSubscription<Position>? _sub;
  StreamSubscription<ServiceStatus>? _serviceSub;
  Timer? _heartbeat;
  DateTime _lastPoint = DateTime.fromMillisecondsSinceEpoch(0);
  bool _reportedOff = false;
  String? error;

  bool get running => _sub != null;
  double get tripKm => _tripKm;
  double get sinceReadingKm => _sinceReadingKm;

  LocationSettings _settings() {
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      return AndroidSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 20,
        intervalDuration: const Duration(seconds: 10),
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: 'EfuLogistix · on duty',
          notificationText: 'Your truck is being tracked during the shift.',
          enableWakeLock: true,
          setOngoing: true,
        ),
      );
    }
    if (!kIsWeb && (defaultTargetPlatform == TargetPlatform.iOS || defaultTargetPlatform == TargetPlatform.macOS)) {
      return AppleSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 20,
        allowBackgroundLocationUpdates: true,
        showBackgroundLocationIndicator: true,
        pauseLocationUpdatesAutomatically: false,
        activityType: ActivityType.automotiveNavigation,
      );
    }
    return const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 20);
  }

  /// Start following the truck (safe to call again).
  Future<String?> start() async {
    if (_sub != null) return null;
    final problem = await ensureLocation();
    if (problem != null) {
      error = problem;
      return problem;
    }
    final prefs = await SharedPreferences.getInstance();
    _sinceReadingKm = prefs.getDouble(_sinceKey) ?? 0;
    _sub = Geolocator.getPositionStream(locationSettings: _settings()).listen(_onPosition, onError: (Object e) {
      error = 'Could not read GPS. Turn on location.';
      _reportTracking(false, 'the phone stopped giving GPS positions');
    });
    if (!kIsWeb) {
      try {
        _serviceSub = Geolocator.getServiceStatusStream().listen((st) {
          _reportTracking(st == ServiceStatus.enabled, 'GPS was switched off on the phone');
        });
      } catch (_) {}
    }
    // a point every minute while standing still, so stops show on the route history with their times
    _heartbeat = Timer.periodic(const Duration(seconds: 60), (_) => _beat());
    if (_reportedOff) _reportTracking(true, '');
    unawaited(GpsTrail.instance.upload());
    return null;
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    await _serviceSub?.cancel();
    _serviceSub = null;
    _heartbeat?.cancel();
    _heartbeat = null;
    await _flushShiftKm();
    await GpsTrail.instance.upload();
    _tripId = null;
  }

  void _reportTracking(bool on, String reason) {
    if (on == !_reportedOff) return; // nothing changed
    _reportedOff = !on;
    if (!on) error = 'GPS is off. Turn on location so the office can follow the vehicle.';
    Outbox.instance.rpc('report_tracking', {'p_on': on, 'p_reason': reason}).catchError((_) {});
  }

  Future<void> _beat() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _reportTracking(false, 'GPS was switched off on the phone');
      return;
    }
    final perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _reportTracking(false, 'location permission was removed');
      return;
    }
    if (_reportedOff) _reportTracking(true, '');
    final here = _last;
    if (here != null && DateTime.now().difference(_lastPoint) > const Duration(seconds: 55)) {
      _lastPoint = DateTime.now();
      await GpsTrail.instance.add(here, 0, null, _tripId);
    }
    await GpsTrail.instance.upload();
  }

  /// The running trip (or null between trips). Resets the trip distance.
  void setTrip(String? tripId) {
    _tripId = tripId;
    _tripKm = 0;
    _lastSent = DateTime.fromMillisecondsSinceEpoch(0); // send the new state now
  }

  /// After an app restart in the middle of a trip: attach the running trip again.
  void setTripIfNone(String tripId) {
    if (_tripId == tripId) return;
    _tripId = tripId;
    _lastSent = DateTime.fromMillisecondsSinceEpoch(0);
  }

  /// Km driven since the last mileage photo, then starts counting again from zero.
  Future<double> takeSinceReading() async {
    final km = (_sinceReadingKm * 10).round() / 10;
    _sinceReadingKm = 0;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_sinceKey, 0);
    return km;
  }

  void _onPosition(Position pos) {
    final here = LatLng(pos.latitude, pos.longitude);
    final prev = _last;
    if (prev != null && pos.accuracy < 80) {
      final step = distanceKm(prev, here);
      if (step < 2) {
        _tripKm += step;
        _sinceReadingKm += step;
        _unsentShiftKm += step;
      }
    }
    _last = here;
    _lastPoint = DateTime.now();
    unawaited(GpsTrail.instance.add(here, pos.speed, pos.accuracy, _tripId));
    position.value = here;
    speedKmh.value = pos.speed.isFinite && pos.speed > 0 ? pos.speed * 3.6 : 0;
    final now = DateTime.now();
    if (now.difference(_lastSent) >= _sendEvery) {
      _lastSent = now;
      _send(here, pos.speed);
    }
  }

  Future<void> _send(LatLng here, double speed) async {
    final me = appState.profile;
    final truck = appState.truck;
    if (me == null || truck == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_sinceKey, _sinceReadingKm);
    try {
      await Outbox.instance.upsert('truck_locations', {
        'truck_id': truck.id,
        'driver_id': me.id,
        'trip_id': _tripId,
        'lat': here.latitude,
        'lng': here.longitude,
        'speed': speed.isFinite ? speed : 0,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
      await _flushShiftKm();
    } catch (e) {
      debugPrint('position not sent: $e');
    }
  }

  Future<void> _flushShiftKm() async {
    if (_unsentShiftKm < 0.05) return;
    final km = (_unsentShiftKm * 10).round() / 10;
    _unsentShiftKm = 0;
    try {
      await Outbox.instance.rpc('add_gps_km', {'p_km': km});
    } catch (_) {}
  }

  /// Tells the server the truck is free (no trip) at its current place.
  Future<void> sendNow() async {
    final here = position.value;
    if (here != null) await _send(here, 0);
  }
}

/// Pickup point name for the current position, falling back to "Here".
Future<String> placeHere() async {
  final p = Tracking.instance.position.value ?? await currentPoint();
  if (p == null) return 'Here';
  return await reverseName(p) ?? 'Here';
}

/// The day's GPS points, kept on the phone until they are uploaded (works for days without signal).
class GpsTrail {
  GpsTrail._();
  static final instance = GpsTrail._();

  static const _key = 'gps_trail_v1';
  static const _max = 20000; // about 3 days of driving
  final List<Map<String, dynamic>> _buf = [];
  final waiting = ValueNotifier<int>(0);
  bool _loaded = false;
  bool _sending = false;
  int _unsaved = 0;

  Future<void> _load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final s in prefs.getStringList(_key) ?? <String>[]) {
        _buf.add(Map<String, dynamic>.from(jsonDecode(s) as Map));
      }
    } catch (_) {}
    waiting.value = _buf.length;
  }

  Future<void> _save() async {
    _unsaved = 0;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, _buf.map(jsonEncode).toList());
    } catch (_) {}
  }

  Future<void> add(LatLng p, double speed, double? accuracy, String? tripId) async {
    await _load();
    _buf.add({
      'lat': double.parse(p.latitude.toStringAsFixed(6)),
      'lng': double.parse(p.longitude.toStringAsFixed(6)),
      'speed': speed.isFinite && speed > 0 ? double.parse(speed.toStringAsFixed(1)) : 0,
      if (accuracy != null && accuracy.isFinite) 'acc': accuracy.round(),
      'at': DateTime.now().toUtc().toIso8601String(),
      if (tripId != null) 'trip': tripId,
    });
    if (_buf.length > _max) _buf.removeRange(0, _buf.length - _max);
    waiting.value = _buf.length;
    if (++_unsaved >= 6) await _save(); // write to the phone about once a minute
  }

  /// Sends the saved points in batches of 300. Stops quietly when there is no signal.
  Future<void> upload() async {
    await _load();
    if (_sending || _buf.isEmpty || db.auth.currentUser == null) return;
    _sending = true;
    try {
      while (_buf.isNotEmpty) {
        final batch = _buf.take(300).toList();
        await db.rpc('upload_gps', params: {'p_points': batch});
        _buf.removeRange(0, batch.length);
        waiting.value = _buf.length;
      }
    } catch (e) {
      debugPrint('gps trail kept on the phone: $e');
    } finally {
      _sending = false;
      await _save();
    }
  }
}
