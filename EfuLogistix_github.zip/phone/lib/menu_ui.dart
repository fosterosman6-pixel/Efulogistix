import 'package:flutter/material.dart';

import 'app_state.dart';
import 'capture.dart';
import 'i18n.dart';
import 'icon_art.dart';
import 'screens/legal.dart';
import 'screens/support/support_screens.dart';
import 'theme.dart';
import 'widgets.dart';

/// Account page building blocks: a bold group heading, rows with an icon, a label and a chevron, and a log-out row.
class MenuHeading extends StatelessWidget {
  const MenuHeading(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 6),
        child: Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.ink)),
      );
}

class MenuRow extends StatelessWidget {
  const MenuRow({super.key, required this.icon, this.art, required this.title, this.subtitle, this.badge, required this.onTap});
  final IconData icon;
  final String? art; // name of a picture in assets/icons, used instead of the plain icon when given
  final String title;
  final String? subtitle;
  final String? badge; // small pill on the right, e.g. a balance or a count
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
          child: Row(children: [
            art == null ? Icon(icon, color: AppColors.navy, size: 26) : IconArt(art!, size: 32, fallback: icon),
            const SizedBox(width: 18),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                if (subtitle != null) Text(subtitle!, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            if (badge != null)
              Container(
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: AppColors.surface100, borderRadius: BorderRadius.circular(16)),
                child: Text(badge!, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            const Icon(Icons.chevron_right, color: AppColors.muted),
          ]),
        ),
      );
}

const menuDivider = Divider(height: 24, indent: 20, endIndent: 20);

/// Log out, with a confirmation.
class LogoutRow extends StatelessWidget {
  const LogoutRow({super.key});

  @override
  Widget build(BuildContext context) => MenuRow(
        icon: Icons.logout,
        title: tx('Log out'),
        onTap: () async {
          final ok = await showDialog<bool>(
            context: context,
            builder: (c) => AlertDialog(
              title: Text(tx('Log out?')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tx('Cancel'))),
                TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tx('Log out'), style: const TextStyle(color: AppColors.danger))),
              ],
            ),
          );
          if (ok == true) {
            if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            appState.signOut();
          }
        },
      );
}

/// The "Support" group every role shares: help, privacy, terms and language.
class SupportGroup extends StatelessWidget {
  const SupportGroup({super.key});

  @override
  Widget build(BuildContext context) {
    void open(Widget s) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => s));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      MenuHeading(tx('Support')),
      MenuRow(art: 'headset', icon: Icons.help_outline, title: tx('Help & support'), onTap: () => open(const SupportHomeScreen())),
      MenuRow(art: 'shield', icon: Icons.shield_outlined, title: tx('Privacy policy'), onTap: () => open(const LegalScreen(kind: LegalKind.privacy))),
      MenuRow(art: 'doc', icon: Icons.description_outlined, title: tx('Terms and conditions'), onTap: () => open(const LegalScreen(kind: LegalKind.terms))),
      const Padding(padding: EdgeInsets.fromLTRB(20, 10, 20, 0), child: AppCard(child: LanguageSwitch())),
    ]);
  }
}
