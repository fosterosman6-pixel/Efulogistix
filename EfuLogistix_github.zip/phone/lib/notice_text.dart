import 'i18n.dart';

/// Messages written by the database are in English. When the app is in Chichewa
/// we match their known shapes and show the Chichewa version ($1, $2 ... are the
/// parts taken from the English text). Anything not matched stays as written.
/// Please have a Chichewa speaker check these before launch.
final List<(RegExp, String)> _rules = [
  (RegExp(r'^Your shift was closed by the office$'), 'Ofesi yatseka ntchito yanu'),
  (RegExp(r'^The shift from (.+) was still open\. Please end your shift each day\.$'), r'Ntchito ya pa $1 inali yotseguka. Chonde malizani ntchito tsiku lililonse.'),
  (RegExp(r'^Shift still open · (.+)$'), r'Ntchito idakali yotseguka · $1'),
  (RegExp(r'^(.+) started on (.+) and has not ended the shift\. End it with the mileage photos\.$'), r'$1 anayamba pa $2 ndipo sanamalize ntchito. Imalizeni ndi zithunzi za makilomita.'),
  (RegExp(r'^(.+) is approved$'), r'$1 yavomerezedwa'),
  (RegExp(r'^Your vehicle can go on the road\. The office will match a driver\.$'), 'Galimoto yanu ikhoza kuyamba ntchito. Ofesi ikupezerani woyendetsa.'),
  (RegExp(r'^(.+) needs changes$'), r'$1 ikufunika kukonza'),
  (RegExp(r'^Please check the details and photos and send again\.$'), 'Chonde onaninso zambiri ndi zithunzi, kenako mutumizenso.'),
  (RegExp(r'^Meet the owner of (.+)$'), r'Kumana ndi mwini wa $1'),
  (RegExp(r'^(.+) at (.+)\. Bring your licence and ID\.$'), r'$1 ku $2. Bweretsani laisensi ndi chizindikiro chanu.'),
  (RegExp(r'^Meet a driver for (.+)$'), r'Kumana ndi woyendetsa wa $1'),
  (RegExp(r'^You drive (.+) now$'), r'Tsopano mukuyendetsa $1'),
  (RegExp(r'^Start your shift from the app\. Hand in the money to the owner each day\.$'), 'Yambani ntchito mu pulogalamu. Perekani ndalama kwa mwini tsiku lililonse.'),
  (RegExp(r'^(.+) drives (.+)$'), r'$1 akuyendetsa $2'),
  (RegExp(r"^The driver hands in each day's money to you\. Confirm it in Cash\.$"), 'Woyendetsa adzakupatsani ndalama tsiku lililonse. Zitsimikizireni mu Cash.'),
  (RegExp(r'^Not matched with (.+)$'), r'Simunapatsidwe $1'),
  (RegExp(r'^You stay on the waiting list\. The office will find another vehicle\.$'), 'Mukhalabe pa mndandanda wodikira. Ofesi ikupezerani galimoto ina.'),
  (RegExp(r'^Office meeting cancelled$'), 'Msonkhano wa ku ofesi wathetsedwa'),
  (RegExp(r'^The office will contact you with a new time\.$'), 'Ofesi ikuimbirani ndi nthawi yatsopano.'),
  (RegExp(r'^Vehicle removed$'), 'Galimoto yachotsedwa'),
  (RegExp(r'^You are back on the waiting list\.$'), 'Mwabwerera pa mndandanda wodikira.'),
  (RegExp(r'^\+ K(.+) in your wallet$'), r'+ K$1 mu wallet yanu'),
  (RegExp(r'^Hand-in for (.+) confirmed\. Paid out on Monday\.$'), r'Ndalama za $1 zatsimikizidwa. Zidzalipidwa Lolemba.'),
  (RegExp(r'^Wallet paid · K(.+)$'), r'Wallet yalipidwa · K$1'),
  (RegExp(r'^K(.+) taken off: (.+)$'), r'K$1 yachotsedwa: $2'),
  (RegExp(r'^Thank you for your work this week\.$'), 'Zikomo chifukwa cha ntchito yanu mlungu uno.'),
  (RegExp(r'^Fee received · K(.+)$'), r'Malipiro alandiridwa · K$1'),
  (RegExp(r'^Thank you\.$'), 'Zikomo.'),
  (RegExp(r'^Booking #(\d+) cancelled$'), r'Kusungitsa #$1 kwathetsedwa'),
  (RegExp(r'^Booking #(\d+) not possible$'), r'Kusungitsa #$1 sikungatheke'),
  (RegExp(r'^Please call the office\.$'), 'Chonde imbirani ofesi.'),
  (RegExp(r'^Booking #(\d+) removed$'), r'Kusungitsa #$1 kwachotsedwa'),
  (RegExp(r'^Booking #(\d+) moved to another vehicle$'), r'Kusungitsa #$1 kwasamutsidwa ku galimoto ina'),
  (RegExp(r'^Booking #(\d+) · car assigned$'), r'Kusungitsa #$1 · galimoto yapatsidwa'),
  (RegExp(r'^(.*) · driver (.*)$'), r'$1 · woyendetsa $2'),
  (RegExp(r'^(.*) · new price K(.+)$'), r'$1 · mtengo watsopano K$2'),
  (RegExp(r'^New pickup · (.+)$'), r'Wokwera watsopano · $1'),
  (RegExp(r'^Missed booking #(\d+)$'), r'Kusungitsa #$1 sikunabwere'),
  (RegExp(r'^The car waited but you were not there\. Missed bookings are counted on your profile\.$'), 'Galimoto inadikira koma simunabwere. Kusungitsa kosabwera kumawerengedwa pa profile yanu.'),
  (RegExp(r'^Booking #(\d+) done$'), r'Kusungitsa #$1 kwatha'),
  (RegExp(r'^Delivered to (.+)\.$'), r'Katundu waperekedwa kwa $1.'),
  (RegExp(r'^Thank you for travelling with EfuLogistix\. Total K(.+)\.$'), r'Zikomo poyenda ndi EfuLogistix. Chiwerengero K$1.'),
  (RegExp(r'^URGENT safety report$'), 'Chidziwitso cha chitetezo CHOFULUMIRA'),
  (RegExp(r'^New support ticket$'), 'Uthenga watsopano wothandizira'),
  (RegExp(r'^Reply to your report #(\d+)$'), r'Yankho la lipoti lanu #$1'),
  (RegExp(r'^New message on ticket #(\d+)$'), r'Uthenga watsopano pa lipoti #$1'),
  (RegExp(r'^Report #(\d+) solved$'), r'Lipoti #$1 lathetsedwa'),
  (RegExp(r'^The office marked it solved\. Reply on the report if it is not\.$'), 'Ofesi yalemba kuti lathetsedwa. Yankhani pa lipoti ngati sizili choncho.'),
  (RegExp(r'^SOS: (.+)$'), r'SOS: $1'),
  (RegExp(r'^Breakdown: (.+)$'), r'Galimoto yaonongeka: $1'),
  (RegExp(r'^(.+) needs help\.$'), r'$1 akufuna thandizo.'),
  (RegExp(r'^(.*) Location: (.+)$'), r'$1 Malo: $2'),
  (RegExp(r'^Low rating: (\d) stars?$'), r'Nyenyezi zochepa: $1'),
  (RegExp(r'^(.+) on booking #(\d+)(.*)$'), r'$1 pa kusungitsa #$2$3'),
  (RegExp(r'^A seat is free$'), 'Pali mpando waulere'),
  (RegExp(r'^(\d+) seats? now free on (.+) \((.+)\)\. Open Book a seat before someone else does\.$'), r'Mipando $1 ilipo pa $2 ($3). Tsegulani Book a seat musanatenge wina.'),
  (RegExp(r'^Your invite worked$'), 'Kuitana kwanu kwagwira ntchito'),
  (RegExp(r'^(.+) joined with your code\.$'), r'$1 walowa ndi code yanu.'),
  (RegExp(r'^EXPIRED · (.+)$'), r'ATHA NTHAWI · $1'),
  (RegExp(r'^Renew soon · (.+)$'), r'Konzaninso posachedwa · $1'),
  (RegExp(r'^Driver paper · (.+)$'), r'Pepala la woyendetsa · $1'),
  (RegExp(r'^Service due · (.+)$'), r'Nthawi yokonza · $1'),
  (RegExp(r'^Fee overdue · (.+)$'), r'Malipiro adutsa nthawi · $1'),
  (RegExp(r'^K(.+) for (.+) is not paid\. Pay it to match new drivers to your vehicles\.$'), r'K$1 ya $2 sinalipidwe. Lipirani kuti mupatsidwe oyendetsa atsopano.'),
  (RegExp(r'^Today · (.+)$'), r'Lero · $1'),
];

String noticeText(String? s) {
  if (s == null || language.value != 'ny') return s ?? '';
  for (final (re, out) in _rules) {
    final m = re.firstMatch(s);
    if (m == null) continue;
    return out.replaceAllMapped(RegExp(r'\$(\d)'), (x) {
      final i = int.parse(x.group(1)!);
      return i <= m.groupCount ? (m.group(i) ?? '') : '';
    });
  }
  return s;
}
