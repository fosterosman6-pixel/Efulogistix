/// Paste your Supabase details here (Supabase > Project Settings > API).
/// You can also pass them when running:
///   flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co --dart-define=SUPABASE_ANON_KEY=xxx
class Config {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://zqrjzruhvrpmdtbhlxsn.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_ZTIMa7ImwHZzmrqxCGxoxQ_vb27ts9m',
  );

  static bool get isConfigured =>
      supabaseUrl.startsWith('https://') &&
      !supabaseAnonKey.contains('YOUR-ANON') &&
      supabaseAnonKey.length > 20;

  /// Sent with OpenStreetMap requests, as their usage policy asks.
  static const userAgent = 'mw.efulogistix.fleet';
}
