import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_state.dart';
import 'demo/demo.dart';

const _bucket = 'photos';
final _picker = ImagePicker();

/// A picture taken in the app, uploaded to private storage.
class Photo {
  final Uint8List bytes;
  final String path; // storage path, e.g. "<user id>/odo_1729437000000.jpg"
  Photo(this.bytes, this.path);
}

/// Opens the camera (or the gallery when [allowGallery]) and uploads the picture.
/// Returns null if the person cancelled. Throws if the upload fails.
Future<Photo?> takePhoto(String label, {bool allowGallery = false, bool front = false}) async {
  final file = await _picker.pickImage(
    source: allowGallery ? ImageSource.gallery : ImageSource.camera,
    preferredCameraDevice: front ? CameraDevice.front : CameraDevice.rear,
    maxWidth: 1600,
    imageQuality: 65,
  );
  if (file == null) return null;
  final bytes = await file.readAsBytes();
  final uid = db.auth.currentUser?.id;
  if (uid == null) throw Exception('not signed in');
  final path = '$uid/${label}_${DateTime.now().millisecondsSinceEpoch}.jpg';
  await db.storage.from(_bucket).uploadBinary(
        path,
        bytes,
        fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: false),
      );
  if (Demo.on) Demo.photos[path] = bytes;
  return Photo(bytes, path);
}

final Map<String, String> _urlCache = {};

/// A short-lived link to view a stored photo (managers and the owner of the photo can open it).
Future<String?> photoUrl(String? path) async {
  if (path == null || path.isEmpty || Demo.on) return null;
  final cached = _urlCache[path];
  if (cached != null) return cached;
  try {
    final url = await db.storage.from(_bucket).createSignedUrl(path, 60 * 60);
    _urlCache[path] = url;
    return url;
  } catch (_) {
    return null;
  }
}
