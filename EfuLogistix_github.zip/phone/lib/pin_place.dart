import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:latlong2/latlong.dart' hide Path;

import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_state.dart';
import 'geo.dart';
import 'i18n.dart';
import 'theme.dart';
import 'widgets.dart';

/// Tap the map to drop a pin, name it, and use that exact spot as a place.
class PinPlaceScreen extends StatefulWidget {
  final LatLng? start;
  const PinPlaceScreen({super.key, this.start});

  @override
  State<PinPlaceScreen> createState() => _PinPlaceScreenState();
}

class _PinPlaceScreenState extends State<PinPlaceScreen> {
  LatLng? _pin;
  final _name = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final centre = widget.start ?? LatLng(-14.4782, 35.2645);
    return Scaffold(
      appBar: AppBar(title: Text(tx('Choose on the map')), backgroundColor: AppColors.navy, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(
          child: g.GoogleMap(
            initialCameraPosition: g.CameraPosition(target: g.LatLng(centre.latitude, centre.longitude), zoom: 14),
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
            onTap: (p) => setState(() => _pin = LatLng(p.latitude, p.longitude)),
            markers: {
              if (_pin != null) g.Marker(markerId: const g.MarkerId('pin'), position: g.LatLng(_pin!.latitude, _pin!.longitude)),
            },
          ),
        ),
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(_pin == null ? tx('Tap the map where you want to be picked up or dropped.') : tx('Pin dropped. Name it, then tap Use this place.'),
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              if (_pin != null) ...[
                const SizedBox(height: 8),
                TextField(controller: _name, decoration: InputDecoration(labelText: tx('Name (e.g. my house, Chitundu shop)'), border: const OutlineInputBorder(), isDense: true)),
              ],
              const SizedBox(height: 10),
              AppButton(tx('Use this place'),
                  height: 46,
                  onPressed: _pin == null
                      ? null
                      : () => Navigator.pop(
                          context, Place(_name.text.trim().isEmpty ? tx('Pinned place') : _name.text.trim(), tx('Pinned on the map'), _pin!)),),
            ]),
          ),
        ),
      ]),
    );
  }
}


/// A passenger named a spot on the map: send it quietly to the office as a suggestion (the admin approves it into Places).
/// Unnamed pins are ignored. Any failure is ignored too: the booking carries on either way.
Future<void> suggestPinnedPlace(Place p) async {
  final me = appState.profile;
  final name = p.name.trim();
  if (me == null || name.isEmpty || name == tx('Pinned place') || name.length < 3) return;
  try {
    await Supabase.instance.client.from('place_suggestions').insert({
      'name': name,
      'detail': 'Suggested by a passenger',
      'lat': p.point.latitude,
      'lng': p.point.longitude,
      'suggested_by': me.id,
    });
  } catch (_) {}
}
