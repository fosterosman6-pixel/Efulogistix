import 'geo.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'demo/demo.dart';
import 'push.dart';
import 'i18n.dart';
import 'models.dart';

SupabaseClient get db => Supabase.instance.client;

final navigatorKey = GlobalKey<NavigatorState>();

/// Where the next trip starts (set when a driver taps "New trip from ...").
class PickupPrefill {
  final String name;
  final LatLng point;
  PickupPrefill(this.name, this.point);
}

/// Login session, the signed-in person's profile and their truck.
class AppState extends ChangeNotifier {
  Session? session;
  Profile? profile;
  Truck? truck;
  VehicleCategory? category; // category of the driver's vehicle
  bool loading = true;
  bool profileLoaded = false;
  String? signInNotice; // shown on the login screen after a wrong-role sign-in
  final nextPickup = ValueNotifier<PickupPrefill?>(null);
  StreamSubscription<AuthState>? _sub;

  Future<void> start() async {
    final prefs = await SharedPreferences.getInstance();
    language.value = prefs.getString('language') ?? 'en';
    session = db.auth.currentSession;
    await loadProfile();
    if (session != null) loadSharedPlaces();
    loading = false;
    notifyListeners();
    _sub = db.auth.onAuthStateChange.listen((data) async {
      final changed = data.session?.user.id != session?.user.id;
      session = data.session;
      if (changed) {
        profileLoaded = false;
        notifyListeners();
        await loadProfile();
        if (session != null) loadSharedPlaces();
      }
      notifyListeners();
    });
  }

  Future<void> loadProfile() async {
    final s = session;
    if (s == null) {
      profile = null;
      truck = null;
      category = null;
      profileLoaded = true;
      return;
    }
    try {
      final row = await db.from('profiles').select().eq('id', s.user.id).maybeSingle();
      profile = row == null ? null : Profile.fromMap(row);
      final truckId = profile?.truckId;
      if (truckId != null) {
        final t = await db.from('trucks').select().eq('id', truckId).maybeSingle();
        truck = t == null ? null : Truck.fromMap(t);
        final catId = truck?.categoryId;
        final c = catId == null ? null : await db.from('vehicle_categories').select().eq('id', catId).maybeSingle();
        category = c == null ? null : VehicleCategory.fromMap(c);
      } else {
        truck = null;
        category = null;
      }
    } catch (e) {
      debugPrint('profile load failed: $e');
    }
    profileLoaded = true;
  }

  Future<void> refresh() async {
    await loadProfile();
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    language.value = code;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', code);
    final me = profile;
    if (me != null) {
      try {
        await db.from('profiles').update({'language': code}).eq('id', me.id);
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> signOut({String? notice}) async {
    signInNotice = notice;
    navigatorKey.currentState?.popUntil((r) => r.isFirst);
    try {
      await Push.unregister();
      await db.auth.signOut();
    } finally {
      if (Demo.on) await Demo.disable(); // signing out also leaves demo mode
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    nextPickup.dispose();
    super.dispose();
  }
}

final appState = AppState();

/// Managers and the admin can change things; vehicle owners only look.
bool get canManage => appState.profile?.isManager ?? false;

/// Vehicle owners confirm the money their drivers hand in (managers do it for company vehicles).
bool get canConfirmCash => (appState.profile?.isVehicleOwner ?? false) || canManage;

/// Turns any error into a plain message (no database details shown to users).
String friendlyError(Object e) {
  final text = _friendly(e);
  // unknown problems: show a short reason so it can be reported and fixed
  if (text == 'Something went wrong. Please try again.') {
    final raw = (e is PostgrestException ? '${e.message} ${e.code ?? ''}' : e.toString()).replaceAll(RegExp(r'\s+'), ' ').trim();
    return '${tx(text)}\n(${raw.length > 110 ? raw.substring(0, 110) : raw})';
  }
  return tx(text);
}

String _friendly(Object e) {
  final msg = e is AuthException
      ? e.message
      : e is PostgrestException
          ? '${e.message} ${e.code ?? ''}'
          : e is StorageException
              ? 'storage ${e.message}'
              : e.toString();
  final m = msg.toLowerCase();
  if (m.contains('missing_documents')) {
    final list = msg.split('MISSING_DOCUMENTS:').last.split(' ').first.split(',');
    final names = list.map((k) => docNames[k.trim()] ?? k).where((s) => s.isNotEmpty).join(', ');
    return txf('Your documents are not approved yet: %s. Open My documents.', [names]);
  }
  if (m.contains('out_of_area')) return 'Pick-up and drop-off must both be in Malawi. Check the places.';
  if (m.contains('too_far')) return 'That trip is too long for one booking. Please call the office.';
  if (m.contains('km_too_high')) return 'That is a lot more km than was booked. Check the odometer, or call the office to settle a longer trip.';
  if (m.contains('code_required')) return 'The passenger must scan or type the ticket code to board.';
  if (m.contains('no_truck')) return 'You have no vehicle yet. The office will match you with one.';
  if (m.contains('full:')) {
    final left = int.tryParse(msg.split(RegExp('FULL:', caseSensitive: false)).last.split(' ').first.trim()) ?? 0;
    return left == 0 ? 'This departure is full. Pick another time.' : txf('Only %s seats are left on this departure.', ['$left']);
  }
  if (m.contains('no_ticket')) return 'No ticket like that for you today. Ask the passenger to open the ticket again.';
  if (m.contains('not_running')) return 'You can share a trip once a car is assigned.';
  if (m.contains('already_waiting')) return 'You are already on this waiting list.';
  if (m.contains('seats_available')) return 'There are seats free now. Go back and book them.';
  if (m.contains('already_rated')) return 'You already rated this trip.';
  if (m.contains('not_completed')) return 'You can rate a trip after it is finished.';
  if (m.contains('bad_stars')) return 'Choose 1 to 5 stars.';
  if (m.contains('bad_code')) return 'That code does not exist. Check it and try again.';
  if (m.contains('own_code')) return 'That is your own code. Give it to a friend.';
  if (m.contains('already_used')) return 'You already used an invite code.';
  if (m.contains('ticket_not_found')) return 'That report was not found.';
  if (m.contains('bad_reason')) return 'Choose what the report is about.';
  if (m.contains('too_many_bookings')) return 'You already have many open bookings. Cancel one or wait until a trip is done.';
  if (m.contains('reference_required')) return 'Type the mobile money reference from your SMS.';
  if (m.contains('no_account')) return 'You are not linked to a company account. Ask the office.';
  if (m.contains('no_departure')) return 'This departure does not run on that day.';
  if (m.contains('departed')) return 'This departure has already left. Pick a later time.';
  if (m.contains('in_the_past')) return 'Pick a time from now on.';
  if (m.contains('seats_required')) return 'Choose how many seats.';
  if (m.contains('goods_required')) return 'Add what you are sending.';
  if (m.contains('receiver_required')) return 'Type the receiver\'s name and phone.';
  if (m.contains('places_required')) return 'Choose where to pick you up and where to go.';
  if (m.contains('not_for_hire')) return 'This type of vehicle cannot be hired.';
  if (m.contains('unknown_goods')) return 'That item has no price yet. Ask the office.';
  if (m.contains('cannot_cancel')) return 'This booking can no longer be cancelled.';
  if (m.contains('wrong_code')) return 'Wrong code. Ask the receiver for the 4-digit code.';
  if (m.contains('nothing_to_pay')) return 'Nothing to pay: the wallet is empty.';
  if (m.contains('deduct_too_big')) return 'You cannot take off more than the wallet balance.';
  if (m.contains('no_driver')) return 'That vehicle has no driver yet.';
  if (m.contains('truck_not_approved')) return 'That vehicle is not approved yet.';
  if (m.contains('truck_in_use')) return 'That truck is already on duty with another driver.';
  if (m.contains('trip_running')) return 'End the running trip first.';
  if (m.contains('photo_required')) return 'Take the mileage photo (and the truck photos) first.';
  if (m.contains('already_decided')) return 'Someone already decided this.';
  if (m.contains('no_shift')) return 'You are not on duty.';
  if (m.contains('invalid login credentials')) return 'Wrong email or password.';
  if (m.contains('email not confirmed')) return 'Please confirm your email first, then sign in.';
  if (m.contains('already registered')) return 'This email already has an account. Sign in instead.';
  if (m.contains('trips_one_running_per_driver') || m.contains('duplicate key') || m.contains('23505')) {
    return 'This was already saved, or a trip is already running.';
  }
  if (m.contains('row-level security') || m.contains('permission') || m.contains('42501') || m.contains('not allowed') || m.contains('not_allowed')) {
    return 'You are not allowed to do that.';
  }
  if (m.contains('socket') ||
      m.contains('network') ||
      m.contains('failed host lookup') ||
      m.contains('clientexception') ||
      m.contains('timeout')) {
    return 'No internet connection. Check your data and try again.';
  }
  if (m.contains('storage')) return 'The photo could not be uploaded. Check your data and try again.';
  if (m.contains('password')) return 'Password must be at least 6 characters.';
  return 'Something went wrong. Please try again.';
}

/// Shows a short message at the bottom of the screen.
void toast(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}
