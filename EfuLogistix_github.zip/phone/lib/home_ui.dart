import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'here.dart';
import 'i18n.dart';
import 'widgets.dart';

import 'profile_header.dart';
import 'theme.dart';

/// Shared building blocks for the three home screens:
/// a navy hero, a body that overlaps it with rounded corners, big action
/// tiles and small "at a glance" tiles.

class HomeHero extends StatelessWidget {
  final String greeting;
  final String headline;
  final String? line; // replaces the location line in the profile header
  final List<Widget> actions;
  final Widget? below;
  const HomeHero({super.key, required this.greeting, required this.headline, this.line, this.actions = const [], this.below});

  @override
  Widget build(BuildContext context) => Container(
        color: AppColors.navy,
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 8, 40),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ProfileHeader(line: line, actions: actions),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(greeting, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
                  Text(headline, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  if (below != null) ...[const SizedBox(height: 12), below!],
                ]),
              ),
            ]),
          ),
        ),
      );
}

/// Body that slides up over the hero's bottom edge.
class HomeBody extends StatelessWidget {
  final List<Widget> children;
  const HomeBody({super.key, required this.children});

  @override
  Widget build(BuildContext context) => Transform.translate(
        offset: const Offset(0, -24),
        child: Container(
          decoration: const BoxDecoration(
            color: AppColors.surface100,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
        ),
      );
}

class HomeLabel extends StatelessWidget {
  final String text;
  const HomeLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 8, left: 2),
        child: Text(text.toUpperCase(),
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
      );
}

/// Big full-width tile: icon square, title, subtitle, chevron.
class ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool primary;
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap, this.primary = false});

  @override
  Widget build(BuildContext context) {
    final bg = primary ? AppColors.lime : AppColors.surface;
    final fg = primary ? AppColors.navy : AppColors.ink;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: primary ? 20 : 14),
            child: Row(children: [
              Container(
                width: primary ? 52 : 44,
                height: primary ? 52 : 44,
                decoration: BoxDecoration(
                    color: primary ? AppColors.navy : AppColors.lime100, borderRadius: BorderRadius.circular(14)),
                child: Icon(icon, color: primary ? AppColors.lime : AppColors.lime600, size: primary ? 28 : 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: TextStyle(fontSize: primary ? 20 : 17, fontWeight: FontWeight.w800, color: fg)),
                  Text(subtitle, style: TextStyle(fontSize: 13, color: primary ? AppColors.navy700 : AppColors.muted)),
                ]),
              ),
              Icon(Icons.chevron_right, color: primary ? AppColors.navy : AppColors.muted),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Small square-ish tile for two side by side.
class QuickTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const QuickTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(12)),
                child: Icon(icon, color: AppColors.lime600, size: 22),
              ),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ),
      );
}

/// "At a glance" number tile. Pass [onTap] to make it tappable.
class GlanceTile extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final bool highlight;
  const GlanceTile(
      {super.key, required this.value, required this.label, required this.icon, this.color = AppColors.navy, this.onTap, this.highlight = false});

  @override
  Widget build(BuildContext context) => Material(
        color: highlight ? AppColors.lime100 : AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(height: 8),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ),
              Text(label, maxLines: 2, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ),
      );
}

/// Lays tiles out two per row with equal heights.
class TileRow extends StatelessWidget {
  final List<Widget> tiles;
  const TileRow(this.tiles, {super.key});

  @override
  Widget build(BuildContext context) {
    final kids = <Widget>[];
    for (var i = 0; i < tiles.length; i++) {
      if (i > 0) kids.add(const SizedBox(width: 10));
      kids.add(Expanded(child: tiles[i]));
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: kids)),
    );
  }
}

/// Small Google map card for the home screen: the phone's own blue dot plus the
/// booked car ([car]) or numbered pickups ([stops]).
class HomeMap extends StatefulWidget {
  final MapTruck? car;
  final List<MapStop> stops;
  const HomeMap({super.key, this.car, this.stops = const []});

  @override
  State<HomeMap> createState() => _HomeMapState();
}

class _HomeMapState extends State<HomeMap> {
  g.GoogleMapController? _map;

  g.LatLng _g(LatLng p) => g.LatLng(p.latitude, p.longitude);

  Set<g.Marker> get _markers => {
        if (widget.car != null)
          g.Marker(
            markerId: g.MarkerId('car-${widget.car!.id}'),
            position: _g(widget.car!.point),
            infoWindow: g.InfoWindow(title: widget.car!.label),
            icon: g.BitmapDescriptor.defaultMarkerWithHue(g.BitmapDescriptor.hueGreen),
          ),
        for (final s in widget.stops)
          g.Marker(
            markerId: g.MarkerId('stop-${s.number}-${s.label}'),
            position: _g(s.point),
            infoWindow: g.InfoWindow(title: '${s.number}. ${s.label}'),
            icon: g.BitmapDescriptor.defaultMarkerWithHue(g.BitmapDescriptor.hueAzure),
          ),
      };

  /// Frames the person and everything on the map.
  void _fit(LatLng? me) {
    final map = _map;
    if (map == null) return;
    final pts = <LatLng>[
      if (me != null) me,
      if (widget.car != null) widget.car!.point,
      ...widget.stops.map((s) => s.point),
    ];
    if (pts.isEmpty) return;
    if (pts.length == 1) {
      map.animateCamera(g.CameraUpdate.newLatLngZoom(_g(pts.first), 14));
      return;
    }
    var south = pts.first.latitude, north = south, west = pts.first.longitude, east = west;
    for (final p in pts) {
      if (p.latitude < south) south = p.latitude;
      if (p.latitude > north) north = p.latitude;
      if (p.longitude < west) west = p.longitude;
      if (p.longitude > east) east = p.longitude;
    }
    map.animateCamera(g.CameraUpdate.newLatLngBounds(
        g.LatLngBounds(southwest: g.LatLng(south, west), northeast: g.LatLng(north, east)), 40));
  }

  @override
  void didUpdateWidget(covariant HomeMap old) {
    super.didUpdateWidget(old);
    WidgetsBinding.instance.addPostFrameCallback((_) => _fit(Here.instance.point.value));
  }

  @override
  void dispose() {
    _map?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<LatLng?>(
        valueListenable: Here.instance.point,
        builder: (context, me, _) {
          WidgetsBinding.instance.addPostFrameCallback((_) => _fit(me));
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(
                height: 180,
                child: Stack(children: [
                  g.GoogleMap(
                    initialCameraPosition: g.CameraPosition(target: _g(me ?? mangochi), zoom: 13),
                    onMapCreated: (c) {
                      _map = c;
                      _fit(me);
                    },
                    markers: _markers,
                    myLocationEnabled: me != null,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    mapToolbarEnabled: false,
                    compassEnabled: false,
                  ),
                  Positioned(
                    left: 10,
                    top: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(999)),
                      child: ValueListenableBuilder<String?>(
                        valueListenable: Here.instance.name,
                        builder: (context, name, _) => Text(
                          me == null ? tx('Finding your location…') : (name ?? tx('You are here')),
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
      );
}
