import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'icon_art.dart';
import 'here.dart';
import 'map_icons.dart';
import 'i18n.dart';
import 'widgets.dart';

import 'profile_header.dart';
import 'theme.dart';

/// Shared building blocks for the three home screens:
/// a navy hero, a body that overlaps it with rounded corners, big action
/// tiles and small "at a glance" tiles.

class HomeHero extends StatelessWidget {
  final String greeting;
  final String headline;
  final String? line; // replaces the location line in the profile header
  final List<Widget> actions;
  final Widget? below;
  const HomeHero({super.key, required this.greeting, required this.headline, this.line, this.actions = const [], this.below});

  @override
  Widget build(BuildContext context) => Container(
        color: AppColors.navy,
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 8, 40),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ProfileHeader(line: line, actions: actions),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(greeting, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
                  Text(headline, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  if (below != null) ...[const SizedBox(height: 12), below!],
                ]),
              ),
            ]),
          ),
        ),
      );
}

/// Body that slides up over the hero's bottom edge.
class HomeBody extends StatelessWidget {
  final List<Widget> children;
  const HomeBody({super.key, required this.children});

  @override
  Widget build(BuildContext context) => Transform.translate(
        offset: const Offset(0, -24),
        child: Container(
          decoration: const BoxDecoration(
            color: AppColors.surface100,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
        ),
      );
}

class HomeLabel extends StatelessWidget {
  final String text;
  const HomeLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 8, left: 2),
        child: Text(text.toUpperCase(),
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
      );
}

/// Big full-width tile: icon square, title, subtitle, chevron.
class ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool primary;
  final String? art;
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap, this.primary = false, this.art});

  @override
  Widget build(BuildContext context) {
    final bg = primary ? AppColors.lime : AppColors.surface;
    final fg = primary ? AppColors.navy : AppColors.ink;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: primary ? 20 : 14),
            child: Row(children: [
              Container(
                width: primary ? 52 : 44,
                height: primary ? 52 : 44,
                decoration: BoxDecoration(
                    color: art != null ? Colors.white : (primary ? AppColors.navy : AppColors.lime100), borderRadius: BorderRadius.circular(14)),
                child: art != null
                    ? Padding(padding: const EdgeInsets.all(6), child: IconArt(art!, size: primary ? 40 : 32, fallback: icon))
                    : Icon(icon, color: primary ? AppColors.lime : AppColors.lime600, size: primary ? 28 : 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: TextStyle(fontSize: primary ? 20 : 17, fontWeight: FontWeight.w800, color: fg)),
                  Text(subtitle, style: TextStyle(fontSize: 13, color: primary ? AppColors.navy700 : AppColors.muted)),
                ]),
              ),
              Icon(Icons.chevron_right, color: primary ? AppColors.navy : AppColors.muted),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Small square-ish tile for two side by side.
class QuickTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final String? art;
  const QuickTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap, this.art});

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: art != null ? 52 : 40,
                height: art != null ? 52 : 40,
                decoration: art != null ? null : BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(12)),
                child: art != null ? IconArt(art!, size: 52, fallback: icon) : Icon(icon, color: AppColors.lime600, size: 22),
              ),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ),
      );
}

/// "At a glance" number tile. Pass [onTap] to make it tappable.
class GlanceTile extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final bool highlight;
  final String? art;
  const GlanceTile(
      {super.key, required this.value, required this.label, required this.icon, this.color = AppColors.navy, this.onTap, this.highlight = false, this.art});

  @override
  Widget build(BuildContext context) => Material(
        color: highlight ? AppColors.lime100 : AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              art != null ? IconArt(art!, size: 36, fallback: icon) : Icon(icon, color: color, size: 20),
              const SizedBox(height: 8),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ),
              Text(label, maxLines: 2, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ),
      );
}

/// Lays tiles out two per row with equal heights.
class TileRow extends StatelessWidget {
  final List<Widget> tiles;
  const TileRow(this.tiles, {super.key});

  @override
  Widget build(BuildContext context) {
    final kids = <Widget>[];
    for (var i = 0; i < tiles.length; i++) {
      if (i > 0) kids.add(const SizedBox(width: 10));
      kids.add(Expanded(child: tiles[i]));
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: kids)),
    );
  }
}

/// Small Google map card for the home screen: the phone's own blue dot plus the
/// booked car ([car]) or numbered pickups ([stops]).
class HomeMap extends StatefulWidget {
  final MapTruck? car;
  final List<MapStop> stops;
  const HomeMap({super.key, this.car, this.stops = const []});

  @override
  State<HomeMap> createState() => _HomeMapState();
}

class _HomeMapState extends State<HomeMap> {
  g.GoogleMapController? _map;
  bool _framed = false; // framed once; after that the blue dot just moves

  @override
  void initState() {
    super.initState();
    Here.instance.startLive();
    _buildMarkers();
  }

  g.LatLng _g(LatLng p) => g.LatLng(p.latitude, p.longitude);

  void _openFull() => Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FullMapScreen(trucks: [if (widget.car != null) widget.car!], stops: widget.stops)));

  Set<g.Marker> _markers = {};
  int _gen = 0;

  Future<void> _buildMarkers() async {
    final gen = ++_gen;
    final out = <g.Marker>{};
    if (widget.car != null) {
      out.add(g.Marker(
        markerId: g.MarkerId('car-${widget.car!.id}'),
        position: _g(widget.car!.point),
        anchor: const Offset(0.5, 0.35),
        icon: await MapIcons.car(label: widget.car!.label, kind: widget.car!.kind),
      ));
    }
    for (final s in widget.stops) {
      out.add(g.Marker(
        markerId: g.MarkerId('stop-${s.number}-${s.label}'),
        position: _g(s.point),
        infoWindow: g.InfoWindow(title: '${s.number}. ${s.label}'),
        icon: await MapIcons.number(s.number, auto: s.auto),
      ));
    }
    if (mounted && gen == _gen) setState(() => _markers = out);
  }

  /// Frames the person and everything on the map.
  void _fit(LatLng? me) {
    final map = _map;
    if (map == null) return;
    final pts = <LatLng>[
      if (me != null && inMalawi(me)) me, // a position outside Malawi is a bad fix: never zoom out to it
      if (widget.car != null) widget.car!.point,
      ...widget.stops.map((s) => s.point),
    ];
    if (pts.isEmpty) return;
    if (pts.length == 1) {
      map.animateCamera(g.CameraUpdate.newLatLngZoom(_g(pts.first), 14));
      return;
    }
    var south = pts.first.latitude, north = south, west = pts.first.longitude, east = west;
    for (final p in pts) {
      if (p.latitude < south) south = p.latitude;
      if (p.latitude > north) north = p.latitude;
      if (p.longitude < west) west = p.longitude;
      if (p.longitude > east) east = p.longitude;
    }
    map.animateCamera(g.CameraUpdate.newLatLngBounds(
        g.LatLngBounds(southwest: g.LatLng(south, west), northeast: g.LatLng(north, east)), 40));
  }

  @override
  void didUpdateWidget(covariant HomeMap old) {
    super.didUpdateWidget(old);
    _buildMarkers();
    // Re-frame only when the pins change, so the map does not jump back every time the list refreshes.
    String key(HomeMap w) => '${w.car?.id}|${w.stops.map((e) => '${e.number}${e.point.latitude}').join(',')}';
    if (key(old) != key(widget)) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _fit(Here.instance.point.value));
    }
  }

  @override
  void dispose() {
    Here.instance.stopLive();
    _map?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<LatLng?>(
        valueListenable: Here.instance.point,
        builder: (context, me, _) {
          if (!_framed && me != null) {
            _framed = true;
            WidgetsBinding.instance.addPostFrameCallback((_) => _fit(me));
          }
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(
                height: 180,
                child: Stack(children: [
                  g.GoogleMap(
                    initialCameraPosition: g.CameraPosition(target: _g(me ?? mangochi), zoom: 13),
                    onMapCreated: (c) {
                      _map = c;
                      _fit(me);
                    },
                    markers: _markers,
                    myLocationEnabled: me != null,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    mapToolbarEnabled: false,
                    compassEnabled: false,
                    scrollGesturesEnabled: false,
                    zoomGesturesEnabled: false,
                    rotateGesturesEnabled: false,
                    tiltGesturesEnabled: false,
                    onTap: (_) => _openFull(),
                  ),
                  Positioned(
                    right: 8,
                    bottom: 8,
                    child: Material(
                      color: Colors.white,
                      shape: const CircleBorder(),
                      elevation: 2,
                      child: IconButton(
                        tooltip: tx('Centre on me'),
                        icon: const Icon(Icons.my_location, size: 20),
                        onPressed: () => _fit(Here.instance.point.value),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    top: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(999)),
                      child: ValueListenableBuilder<LatLng?>(
                        valueListenable: Here.instance.badFix,
                        builder: (context, bad, _) => ValueListenableBuilder<String?>(
                          valueListenable: Here.instance.name,
                          builder: (context, name, _) => Text(
                            me != null
                                ? (name ?? tx('You are here'))
                                : bad != null
                                    ? tx('Your phone says you are outside Malawi. Turn off VPN or mock location.')
                                    : tx('Finding your location…'),
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
      );
}

/// The map opened full screen (tap a small map on a home screen). Follows the phone live.
class FullMapScreen extends StatefulWidget {
  final List<MapTruck> trucks;
  final List<MapStop> stops;
  const FullMapScreen({super.key, this.trucks = const [], this.stops = const []});

  @override
  State<FullMapScreen> createState() => _FullMapScreenState();
}

class _FullMapScreenState extends State<FullMapScreen> {
  @override
  void initState() {
    super.initState();
    Here.instance.startLive();
  }

  @override
  void dispose() {
    Here.instance.stopLive();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.navy,
          foregroundColor: Colors.white,
          title: Text(tx('Map'), style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
        body: ValueListenableBuilder<LatLng?>(
          valueListenable: Here.instance.point,
          builder: (context, me, _) => FleetMap(me: me, trucks: widget.trucks, stops: widget.stops, topPadding: 60, bottomPadding: 20),
        ),
      );
}
