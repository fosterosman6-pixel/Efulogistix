import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_lock.dart';
import 'app_state.dart';
import 'config.dart';
import 'demo/demo.dart';
import 'i18n.dart';
import 'outbox.dart';
import 'push.dart';
import 'screens/driver/driver_home.dart';
import 'screens/login.dart';
import 'screens/passenger/passenger_home.dart';
import 'screens/owner/vehicle_owner_home.dart';
import 'screens/pending.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Config.isConfigured) {
    await Demo.load();
    await Supabase.initialize(
      url: Config.supabaseUrl,
      anonKey: Config.supabaseAnonKey,
      httpClient: Demo.httpClient, // sends to the built-in demo server while demo mode is on
    );
    await appState.start();
    await Outbox.instance.start();
    unawaited(Push.init()); // push notifications; skipped quietly if Firebase is not set up
  }
  // when the language changes every screen is rebuilt (keeps where you are)
  language.addListener(() {
    void rebuild(Element el) {
      el.markNeedsBuild();
      el.visitChildren(rebuild);
    }

    WidgetsBinding.instance.rootElement?.visitChildren(rebuild);
  });
  runApp(const EfuLogistixApp());
}

class EfuLogistixApp extends StatelessWidget {
  const EfuLogistixApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'EfuLogistix Fleet',
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        theme: buildTheme(),
        builder: (context, child) => AppLockGate(child: _DemoRibbon(child: child ?? const SizedBox.shrink())),
        home: Config.isConfigured ? const AuthGate() : const SetupNeeded(),
      );
}

/// Sends each person to the right screen: login, waiting, passenger, driver or vehicle owner.
/// Managers and the admin are sent to the web admin panel.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) {
          if (appState.loading) return const _Spinner();
          if (appState.session == null) return const LoginScreen();
          final p = appState.profile;
          if (!appState.profileLoaded) return const _Spinner();
          if (p == null || !p.active) return const PendingScreen();
          if (p.isManager) return const UseAdminPanel();
          if (p.isPassenger) return PassengerHome(key: ValueKey(p.id));
          if (p.isVehicleOwner) return VehicleOwnerHome(key: ValueKey(p.id));
          return DriverHome(key: ValueKey(p.id));
        },
      );
}

class _Spinner extends StatelessWidget {
  const _Spinner();

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.navy)));
}

class SetupNeeded extends StatelessWidget {
  const SetupNeeded({super.key});

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Setup needed', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.navy)),
                SizedBox(height: 8),
                Text('Add your Supabase URL and key in lib/config.dart, then run the app again. See README.md.',
                    textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      );
}

/// Shows a small "DEMO" label in the corner while demo mode is on.
class _DemoRibbon extends StatelessWidget {
  final Widget child;
  const _DemoRibbon({required this.child});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
        valueListenable: Demo.active,
        builder: (context, on, _) => on
            ? Banner(
                message: 'DEMO',
                location: BannerLocation.topEnd,
                color: AppColors.lime,
                textStyle: const TextStyle(color: AppColors.navy, fontSize: 10, fontWeight: FontWeight.w900),
                child: child,
              )
            : child,
      );
}

/// Managers and the admin work in the web admin panel (on a computer), not in the phone app.
class UseAdminPanel extends StatelessWidget {
  const UseAdminPanel({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.navy,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Icon(Icons.desktop_windows_outlined, color: AppColors.lime, size: 48),
                const SizedBox(height: 12),
                Text('Hi ${appState.profile?.firstName ?? ''}',
                    textAlign: TextAlign.center, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 15)),
                Text(tx('Use the admin panel'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(
                  'Managers and the admin work in the EfuLogistix admin panel on a computer: bookings, drivers and '
                  'matching, vehicles, cash, route history and settings. This phone app is for passengers, drivers and vehicle owners.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.onNavyMuted, fontSize: 14),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: AppColors.lime, foregroundColor: AppColors.navy, minimumSize: const Size.fromHeight(52)),
                  onPressed: () => appState.signOut(),
                  child: Text(tx('Sign out'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                ),
              ]),
            ),
          ),
        ),
      );
}
