import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import 'demo_server.dart';

/// Demo mode: the app talks to a small built-in server with sample Mangochi data instead of Supabase.
/// No account and no internet needed. Everything a demo user does is kept until the app is closed.
class Demo {
  Demo._();

  static const _prefKey = 'demo_mode';

  /// True while the app is in demo mode.
  static final active = ValueNotifier<bool>(false);
  static bool get on => active.value;

  /// The one http client Supabase uses; it sends to the demo server while demo mode is on.
  static final httpClient = _SwitchClient();

  static DemoServer? _server;
  static DemoServer get server => _server ??= DemoServer();

  /// Photos taken in demo mode, kept in memory so they can be shown again.
  static final Map<String, Uint8List> photos = {};

  /// Demo sign-in emails, one per role.
  static const emails = {
    'passenger': 'passenger@demo.efulogistix',
    'driver': 'driver@demo.efulogistix',
    'owner': 'owner@demo.efulogistix',
  };
  static const password = 'demo-demo';

  /// Call before Supabase.initialize, so a demo session left open is reopened in demo mode.
  static Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      active.value = prefs.getBool(_prefKey) ?? false;
    } catch (_) {}
  }

  static Future<void> enable() async {
    active.value = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_prefKey, true);
    } catch (_) {}
  }

  static Future<void> disable() async {
    active.value = false;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_prefKey, false);
    } catch (_) {}
  }
}

/// Sends Supabase requests to the demo server in demo mode, and to the internet otherwise.
/// Map tiles and place search always go to the internet.
class _SwitchClient extends http.BaseClient {
  final http.Client _real = http.Client();
  final String _host = Uri.parse(Config.supabaseUrl).host;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    if (Demo.on && request.url.host == _host) return Demo.server.handle(request);
    return _real.send(request);
  }

  @override
  void close() => _real.close();
}
