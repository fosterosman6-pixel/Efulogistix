part of 'demo_seed.dart';

/// Demo data for the v3 features: passengers and bookings, owner vehicles waiting for approval,
/// a driver waiting for a vehicle with an office meeting, wallets and EfuLogistix fees.
extension _SeedV3 on _Seed {
  static final pFatima = _id('b1'), pEsther = _id('b2'), pGraceP = _id('b3'), dJoseph = _id('d7');
  static final accPhiri = _id('f1'), tPending = _id('e7');

  void v3() {
    final st = t['app_settings']!.first;
    st['wallet_pct'] = 10;
    st['office_phone'] = '0888 120 455';
    st['office_place'] = 'EfuLogistix office, Mangochi Boma';
    st['max_open_bookings'] = 5;
    st['stop_min_seconds'] = 120;
    st['stop_speed_kmh'] = 5;

    const rates = {
      'Kabaza': [300, 1000, 2500, 9000, 100],
      'Taxi': [900, 5000, 7500, 27000, 300],
      'Matola': [1200, 15000, 15000, 55000, 500],
      'Minibus': [1100, 15000, 15000, 55000, 500],
      'Lorry': [2500, 40000, 25000, 90000, 1500],
    };
    for (final c in t['vehicle_categories']!) {
      final r = rates[c['name']] ?? [0, 0, 0, 0, 0];
      c['hire_per_km'] = r[0];
      c['hire_min'] = r[1];
      c['fee_weekly'] = r[2];
      c['fee_monthly'] = r[3];
      c['fee_per_trip'] = r[4];
    }

    const looks = {
      'MZ 4521': ['Toyota', 'white', 2014, 'monthly'],
      'BT 4410': ['Toyota', 'blue', 2009, 'monthly'],
      'BT 8812': ['Toyota', 'silver', 2012, 'weekly'],
      'LL 2290': ['Isuzu', 'white', 2011, 'per_trip'],
      'MZ 1190': ['Toyota', 'silver', 2010, 'weekly'],
      'MZ 3307': ['Nissan', 'red', 2008, 'per_trip'],
    };
    for (final tr in t['trucks']!) {
      final l = looks[tr['plate']];
      tr['status'] = 'approved';
      tr['make'] = l?[0];
      tr['colour'] = l?[1];
      tr['year'] = l?[2];
      tr['fee_plan'] = l?[3] ?? 'monthly';
      tr['photos'] = <String>[];
      tr['reviewed_at'] = tr['created_at'];
    }
    // a taxi the owner sent yesterday, waiting for the admin
    t['trucks']!.add({
      'id': tPending,
      'plate': 'MZ 5120',
      'model': 'Sienta',
      'make': 'Toyota',
      'colour': 'white',
      'year': 2016,
      'active': false,
      'status': 'pending',
      'category_id': _Seed.cTaxi,
      'owner_id': _Seed.pPhiri,
      'seats': 6,
      'current_km': null,
      'oil_interval_km': 5000,
      'last_oil_km': null,
      'photos': <String>[],
      'fee_plan': 'weekly',
      'submitted_at': iso(now.subtract(const Duration(days: 1))),
      'created_at': iso(now.subtract(const Duration(days: 1))),
    });
    for (final k in ['blue_book', 'insurance', 'cof']) {
      t['documents']!.add({
        'id': nid(),
        'driver_id': null,
        'truck_id': tPending,
        'kind': k,
        'front_path': null,
        'expires_on': k == 'blue_book' ? null : day(today.add(const Duration(days: 300))),
        'status': 'pending',
        'created_at': iso(now.subtract(const Duration(days: 1))),
      });
    }

    t['company_accounts'] = [
      {'id': accPhiri, 'name': 'Phiri Hardware', 'contact_name': 'Mr Phiri', 'phone': '0888 300 100', 'active': true},
    ];

    void person(String id, String name, String email, String phone, String role, {String? truck, String? account}) =>
        t['profiles']!.add({
          'id': id,
          'email': email,
          'full_name': name,
          'phone': phone,
          'role': role,
          'active': true,
          'truck_id': truck,
          'account_id': account,
          'no_shows': 0,
          'language': 'en',
          'next_of_kin_name': role == 'driver' ? 'Mary Tembo' : null,
          'next_of_kin_phone': role == 'driver' ? '0884 101 202' : null,
          'created_at': iso(today.subtract(const Duration(days: 20))),
        });
    person(pFatima, 'Fatima Banda', 'passenger@demo.efulogistix', '0999 456 120', 'passenger');
    person(pEsther, 'Esther Kumwenda', 'esther@demo.efulogistix', '0995 220 431', 'passenger');
    person(pGraceP, 'Grace Phiri', 'gphiri@demo.efulogistix', '0888 761 004', 'passenger', account: accPhiri);
    person(dJoseph, 'Joseph Tembo', 'joseph@demo.efulogistix', '0997 410 662', 'driver');
    for (final k in ['national_id', 'licence', 'selfie']) {
      t['documents']!.add({
        'id': nid(),
        'driver_id': dJoseph,
        'truck_id': null,
        'kind': k,
        'licence_class': k == 'licence' ? 'B' : null,
        'expires_on': k == 'licence' ? day(today.add(const Duration(days: 500))) : null,
        'status': 'approved',
        'created_at': iso(today.subtract(const Duration(days: 6))),
      });
    }
    final meet = DateTime(today.year, today.month, today.day + 1, 10);
    t['driver_matches'] = [
      {
        'id': nid(),
        'driver_id': dJoseph,
        'truck_id': tPending,
        'meet_at': iso(meet),
        'place': 'EfuLogistix office, Mangochi Boma',
        'status': 'invited',
        'note': 'Once the taxi is approved',
        'created_at': iso(now.subtract(const Duration(hours: 3))),
      }
    ];

    // timetable on the matola and minibus routes from the rank
    t['departures'] = [];
    for (final r in t['routes']!) {
      final cat = r['category_id'];
      if (r['from_name'] != _Seed.rank || (cat != _Seed.cMatola && cat != _Seed.cMinibus)) continue;
      final times = cat == _Seed.cMatola ? ['07:00:00', '10:00:00', '13:00:00', '16:00:00'] : ['06:30:00', '09:30:00', '12:30:00', '15:30:00'];
      for (final tm in times) {
        t['departures']!.add({
          'id': nid(),
          'route_id': r['id'],
          'leaves_at': tm,
          'days': [1, 2, 3, 4, 5, 6, 7],
          'seats': null,
          'active': true,
        });
      }
    }

    // bookings: the next matola to Monkey Bay that has not left yet
    final mb = t['routes']!.firstWhere((r) => r['category_id'] == _Seed.cMatola && r['to_name'] == 'Monkey Bay');
    final deps = t['departures']!.where((d) => d['route_id'] == mb['id']).toList();
    DateTime depAt(Map<String, dynamic> d, DateTime onDay) {
      final p = (d['leaves_at'] as String).split(':');
      return DateTime(onDay.year, onDay.month, onDay.day, int.parse(p[0]), int.parse(p[1]));
    }
    final upcoming = deps.where((d) => depAt(d, today).isAfter(now.add(const Duration(minutes: 20)))).firstOrNull;
    final travel = upcoming == null ? today.add(const Duration(days: 1)) : today;
    final dep = upcoming ?? deps[1];
    final leaves = depAt(dep, travel);
    var no = 2040;
    t['bookings'] = [];
    t['booking_codes'] = [];
    Map<String, dynamic> b(String? pax, String kind, String status, Map<String, dynamic> x) {
      final row = <String, dynamic>{
        'id': nid(),
        'booking_no': ++no,
        'passenger_id': pax,
        'kind': kind,
        'category_id': _Seed.cMatola,
        'route_id': mb['id'],
        'departure_id': dep['id'],
        'travel_on': day(travel),
        'pickup_at': iso(leaves),
        'seats': 0,
        'pickup_name': _Seed.rank,
        'pickup_lat': _Seed.rankLat,
        'pickup_lng': _Seed.rankLng,
        'dest_name': 'Monkey Bay',
        'dest_lat': mb['to_lat'],
        'dest_lng': mb['to_lng'],
        'goods': <Map<String, dynamic>>[],
        'price': 0,
        'pay_method': 'cash',
        'status': status,
        'truck_id': status == 'requested' ? null : _Seed.tMZ4521,
        'driver_id': status == 'requested' ? null : _Seed.dChikondi,
        'assigned_at': status == 'requested' ? null : iso(now.subtract(const Duration(minutes: 40))),
        'created_at': iso(now.subtract(const Duration(hours: 2))),
        ...x,
      };
      t['bookings']!.add(row);
      return row;
    }
    final fare = (mb['fare'] as num).toDouble();
    b(pFatima, 'seat', 'assigned', {'seats': 2, 'price': fare * 2, 'message': 'Be at the rank 10 minutes before'});
    b(pEsther, 'seat', 'assigned', {'seats': 3, 'price': fare * 3, 'pay_method': 'airtel_money', 'pay_reference': 'CI2610.8812'});
    b(pGraceP, 'seat', 'assigned', {
      'seats': 2,
      'price': fare * 2,
      'pay_method': 'account',
      'account_id': accPhiri,
      'pickup_name': 'Nkopola junction',
      'pickup_at': iso(leaves.add(const Duration(minutes: 20))),
    });
    final g = b(pFatima, 'goods', 'assigned', {
      'goods': [
        {'label': '50 kg bag of maize', 'qty': 4, 'price': 1500}
      ],
      'price': 6000,
      'receiver_name': 'Yohane Chirwa',
      'receiver_phone': '0884 220 913',
    });
    t['booking_codes']!.add({'booking_id': g['id'], 'code': '4827'});
    b(pFatima, 'hire', 'requested', {
      'category_id': _Seed.cTaxi,
      'route_id': null,
      'departure_id': null,
      'travel_on': null,
      'pickup_at': iso(DateTime(today.year, today.month, today.day, now.hour + 3)),
      'pickup_name': 'Chitundu',
      'pickup_lat': -14.468,
      'pickup_lng': 35.258,
      'dest_name': 'Nkopola Lodge',
      'dest_lat': -14.36,
      'dest_lng': 35.17,
      'trip_type': 'return',
      'km': 34,
      'rate_per_km': 900,
      'price': 30600,
      'pay_method': 'airtel_money',
      'pay_reference': 'CI2610.88',
    });
    b(pFatima, 'seat', 'completed', {
      'seats': 1,
      'price': fare,
      'final_price': fare,
      'pickup_name': 'Monkey Bay',
      'dest_name': _Seed.rank,
      'pickup_at': iso(at(2, 15, 0)),
      'travel_on': day(today.subtract(const Duration(days: 2))),
      'created_at': iso(at(3, 18, 0)),
    });

    t['notices'] = [
      {
        'id': nid(),
        'user_id': pFatima,
        'title': 'Booking #2041 · car assigned',
        'body': 'MZ 4521 · white Toyota Hilux · driver Chikondi Banda · 0991 234 567',
        'kind': 'booking',
        'read': false,
        'created_at': iso(now.subtract(const Duration(minutes: 40))),
      },
      {
        'id': nid(),
        'user_id': _Seed.dChikondi,
        'title': 'New pickups for the ${clock2(leaves)} to Monkey Bay',
        'body': '7 seats and 1 goods booking',
        'kind': 'booking',
        'read': false,
        'created_at': iso(now.subtract(const Duration(minutes: 40))),
      },
      {
        'id': nid(),
        'user_id': _Seed.pPhiri,
        'title': 'Meet a driver for MZ 5120',
        'body': 'Joseph Tembo · tomorrow 10:00 at the EfuLogistix office',
        'kind': 'match',
        'read': false,
        'created_at': iso(now.subtract(const Duration(hours: 3))),
      },
      {
        'id': nid(),
        'user_id': dJoseph,
        'title': 'Meet the owner of MZ 5120',
        'body': 'Tomorrow 10:00 at the EfuLogistix office, Mangochi Boma. Bring your licence and ID.',
        'kind': 'match',
        'read': false,
        'created_at': iso(now.subtract(const Duration(hours: 3))),
      },
    ];

    // wallets: 10% of every confirmed hand-in; last Monday's payout
    t['wallet_entries'] = [];
    final monday = today.subtract(Duration(days: today.weekday - 1));
    final owners = {for (final tr in t['trucks']!) tr['id']: tr['owner_id']};
    for (final h in t['hand_ins']!) {
      if (h['received'] == null) continue;
      final share = ((h['expected'] as num) * 0.10).roundToDouble();
      if (share <= 0) continue;
      t['wallet_entries']!.add({
        'id': nid(),
        'driver_id': h['driver_id'],
        'owner_id': owners[h['truck_id']],
        'hand_in_id': h['id'],
        'kind': 'earn',
        'amount': share,
        'day': h['day'],
        'note': '10% of K${(h['expected'] as num).round()}',
        'created_at': h['received_at'] ?? h['created_at'],
      });
    }
    final byDriver = <String, Map<String, dynamic>>{};
    for (final e in t['wallet_entries']!) {
      if (DateTime.parse(e['day'] as String).isBefore(monday)) {
        final k = '${e['driver_id']}|${e['owner_id']}';
        final x = byDriver.putIfAbsent(k, () => {'driver_id': e['driver_id'], 'owner_id': e['owner_id'], 'sum': 0.0});
        x['sum'] = (x['sum'] as double) + (e['amount'] as num).toDouble();
      }
    }
    for (final x in byDriver.values) {
      t['wallet_entries']!.add({
        'id': nid(),
        'driver_id': x['driver_id'],
        'owner_id': x['owner_id'],
        'kind': 'payout',
        'amount': -(x['sum'] as double),
        'day': day(monday),
        'method': 'airtel_money',
        'reference': 'CI${day(monday).replaceAll('-', '').substring(2)}.4471',
        'note': 'Paid out',
        'created_at': iso(monday.add(const Duration(hours: 9))),
      });
    }

    // EfuLogistix fee bills: last month for monthly vehicles, last week for weekly ones
    t['fee_bills'] = [];
    final lastMonth = DateTime(today.year, today.month - 1, 1);
    final lastMonthEnd = DateTime(today.year, today.month, 0);
    final lastWeek = monday.subtract(const Duration(days: 7));
    for (final tr in t['trucks']!) {
      if (tr['owner_id'] == null || tr['status'] != 'approved') continue;
      final c = t['vehicle_categories']!.firstWhere((x) => x['id'] == tr['category_id']);
      final plan = tr['fee_plan'] as String;
      final weekly = plan == 'weekly';
      final trips = plan == 'per_trip' ? 40 + rnd.nextInt(30) : 0;
      final amount = switch (plan) {
        'weekly' => c['fee_weekly'] as num,
        'per_trip' => (c['fee_per_trip'] as num) * trips,
        _ => c['fee_monthly'] as num,
      };
      t['fee_bills']!.add({
        'id': nid(),
        'truck_id': tr['id'],
        'owner_id': tr['owner_id'],
        'plan': plan,
        'period_start': day(weekly ? lastWeek : lastMonth),
        'period_end': day(weekly ? lastWeek.add(const Duration(days: 6)) : lastMonthEnd),
        'trips': trips,
        'amount': amount,
        'status': tr['plate'] == 'MZ 3307' ? 'due' : 'paid',
        'paid_at': tr['plate'] == 'MZ 3307' ? null : iso(monday),
        'created_at': iso(monday),
      });
    }
    t['gps_points'] = [];
  }

  String clock2(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}
