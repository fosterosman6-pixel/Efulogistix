import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

import 'demo_seed.dart';

part 'demo_server_v3.dart';

typedef Row = Map<String, dynamic>;

class DemoError implements Exception {
  final String message;
  DemoError(this.message);
}

/// A tiny in-memory stand-in for Supabase (database, sign-in and photo storage) used by demo mode.
/// It answers the same requests the real Supabase does, so every screen works unchanged.
class DemoServer {
  final Map<String, List<Row>> t = buildDemoSeed();
  final _rnd = Random();
  String? _uid; // who is calling (from the access token)

  // ------------------------------------------------------------------ entry point

  Future<http.StreamedResponse> handle(http.BaseRequest req) async {
    final bytes = await req.finalize().toBytes();
    final path = req.url.path;
    _uid = _uidFromAuth(req.headers['Authorization'] ?? req.headers['authorization']);
    try {
      if (path.startsWith('/auth/v1/')) return _auth(req, path.substring('/auth/v1/'.length), bytes);
      if (path.startsWith('/storage/v1/')) return _storage(req, path.substring('/storage/v1/'.length));
      if (path.startsWith('/rest/v1/')) return _rest(req, path.substring('/rest/v1/'.length), bytes);
      if (path.startsWith('/functions/v1/')) return _send(req, 200, {});
      return _send(req, 404, {'message': 'Not found in demo'});
    } on DemoError catch (e) {
      return _send(req, 400, {'message': e.message, 'code': 'P0001', 'details': null, 'hint': null});
    } catch (e) {
      return _send(req, 500, {'message': 'demo: $e', 'code': 'XX000', 'details': null, 'hint': null});
    }
  }

  http.StreamedResponse _send(http.BaseRequest req, int status, Object? body) {
    final data = body == null ? <int>[] : utf8.encode(jsonEncode(body));
    return http.StreamedResponse(
      Stream.value(data),
      status,
      contentLength: data.length,
      request: req,
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }

  // ------------------------------------------------------------------ sign-in

  String? _uidFromAuth(String? header) {
    if (header == null || !header.startsWith('Bearer ')) return null;
    final parts = header.substring(7).split('.');
    if (parts.length != 3) return null;
    try {
      final payload = jsonDecode(utf8.decode(base64Url.decode(base64Url.normalize(parts[1])))) as Map;
      return payload['sub'] as String?;
    } catch (_) {
      return null;
    }
  }

  String _b64(Object o) => base64Url.encode(utf8.encode(jsonEncode(o))).replaceAll('=', '');

  Row? _profileById(String? id) => t['profiles']!.where((p) => p['id'] == id).firstOrNull;

  Row _session(Row p) {
    final now = DateTime.now();
    final exp = now.add(const Duration(days: 30)).millisecondsSinceEpoch ~/ 1000;
    final token = '${_b64({'alg': 'HS256', 'typ': 'JWT'})}.${_b64({
          'sub': p['id'],
          'email': p['email'],
          'role': 'authenticated',
          'aud': 'authenticated',
          'iat': now.millisecondsSinceEpoch ~/ 1000,
          'exp': exp,
        })}.ZGVtbw';
    return {
      'access_token': token,
      'token_type': 'bearer',
      'expires_in': 30 * 24 * 3600,
      'expires_at': exp,
      'refresh_token': 'demo-${p['id']}',
      'user': _user(p),
    };
  }

  Row _user(Row p) {
    final created = DateTime.now().subtract(const Duration(days: 60)).toUtc().toIso8601String();
    return {
      'id': p['id'],
      'aud': 'authenticated',
      'role': 'authenticated',
      'email': p['email'],
      'phone': '',
      'email_confirmed_at': created,
      'confirmed_at': created,
      'last_sign_in_at': DateTime.now().toUtc().toIso8601String(),
      'app_metadata': {'provider': 'email', 'providers': ['email']},
      'user_metadata': {'full_name': p['full_name']},
      'identities': [],
      'created_at': created,
      'updated_at': created,
      'is_anonymous': false,
    };
  }

  http.StreamedResponse _auth(http.BaseRequest req, String path, List<int> bytes) {
    final body = bytes.isEmpty ? <String, dynamic>{} : (jsonDecode(utf8.decode(bytes)) as Map).cast<String, dynamic>();
    if (path == 'token') {
      final grant = req.url.queryParameters['grant_type'];
      Row? p;
      if (grant == 'password') {
        final email = (body['email'] ?? '').toString().toLowerCase();
        p = t['profiles']!.where((x) => (x['email'] ?? '').toString().toLowerCase() == email).firstOrNull;
      } else if (grant == 'refresh_token') {
        final rt = (body['refresh_token'] ?? '').toString();
        p = _profileById(rt.startsWith('demo-') ? rt.substring(5) : null);
      }
      if (p == null) {
        return _send(req, 400, {
          'code': 400,
          'error_code': 'invalid_credentials',
          'msg': 'Invalid login credentials',
          'error': 'invalid_grant',
          'error_description': 'Invalid login credentials',
        });
      }
      return _send(req, 200, _session(p));
    }
    if (path == 'logout') return _send(req, 204, null);
    if (path == 'user') {
      final p = _profileById(_uid);
      return p == null ? _send(req, 401, {'msg': 'not signed in', 'code': 401}) : _send(req, 200, _user(p));
    }
    if (path == 'signup') {
      return _send(req, 422, {'code': 422, 'msg': 'In the demo, use the Try demo button. No new accounts.'});
    }
    return _send(req, 200, {});
  }

  // ------------------------------------------------------------------ photos

  http.StreamedResponse _storage(http.BaseRequest req, String path) {
    if (path.startsWith('object/sign/')) return _send(req, 404, {'message': 'no internet photos in demo'});
    if (path.startsWith('object/')) {
      final key = path.substring('object/'.length);
      return _send(req, 200, {'Key': key, 'Id': _uuid()});
    }
    return _send(req, 200, {});
  }

  // ------------------------------------------------------------------ database

  static const _reserved = {'select', 'order', 'limit', 'offset', 'on_conflict', 'columns'};

  http.StreamedResponse _rest(http.BaseRequest req, String table, List<int> bytes) {
    final text = utf8.decode(bytes);
    if (table.startsWith('rpc/')) {
      final params = text.isEmpty ? <String, dynamic>{} : (jsonDecode(text) as Map).cast<String, dynamic>();
      final result = _rpc(table.substring(4), params);
      return _send(req, 200, result);
    }
    final rows = t.putIfAbsent(table, () => []);
    final q = req.url.queryParametersAll;
    bool match(Row r) {
      for (final e in q.entries) {
        if (_reserved.contains(e.key)) continue;
        for (final expr in e.value) {
          if (!_test(r[e.key], expr)) return false;
        }
      }
      return true;
    }

    final prefer = req.headers['Prefer'] ?? '';
    final wantRows = prefer.contains('return=representation');
    switch (req.method) {
      case 'GET':
      case 'HEAD': {
        var out = rows.where(match).where((r) => _visible(table, r)).toList();
        out = _order(out, q['order']?.join(','));
        final limit = int.tryParse(q['limit']?.first ?? '');
        if (limit != null && out.length > limit) out = out.sublist(0, limit);
        return _result(req, out, 200);
      }
      case 'POST': {
        final body = jsonDecode(text);
        final list = body is List ? body.cast<Map>() : [body as Map];
        final upsert = prefer.contains('resolution=');
        final out = <Row>[];
        for (final m in list) {
          final row = m.cast<String, dynamic>();
          if (upsert) {
            final key = q['on_conflict']?.first ?? (table == 'truck_locations' ? 'truck_id' : 'id');
            final existing = rows.where((r) => r[key] == row[key]).firstOrNull;
            if (existing != null) {
              existing.addAll(row);
              _afterChange(table, existing, insert: false);
              out.add(existing);
              continue;
            }
          }
          out.add(insert(table, row));
        }
        return wantRows ? _result(req, out, 201) : _send(req, 201, null);
      }
      case 'PATCH': {
        final values = (jsonDecode(text) as Map).cast<String, dynamic>();
        final hit = rows.where(match).toList();
        for (final r in hit) {
          r.addAll(values);
          _afterChange(table, r, insert: false);
        }
        return wantRows ? _result(req, hit, 200) : _send(req, 204, null);
      }
      case 'DELETE': {
        final hit = rows.where(match).toList();
        rows.removeWhere(hit.contains);
        return wantRows ? _result(req, hit, 200) : _send(req, 204, null);
      }
    }
    return _send(req, 405, {'message': 'method not allowed'});
  }

  http.StreamedResponse _result(http.BaseRequest req, List<Row> rows, int status) {
    final accept = req.headers['Accept'] ?? '';
    if (accept.contains('vnd.pgrst.object')) {
      if (rows.length == 1) return _send(req, status, rows.first);
      return _send(req, 406, {
        'code': 'PGRST116',
        'details': 'Results contain ${rows.length} rows, application/vnd.pgrst.object+json requires 1 row',
        'hint': null,
        'message': 'JSON object requested, multiple (or no) rows returned',
      });
    }
    return _send(req, status, rows);
  }

  /// What a vehicle owner may see: only their own vehicles (like the real database rules).
  bool _visible(String table, Row r) {
    final me = _profileById(_uid);
    if (me == null || me['role'] != 'owner') return true;
    final mine = t['trucks']!.where((x) => x['owner_id'] == me['id']).map((x) => x['id']).toSet();
    switch (table) {
      case 'trips':
      case 'truck_locations':
      case 'expenses':
      case 'shifts':
      case 'odometer_readings':
      case 'hand_ins':
      case 'alerts':
      case 'service_records':
        return mine.contains(r['truck_id']);
      case 'trip_stops':
        final trip = t['trips']!.where((x) => x['id'] == r['trip_id']).firstOrNull;
        return trip != null && mine.contains(trip['truck_id']);
      case 'truck_changes':
        return mine.contains(r['from_truck']) || mine.contains(r['to_truck']);
      case 'profiles':
        return r['id'] == me['id'] || mine.contains(r['truck_id']);
      case 'documents':
        if (r['truck_id'] != null) return mine.contains(r['truck_id']);
        final d = _profileById(r['driver_id'] as String?);
        return d != null && mine.contains(d['truck_id']);
    }
    return true;
  }

  // ------------------------------------------------------------------ filters and order

  bool _test(dynamic v, String expr) {
    var neg = false;
    if (expr.startsWith('not.')) {
      neg = true;
      expr = expr.substring(4);
    }
    final dot = expr.indexOf('.');
    if (dot < 0) return true;
    final op = expr.substring(0, dot);
    final arg = expr.substring(dot + 1);
    bool r;
    switch (op) {
      case 'eq':
        r = _eq(v, arg);
      case 'neq':
        r = v != null && !_eq(v, arg);
      case 'gt':
        r = _cmp(v, arg) > 0;
      case 'gte':
        r = _cmp(v, arg) >= 0;
      case 'lt':
        r = v != null && _cmp(v, arg) < 0;
      case 'lte':
        r = v != null && _cmp(v, arg) <= 0;
      case 'is':
        r = arg == 'null' ? v == null : '$v' == arg;
      case 'in':
        final inner = arg.replaceAll(RegExp(r'^\(|\)$'), '');
        r = inner.split(',').map((s) => s.trim().replaceAll('"', '')).any((s) => _eq(v, s));
      case 'like':
      case 'ilike':
        final pattern = RegExp('^${RegExp.escape(arg).replaceAll(r'\*', '.*').replaceAll('%', '.*')}\$',
            caseSensitive: op == 'like');
        r = v != null && pattern.hasMatch('$v');
      default:
        r = true;
    }
    return neg ? !r : r;
  }

  bool _eq(dynamic v, String arg) {
    if (v == null) return false;
    if (v is num) {
      final n = num.tryParse(arg);
      return n != null && n == v;
    }
    return '$v' == arg;
  }

  /// Compares a stored value with a filter value. Missing values sort first.
  int _cmp(dynamic v, String arg) {
    if (v == null) return -1;
    if (v is num) {
      final n = num.tryParse(arg);
      if (n != null) return v.compareTo(n);
    }
    return _norm('$v').compareTo(_norm(arg));
  }

  /// Dates are stored as UTC text; make "2026-10-24T05:00:00.000Z" and "+00:00" forms compare the same.
  String _norm(String s) {
    final d = DateTime.tryParse(s);
    if (d != null && s.length > 10) return d.toUtc().toIso8601String();
    return s;
  }

  List<Row> _order(List<Row> rows, String? order) {
    if (order == null || order.isEmpty) return rows;
    final keys = order.split(',').map((o) => o.split('.')).toList();
    final out = [...rows];
    out.sort((a, b) {
      for (final k in keys) {
        final col = k[0];
        final desc = k.length > 1 && k[1] == 'desc';
        final nullsFirst = k.length > 2 && k[2] == 'nullsfirst';
        final x = a[col], y = b[col];
        if (x == null && y == null) continue;
        if (x == null) return nullsFirst ? -1 : 1;
        if (y == null) return nullsFirst ? 1 : -1;
        int c;
        if (x is num && y is num) {
          c = x.compareTo(y);
        } else {
          c = _norm('$x').compareTo(_norm('$y'));
        }
        if (c != 0) return desc ? -c : c;
      }
      return 0;
    });
    return out;
  }

  // ------------------------------------------------------------------ writes with the database's own rules

  String _uuid() {
    String h(int n) => List.generate(n, (_) => _rnd.nextInt(16).toRadixString(16)).join();
    return '${h(8)}-${h(4)}-4${h(3)}-${(8 + _rnd.nextInt(4)).toRadixString(16)}${h(3)}-${h(12)}';
  }

  String get _now => DateTime.now().toUtc().toIso8601String();
  String get _today {
    final d = DateTime.now();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  Row insert(String table, Row row) {
    final r = <String, dynamic>{...row};
    if (table != 'truck_locations') r['id'] ??= _uuid();
    r['created_at'] ??= _now;
    switch (table) {
      case 'trips':
        final maxNo = t['trips']!.fold<int>(0, (m, x) => max(m, (x['trip_no'] as num?)?.toInt() ?? 0));
        r['trip_no'] ??= maxNo + 1;
        r['status'] ??= 'in_progress';
        r['started_at'] ??= _now;
        r['stops_total'] ??= 0;
        r['goods'] ??= [];
        r['goods_total'] ??= 0;
        r['passengers'] ??= 0;
        r['fare_per_passenger'] ??= 0;
      case 'trip_stops':
        r['at'] ??= _now;
        r['auto'] ??= false;
        r['goods_on'] ??= [];
        r['goods_total'] ??= 0;
        r['dropped'] ??= 0;
        r['picked'] ??= 0;
        r['fare_each'] ??= 0;
      case 'expenses':
        r['spent_at'] ??= _now;
        r['created_by'] ??= _uid;
        r['paid_by'] ??= (_profileById(_uid)?['role'] == 'driver' ? 'driver' : 'office');
      case 'truck_locations':
        r['updated_at'] = _now;
      case 'documents':
        r['status'] ??= 'pending';
      case 'truck_changes':
        r['driver_id'] ??= _uid;
        r['status'] ??= 'pending';
        r['in_truck_photos'] ??= [];
      case 'service_records':
        r['done_on'] ??= _today;
        r['created_by'] ??= _uid;
        r['cost'] ??= 0;
      case 'trucks':
        if (_profileById(_uid)?['role'] == 'owner') {
          r['owner_id'] = _uid;
          r['status'] = 'pending';
          r['active'] = false;
          r['submitted_at'] = _now;
        }
        r['status'] ??= 'approved';
        r['photos'] ??= <String>[];
        r['fee_plan'] ??= 'monthly';
        r['oil_interval_km'] ??= 5000;
      case 'notices':
        r['read'] ??= false;
      case 'wallet_entries':
        r['created_by'] ??= _uid;
      case 'alerts':
        r['seen'] ??= false;
        r['resolved'] ??= false;
        r['day'] ??= _today;
    }
    t.putIfAbsent(table, () => []).add(r);
    _afterChange(table, r, insert: true);
    return r;
  }

  void _afterChange(String table, Row r, {required bool insert}) {
    switch (table) {
      case 'trips':
        _retotal(r);
      case 'trip_stops':
        r['amount'] = _n(r['picked']) * _n(r['fare_each']) + _n(r['goods_total']);
        final trip = _byId('trips', r['trip_id']);
        if (trip != null) _retotal(trip);
      case 'truck_locations':
        r['updated_at'] = _now;
      case 'hand_ins':
        r['expected'] = _n(r['collected']) - _n(r['driver_expenses']);
      case 'service_records':
        if (insert && r['kind'] == 'oil') {
          final truck = _byId('trucks', r['truck_id']);
          if (truck != null) {
            truck['last_oil_km'] = r['km'] ?? truck['current_km'];
            truck['last_oil_on'] = r['done_on'];
          }
        }
      case 'truck_changes':
        if (insert) {
          final who = _profileById(r['driver_id'] as String?)?['full_name'] ?? 'Driver';
          final from = _byId('trucks', r['from_truck'])?['plate'] ?? '';
          final to = _byId('trucks', r['to_truck'])?['plate'] ?? '';
          this.insert('alerts', {
            'kind': 'truck_change',
            'truck_id': r['from_truck'],
            'driver_id': r['driver_id'],
            'ref_id': r['id'],
            'title': 'Truck change · ${who.toString().split(' ').first}',
            'detail': '$from → $to · ${r['reason']}',
          });
        }
    }
  }

  void _retotal(Row trip) {
    final stops = t['trip_stops']!.where((s) => s['trip_id'] == trip['id']).toList();
    final stopsTotal = stops.fold<double>(0, (s, x) => s + _n(x['amount']));
    final picked = stops.fold<int>(0, (s, x) => s + _n(x['picked']).round());
    trip['stops_total'] = stopsTotal;
    if (stops.isNotEmpty) trip['pax_carried'] = _n(trip['passengers']).round() + picked;
    trip['total'] = _n(trip['passengers']) * _n(trip['fare_per_passenger']) + _n(trip['goods_total']) + stopsTotal;
  }

  double _n(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}') ?? 0;

  Row? _byId(String table, dynamic id) => t[table]?.where((x) => x['id'] == id).firstOrNull;

  Row? _openShift(String? driverId) =>
      t['shifts']!.where((s) => s['driver_id'] == driverId && s['status'] == 'on_duty').firstOrNull;

  Row _reading(Row shift, String? tripId, String kind, num km, String? photo, num? gpsSince) {
    final last = t['odometer_readings']!
        .where((x) => x['shift_id'] == shift['id'])
        .fold<Row?>(null, (a, b) => a == null || '${b['taken_at']}'.compareTo('${a['taken_at']}') > 0 ? b : a);
    int? expected;
    var mismatch = false;
    if (last != null && gpsSince != null) {
      expected = (_n(last['km']) + gpsSince).round();
      mismatch = gpsSince > 0 && (km - expected).abs() > 3;
    }
    final truck = _byId('trucks', shift['truck_id']);
    if (truck != null) truck['current_km'] = km;
    return insert('odometer_readings', {
      'shift_id': shift['id'],
      'trip_id': tripId,
      'driver_id': shift['driver_id'],
      'truck_id': shift['truck_id'],
      'kind': kind,
      'km': km,
      'photo_path': photo,
      'gps_since_last_km': gpsSince,
      'expected_km': expected,
      'mismatch': mismatch,
      'taken_at': _now,
    });
  }

  Map<String, dynamic> _totals(String shiftId) {
    final trips = t['trips']!.where((x) => x['shift_id'] == shiftId && x['status'] == 'completed').toList();
    final exp = t['expenses']!.where((x) => x['shift_id'] == shiftId && x['paid_by'] == 'driver');
    return {
      'trips': trips.length,
      'passengers': trips.fold<int>(0, (s, x) => s + _n(x['pax_carried'] ?? x['passengers']).round()),
      'collected': trips.fold<double>(0, (s, x) => s + _n(x['total'])),
      'driver_expenses': exp.fold<double>(0, (s, x) => s + _n(x['amount'])),
    };
  }

  // ------------------------------------------------------------------ database functions (rpc)

  Object? _rpc(String fn, Map<String, dynamic> p) {
    final me = _profileById(_uid);
    switch (fn) {
      case 'missing_documents': {
        return _missing(p['p_driver'] as String? ?? _uid);
      }
      case 'run_checks': {
        return null;
      }
      case 'start_shift': {
        if (me == null) throw DemoError('not signed in');
        final missing = _missing(me['id'] as String);
        if (missing.isNotEmpty) throw DemoError('MISSING_DOCUMENTS:$missing');
        final truckId = me['truck_id'];
        if (truckId == null) throw DemoError('NO_TRUCK');
        final open = _openShift(me['id'] as String);
        if (open != null) return open['id'];
        if (t['shifts']!.any((s) => s['truck_id'] == truckId && s['status'] == 'on_duty')) {
          throw DemoError('TRUCK_IN_USE');
        }
        final shift = insert('shifts', {
          'driver_id': me['id'],
          'truck_id': truckId,
          'status': 'on_duty',
          'started_at': _now,
          'start_km': p['p_km'],
          'truck_photos': [],
          'start_truck_photos': p['p_truck_photos'] ?? [],
          'gps_km': 0,
          'review': 'open',
        });
        _reading(shift, null, 'shift_start', _n(p['p_km']), p['p_photo'] as String?, null);
        return shift['id'];
      }
      case 'record_trip_reading': {
        final trip = _byId('trips', p['p_trip']);
        if (trip == null) throw DemoError('trip not found');
        final shift = _byId('shifts', trip['shift_id']) ?? _openShift(trip['driver_id'] as String?);
        if (shift == null) throw DemoError('NO_SHIFT');
        _reading(shift, trip['id'] as String, p['p_kind'] as String, _n(p['p_km']), p['p_photo'] as String?,
            p['p_gps_since'] == null ? null : _n(p['p_gps_since']));
        if (p['p_kind'] == 'trip_start') trip['start_km'] = p['p_km'];
        if (p['p_kind'] == 'trip_end') trip['end_km'] = p['p_km'];
        return null;
      }
      case 'add_gps_km': {
        final shift = _openShift(_uid);
        if (shift != null) shift['gps_km'] = _n(shift['gps_km']) + _n(p['p_km']);
        return null;
      }
      case 'shift_totals': {
        return [_totals(p['p_shift'] as String)];
      }
      case 'end_shift': {
        final shift = _openShift(_uid);
        if (shift == null) throw DemoError('NO_SHIFT');
        if ((p['p_truck_photos'] as List?)?.length != 4) throw DemoError('PHOTO_REQUIRED');
        if (t['trips']!.any((x) => x['driver_id'] == _uid && x['status'] == 'in_progress')) {
          throw DemoError('TRIP_RUNNING');
        }
        _reading(shift, null, 'shift_end', _n(p['p_km']), p['p_photo'] as String?,
            p['p_gps_since'] == null ? null : _n(p['p_gps_since']));
        shift
          ..['status'] = 'off_duty'
          ..['ended_at'] = _now
          ..['end_km'] = p['p_km']
          ..['end_reason'] = 'end_of_day'
          ..['truck_photos'] = p['p_truck_photos'];
        final tot = _totals(shift['id'] as String);
        final h = insert('hand_ins', {
          'shift_id': shift['id'],
          'driver_id': shift['driver_id'],
          'truck_id': shift['truck_id'],
          'day': _today,
          ...tot,
          'method': p['p_method'] ?? 'cash',
          'reference': (p['p_reference'] as String?)?.isEmpty ?? true ? null : p['p_reference'],
        });
        return h['id'];
      }
      case 'receive_hand_in': {
        final h = _byId('hand_ins', p['p_id']);
        if (h == null) throw DemoError('not found');
        if (h['received'] != null) throw DemoError('ALREADY_DECIDED');
        h
          ..['received'] = _n(p['p_amount'])
          ..['received_by'] = _uid
          ..['received_at'] = _now
          ..['method'] = p['p_method'] ?? h['method']
          ..['reference'] = (p['p_reference'] as String?)?.isEmpty ?? true ? h['reference'] : p['p_reference']
          ..['note'] = (p['p_note'] as String?)?.isEmpty ?? true ? null : p['p_note'];
        final short = _n(h['expected']) - _n(h['received']);
        if (short > 0) {
          final who = _profileById(h['driver_id'] as String?)?['full_name'] ?? 'Driver';
          insert('alerts', {
            'kind': 'cash_short',
            'truck_id': h['truck_id'],
            'driver_id': h['driver_id'],
            'shift_id': h['shift_id'],
            'ref_id': h['id'],
            'title': 'Cash short K${short.round()}',
            'detail': '${who.toString().split(' ').first} handed in K${_n(h['received']).round()} of K${_n(h['expected']).round()}',
          });
        }
        _DemoV3(this).walletForHandIn(h);
        return null;
      }
      case 'decide_shortfall': {
        final h = _byId('hand_ins', p['p_id']);
        if (h == null) throw DemoError('not found');
        h['decision'] = p['p_decision'];
        for (final a in t['alerts']!.where((a) => a['kind'] == 'cash_short' && a['ref_id'] == h['id'])) {
          a['resolved'] = true;
        }
        return null;
      }
      case 'decide_truck_change': {
        final c = _byId('truck_changes', p['p_id']);
        if (c == null) throw DemoError('not found');
        if (c['status'] != 'pending') throw DemoError('ALREADY_DECIDED');
        final approve = p['p_approve'] == true;
        c
          ..['status'] = approve ? 'approved' : 'declined'
          ..['decided_by'] = _uid
          ..['decided_at'] = _now;
        for (final a in t['alerts']!.where((a) => a['kind'] == 'truck_change' && a['ref_id'] == c['id'])) {
          a['resolved'] = true;
          a['seen'] = true;
        }
        if (approve) {
          final old = _openShift(c['driver_id'] as String?);
          if (old != null) {
            _reading(old, null, 'change_out', _n(c['out_km']), c['out_photo'] as String?, null);
            old
              ..['status'] = 'off_duty'
              ..['ended_at'] = _now
              ..['end_km'] = c['out_km']
              ..['end_reason'] = 'truck_change';
          }
          final driver = _profileById(c['driver_id'] as String?);
          if (driver != null) driver['truck_id'] = c['to_truck'];
          final shift = insert('shifts', {
            'driver_id': c['driver_id'],
            'truck_id': c['to_truck'],
            'status': 'on_duty',
            'started_at': _now,
            'start_km': c['in_km'],
            'truck_photos': c['in_truck_photos'] ?? [],
            'gps_km': 0,
            'review': 'open',
          });
          _reading(shift, null, 'change_in', _n(c['in_km']), c['in_photo'] as String?, null);
        }
        return null;
      }
      case 'raise_fares': {
        final pct = _n(p['p_pct']);
        for (final r in t['routes']!) {
          r['fare'] = ((_n(r['fare']) * (1 + pct / 100)) / 500).ceil() * 500;
        }
        return null;
      }
    }
    final v3 = _DemoV3(this).rpcV3(fn, p, me);
    if (!identical(v3, _notV3)) return v3;
    throw DemoError('This action is not in the demo');
  }

  String _missing(String? driverId) {
    final d = _profileById(driverId);
    if (d == null) return '';
    final approved = t['documents']!
        .where((x) => x['driver_id'] == driverId && x['status'] == 'approved')
        .map((x) => x['kind'])
        .toSet();
    final out = [
      for (final k in ['national_id', 'licence', 'selfie'])
        if (!approved.contains(k)) k,
      if ((d['next_of_kin_name'] ?? '').toString().isEmpty) 'next_of_kin',
    ];
    return out.join(',');
  }
}
