import 'dart:math';

part 'demo_seed_v3.dart';

/// Sample data for demo mode: a small Mangochi fleet with two weeks of trips, today's shifts,
/// cash hand-ins, alerts and a truck change waiting for approval. Dates follow today's date.
Map<String, List<Map<String, dynamic>>> buildDemoSeed() => _Seed().build();

String _id(String tail) => '00000000-0000-4000-8000-${tail.padLeft(12, '0')}';

class _Seed {
  final rnd = Random(7);
  final now = DateTime.now();
  late final DateTime today = DateTime(now.year, now.month, now.day);
  int _n = 0;
  int _tripNo = 1000;

  final Map<String, List<Map<String, dynamic>>> t = {
    for (final k in [
      'vehicle_categories', 'trucks', 'profiles', 'documents', 'routes', 'goods_prices', 'shifts',
      'odometer_readings', 'trips', 'trip_stops', 'truck_locations', 'expenses', 'hand_ins', 'alerts',
      'truck_changes', 'service_records', 'app_settings', 'invites', 'activity_log',
    ])
      k: <Map<String, dynamic>>[],
  };

  String nid() => _id('9${(++_n).toString().padLeft(8, '0')}');
  String iso(DateTime d) => d.toUtc().toIso8601String();
  String day(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  DateTime at(int daysAgo, int h, int m) => today.subtract(Duration(days: daysAgo)).add(Duration(hours: h, minutes: m));

  // ids
  static final cMatola = _id('c1'), cMinibus = _id('c2'), cLorry = _id('c3'), cTaxi = _id('c4'), cKabaza = _id('c5');
  static final tMZ4521 = _id('e1'), tBT4410 = _id('e2'), tBT8812 = _id('e3'), tLL2290 = _id('e4'),
      tMZ1190 = _id('e5'), tMZ3307 = _id('e6');
  static final pManager = _id('a1'), pPhiri = _id('a2'), pChirwa = _id('a3');
  static final dChikondi = _id('d1'), dGrace = _id('d2'), dYusuf = _id('d3'), dMphatso = _id('d4'),
      dKondwani = _id('d5'), dMike = _id('d6');

  static const rank = 'Mangochi Main Rank';
  static const rankLat = -14.4782, rankLng = 35.2645;
  static const places = {
    'Monkey Bay': [-14.0833, 34.9167, 72.0],
    'Namwera': [-14.3667, 35.4833, 45.0],
    'Makanjira': [-13.7000, 35.5000, 110.0],
    'Mpondasi': [-14.461511, 35.243191, 4.0],
    'Nkopola': [-14.3600, 35.1700, 15.0],
    'Liwonde': [-15.0667, 35.2333, 68.0],
    'Blantyre': [-15.7861, 35.0058, 190.0],
    'Mangochi Boma': [-14.4780, 35.2640, 3.0],
  };

  Map<String, List<Map<String, dynamic>>> build() {
    _settings();
    _categories();
    _trucks();
    _people();
    _documents();
    _routes();
    _history();
    _todayFleet();
    _service();
    for (final k in ['company_accounts', 'departures', 'bookings', 'booking_codes', 'notices', 'driver_matches', 'wallet_entries', 'fee_bills', 'gps_points']) {
      t[k] = <Map<String, dynamic>>[];
    }
    _SeedV3(this).v3();
    return t;
  }

  void _settings() {
    t['app_settings']!.add({
      'id': 1,
      'speed_limit_kmh': 80,
      'long_stop_min': 30,
      'unrecorded_stop_min': 3,
      'mileage_tolerance_km': 3,
      'no_signal_min': 60,
      'require_prdp': false,
    });
  }

  void _categories() {
    void c(String id, String name, bool pax, bool goods, int seats, List<String> classes) =>
        t['vehicle_categories']!.add({
          'id': id,
          'name': name,
          'carries_passengers': pax,
          'carries_goods': goods,
          'seats': seats,
          'licence_classes': classes,
          'active': true,
        });
    c(cKabaza, 'Kabaza', true, true, 1, ['A', 'A1']);
    c(cLorry, 'Lorry', false, true, 0, ['C1', 'C', 'EC1', 'EC']);
    c(cMatola, 'Matola', true, true, 16, ['B', 'C1', 'C', 'EB', 'EC1', 'EC', 'D1', 'D', 'ED1', 'ED']);
    c(cMinibus, 'Minibus', true, false, 15, ['D1', 'D', 'ED1', 'ED']);
    c(cTaxi, 'Taxi', true, false, 4, ['B', 'EB', 'C1', 'C', 'D1', 'D']);
  }

  void _trucks() {
    void tr(String id, String plate, String model, String cat, String? owner, int km, int lastOil, int insDays, int cofDays,
            {bool active = true}) =>
        t['trucks']!.add({
          'id': id,
          'plate': plate,
          'model': model,
          'active': active,
          'category_id': cat,
          'owner_id': owner,
          'seats': null,
          'current_km': km,
          'oil_interval_km': 5000,
          'last_oil_km': lastOil,
          'last_oil_on': day(today.subtract(const Duration(days: 40))),
          'insurance_to': day(today.add(Duration(days: insDays))),
          'cof_to': day(today.add(Duration(days: cofDays))),
          'created_at': iso(today.subtract(const Duration(days: 90))),
        });
    tr(tMZ4521, 'MZ 4521', 'Toyota Hilux', cMatola, pPhiri, 45210, 43000, 101, 196);
    tr(tBT4410, 'BT 4410', 'Toyota Dyna', cMatola, null, 112044, 110204, 188, 79);
    tr(tBT8812, 'BT 8812', 'Toyota Hiace', cMinibus, pChirwa, 161700, 156560, -9, 131);
    tr(tLL2290, 'LL 2290', 'Isuzu FTR 7 t', cLorry, null, 208150, 203730, 250, 19);
    tr(tMZ1190, 'MZ 1190', 'Toyota Corolla', cTaxi, pChirwa, 88410, 86112, 293, 162);
    tr(tMZ3307, 'MZ 3307', 'Nissan Hardbody', cMatola, pPhiri, 73120, 72320, 46, 119);
  }

  void _people() {
    void p(String id, String name, String email, String phone, String role,
            {String? truck, bool active = true, String? kin, String? kinPhone, String? kinRel}) =>
        t['profiles']!.add({
          'id': id,
          'email': email,
          'full_name': name,
          'phone': phone,
          'role': role,
          'active': active,
          'truck_id': truck,
          'next_of_kin_name': kin,
          'next_of_kin_phone': kinPhone,
          'next_of_kin_relation': kinRel,
          'language': 'en',
          'created_at': iso(today.subtract(const Duration(days: 80))),
        });
    p(pManager, 'Tamanda Chirwa', 'manager@demo.efulogistix', '0888 120 455', 'manager');
    p(pPhiri, 'Lameck Phiri', 'owner@demo.efulogistix', '0888 202 333', 'owner');
    p(pChirwa, 'Ruth Chirwa', 'ruth.chirwa@demo.efulogistix', '0999 404 118', 'owner');
    p(dChikondi, 'Chikondi Banda', 'driver@demo.efulogistix', '0991 234 567', 'driver',
        truck: tMZ4521, kin: 'Esther Banda', kinPhone: '0888 410 223', kinRel: 'Wife');
    p(dGrace, 'Grace Mwale', 'grace@demo.efulogistix', '0884 551 902', 'driver',
        truck: tBT8812, kin: 'Peter Mwale', kinPhone: '0995 700 812', kinRel: 'Husband');
    p(dYusuf, 'Yusuf Ali', 'yusuf@demo.efulogistix', '0997 655 010', 'driver',
        truck: tLL2290, kin: 'Amina Ali', kinPhone: '0888 990 341', kinRel: 'Mother');
    p(dMphatso, 'Mphatso Jere', 'mphatso@demo.efulogistix', '0881 300 455', 'driver',
        truck: tMZ1190, kin: 'Chisomo Jere', kinPhone: '0999 152 640', kinRel: 'Brother');
    p(dKondwani, 'Kondwani Phiri', 'kondwani@demo.efulogistix', '0999 870 114', 'driver',
        truck: tMZ3307, kin: 'Joseph Phiri', kinPhone: '0884 300 201', kinRel: 'Brother');
    p(dMike, 'Mike Kalua', 'mike@demo.efulogistix', '0995 112 870', 'driver', active: false);
  }

  void _documents() {
    void doc(String driver, String kind, {String? number, String? cls, int? expiresDays, String status = 'approved'}) =>
        t['documents']!.add({
          'id': nid(),
          'driver_id': driver,
          'truck_id': null,
          'kind': kind,
          'front_path': null,
          'back_path': null,
          'number': number,
          'licence_class': cls,
          'expires_on': expiresDays == null ? null : day(today.add(Duration(days: expiresDays))),
          'status': status,
          'note': null,
          'created_at': iso(today.subtract(const Duration(days: 30))),
        });
    final cls = {dChikondi: 'C1', dGrace: 'D1', dYusuf: 'C', dMphatso: 'B', dKondwani: 'C1'};
    var i = 0;
    cls.forEach((d, c) {
      i++;
      doc(d, 'national_id', number: 'NTX${4000 + i * 137}K');
      doc(d, 'licence', number: 'MW-DL-22${(1500 + i * 311)}', cls: c, expiresDays: 300 + i * 90);
      doc(d, 'selfie');
    });
    doc(dGrace, 'police_clearance', status: 'pending');
    doc(dMike, 'national_id', number: 'NTX4K9P2', status: 'pending');
    doc(dMike, 'selfie', status: 'pending');
  }

  void _routes() {
    void r(String cat, String to, int fare, {String from = rank}) {
      final p = places[to]!;
      t['routes']!.add({
        'id': nid(),
        'from_name': from,
        'to_name': to,
        'to_lat': p[0],
        'to_lng': p[1],
        'km': p[2],
        'fare': fare,
        'active': true,
        'category_id': cat,
      });
    }
    r(cMatola, 'Monkey Bay', 5000);
    r(cMatola, 'Namwera', 3500);
    r(cMatola, 'Makanjira', 8000);
    r(cMatola, 'Mpondasi', 2500);
    r(cMatola, 'Nkopola', 1500);
    r(cMatola, 'Liwonde', 4500);
    r(cMinibus, 'Monkey Bay', 6000);
    r(cMinibus, 'Namwera', 3500);
    r(cMinibus, 'Liwonde', 5000);
    r(cLorry, 'Liwonde', 180000);
    r(cLorry, 'Monkey Bay', 150000);
    r(cLorry, 'Blantyre', 350000);
    r(cTaxi, 'Nkopola', 15000, from: 'Mangochi Boma');
    r(cTaxi, 'Mangochi Boma', 5000, from: 'Mangochi Boma');
    r(cKabaza, 'Mangochi Boma', 1000, from: 'Mangochi Boma');
    for (final g in [('50 kg bag of maize', 1500), ('Bicycle', 2000), ('Goat', 3000), ('Chicken', 500), ('20 L container', 1000)]) {
      t['goods_prices']!.add({'id': nid(), 'label': g.$1, 'price': g.$2, 'active': true});
    }
  }

  Map<String, dynamic> _route(String cat, String to) =>
      t['routes']!.firstWhere((r) => r['category_id'] == cat && r['to_name'] == to);

  // ------------------------------------------------------------------ one driver's shift

  /// Adds a shift with trips. Returns the shift row. [tripsSpec] decides the trips; the last one can be running.
  Map<String, dynamic> _shift(String driver, String truck, String cat, DateTime start,
      {required int trips, bool endShift = true, bool lastRunning = false, DateTime? end, int startKm = 0}) {
    final sid = nid();
    var km = startKm;
    final shift = <String, dynamic>{
      'id': sid,
      'driver_id': driver,
      'truck_id': truck,
      'status': 'on_duty',
      'started_at': iso(start),
      'start_km': km,
      'ended_at': null,
      'end_km': null,
      'end_reason': null,
      'truck_photos': <String>[],
      'gps_km': 0.0,
      'review': 'open',
      'review_note': null,
      'created_at': iso(start),
    };
    t['shifts']!.add(shift);
    _readingRow(sid, null, driver, truck, 'shift_start', km, start, null);
    var clock = start.add(const Duration(minutes: 35));
    final dests = switch (cat) {
      'lorry' => ['Liwonde', 'Blantyre', 'Monkey Bay'],
      'minibus' => ['Namwera', 'Monkey Bay', 'Liwonde'],
      'taxi' => ['Nkopola', 'Mangochi Boma'],
      _ => ['Monkey Bay', 'Namwera', 'Mpondasi', 'Nkopola', 'Makanjira', 'Liwonde'],
    };
    final catId = switch (cat) { 'lorry' => cLorry, 'minibus' => cMinibus, 'taxi' => cTaxi, _ => cMatola };
    var gps = 0.0;
    for (var i = 0; i < trips; i++) {
      final running = lastRunning && i == trips - 1;
      final to = dests[(i + rnd.nextInt(dests.length)) % dests.length];
      final route = _route(catId, to);
      final dist = (route['km'] as num).toDouble();
      final tid = nid();
      final from = cat == 'taxi' ? 'Mangochi Boma' : rank;
      int pax = 0;
      double fare = 0;
      final goods = <Map<String, dynamic>>[];
      double? cargoKg;
      if (cat == 'lorry') {
        goods.add({'label': 'Load to $to', 'amount': route['fare']});
        cargoKg = (2500 + rnd.nextInt(4500)).toDouble();
      } else {
        final seats = switch (cat) { 'minibus' => 15, 'taxi' => 4, _ => 16 };
        pax = cat == 'taxi' ? 1 + rnd.nextInt(4) : seats - rnd.nextInt(5);
        fare = (route['fare'] as num).toDouble();
        if (cat == 'matola' && rnd.nextBool()) {
          final n = 1 + rnd.nextInt(3);
          goods.add({'label': '50 kg bag of maize ×$n', 'amount': 1500 * n});
        }
      }
      final goodsTotal = goods.fold<double>(0, (s, g) => s + (g['amount'] as num));
      final minutes = (dist * 1.6).round() + 15;
      final started = clock;
      final ended = clock.add(Duration(minutes: minutes));
      final oneWay = dist.round();
      final trip = <String, dynamic>{
        'id': tid,
        'trip_no': ++_tripNo,
        'driver_id': driver,
        'truck_id': truck,
        'shift_id': sid,
        'route_id': route['id'],
        'pickup_name': from,
        'pickup_lat': rankLat,
        'pickup_lng': rankLng,
        'dest_name': to,
        'dest_lat': route['to_lat'],
        'dest_lng': route['to_lng'],
        'passengers': pax,
        'pax_carried': null,
        'fare_per_passenger': fare,
        'goods': goods,
        'goods_total': goodsTotal,
        'stops_total': 0.0,
        'total': pax * fare + goodsTotal,
        'planned_km': dist,
        'actual_km': running ? null : oneWay.toDouble(),
        'start_km': km,
        'end_km': running ? null : km + oneWay,
        'gps_km': running ? null : oneWay - 1.0,
        'status': running ? 'in_progress' : 'completed',
        'started_at': iso(started),
        'ended_at': running ? null : iso(ended),
        'cargo_kg': cargoKg,
        'cargo_note': cargoKg == null ? null : 'Cement',
        'created_at': iso(started),
      };
      t['trips']!.add(trip);
      _readingRow(sid, tid, driver, truck, 'trip_start', km, started, null);
      // one stop on the way for matola and minibus trips that pass a trading centre
      if (cat != 'lorry' && cat != 'taxi' && dist > 30) {
        final picked = rnd.nextInt(4);
        final dropped = 1 + rnd.nextInt(3);
        final stopFare = to == 'Monkey Bay' ? 2500 : 1500;
        final stopAt = started.add(Duration(minutes: (minutes * 0.4).round()));
        if (!running || stopAt.isBefore(now)) {
          t['trip_stops']!.add({
            'id': nid(),
            'trip_id': tid,
            'place_name': to == 'Monkey Bay' ? 'Mpondasi' : to == 'Namwera' ? 'Chilipa' : 'Nkopola',
            'lat': rankLat + ((route['to_lat'] as num) - rankLat) * 0.4,
            'lng': rankLng + ((route['to_lng'] as num) - rankLng) * 0.4,
            'dropped': dropped,
            'picked': picked,
            'picked_to': picked > 0 ? to : null,
            'fare_each': picked > 0 ? stopFare : 0,
            'goods_off': null,
            'goods_on': [],
            'goods_total': 0,
            'amount': picked * stopFare,
            'km_from_start': (dist * 0.4).roundToDouble(),
            'auto': false,
            'at': iso(stopAt),
          });
          trip['stops_total'] = picked * stopFare * 1.0;
          trip['pax_carried'] = pax + picked;
          trip['total'] = pax * fare + goodsTotal + picked * stopFare;
        }
      }
      if (running) {
        gps += dist * 0.55;
        break;
      }
      km += oneWay;
      gps += oneWay - 1;
      _readingRow(sid, tid, driver, truck, 'trip_end', km, ended, oneWay - 1.0);
      // empty drive back to the rank
      km += oneWay;
      gps += oneWay - 0.5;
      clock = ended.add(Duration(minutes: minutes - 10 + rnd.nextInt(30)));
    }
    shift['gps_km'] = (gps * 10).round() / 10;
    if (endShift) {
      final e = end ?? clock.add(const Duration(minutes: 20));
      shift
        ..['status'] = 'off_duty'
        ..['ended_at'] = iso(e)
        ..['end_km'] = km
        ..['end_reason'] = 'end_of_day'
        ..['truck_photos'] = <String>[]
        ..['review'] = 'approved';
      _readingRow(sid, null, driver, truck, 'shift_end', km, e, null);
    }
    shift['_km'] = km; // removed below
    return shift;
  }

  void _readingRow(String shift, String? trip, String driver, String truck, String kind, int km, DateTime at, double? gps,
      {bool mismatch = false, int? expected}) {
    t['odometer_readings']!.add({
      'id': nid(),
      'shift_id': shift,
      'trip_id': trip,
      'driver_id': driver,
      'truck_id': truck,
      'kind': kind,
      'km': km,
      'photo_path': null,
      'gps_since_last_km': gps,
      'expected_km': expected,
      'mismatch': mismatch,
      'taken_at': iso(at),
    });
  }

  Map<String, dynamic> _handIn(Map<String, dynamic> shift, DateTime dayDate,
      {String method = 'cash', String? reference, double short = 0, bool received = true, String? decision, String? note}) {
    final trips = t['trips']!.where((x) => x['shift_id'] == shift['id'] && x['status'] == 'completed').toList();
    final collected = trips.fold<double>(0, (s, x) => s + (x['total'] as num));
    final pax = trips.fold<int>(0, (s, x) => s + ((x['pax_carried'] ?? x['passengers']) as num).toInt());
    final exp = t['expenses']!
        .where((x) => x['shift_id'] == shift['id'] && x['paid_by'] == 'driver')
        .fold<double>(0, (s, x) => s + (x['amount'] as num));
    final h = {
      'id': nid(),
      'shift_id': shift['id'],
      'driver_id': shift['driver_id'],
      'truck_id': shift['truck_id'],
      'day': day(dayDate),
      'trips': trips.length,
      'passengers': pax,
      'collected': collected,
      'driver_expenses': exp,
      'expected': collected - exp,
      'method': method,
      'reference': reference,
      'received': received ? collected - exp - short : null,
      'received_at': received ? shift['ended_at'] : null,
      'note': note,
      'decision': decision,
      'created_at': shift['ended_at'],
    };
    t['hand_ins']!.add(h);
    return h;
  }

  void _fuel(Map<String, dynamic> shift, DateTime when, double amount, {String paidBy = 'driver'}) {
    t['expenses']!.add({
      'id': nid(),
      'truck_id': shift['truck_id'],
      'created_by': paidBy == 'driver' ? shift['driver_id'] : pManager,
      'category': 'fuel',
      'litres': (amount / 2930).roundToDouble(),
      'amount': amount,
      'note': paidBy == 'driver' ? 'Puma Mangochi' : null,
      'paid_by': paidBy,
      'receipt_path': null,
      'shift_id': paidBy == 'driver' ? shift['id'] : null,
      'spent_at': iso(when),
    });
  }

  // ------------------------------------------------------------------ the last two weeks

  void _history() {
    final crew = [
      (dChikondi, tMZ4521, 'matola'),
      (dGrace, tBT8812, 'minibus'),
      (dYusuf, tLL2290, 'lorry'),
      (dMphatso, tMZ1190, 'taxi'),
      (dKondwani, tMZ3307, 'matola'),
    ];
    final kmNow = {for (final tr in t['trucks']!) tr['id'] as String: (tr['current_km'] as num).toInt()};
    // walk backwards so today's odometer ends at the truck's current km
    final startKm = <String, int>{};
    for (final c in crew) {
      startKm[c.$2] = kmNow[c.$2]! - 14 * (c.$3 == 'lorry' ? 300 : c.$3 == 'taxi' ? 95 : 190);
    }
    for (var d = 14; d >= 1; d--) {
      final date = today.subtract(Duration(days: d));
      if (date.weekday == DateTime.sunday) continue;
      for (final c in crew) {
        final (driver, truck, cat) = c;
        if (rnd.nextInt(10) == 0) continue; // day off now and then
        final start = at(d, 6, rnd.nextInt(40));
        final n = switch (cat) { 'lorry' => 1 + rnd.nextInt(2), 'taxi' => 4 + rnd.nextInt(3), _ => 3 + rnd.nextInt(3) };
        final s = _shift(driver, truck, cat, start, trips: n, startKm: startKm[truck]!);
        startKm[truck] = s.remove('_km') as int;
        if (rnd.nextInt(3) != 0) _fuel(s, start.add(const Duration(minutes: 20)), (20 + rnd.nextInt(30)) * 2930.0);
        final shortDay = d == 1 && driver == dGrace;
        _handIn(
          s,
          date,
          method: driver == dGrace ? 'airtel_money' : (rnd.nextInt(4) == 0 ? 'tnm_mpamba' : 'cash'),
          reference: driver == dGrace ? 'CI${day(date).replaceAll('-', '').substring(2)}.1${rnd.nextInt(900) + 100}' : null,
          short: shortDay ? 4870 : 0,
          note: shortDay ? 'Puncture paid, no receipt' : null,
        );
      }
    }
    for (final tr in t['trucks']!) {
      final k = startKm[tr['id']];
      if (k != null) tr['current_km'] = k;
    }
    // a repair paid by the office
    t['expenses']!.add({
      'id': nid(),
      'truck_id': tBT8812,
      'created_by': pManager,
      'category': 'tyre',
      'litres': null,
      'amount': 85000,
      'note': 'Two tyres, Mangochi tyre centre',
      'paid_by': 'office',
      'receipt_path': null,
      'shift_id': null,
      'spent_at': iso(at(3, 10, 15)),
    });
    // yesterday's short hand-in waits for a decision
    final yGrace = t['hand_ins']!.where((h) => h['driver_id'] == dGrace).lastOrNull;
    if (yGrace != null && (yGrace['received'] as num?) != null) {
      final short = (yGrace['expected'] as num) - (yGrace['received'] as num);
      if (short > 0) {
        _alert('cash_short', truck: tBT8812, driver: dGrace, ref: yGrace['id'] as String,
            title: 'Cash short K${short.round()}', detail: 'Grace handed in less than expected', when: at(1, 18, 42));
      }
    }
    // a mileage check two days ago
    final ySh = t['shifts']!.where((s) => s['driver_id'] == dYusuf).lastOrNull;
    if (ySh != null) {
      final r = t['odometer_readings']!.where((x) => x['shift_id'] == ySh['id'] && x['kind'] == 'trip_end').firstOrNull;
      if (r != null) {
        r['mismatch'] = true;
        r['expected_km'] = (r['km'] as int) - 34;
        r['km'] = (r['km'] as int);
        ySh['review'] = 'open';
        _alert('mileage', truck: tLL2290, driver: dYusuf,
            title: 'Mileage check · LL 2290', detail: 'Typed ${r['km']} km, GPS expects about ${r['expected_km']}',
            when: DateTime.parse(r['taken_at'] as String).toLocal());
      }
    }
  }

  // ------------------------------------------------------------------ today

  void _todayFleet() {
    final km = {for (final tr in t['trucks']!) tr['id'] as String: (tr['current_km'] as num).toInt()};
    final h = now.hour;

    // Grace (minibus): on duty, two trips done and one running to Namwera
    final g = _shift(dGrace, tBT8812, 'minibus', at(0, min(6, max(0, h - 4)), 40),
        trips: 3, endShift: false, lastRunning: true, startKm: km[tBT8812]!);
    final gKm = g.remove('_km') as int;
    _setKm(tBT8812, gKm);
    _moveShift(g, now.subtract(const Duration(minutes: 35)));
    final gTrip = t['trips']!.lastWhere((x) => x['shift_id'] == g['id']);
    t['trip_stops']!.add({
      'id': nid(),
      'trip_id': gTrip['id'],
      'place_name': null,
      'lat': -14.420,
      'lng': 35.360,
      'dropped': 0,
      'picked': 0,
      'picked_to': null,
      'fare_each': 0,
      'goods_off': null,
      'goods_on': [],
      'goods_total': 0,
      'amount': 0,
      'km_from_start': 14.0,
      'auto': true,
      'at': iso(now.subtract(const Duration(minutes: 25))),
    });
    _location(tBT8812, dGrace, gTrip['id'] as String, -14.405, 35.395);
    _alert('overspeed', truck: tBT8812, driver: dGrace, trip: gTrip['id'] as String,
        title: 'Overspeed · 92 km/h', detail: 'Limit 80 km/h on the M3', when: now.subtract(const Duration(minutes: 50)));
    _alert('unrecorded_stop', truck: tBT8812, driver: dGrace, trip: gTrip['id'] as String,
        title: 'Stop not saved', detail: 'Stood still 6 min during a trip', when: now.subtract(const Duration(minutes: 25)));

    // Yusuf (lorry): on duty, cement to Liwonde
    final y = _shift(dYusuf, tLL2290, 'lorry', at(0, min(5, max(0, h - 5)), 55),
        trips: 1, endShift: false, lastRunning: true, startKm: km[tLL2290]!);
    _setKm(tLL2290, y.remove('_km') as int);
    _moveShift(y, now.subtract(const Duration(minutes: 70)));
    final yTrip = t['trips']!.lastWhere((x) => x['shift_id'] == y['id']);
    _location(tLL2290, dYusuf, yTrip['id'] as String, -14.80, 35.25);

    // Mphatso (taxi): finished, Airtel Money hand-in waiting to be confirmed
    final m = _shift(dMphatso, tMZ1190, 'taxi', at(0, min(7, max(0, h - 6)), 30),
        trips: 4, endShift: true, startKm: km[tMZ1190]!);
    _setKm(tMZ1190, m.remove('_km') as int);
    m['review'] = 'open';
    _fuel(m, DateTime.parse(m['started_at'] as String).add(const Duration(minutes: 15)), 29300);
    _moveShift(m, now.subtract(const Duration(minutes: 40)));
    _handIn(m, today, method: 'airtel_money', reference: 'CI${day(today).replaceAll('-', '').substring(2)}.1544.K7302', received: false);
    _location(tMZ1190, dMphatso, null, -14.4790, 35.2655, minutesAgo: 35);

    // Kondwani (matola): broke down, asked to change to the spare BT 4410
    final k = _shift(dKondwani, tMZ3307, 'matola', at(0, min(6, max(0, h - 4)), 30),
        trips: 1, endShift: false, startKm: km[tMZ3307]!);
    final kKm = k.remove('_km') as int;
    _setKm(tMZ3307, kKm);
    _moveShift(k, now.subtract(const Duration(minutes: 45)));
    final change = {
      'id': nid(),
      'driver_id': dKondwani,
      'from_truck': tMZ3307,
      'to_truck': tBT4410,
      'reason': 'Breakdown',
      'note': 'Clutch slipping near Mpondasi',
      'out_km': kKm + 18,
      'out_photo': '',
      'parked_at': 'Mpondasi trading centre',
      'out_lat': -14.25,
      'out_lng': 35.10,
      'in_km': km[tBT4410]!,
      'in_photo': '',
      'in_truck_photos': <String>[],
      'status': 'pending',
      'created_at': iso(now.subtract(const Duration(minutes: 15))),
    };
    t['truck_changes']!.add(change);
    _alert('truck_change', truck: tMZ3307, driver: dKondwani, ref: change['id'] as String,
        title: 'Truck change · Kondwani', detail: 'MZ 3307 → BT 4410 · Breakdown', when: now.subtract(const Duration(minutes: 15)));
    _location(tMZ3307, dKondwani, null, -14.25, 35.10, minutesAgo: 14);

    // parked at the rank / depot
    _location(tMZ4521, dChikondi, null, rankLat, rankLng, minutesAgo: 60 * 11);
    _location(tBT4410, null, null, -14.4800, 35.2620, minutesAgo: 60 * 20);

    // service and papers
    _alert('service_due', truck: tBT8812, title: 'Oil change overdue', detail: 'BT 8812 · ${_oilText(tBT8812)}', when: at(0, 6, 0));
    _alert('service_due', truck: tLL2290, title: 'Oil change due', detail: 'LL 2290 · ${_oilText(tLL2290)}', when: at(0, 6, 0));
    _alert('paper_expiry', truck: tBT8812, title: 'Insurance expired', detail: 'BT 8812 · ask the owner to renew', when: at(0, 6, 0));
    _alert('paper_expiry', truck: tLL2290, title: 'COF expires in 19 days', detail: 'LL 2290', when: at(0, 6, 0));
  }

  String _oilText(String truck) {
    final tr = t['trucks']!.firstWhere((x) => x['id'] == truck);
    final left = (tr['last_oil_km'] as int) + 5000 - (tr['current_km'] as int);
    return left <= 0 ? '${-left} km overdue' : 'due in $left km';
  }

  /// Moves every time of a shift (and its trips, stops, readings, fuel) so its last event happens at [latest].
  void _moveShift(Map<String, dynamic> shift, DateTime latest) {
    final sid = shift['id'];
    final trips = t['trips']!.where((x) => x['shift_id'] == sid).toList();
    final tripIds = trips.map((x) => x['id']).toSet();
    DateTime last = DateTime.parse(shift['started_at'] as String);
    void see(dynamic v) {
      if (v is String) {
        final d = DateTime.parse(v);
        if (d.isAfter(last)) last = d;
      }
    }
    see(shift['ended_at']);
    for (final x in trips) {
      see(x['started_at']);
      see(x['ended_at']);
    }
    final offset = latest.toUtc().difference(last.toUtc());
    String mv(dynamic v) => iso(DateTime.parse(v as String).add(offset));
    for (final k in ['started_at', 'ended_at', 'created_at']) {
      if (shift[k] != null) shift[k] = mv(shift[k]);
    }
    for (final x in trips) {
      for (final k in ['started_at', 'ended_at', 'created_at']) {
        if (x[k] != null) x[k] = mv(x[k]);
      }
    }
    for (final x in t['trip_stops']!.where((x) => tripIds.contains(x['trip_id']))) {
      x['at'] = mv(x['at']);
    }
    for (final x in t['odometer_readings']!.where((x) => x['shift_id'] == sid)) {
      x['taken_at'] = mv(x['taken_at']);
    }
    for (final x in t['expenses']!.where((x) => x['shift_id'] == sid)) {
      x['spent_at'] = mv(x['spent_at']);
    }
  }

  void _setKm(String truck, int km) => t['trucks']!.firstWhere((x) => x['id'] == truck)['current_km'] = km;

  void _location(String truck, String? driver, String? trip, double lat, double lng, {int minutesAgo = 0}) {
    t['truck_locations']!.add({
      'truck_id': truck,
      'driver_id': driver,
      'trip_id': trip,
      'lat': lat,
      'lng': lng,
      'speed_kmh': trip == null ? 0 : 54,
      'updated_at': iso(now.subtract(Duration(minutes: minutesAgo))),
    });
  }

  void _alert(String kind,
      {String? truck, String? driver, String? trip, String? ref, required String title, String? detail, required DateTime when}) {
    t['alerts']!.add({
      'id': nid(),
      'kind': kind,
      'truck_id': truck,
      'driver_id': driver,
      'shift_id': null,
      'trip_id': trip,
      'ref_id': ref,
      'title': title,
      'detail': detail,
      'day': day(when),
      'seen': false,
      'resolved': false,
      'created_at': iso(when),
    });
  }

  void _service() {
    void s(String truck, String kind, int? km, double cost, int daysAgo, String note) => t['service_records']!.add({
          'id': nid(),
          'truck_id': truck,
          'kind': kind,
          'km': km,
          'cost': cost,
          'note': note,
          'done_on': day(today.subtract(Duration(days: daysAgo))),
          'created_by': pManager,
          'created_at': iso(today.subtract(Duration(days: daysAgo))),
        });
    s(tMZ4521, 'oil', 43000, 38000, 40, 'Oil and filter, Mangochi Motors');
    s(tLL2290, 'repair', null, 120000, 21, 'Brake pads front');
    s(tBT8812, 'tyre', null, 85000, 3, 'Two tyres');
    s(tMZ1190, 'papers', null, 45000, 60, 'COF renewal');
  }
}
