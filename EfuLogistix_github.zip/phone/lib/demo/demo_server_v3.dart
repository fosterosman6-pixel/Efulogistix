part of 'demo_server.dart';

/// Marks "this function is not one of the v3 functions".
const _notV3 = Object();

/// Demo versions of the v3 database functions (bookings, wallet, fees, GPS trail).
extension _DemoV3 on DemoServer {
  Object? rpcV3(String fn, Map<String, dynamic> p, Row? me) {
    switch (fn) {
      case 'departure_seats': {
        final dayStr = p['p_day'].toString();
        return [
          for (final d in t['departures'] ?? <Row>[])
            {
              'departure_id': d['id'],
              'seats': d['seats'] ?? _catSeats(d['route_id']),
              'booked': (t['bookings'] ?? <Row>[])
                  .where((b) =>
                      b['departure_id'] == d['id'] &&
                      b['travel_on'] == dayStr &&
                      b['kind'] == 'seat' &&
                      ['requested', 'assigned', 'picked_up'].contains(b['status']))
                  .fold<int>(0, (s, b) => s + _n(b['seats']).round()),
            }
        ];
      }
      case 'book':
        return _book(Map<String, dynamic>.from(p['p'] as Map), me);
      case 'cancel_booking': {
        final b = _byId('bookings', p['p_id']);
        if (b == null || !['requested', 'assigned'].contains(b['status'])) throw DemoError('CANNOT_CANCEL');
        b
          ..['status'] = 'cancelled'
          ..['cancelled_at'] = _now
          ..['cancel_reason'] = p['p_reason'];
        return null;
      }
      case 'booking_step':
        _bookingStep(p);
        return null;
      case 'upload_gps': {
        final list = (p['p_points'] as List? ?? []).cast<Map>();
        final rows = t.putIfAbsent('gps_points', () => []);
        final truck = me?['truck_id'];
        for (final x in list) {
          rows.add({...x.cast<String, dynamic>(), 'driver_id': _uid, 'truck_id': truck, 'id': rows.length + 1});
        }
        return list.length;
      }
      case 'report_tracking': {
        final shift = _openShift(_uid);
        if (shift == null) return null;
        if (p['p_on'] == true) {
          for (final a in t['alerts']!.where((a) => a['kind'] == 'tracking_off' && a['shift_id'] == shift['id'])) {
            a['resolved'] = true;
          }
        } else {
          insert('alerts', {
            'kind': 'tracking_off',
            'truck_id': shift['truck_id'],
            'driver_id': _uid,
            'shift_id': shift['id'],
            'title': 'Tracking stopped · ${_byId('trucks', shift['truck_id'])?['plate'] ?? ''}',
            'detail': '${me?['full_name'] ?? 'Driver'}: ${p['p_reason']}',
          });
        }
        return null;
      }
      case 'pay_wallet': {
        final owner = me?['role'] == 'owner' ? _uid : null;
        final rows = t['wallet_entries']!.where((e) => e['driver_id'] == p['p_driver'] && e['owner_id'] == owner);
        final bal = rows.fold<double>(0, (s, e) => s + _n(e['amount']));
        final ded = _n(p['p_deduct']);
        if (bal <= 0) throw DemoError('NOTHING_TO_PAY');
        if (ded > bal) throw DemoError('DEDUCT_TOO_BIG');
        if (ded > 0) {
          insert('wallet_entries', {
            'driver_id': p['p_driver'],
            'owner_id': owner,
            'kind': 'deduct',
            'amount': -ded,
            'day': _today,
            'note': p['p_note'],
          });
        }
        insert('wallet_entries', {
          'driver_id': p['p_driver'],
          'owner_id': owner,
          'kind': 'payout',
          'amount': -(bal - ded),
          'day': _today,
          'method': p['p_method'],
          'reference': p['p_reference'],
          'note': 'Paid out',
        });
        _notice(p['p_driver'] as String?, 'Wallet paid · K${(bal - ded).round()}', 'Thank you for your work this week.', 'wallet');
        return bal - ded;
      }
      case 'report_fee_paid': {
        final b = _byId('fee_bills', p['p_id']);
        if (b == null) throw DemoError('NOT_FOUND');
        b
          ..['method'] = p['p_method']
          ..['reference'] = p['p_reference']
          ..['reported_at'] = _now;
        return null;
      }
    }
    return _notV3;
  }

  /// The driver's share goes into the wallet when the owner confirms a hand-in.
  void walletForHandIn(Row h) {
    final share = (_n(h['expected']) * 0.10).roundToDouble();
    if (share <= 0) return;
    final owner = _byId('trucks', h['truck_id'])?['owner_id'];
    insert('wallet_entries', {
      'driver_id': h['driver_id'],
      'owner_id': owner,
      'hand_in_id': h['id'],
      'kind': 'earn',
      'amount': share,
      'day': h['day'],
      'note': '10% of K${_n(h['expected']).round()}',
    });
    _notice(h['driver_id'] as String?, '+ K${share.round()} in your wallet', 'Hand-in confirmed. Paid out on Monday.', 'wallet');
  }

  int _catSeats(dynamic routeId) {
    final r = _byId('routes', routeId);
    final c = _byId('vehicle_categories', r?['category_id']);
    return _n(c?['seats']).round();
  }

  void _notice(String? user, String title, String? body, String kind) {
    if (user == null) return;
    insert('notices', {'user_id': user, 'title': title, 'body': body, 'kind': kind, 'read': false});
  }

  String _code() => (1000 + _rnd.nextInt(9000)).toString();

  String _book(Map<String, dynamic> p, Row? me) {
    if (me == null || me['role'] != 'passenger') throw DemoError('not allowed');
    final kind = p['kind'] as String;
    final pay = (p['pay_method'] ?? 'cash') as String;
    final ref = (p['pay_reference'] ?? '').toString().trim();
    if ((pay == 'airtel_money' || pay == 'tnm_mpamba') && ref.isEmpty) throw DemoError('REFERENCE_REQUIRED');
    if (pay == 'account' && me['account_id'] == null) throw DemoError('NO_ACCOUNT');
    final rows = t.putIfAbsent('bookings', () => []);
    final no = rows.fold<int>(2000, (m, b) => max(m, _n(b['booking_no']).round())) + 1;
    final row = <String, dynamic>{
      'booking_no': no,
      'passenger_id': me['id'],
      'kind': kind,
      'seats': 0,
      'goods': <Map<String, dynamic>>[],
      'pay_method': pay,
      'pay_reference': ref.isEmpty ? null : ref,
      'account_id': pay == 'account' ? me['account_id'] : null,
      'note': p['note'],
      'status': 'requested',
    };
    if (kind == 'seat' || kind == 'goods') {
      final d = _byId('departures', p['departure_id']);
      final r = _byId('routes', d?['route_id']);
      if (d == null || r == null) throw DemoError('NO_DEPARTURE');
      final day = DateTime.parse(p['travel_on'] as String);
      final parts = (d['leaves_at'] as String).split(':');
      final leaves = DateTime(day.year, day.month, day.day, int.parse(parts[0]), int.parse(parts[1]));
      if (leaves.isBefore(DateTime.now().subtract(const Duration(minutes: 5)))) throw DemoError('DEPARTED');
      row.addAll({
        'departure_id': d['id'],
        'route_id': r['id'],
        'category_id': r['category_id'],
        'travel_on': p['travel_on'],
        'pickup_at': leaves.toUtc().toIso8601String(),
        'pickup_name': r['from_name'],
        'dest_name': r['to_name'],
        'dest_lat': r['to_lat'],
        'dest_lng': r['to_lng'],
      });
      if (kind == 'seat') {
        final seats = _n(p['seats']).round();
        if (seats < 1) throw DemoError('SEATS_REQUIRED');
        final cap = _n(d['seats'] ?? _catSeats(r['id'])).round();
        final taken = rows
            .where((b) =>
                b['departure_id'] == d['id'] &&
                b['travel_on'] == p['travel_on'] &&
                b['kind'] == 'seat' &&
                ['requested', 'assigned', 'picked_up'].contains(b['status']))
            .fold<int>(0, (s, b) => s + _n(b['seats']).round());
        if (taken + seats > cap) throw DemoError('FULL:${max(cap - taken, 0)}');
        row['seats'] = seats;
        row['price'] = _n(r['fare']) * seats;
      }
    } else {
      final c = _byId('vehicle_categories', p['category_id']);
      if (c == null || _n(c['hire_per_km']) <= 0) throw DemoError('NOT_FOR_HIRE');
      var km = _n(p['km']);
      if (p['trip_type'] == 'whole_day' && km < 100) km = 100;
      final price = max(_n(c['hire_min']), (km * _n(c['hire_per_km']) / 500).ceil() * 500.0);
      row.addAll({
        'category_id': c['id'],
        'pickup_name': p['pickup_name'],
        'pickup_lat': p['pickup_lat'],
        'pickup_lng': p['pickup_lng'],
        'dest_name': p['dest_name'],
        'dest_lat': p['dest_lat'],
        'dest_lng': p['dest_lng'],
        'trip_type': p['trip_type'],
        'pickup_at': p['pickup_at'] ?? _now,
        'km': km,
        'rate_per_km': c['hire_per_km'],
        'price': price,
      });
    }
    final goods = (p['goods'] as List? ?? []).cast<Map>();
    String? code;
    if (goods.isNotEmpty || kind == 'goods') {
      final items = <Map<String, dynamic>>[];
      var total = 0.0;
      for (final g in goods) {
        final qty = _n(g['qty']).round();
        if (qty < 1) continue;
        final price = kind == 'goods'
            ? _n(t['goods_prices']!.where((x) => x['label'] == g['label']).firstOrNull?['price'])
            : 0.0;
        items.add({'label': g['label'], 'qty': qty, 'price': price});
        total += price * qty;
      }
      if (kind == 'goods' && items.isEmpty) throw DemoError('GOODS_REQUIRED');
      if ((p['receiver_name'] ?? '').toString().isEmpty || (p['receiver_phone'] ?? '').toString().isEmpty) {
        throw DemoError('RECEIVER_REQUIRED');
      }
      row['goods'] = items;
      if (kind == 'goods') row['price'] = total;
      row['receiver_name'] = p['receiver_name'];
      row['receiver_phone'] = p['receiver_phone'];
      code = _code();
    }
    final saved = insert('bookings', row);
    if (code != null) t.putIfAbsent('booking_codes', () => []).add({'booking_id': saved['id'], 'code': code});
    return saved['id'] as String;
  }

  void _bookingStep(Map<String, dynamic> p) {
    final b = _byId('bookings', p['p_id']);
    if (b == null || b['driver_id'] != _uid) throw DemoError('not allowed');
    final step = p['p_step'];
    final trip = t['trips']!.where((x) => x['driver_id'] == _uid && x['status'] == 'in_progress').firstOrNull;
    final who = _profileById(b['passenger_id'] as String?)?['full_name'] ?? b['caller_name'] ?? 'Passenger';
    switch (step) {
      case 'picked_up':
        if (b['status'] != 'assigned') throw DemoError('ALREADY_DECIDED');
        b['status'] = 'picked_up';
        b['picked_up_at'] = _now;
        if (trip != null && b['pay_method'] == 'cash' && b['kind'] != 'hire') {
          final seats = _n(b['seats']).round();
          insert('trip_stops', {
            'trip_id': trip['id'],
            'place_name': 'Booking #${b['booking_no']} · $who',
            'picked': seats,
            'fare_each': seats > 0 ? _n(b['price']) / seats : 0,
            'goods_on': b['kind'] == 'goods' ? b['goods'] : [],
            'goods_total': b['kind'] == 'goods' ? b['price'] : 0,
          });
        }
      case 'no_show':
        if (b['status'] != 'assigned') throw DemoError('ALREADY_DECIDED');
        b['status'] = 'no_show';
        final pax = _profileById(b['passenger_id'] as String?);
        if (pax != null) pax['no_shows'] = _n(pax['no_shows']).round() + 1;
      case 'completed':
        final code = (t['booking_codes'] ?? <Row>[]).where((c) => c['booking_id'] == b['id']).firstOrNull?['code'];
        if (code != null && (p['p_code'] ?? '').toString().trim() != code) throw DemoError('WRONG_CODE');
        var finalPrice = _n(b['price']);
        final km = _n(p['p_km']);
        if (b['kind'] == 'hire' && km > 0) {
          final c = _byId('vehicle_categories', b['category_id']);
          finalPrice = max(_n(c?['hire_min']), (km * _n(b['rate_per_km']) / 500).ceil() * 500.0);
          b['km'] = km;
        }
        b
          ..['status'] = 'completed'
          ..['completed_at'] = _now
          ..['final_price'] = finalPrice;
        if (trip != null && b['pay_method'] == 'cash' && b['kind'] == 'hire') {
          insert('trip_stops', {'trip_id': trip['id'], 'place_name': 'Hire #${b['booking_no']} · $who', 'picked': 1, 'fare_each': finalPrice});
        }
      default:
        throw DemoError('bad step');
    }
  }
}
