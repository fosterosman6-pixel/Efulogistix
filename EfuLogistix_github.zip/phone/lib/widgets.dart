import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'map_icons.dart';
import 'theme.dart';
import 'i18n.dart';

enum ButtonKind { lime, navy, outline, ghost, danger }

class AppButton extends StatelessWidget {
  final String title;
  final VoidCallback? onPressed;
  final ButtonKind kind;
  final bool loading;
  final double height;

  const AppButton(this.title,
      {super.key, required this.onPressed, this.kind = ButtonKind.lime, this.loading = false, this.height = 52});

  @override
  Widget build(BuildContext context) {
    final bg = switch (kind) {
      ButtonKind.lime => AppColors.lime,
      ButtonKind.navy => AppColors.navy,
      ButtonKind.outline || ButtonKind.danger => AppColors.surface,
      ButtonKind.ghost => Colors.transparent,
    };
    final fg = switch (kind) {
      ButtonKind.lime || ButtonKind.outline || ButtonKind.ghost => AppColors.navy,
      ButtonKind.navy => Colors.white,
      ButtonKind.danger => AppColors.danger,
    };
    final border = switch (kind) {
      ButtonKind.outline => AppColors.navy,
      ButtonKind.danger => AppColors.danger,
      _ => Colors.transparent,
    };
    return SizedBox(
      height: height,
      child: TextButton(
        onPressed: loading ? null : onPressed,
        style: TextButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          disabledBackgroundColor: bg.withValues(alpha: kind == ButtonKind.ghost ? 0 : 0.6),
          disabledForegroundColor: fg.withValues(alpha: 0.6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: border, width: 2)),
          padding: const EdgeInsets.symmetric(horizontal: 16),
        ),
        child: loading
            ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: fg))
            : Text(tx(title), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
      ),
    );
  }
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final Color? borderColor;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    this.color = AppColors.surface,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
          border: borderColor == null ? null : Border.all(color: borderColor!, width: 2),
        ),
        child: child,
      );
}

class FieldLabel extends StatelessWidget {
  final String text;
  const FieldLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Text(
        tx(text),
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.muted, letterSpacing: 0.3),
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 2),
        child: FieldLabel(text),
      );
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final bool dark;
  const StatTile(this.label, this.value, {super.key, this.dark = false});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: dark ? AppColors.navy : AppColors.surface, borderRadius: BorderRadius.circular(12)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(fontSize: 12, color: dark ? AppColors.onNavyMuted : AppColors.muted)),
              const SizedBox(height: 2),
              Text(value,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: dark ? Colors.white : AppColors.ink)),
            ],
          ),
        ),
      );
}

class ChoiceChipButton extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const ChoiceChipButton(this.text, {super.key, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        selected: selected,
        child: Material(
          color: selected ? AppColors.navy : AppColors.lime100,
          borderRadius: BorderRadius.circular(999),
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              child: Text(tx(text),
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppColors.navy)),
            ),
          ),
        ),
      );
}

class ErrorLine extends StatelessWidget {
  final String? text;
  const ErrorLine(this.text, {super.key});

  @override
  Widget build(BuildContext context) => text == null
      ? const SizedBox.shrink()
      : Semantics(
          liveRegion: true,
          child: Text(text!, style: const TextStyle(color: AppColors.danger, fontSize: 14, fontWeight: FontWeight.w600)),
        );
}

class EmptyText extends StatelessWidget {
  final String text;
  const EmptyText(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Text(tx(text), textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
      );
}

/// Small truck badge drawn with shapes (no image files), like the logo.
class TruckBadge extends StatelessWidget {
  final bool idle;
  const TruckBadge({super.key, this.idle = false});

  @override
  Widget build(BuildContext context) => Container(
        width: 40,
        height: 26,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: idle ? AppColors.muted : AppColors.navy,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white, width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
                width: 9, height: 7, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
            Container(
                width: 12,
                height: 11,
                decoration: BoxDecoration(color: idle ? AppColors.line : AppColors.lime, borderRadius: BorderRadius.circular(2))),
          ],
        ),
      );
}

/// Destination pin: navy circle with a lime centre and a point.
class EndPin extends StatelessWidget {
  const EndPin({super.key});

  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.navy,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Container(
                width: 12, height: 12, decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle)),
          ),
          CustomPaint(size: const Size(14, 10), painter: _PinTip()),
        ],
      );
}

class _PinTip extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = AppColors.navy);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class MapStop {
  final LatLng point;
  final String label; // e.g. "Nkope · 3 off · 4 on"
  final int number; // 0 = start
  final bool auto;
  MapStop(this.point, this.label, this.number, {this.auto = false});
}

class MapTruck {
  final String id;
  final LatLng point;
  final String label;
  final bool idle;
  final String kind; // kabaza, taxi, matola, minibus, lorry (see vehicleKind)
  MapTruck(this.id, this.point, this.label, {this.idle = false, this.kind = 'matola'});
}

/// Google map with trucks, a route line, the trip's end point, numbered stops and the person's own dot.
class FleetMap extends StatefulWidget {
  final List<MapTruck> trucks;
  final List<LatLng>? route;
  final LatLng? end;
  final String? endLabel;
  final List<MapStop> stops;

  /// The person's own position (blue dot) and the space above the framed points.
  final LatLng? me;
  final double topPadding;

  /// false = the map only displays (so a page scroll that starts on it still scrolls the page); [onTap] then opens it bigger.
  final bool interactive;
  final VoidCallback? onTap;

  /// Space covered by panels at the bottom, so the route is framed above them.
  final double bottomPadding;

  /// true = the camera stays on the first vehicle (zoomed in) as it moves, until the person moves the map by hand;
  /// a "recentre" button then brings it back.
  final bool follow;

  /// Draw the person's own position as a top-view car (drivers) instead of the blue dot.
  final bool meAsCar;

  /// Navigation mode: the camera turns to this heading and tilts, so the road ahead is at the top.
  final double? navBearing;

  /// Which top view the own car uses (see vehicleKind).
  final String meKind;

  const FleetMap(
      {super.key,
      this.trucks = const [],
      this.route,
      this.end,
      this.endLabel,
      this.stops = const [],
      this.me,
      this.topPadding = 110,
      this.interactive = true,
      this.onTap,
      this.bottomPadding = 60,
      this.follow = false,
      this.meAsCar = false,
      this.navBearing,
      this.meKind = 'taxi'});

  @override
  State<FleetMap> createState() => _FleetMapState();
}

class _FleetMapState extends State<FleetMap> {
  g.GoogleMapController? _controller;

  g.LatLng _g(LatLng p) => g.LatLng(p.latitude, p.longitude);

  bool _following = true;
  bool _zoomedIn = false;

  void _followNow() {
    final c = _controller;
    if (c == null || widget.trucks.isEmpty) return;
    final p = _g(widget.trucks.first.point);
    if (widget.navBearing != null) {
      c.animateCamera(g.CameraUpdate.newCameraPosition(g.CameraPosition(target: p, zoom: 17.5, bearing: widget.navBearing!, tilt: 50)));
      return;
    }
    if (!_zoomedIn) {
      _zoomedIn = true;
      c.animateCamera(g.CameraUpdate.newLatLngZoom(p, 16));
    } else {
      c.animateCamera(g.CameraUpdate.newLatLng(p));
    }
  }

  List<LatLng> get _points => [
        ...widget.trucks.map((t) => t.point),
        if (widget.end != null) widget.end!,
        ...widget.stops.map((s) => s.point),
        ...?widget.route,
        if (widget.me != null && inMalawi(widget.me!)) widget.me!, // a position outside Malawi is a bad fix: do not zoom out to it
      ];

  String _fitKey(FleetMap w) => '${w.end?.latitude}|${w.route?.length ?? 0}|${w.trucks.length}|${w.stops.length}';

  void _fit() {
    final c = _controller;
    if (c == null) return;
    final pts = _points;
    if (pts.isEmpty) return;
    if (pts.length == 1) {
      c.animateCamera(g.CameraUpdate.newLatLngZoom(_g(pts.first), 14));
      return;
    }
    var south = pts.first.latitude, north = south, west = pts.first.longitude, east = west;
    for (final p in pts) {
      if (p.latitude < south) south = p.latitude;
      if (p.latitude > north) north = p.latitude;
      if (p.longitude < west) west = p.longitude;
      if (p.longitude > east) east = p.longitude;
    }
    if (south == north && west == east) {
      c.animateCamera(g.CameraUpdate.newLatLngZoom(g.LatLng(south, west), 14));
      return;
    }
    c.animateCamera(g.CameraUpdate.newLatLngBounds(
        g.LatLngBounds(southwest: g.LatLng(south, west), northeast: g.LatLng(north, east)), 50));
  }

  @override
  void initState() {
    super.initState();
    _buildMarkers();
  }

  @override
  void didUpdateWidget(covariant FleetMap oldWidget) {
    super.didUpdateWidget(oldWidget);
    _buildMarkers();
    if (widget.follow) {
      if (_following && widget.trucks.isNotEmpty &&
          (oldWidget.trucks.isEmpty || oldWidget.trucks.first.point != widget.trucks.first.point)) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _followNow());
      }
      return;
    }
    if (_fitKey(oldWidget) != _fitKey(widget)) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _fit());
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  final _last = <String, LatLng>{};
  final _bearing = <String, double>{};
  Set<g.Marker> _markers = {};
  int _gen = 0;

  /// Draws the car / stop / flag icons (cached), then shows them.
  Future<void> _buildMarkers() async {
    final gen = ++_gen;
    final out = <g.Marker>{};
    for (final t in widget.trucks) {
      final prev = _last[t.id];
      if (prev != null) {
        final b = MapIcons.bearing(prev.latitude, prev.longitude, t.point.latitude, t.point.longitude);
        if (b != null) {
          _bearing[t.id] = b;
          _last[t.id] = t.point;
        }
      } else {
        _last[t.id] = t.point;
      }
      out.add(g.Marker(
        markerId: g.MarkerId('truck-${t.id}'),
        position: _g(t.point),
        anchor: const Offset(0.5, 0.5),
        flat: true,
        rotation: _bearing[t.id] ?? 0,
        icon: await MapIcons.topCar(idle: t.idle, kind: t.kind),
      ));
      if (t.label.isNotEmpty)
        out.add(g.Marker(
                markerId: g.MarkerId('plate-${t.id}'),
                position: _g(t.point),
                anchor: const Offset(0.5, 0),
                icon: await MapIcons.plate(t.label, idle: t.idle),
              ));

    }
    if (widget.meAsCar && widget.me != null && inMalawi(widget.me!) && !widget.trucks.any((t) => distanceKm(t.point, widget.me!) < 0.05)) {
      final me = widget.me!;
      final prev = _last['me'];
      if (prev == null) {
        _last['me'] = me;
      } else {
        final b = MapIcons.bearing(prev.latitude, prev.longitude, me.latitude, me.longitude);
        if (b != null) {
          _bearing['me'] = b;
          _last['me'] = me;
        }
      }
      out.add(g.Marker(
        markerId: const g.MarkerId('me-car'),
        position: _g(me),
        anchor: const Offset(0.5, 0.5),
        flat: true,
        rotation: _bearing['me'] ?? 0,
        icon: await MapIcons.topCar(kind: widget.meKind),
      ));
    }
    for (final s in widget.stops) {
      // the start point sits under the vehicle at the beginning of a trip: no marker then
      if (s.number == 0 && widget.trucks.any((t) => distanceKm(t.point, s.point) < 0.08)) continue;
      out.add(g.Marker(
        markerId: g.MarkerId('stop-${s.number}-${s.label}'),
        position: _g(s.point),
        infoWindow: g.InfoWindow(title: s.number == 0 ? s.label : '${s.number}. ${s.label}'),
        icon: await MapIcons.number(s.number, auto: s.auto),
      ));
    }
    if (widget.end != null) {
      out.add(g.Marker(
        markerId: const g.MarkerId('end'),
        position: _g(widget.end!),
        infoWindow: g.InfoWindow(title: widget.endLabel ?? tx('Trip ends here')),
        icon: await MapIcons.flag(),
      ));
    }
    if (mounted && gen == _gen) setState(() => _markers = out);
  }

  Set<g.Polyline> get _lines => {
        if ((widget.route?.length ?? 0) > 1)
          g.Polyline(
            polylineId: const g.PolylineId('route'),
            points: [for (final p in widget.route!) _g(p)],
            color: AppColors.navy,
            width: 6,
          ),
      };

  @override
  Widget build(BuildContext context) {
    final pts = _points;
    final map = g.GoogleMap(
      initialCameraPosition: g.CameraPosition(target: _g(pts.isNotEmpty ? pts.first : mangochi), zoom: 12),
      onMapCreated: (c) {
        _controller = c;
        if (widget.follow && widget.trucks.isNotEmpty) {
          _followNow();
        } else {
          _fit();
        }
      },
      markers: _markers,
      polylines: _lines,
      myLocationEnabled: !widget.meAsCar && widget.me != null && inMalawi(widget.me!),
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      mapToolbarEnabled: false,
      compassEnabled: false,
      rotateGesturesEnabled: false,
      scrollGesturesEnabled: widget.interactive,
      zoomGesturesEnabled: widget.interactive,
      tiltGesturesEnabled: false,
      onTap: widget.onTap == null ? null : (_) => widget.onTap!(),
      padding: EdgeInsets.only(bottom: widget.bottomPadding > 30 ? widget.bottomPadding - 30 : 0),
    );
    if (!widget.follow) return map;
    return Stack(children: [
      Positioned.fill(
        // touching the map by hand stops the following
        child: Listener(onPointerDown: (_) {
          if (_following) setState(() => _following = false);
        }, child: map),
      ),
      if (!_following)
        Positioned(
          right: 14,
          bottom: widget.bottomPadding + 12,
          child: FloatingActionButton.small(
            heroTag: 'recentre',
            backgroundColor: Colors.white,
            foregroundColor: AppColors.navy,
            onPressed: () {
              setState(() => _following = true);
              _followNow();
            },
            child: const Icon(Icons.my_location),
          ),
        ),
    ]);
  }
}

/// Yes/No question.
Future<bool> confirmDialog(BuildContext context, String title, String message, {String yes = 'Yes'}) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(yes, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
  return ok ?? false;
}

InputDecoration plainInput(String hint) => InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: AppColors.muted),
      filled: true,
      fillColor: AppColors.surface100,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: BorderSide.none),
    );
