import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'config.dart';
import 'geo.dart';
import 'theme.dart';

enum ButtonKind { lime, navy, outline, ghost, danger }

class AppButton extends StatelessWidget {
  final String title;
  final VoidCallback? onPressed;
  final ButtonKind kind;
  final bool loading;
  final double height;

  const AppButton(this.title,
      {super.key, required this.onPressed, this.kind = ButtonKind.lime, this.loading = false, this.height = 52});

  @override
  Widget build(BuildContext context) {
    final bg = switch (kind) {
      ButtonKind.lime => AppColors.lime,
      ButtonKind.navy => AppColors.navy,
      ButtonKind.outline || ButtonKind.danger => AppColors.surface,
      ButtonKind.ghost => Colors.transparent,
    };
    final fg = switch (kind) {
      ButtonKind.lime || ButtonKind.outline || ButtonKind.ghost => AppColors.navy,
      ButtonKind.navy => Colors.white,
      ButtonKind.danger => AppColors.danger,
    };
    final border = switch (kind) {
      ButtonKind.outline => AppColors.navy,
      ButtonKind.danger => AppColors.danger,
      _ => Colors.transparent,
    };
    return SizedBox(
      height: height,
      child: TextButton(
        onPressed: loading ? null : onPressed,
        style: TextButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          disabledBackgroundColor: bg.withValues(alpha: kind == ButtonKind.ghost ? 0 : 0.6),
          disabledForegroundColor: fg.withValues(alpha: 0.6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: border, width: 2)),
          padding: const EdgeInsets.symmetric(horizontal: 16),
        ),
        child: loading
            ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: fg))
            : Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
      ),
    );
  }
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final Color? borderColor;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    this.color = AppColors.surface,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
          border: borderColor == null ? null : Border.all(color: borderColor!, width: 2),
        ),
        child: child,
      );
}

class FieldLabel extends StatelessWidget {
  final String text;
  const FieldLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Text(
        text,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.muted, letterSpacing: 0.3),
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 2),
        child: FieldLabel(text),
      );
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final bool dark;
  const StatTile(this.label, this.value, {super.key, this.dark = false});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: dark ? AppColors.navy : AppColors.surface, borderRadius: BorderRadius.circular(12)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(fontSize: 12, color: dark ? AppColors.onNavyMuted : AppColors.muted)),
              const SizedBox(height: 2),
              Text(value,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: dark ? Colors.white : AppColors.ink)),
            ],
          ),
        ),
      );
}

class ChoiceChipButton extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const ChoiceChipButton(this.text, {super.key, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        selected: selected,
        child: Material(
          color: selected ? AppColors.navy : AppColors.lime100,
          borderRadius: BorderRadius.circular(999),
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              child: Text(text,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppColors.navy)),
            ),
          ),
        ),
      );
}

class ErrorLine extends StatelessWidget {
  final String? text;
  const ErrorLine(this.text, {super.key});

  @override
  Widget build(BuildContext context) => text == null
      ? const SizedBox.shrink()
      : Semantics(
          liveRegion: true,
          child: Text(text!, style: const TextStyle(color: AppColors.danger, fontSize: 14, fontWeight: FontWeight.w600)),
        );
}

class EmptyText extends StatelessWidget {
  final String text;
  const EmptyText(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
      );
}

/// Small truck badge drawn with shapes (no image files), like the logo.
class TruckBadge extends StatelessWidget {
  final bool idle;
  const TruckBadge({super.key, this.idle = false});

  @override
  Widget build(BuildContext context) => Container(
        width: 40,
        height: 26,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: idle ? AppColors.muted : AppColors.navy,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white, width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
                width: 9, height: 7, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
            Container(
                width: 12,
                height: 11,
                decoration: BoxDecoration(color: idle ? AppColors.line : AppColors.lime, borderRadius: BorderRadius.circular(2))),
          ],
        ),
      );
}

/// Destination pin: navy circle with a lime centre and a point.
class EndPin extends StatelessWidget {
  const EndPin({super.key});

  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.navy,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Container(
                width: 12, height: 12, decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle)),
          ),
          CustomPaint(size: const Size(14, 10), painter: _PinTip()),
        ],
      );
}

class _PinTip extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = AppColors.navy);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class MapStop {
  final LatLng point;
  final String label; // e.g. "Nkope · 3 off · 4 on"
  final int number; // 0 = start
  final bool auto;
  MapStop(this.point, this.label, this.number, {this.auto = false});
}

class MapTruck {
  final String id;
  final LatLng point;
  final String label;
  final bool idle;
  MapTruck(this.id, this.point, this.label, {this.idle = false});
}

/// Free OpenStreetMap map with trucks, a route line and the trip's end point.
/// Works on phones and on the web.
class FleetMap extends StatefulWidget {
  final List<MapTruck> trucks;
  final List<LatLng>? route;
  final LatLng? end;
  final String? endLabel;
  final List<MapStop> stops;

  /// Space covered by panels at the bottom, so the route is framed above them.
  final double bottomPadding;

  const FleetMap(
      {super.key,
      this.trucks = const [],
      this.route,
      this.end,
      this.endLabel,
      this.stops = const [],
      this.bottomPadding = 60});

  @override
  State<FleetMap> createState() => _FleetMapState();
}

class _FleetMapState extends State<FleetMap> {
  final _controller = MapController();
  bool _ready = false;

  List<LatLng> get _points => [
        ...widget.trucks.map((t) => t.point),
        if (widget.end != null) widget.end!,
        ...widget.stops.map((s) => s.point),
        ...?widget.route,
      ];

  String _fitKey(FleetMap w) => '${w.end?.latitude}|${w.route?.length ?? 0}|${w.trucks.length}|${w.stops.length}';

  void _fit() {
    if (!_ready) return;
    final pts = _points;
    if (pts.length > 1) {
      _controller.fitCamera(CameraFit.coordinates(
        coordinates: pts,
        padding: EdgeInsets.fromLTRB(50, 110, 50, widget.bottomPadding + 30),
        maxZoom: 15,
      ));
    } else if (pts.length == 1) {
      _controller.move(pts.first, 14);
    }
  }

  @override
  void didUpdateWidget(covariant FleetMap oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_fitKey(oldWidget) != _fitKey(widget)) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _fit());
    }
  }

  @override
  Widget build(BuildContext context) {
    final pts = _points;
    return FlutterMap(
      mapController: _controller,
      options: MapOptions(
        initialCenter: pts.isNotEmpty ? pts.first : mangochi,
        initialZoom: 12,
        backgroundColor: AppColors.mapGround,
        interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
        onMapReady: () {
          _ready = true;
          _fit();
        },
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: Config.userAgent,
        ),
        if ((widget.route?.length ?? 0) > 1)
          PolylineLayer(polylines: [
            Polyline(
              points: widget.route!,
              color: AppColors.lime,
              strokeWidth: 5,
              borderColor: AppColors.navy,
              borderStrokeWidth: 2,
            ),
          ]),
        MarkerLayer(markers: [
          for (final s in widget.stops)
            Marker(
              point: s.point,
              width: 170,
              height: 30,
              alignment: const Alignment(0.85, 0),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 26,
                  height: 26,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: s.number == 0 ? Colors.white : (s.auto ? AppColors.warning : AppColors.navy),
                    shape: BoxShape.circle,
                    border: Border.all(color: s.number == 0 ? AppColors.navy : Colors.white, width: 3),
                  ),
                  child: s.number == 0
                      ? null
                      : Text(s.auto ? '?' : '${s.number}',
                          style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(width: 4),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6)),
                    child: Text(s.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.navy)),
                  ),
                ),
              ]),
            ),
          if (widget.end != null)
            Marker(
              point: widget.end!,
              width: 160,
              height: 74,
              alignment: Alignment.topCenter,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(8)),
                    child: Text(widget.endLabel ?? 'Trip ends here',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(height: 2),
                  const EndPin(),
                ],
              ),
            ),
          for (final t in widget.trucks)
            Marker(
              point: t.point,
              width: 90,
              height: 48,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TruckBadge(idle: t.idle),
                  Container(
                    margin: const EdgeInsets.only(top: 2),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.9), borderRadius: BorderRadius.circular(4)),
                    child: Text(t.label,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.navy)),
                  ),
                ],
              ),
            ),
        ]),
        const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
      ],
    );
  }
}

/// Yes/No question.
Future<bool> confirmDialog(BuildContext context, String title, String message, {String yes = 'Yes'}) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(yes, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
  return ok ?? false;
}

InputDecoration plainInput(String hint) => InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: AppColors.muted),
      filled: true,
      fillColor: AppColors.surface100,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: BorderSide.none),
    );
