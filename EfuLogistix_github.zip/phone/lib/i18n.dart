import 'package:flutter/foundation.dart';

/// English and Chichewa words for the driver screens.
/// The Chichewa was written for this app; please have a Chichewa speaker check it before launch.
final language = ValueNotifier<String>('en');

String tr(String key) {
  final lang = language.value;
  final row = _words[key];
  if (row == null) return key;
  return (lang == 'ny' ? row.$2 : row.$1);
}

const Map<String, (String, String)> _words = {
  'start_shift': ('Start shift', 'Yambani ntchito'),
  'go_on_duty': ('Go on duty · drive to rank', 'Yambani ntchito · pitani ku siteji'),
  'on_duty_at': ('ON DUTY AT', 'MWAYAMBA NTCHITO NTHAWI'),
  'truck': ('TRUCK', 'GALIMOTO'),
  'mileage_photo': ('PHOTO OF MILEAGE (ODOMETER)', 'CHITHUNZI CHA MAKILOMITA'),
  'type_mileage': ('TYPE THE MILEAGE (KM)', 'LEMBANI MAKILOMITA'),
  'take_photo': ('Take photo', 'Jambulani chithunzi'),
  'retake': ('Retake', 'Jambulaninso'),
  'camera_only': ('Camera only. Pictures from the gallery are not allowed.',
      'Kamera yokha. Zithunzi zakale siziloledwa.'),
  'tracking_locked': ('Tracking stays on while the phone is locked.',
      'Malo agalimoto akuwonekabe ngakhale foni itatsekedwa.'),
  'new_trip': ('New trip', 'Ulendo watsopano'),
  'route': ('ROUTE (FARES SET BY ADMIN)', 'NJIRA (MITENGO YAKHAZIKITSIDWA)'),
  'other_destination': ('Other destination', 'Kopita kwina'),
  'passengers': ('PASSENGERS', 'OKWERA'),
  'fare_each': ('FARE EACH (MWK)', 'MTENGO WA MUNTHU (MWK)'),
  'goods': ('GOODS / LUGGAGE', 'KATUNDU'),
  'trip_total': ('TRIP TOTAL', 'NDALAMA ZONSE'),
  'loaded_record': ('Loaded · record mileage', 'Takweza · lembani makilomita'),
  'start_route': ('Start route', 'Yambani ulendo'),
  'stop_on_way': ('Stop: drop / pick up', 'Imani: tsitsani / kwezani'),
  'dropped_off': ('DROPPED OFF', 'OTSIKA'),
  'picked_up': ('PICKED UP', 'OKWERA ATSOPANO'),
  'going_to': ('NEW PASSENGERS GOING TO', 'OKWERA ATSOPANO AKUPITA'),
  'save_stop': ('Save stop · continue', 'Sungani · pitirizani'),
  'offload': ('Offload · end trip', 'Tsitsani · malizitsani ulendo'),
  'cash_collected': ('Cash collected', 'Ndalama zolandiridwa'),
  'trip_ended': ('Trip ended', 'Ulendo watha'),
  'end_of_day': ('End of day · drop truck', 'Kumapeto kwa tsiku · siyani galimoto'),
  'truck_photos': ('PHOTOS OF THE TRUCK', 'ZITHUNZI ZA GALIMOTO'),
  'to_hand_in': ('To hand in', 'Zopereka'),
  'go_off_duty': ('Drop truck · go off duty', 'Siyani galimoto · malizani ntchito'),
  'change_truck': ('Change truck', 'Sinthani galimoto'),
  'send_to_owner': ('Send to manager', 'Tumizani kwa manijala'),
  'waiting_approval': ('Waiting for manager approval…', 'Tikudikira chilolezo cha manijala…'),
  'documents': ('My documents', 'Zikalata zanga'),
  'add_expense': ('Add fuel or expense', 'Lembani mafuta kapena ndalama zina'),
  'cancel': ('Cancel', 'Lekani'),
  'offline_waiting': ('Offline · %s waiting to upload', 'Palibe intaneti · %s zikudikira kutumizidwa'),
};

/// "Offline · 2 waiting" style text.
String trf(String key, String value) => tr(key).replaceFirst('%s', value);
