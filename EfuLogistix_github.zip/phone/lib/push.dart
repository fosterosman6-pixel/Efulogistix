import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'notices.dart';

/// Messages that arrive while the app is closed are shown by Android itself.
/// This empty handler only has to exist.
@pragma('vm:entry-point')
Future<void> _background(RemoteMessage message) async {}

/// Push notifications (Firebase). Safe when Firebase is not set up: everything is skipped quietly.
class Push {
  Push._();
  static bool _ready = false;
  static String? _token;

  static Future<void> init() async {
    try {
      await Firebase.initializeApp(); // reads google-services.json added at build time
      FirebaseMessaging.onBackgroundMessage(_background);
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission();
      _ready = true;
      // while the app is open the in-app inbox refreshes at once
      FirebaseMessaging.onMessage.listen((_) => NoticeCenter.instance.load());
      fm.onTokenRefresh.listen((t) {
        _token = t;
        _register();
      });
      Supabase.instance.client.auth.onAuthStateChange.listen((data) {
        if (data.session != null) _register();
      });
      await _register();
    } catch (e) {
      debugPrint('Push not active: $e');
    }
  }

  static Future<void> _register() async {
    if (!_ready) return;
    try {
      final db = Supabase.instance.client;
      if (db.auth.currentSession == null) return;
      _token ??= await FirebaseMessaging.instance.getToken();
      if (_token == null) return;
      await db.rpc('register_device', params: {'p_token': _token, 'p_platform': 'android'});
    } catch (e) {
      debugPrint('Push register failed: $e');
    }
  }

  /// Call just before signing out so this phone stops getting that person's messages.
  static Future<void> unregister() async {
    if (!_ready || _token == null) return;
    try {
      await Supabase.instance.client.rpc('unregister_device', params: {'p_token': _token});
    } catch (_) {}
  }
}
