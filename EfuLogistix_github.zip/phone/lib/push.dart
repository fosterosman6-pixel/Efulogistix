import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'notices.dart';

/// Messages that arrive while the app is closed are shown by Android itself.
/// This empty handler only has to exist.
@pragma('vm:entry-point')
Future<void> _background(RemoteMessage message) async {}

/// Push notifications (Firebase). Safe when Firebase is not set up: everything is skipped quietly.
class Push {
  Push._();
  static bool _ready = false;
  static String? _token;
  static final _local = FlutterLocalNotificationsPlugin();

  /// Two Android notification channels: "ring" (hire requests, pickups, SOS: loud, with the phone's ringtone, shows over other apps)
  /// and "messages" (chat and everything else: pops up with the normal tone). The push server names the channel in each push.
  static Future<void> _channels() async {
    await _local.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    final android = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    // Android never changes a channel after it is created, so older copies (possibly silent) are removed and replaced by new ones
    for (final old in const ['efu_ring', 'efu_messages']) {
      try {
        await android?.deleteNotificationChannel(old);
      } catch (_) {}
    }
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      'efu_ring2',
      'Ringing alerts',
      description: 'Messages, chat, booking and trip updates, incoming requests. Rings like a call.',
      importance: Importance.max,
      playSound: true,
      sound: UriAndroidNotificationSound('content://settings/system/ringtone'),
      enableVibration: true,
      audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
    ));
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      'efu_messages2',
      'Messages',
      description: 'Chat messages, booking updates and notices.',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
    ));
  }

  /// Notice kinds that pop up quietly instead of ringing. Empty: everything rings (keep in step with QUIET_KINDS in send-push).
  static const _quietKinds = <String>{};

  /// While the app is open Android shows nothing by itself, so show the alert here (and ring for the urgent ones).
  static Future<void> _showOpen(RemoteMessage m) async {
    final title = m.notification?.title ?? '';
    final ring = !_quietKinds.contains(m.data['kind']);
    final nid = (m.data['notice_id'] ?? '').toString();
    await _local.show(
      nid.isEmpty ? m.hashCode : (nid.hashCode & 0x7fffffff),
      title.isEmpty ? 'EfuLogistix' : title,
      m.notification?.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          ring ? 'efu_ring2' : 'efu_messages2',
          ring ? 'Ringing alerts' : 'Messages',
          importance: ring ? Importance.max : Importance.high,
          priority: ring ? Priority.max : Priority.high,
          fullScreenIntent: ring,
          onlyAlertOnce: true,
        ),
      ),
    );
  }

  static bool _localReady = false;

  /// Ring and pop up from inside the app (used when a new notice arrives while the app is running).
  /// Works without Firebase. The same notice id replaces an earlier alert, so push and this never ring twice.
  static Future<void> ringNow(String noticeId, String title, String? body) async {
    if (!_localReady) return;
    try {
      await _local.show(
        noticeId.hashCode & 0x7fffffff,
        title.isEmpty ? 'EfuLogistix' : title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'efu_ring2',
            'Ringing alerts',
            importance: Importance.max,
            priority: Priority.max,
            fullScreenIntent: true,
            onlyAlertOnce: true,
          ),
        ),
      );
    } catch (e) {
      debugPrint('ring failed: $e');
    }
  }

  static Future<void> init() async {
    try {
      await _channels();
      _localReady = true;
    } catch (e) {
      debugPrint('Local alerts not active: $e');
    }
    try {
      await Firebase.initializeApp(); // reads google-services.json added at build time
      FirebaseMessaging.onBackgroundMessage(_background);
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission();
      _ready = true;
      // while the app is open the in-app inbox refreshes at once
      FirebaseMessaging.onMessage.listen((m) {
        NoticeCenter.instance.load();
        _showOpen(m);
      });
      fm.onTokenRefresh.listen((t) {
        _token = t;
        _register();
      });
      Supabase.instance.client.auth.onAuthStateChange.listen((data) {
        if (data.session != null) _register();
      });
      await _register();
    } catch (e) {
      debugPrint('Push not active: $e');
    }
  }

  static Future<void> _register() async {
    if (!_ready) return;
    try {
      final db = Supabase.instance.client;
      if (db.auth.currentSession == null) return;
      _token ??= await FirebaseMessaging.instance.getToken();
      if (_token == null) return;
      await db.rpc('register_device', params: {'p_token': _token, 'p_platform': 'android'});
    } catch (e) {
      debugPrint('Push register failed: $e');
    }
  }

  /// Call just before signing out so this phone stops getting that person's messages.
  static Future<void> unregister() async {
    if (!_ready || _token == null) return;
    try {
      await Supabase.instance.client.rpc('unregister_device', params: {'p_token': _token});
    } catch (_) {}
  }
}
