import 'package:flutter/material.dart';

import '../app_state.dart';
import '../format.dart';
import '../i18n.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat_screen.dart';

class _Thread {
  final String? bookingId;
  final String peerId;
  String name = '';
  String preview = '';
  DateTime at;
  int unread = 0;
  _Thread(this.bookingId, this.peerId, this.at);
}

/// All of this person's conversations in one list: tap one to open it.
class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<_Thread>? _threads;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile?.id;
    if (me == null) return;
    try {
      final rows = await db
          .from('chat_messages')
          .select('booking_id, sender_id, recipient_id, kind, body, created_at, read_at')
          .or('sender_id.eq.$me,recipient_id.eq.$me')
          .order('created_at', ascending: false)
          .limit(400);
      final map = <String, _Thread>{};
      for (final r in rows as List) {
        final peer = (r['sender_id'] == me ? r['recipient_id'] : r['sender_id']) as String;
        final booking = r['booking_id'] as String?;
        final key = booking ?? 'peer:$peer';
        final at = DateTime.parse(r['created_at'] as String).toLocal();
        final t = map.putIfAbsent(key, () {
          final x = _Thread(booking, peer, at);
          x.preview = switch (r['kind']) {
            'photo' => '📷 ${tx('Photo')}',
            'voice' => '🎤 ${tx('Voice note')}',
            _ => '${r['body'] ?? ''}',
          };
          if (r['sender_id'] == me) x.preview = '${tx('You')}: ${x.preview}';
          return x;
        });
        if (r['recipient_id'] == me && r['read_at'] == null) t.unread++;
      }
      final list = map.values.toList()..sort((a, b) => b.at.compareTo(a.at));
      final ids = list.map((t) => t.peerId).toSet().toList();
      if (ids.isNotEmpty) {
        try {
          final people = await db.from('profiles').select('id, full_name').inFilter('id', ids);
          final names = {for (final p in people as List) p['id'] as String: (p['full_name'] ?? '') as String};
          for (final t in list) {
            t.name = names[t.peerId] ?? '';
          }
        } catch (_) {}
      }
      if (mounted) setState(() => _threads = list);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = _threads;
    return Scaffold(
      appBar: AppBar(
        title: Text(tx('Chats'), style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: list == null
            ? ListView(children: [
                const SizedBox(height: 120),
                Center(child: _error != null ? Text(_error!) : const CircularProgressIndicator()),
              ])
            : list.isEmpty
                ? ListView(children: [const SizedBox(height: 80), EmptyText(tx('No chats yet. Open a booking to message the driver or passenger.'))])
                : ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
                    itemBuilder: (context, i) {
                      final t = list[i];
                      final name = t.name.isEmpty ? tx('Chat') : t.name;
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        leading: CircleAvatar(
                          radius: 24,
                          backgroundColor: AppColors.lime,
                          child: Text(name.substring(0, 1).toUpperCase(),
                              style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy, fontSize: 18)),
                        ),
                        title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: t.unread > 0 ? FontWeight.w800 : FontWeight.w600)),
                        subtitle: Text(t.preview, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: t.unread > 0 ? AppColors.ink : AppColors.muted, fontWeight: t.unread > 0 ? FontWeight.w600 : FontWeight.w400)),
                        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(shortDate(t.at), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                          if (t.unread > 0)
                            Container(
                              margin: const EdgeInsets.only(top: 4),
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(10)),
                              child: Text('${t.unread}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.navy)),
                            ),
                        ]),
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => t.bookingId != null
                                  ? ChatScreen(bookingId: t.bookingId, title: name)
                                  : ChatScreen(peerId: t.peerId, title: name)));
                          _load();
                        },
                      );
                    },
                  ),
      ),
    );
  }
}

/// Header button for the chats list, with a count of unread messages.
class ChatsButton extends StatefulWidget {
  const ChatsButton({super.key});

  @override
  State<ChatsButton> createState() => _ChatsButtonState();
}

class _ChatsButtonState extends State<ChatsButton> {
  int _unread = 0;

  @override
  void initState() {
    super.initState();
    _count();
  }

  Future<void> _count() async {
    final me = appState.profile?.id;
    if (me == null) return;
    try {
      final rows = await db.from('chat_messages').select('id').eq('recipient_id', me).isFilter('read_at', null).limit(99);
      if (mounted) setState(() => _unread = (rows as List).length);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: tx('Chats'),
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChatsScreen()));
          _count();
        },
        icon: Badge(
          isLabelVisible: _unread > 0,
          label: Text('$_unread'),
          child: const Icon(Icons.chat_bubble_outline_rounded, size: 24, color: Colors.white),
        ),
      );
}
