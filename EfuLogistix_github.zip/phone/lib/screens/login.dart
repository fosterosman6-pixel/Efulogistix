import 'package:flutter/material.dart';

import '../app_state.dart';
import '../demo/demo.dart';
import '../theme.dart';
import '../widgets.dart';
import '../i18n.dart';

/// Sign in or create an account as a Passenger, Driver or Vehicle owner.
/// Managers and the admin use the separate web admin panel.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  String _as = 'passenger'; // passenger, driver or owner
  bool _signUp = false;
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  bool _busy = false;
  String? _error;
  String? _info;

  @override
  void initState() {
    super.initState();
    _error = appState.signInNotice;
    appState.signInNotice = null;
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  /// Opens the app with sample data, no account or internet needed.
  Future<void> _tryDemo() async {
    setState(() {
      _error = null;
      _info = null;
      _busy = true;
    });
    try {
      await Demo.enable();
      await db.auth.signInWithPassword(email: Demo.emails[_as]!, password: Demo.password);
    } catch (e) {
      await Demo.disable();
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    setState(() {
      _error = null;
      _info = null;
    });
    final email = _email.text.trim();
    if (email.isEmpty || _password.text.length < 6) {
      setState(() => _error = 'Enter your email and a password of at least 6 characters.');
      return;
    }
    if (_signUp && _name.text.trim().isEmpty) {
      setState(() => _error = 'Enter your full name.');
      return;
    }
    setState(() => _busy = true);
    try {
      if (_signUp) {
        final res = await db.auth.signUp(
          email: email,
          password: _password.text,
          data: {'full_name': _name.text.trim(), 'phone': _phone.text.trim(), 'role': _as},
        );
        if (res.session == null && mounted) {
          setState(() => _info = 'Account created. Check your email to confirm, then sign in.');
        }
      } else {
        final res = await db.auth.signInWithPassword(email: email, password: _password.text);
        // make sure the account matches the button the person chose
        final uid = res.user?.id;
        if (uid != null) {
          final row = await db.from('profiles').select('role').eq('id', uid).maybeSingle();
          final role = (row?['role'] as String?) ?? 'driver';
          if (role == 'manager' || role == 'admin') {
            await appState.signOut(notice: 'Managers and the admin use the EfuLogistix admin panel on a computer, not this app.');
          } else if (role != _as) {
            await appState.signOut(
                notice: 'This is a ${_names[role]?.toLowerCase() ?? role} account. Tap ${_names[role] ?? role} to sign in.');
          }
        }
      }
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  static const _names = {'passenger': 'Passenger', 'driver': 'Driver', 'owner': 'Vehicle owner'};

  Widget _field(String label, TextEditingController c,
          {TextInputType? type, bool obscure = false, String? hint, List<String>? autofill}) =>
      AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FieldLabel(label),
            TextField(
              controller: c,
              keyboardType: type,
              obscureText: obscure,
              autofillHints: autofill,
              decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      );

  Widget _roleButton(String text, IconData icon, String kind) {
    final selected = _as == kind;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        child: Material(
          color: selected ? AppColors.navy : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() {
              _as = kind;
              _error = null;
              _info = null;
            }),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Column(children: [
                Icon(icon, color: selected ? AppColors.lime : AppColors.navy),
                const SizedBox(height: 4),
                Text(text,
                    style: TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w800, color: selected ? Colors.white : AppColors.navy)),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset('assets/logo_full_white.png', height: 120, fit: BoxFit.contain,
                      alignment: Alignment.centerLeft),
                  const SizedBox(height: 6),
                  Text(tx('Book a ride · drive · own vehicles · Mangochi'),
                      style: TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
                ],
              ),
            ),
            Container(
              constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height * 0.72),
              decoration: const BoxDecoration(
                color: AppColors.surface100,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              padding: const EdgeInsets.all(16),
              child: AutofillGroup(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    FieldLabel(tx('I AM A')),
                    const SizedBox(height: 8),
                    Row(children: [
                      _roleButton('Passenger', Icons.person_pin_circle_outlined, 'passenger'),
                      const SizedBox(width: 8),
                      _roleButton('Driver', Icons.local_shipping, 'driver'),
                      const SizedBox(width: 8),
                      _roleButton('Vehicle owner', Icons.key, 'owner'),
                    ]),
                    const SizedBox(height: 16),
                    Text(
                        '${_signUp ? 'Create' : 'Sign in ·'} ${_names[_as]!.toLowerCase()}${_signUp ? ' account' : ''}',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    if (_signUp) ...[
                      _field('FULL NAME', _name, hint: 'e.g. Chikondi Banda', autofill: const [AutofillHints.name]),
                      const SizedBox(height: 12),
                      _field('PHONE', _phone, type: TextInputType.phone, hint: 'e.g. 0991 234 567'),
                      const SizedBox(height: 12),
                    ],
                    _field('EMAIL', _email, type: TextInputType.emailAddress, autofill: const [AutofillHints.email]),
                    const SizedBox(height: 12),
                    _field('PASSWORD', _password, obscure: true, autofill: const [AutofillHints.password]),
                    const SizedBox(height: 12),
                    ErrorLine(_error),
                    if (_info != null)
                      Text(_info!, style: const TextStyle(color: AppColors.lime600, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    AppButton(_signUp ? tx('Create account') : tx('Sign in'), onPressed: _submit, loading: _busy),
                    const SizedBox(height: 4),
                    AppButton(
                        _signUp
                            ? tx('Have an account? Sign in')
                            : tx('New here? Create an account'),
                        kind: ButtonKind.ghost,
                        onPressed: () => setState(() {
                          _signUp = !_signUp;
                          _error = null;
                          _info = null;
                        }),
                      ),
                    const SizedBox(height: 8),
                    AppButton(
                      txf('Try demo as %s · no account', ['${_names[_as]!.toLowerCase()}']),
                      kind: ButtonKind.outline,
                      height: 48,
                      onPressed: _busy ? null : _tryDemo,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text(tx('Sample data from a Mangochi fleet. Nothing is saved to the real database.'),
                          textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 12)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        switch (_as) {
                          'driver' => 'New drivers upload their documents. The admin checks them, then the office matches you with a vehicle.',
                          'owner' => 'Add your vehicles, photos and papers. The admin checks each vehicle before it goes on the road.',
                          _ => 'Book a seat, hire a car or send goods. Cancelling is free.',
                        },
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.muted, fontSize: 13),
                      ),
                    ),
                    Text(tx('Managers and admin use the web admin panel.'),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
