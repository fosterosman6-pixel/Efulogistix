import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';

/// Vehicles and drivers. Managers assign drivers to vehicles; adding vehicles, approving drivers and
/// checking documents is done by the admin in the admin panel.
class FleetScreen extends StatefulWidget {
  const FleetScreen({super.key});

  @override
  State<FleetScreen> createState() => _FleetScreenState();
}

class _FleetScreenState extends State<FleetScreen> {
  final _fleet = FleetLookup();
  final Map<String, String> _missing = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final results = await Future.wait([
        for (final d in _fleet.drivers) db.rpc('missing_documents', params: {'p_driver': d.id}),
      ]);
      _missing.clear();
      for (var i = 0; i < _fleet.drivers.length; i++) {
        _missing[_fleet.drivers[i].id] = (results[i] ?? '').toString();
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _assign(Profile d) async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Vehicle for ${d.displayName}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
          ListTile(
            leading: const Icon(Icons.block),
            title: const Text('No vehicle'),
            onTap: () => Navigator.pop(ctx, ''),
          ),
          for (final t in _fleet.activeTrucks)
            ListTile(
              leading: Icon(Icons.local_shipping, color: t.id == d.truckId ? AppColors.lime600 : AppColors.navy),
              title: Text(_fleet.plateWithCategory(t.id)),
              subtitle: Text(_fleet.driversOf(t.id).map((x) => x.firstName).join(', ')),
              trailing: t.id == d.truckId ? const Icon(Icons.check, color: AppColors.lime600) : null,
              onTap: () => Navigator.pop(ctx, t.id),
            ),
        ]),
      ),
    );
    if (picked == null) return;
    try {
      await db.from('profiles').update({'truck_id': picked.isEmpty ? null : picked}).eq('id', d.id);
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Vehicles & drivers', style: TextStyle(fontWeight: FontWeight.w800)),
          backgroundColor: AppColors.surface,
          foregroundColor: AppColors.ink,
          elevation: 0,
          bottom: const TabBar(tabs: [Tab(text: 'Vehicles'), Tab(text: 'Drivers')]),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                RefreshIndicator(onRefresh: _load, child: _vehicles()),
                RefreshIndicator(onRefresh: _load, child: _drivers()),
              ]),
      ),
    );
  }

  Widget _vehicles() {
    final trucks = _fleet.trucks;
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (trucks.isEmpty) const EmptyText('No vehicles yet. The admin adds vehicles in the admin panel.'),
      for (final t in trucks) ...[
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(_fleet.plateWithCategory(t.id),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              if (!t.active) const StatusPill('Off road', color: AppColors.muted),
            ]),
            if (t.model != null) Text(t.model!, style: const TextStyle(color: AppColors.muted)),
            if (canManage)
              Text('Owner: ${_fleet.owner(t.ownerId)?.displayName ?? 'company'}', style: const TextStyle(fontSize: 13)),
            Text(
              'Drivers: ${_fleet.driversOf(t.id).map((d) => d.firstName).join(', ').ifEmpty('none')}',
              style: const TextStyle(fontSize: 13),
            ),
            Text(
              '${t.currentKm != null ? '${t.currentKm} km' : 'km not known'}'
              '${t.oilLeftKm != null ? ' · oil in ${t.oilLeftKm} km' : ''}'
              '${t.insuranceTo != null ? ' · insurance ${shortDate(t.insuranceTo!)}' : ''}',
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ]),
        ),
        const SizedBox(height: 8),
      ],
    ]);
  }

  Widget _drivers() {
    final drivers = _fleet.drivers;
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (drivers.isEmpty) const EmptyText('No drivers yet. The admin invites drivers in the admin panel.'),
      for (final d in drivers) ...[
        _driverCard(d),
        const SizedBox(height: 8),
      ],
    ]);
  }

  Widget _driverCard(Profile d) {
    final missing = _missing[d.id] ?? '';
    final missingNames = missing.isEmpty ? <String>[] : missing.split(',').map((k) => docNames[k.trim()] ?? k).toList();
    return AppCard(
      borderColor: !d.active ? AppColors.warning : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.displayName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              Text(
                d.truckId == null ? 'No vehicle' : _fleet.plateWithCategory(d.truckId),
                style: const TextStyle(fontSize: 13, color: AppColors.navy, fontWeight: FontWeight.w700),
              ),
            ]),
          ),
          if (d.phone != null)
            IconButton(
              tooltip: 'Call',
              onPressed: () => launchUrl(Uri.parse('tel:${d.phone}')),
              icon: const Icon(Icons.call, color: AppColors.navy),
            ),
        ]),
        const SizedBox(height: 4),
        if (!d.active)
          const Text('Waiting for the admin to approve', style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700))
        else if (missingNames.isEmpty)
          const Text('Documents complete ✓', style: TextStyle(color: AppColors.lime600, fontWeight: FontWeight.w700))
        else
          Text('Missing: ${missingNames.join(', ')}',
              style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
        if (d.nextOfKinName != null)
          Text('Next of kin: ${d.nextOfKinName}${d.nextOfKinRelation != null ? ' (${d.nextOfKinRelation})' : ''}'
              '${d.nextOfKinPhone != null ? ' · ${d.nextOfKinPhone}' : ''}',
              style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: AppButton('Documents',
                kind: ButtonKind.outline,
                height: 40,
                onPressed: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => DriverDocsScreen(driver: d)))),
          ),
          if (canManage) ...[
            const SizedBox(width: 8),
            Expanded(child: AppButton('Assign vehicle', kind: ButtonKind.navy, height: 40, onPressed: () => _assign(d))),
          ],
        ]),
      ]),
    );
  }
}

extension on String {
  String ifEmpty(String other) => isEmpty ? other : this;
}

/// A driver's uploaded documents (view only; the admin approves them).
class DriverDocsScreen extends StatefulWidget {
  final Profile driver;
  const DriverDocsScreen({super.key, required this.driver});

  @override
  State<DriverDocsScreen> createState() => _DriverDocsScreenState();
}

class _DriverDocsScreenState extends State<DriverDocsScreen> {
  List<Doc> _docs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows =
          await db.from('documents').select().eq('driver_id', widget.driver.id).order('created_at', ascending: false);
      if (mounted) setState(() => _docs = rows.map(Doc.fromMap).toList());
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.driver.displayName, style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (_loading) const LinearProgressIndicator(),
        if (!_loading && _docs.isEmpty) const EmptyText('No documents uploaded yet'),
        for (final doc in _docs) ...[
          AppCard(
            borderColor: doc.expired ? AppColors.danger : null,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                Expanded(
                  child: Text(docNames[doc.kind] ?? doc.kind,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                ),
                StatusPill(
                  doc.expired ? 'Expired' : (doc.status == 'approved' ? 'Approved' : doc.status == 'rejected' ? 'Rejected' : 'Waiting'),
                  color: doc.expired || doc.status == 'rejected'
                      ? AppColors.danger
                      : (doc.status == 'approved' ? AppColors.lime600 : AppColors.warning),
                ),
              ]),
              Text(
                [
                  if (doc.number != null) 'No. ${doc.number}',
                  if (doc.licenceClass != null) 'Class ${doc.licenceClass}',
                  if (doc.expiresOn != null) 'Expires ${shortDate(doc.expiresOn!)} ${doc.expiresOn!.year}',
                  if (doc.note != null) doc.note!,
                ].join(' · '),
                style: const TextStyle(fontSize: 12, color: AppColors.muted),
              ),
              const SizedBox(height: 8),
              Row(children: [
                if (doc.frontPath != null) Expanded(child: StoredImage(doc.frontPath, height: 110)),
                if (doc.frontPath != null && doc.backPath != null) const SizedBox(width: 8),
                if (doc.backPath != null) Expanded(child: StoredImage(doc.backPath, height: 110)),
              ]),
            ]),
          ),
          const SizedBox(height: 8),
        ],
      ]),
    );
  }
}
