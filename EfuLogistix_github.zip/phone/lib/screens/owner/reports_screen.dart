import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import '../../i18n.dart';

class _Row {
  final String name;
  int trips = 0;
  int pax = 0;
  double collected = 0;
  double spent = 0;
  int km = 0;
  _Row(this.name);
  double get profit => collected - spent;
}

/// Monthly report: money in and out per vehicle, category and driver. Share on WhatsApp or copy as CSV.
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  static const _months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
    'October', 'November', 'December'];
  final _fleet = FleetLookup();
  late DateTime _month;
  List<Trip> _trips = [];
  List<Expense> _expenses = [];
  double _shortTotal = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _month = DateTime(now.year, now.month);
    _fleet.load().catchError((_) {}).whenComplete(_load);
  }

  Future<void> _load() async {
    final from = _month;
    final to = DateTime(_month.year, _month.month + 1);
    setState(() => _loading = true);
    try {
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db.from('trips').select().eq('status', 'completed').gte('started_at', isoUtc(from)).lt('started_at', isoUtc(to)),
        db.from('expenses').select().gte('spent_at', isoUtc(from)).lt('spent_at', isoUtc(to)),
        db.from('hand_ins').select().gte('day', isoDay(from)).lt('day', isoDay(to)),
      ]);
      if (!mounted) return;
      setState(() {
        _trips = results[0].map(Trip.fromMap).toList();
        _expenses = results[1].map(Expense.fromMap).toList();
        _shortTotal = results[2].map(HandIn.fromMap).fold<double>(0, (s, h) => s + h.short);
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String get _monthName => '${tx(_months[_month.month - 1])} ${_month.year}';

  Map<String, _Row> _group(String Function(String truckId, String? driverId) key) {
    final out = <String, _Row>{};
    for (final t in _trips) {
      final k = key(t.truckId, t.driverId);
      final r = out.putIfAbsent(k, () => _Row(k));
      r.trips++;
      r.pax += t.carried;
      r.collected += t.total;
      r.km += t.odometerKm ?? 0;
    }
    for (final e in _expenses) {
      final k = key(e.truckId, e.createdBy);
      out.putIfAbsent(k, () => _Row(k)).spent += e.amount;
    }
    return out;
  }

  List<_Row> get _byVehicle =>
      (_group((truck, _) => _fleet.truck(truck)?.plate ?? '?').values.toList()..sort((a, b) => b.profit.compareTo(a.profit)));

  List<_Row> get _byCategory => (_group((truck, _) => _fleet.category(_fleet.truck(truck)?.categoryId)?.name ?? 'Other')
      .values
      .toList()
    ..sort((a, b) => b.profit.compareTo(a.profit)));

  /// Drivers ranked by money collected (expenses by the office are left out).
  List<_Row> get _byDriver {
    final out = <String, _Row>{};
    for (final t in _trips) {
      final r = out.putIfAbsent(t.driverId, () => _Row(_fleet.driver(t.driverId)?.displayName ?? 'Driver'));
      r.trips++;
      r.pax += t.carried;
      r.collected += t.total;
      r.km += t.odometerKm ?? 0;
    }
    for (final e in _expenses.where((e) => e.paidBy == 'driver')) {
      out[e.createdBy]?.spent += e.amount;
    }
    return out.values.toList()..sort((a, b) => b.collected.compareTo(a.collected));
  }

  String _text() {
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final spent = _expenses.fold<double>(0, (s, e) => s + e.amount);
    final b = StringBuffer('EfuLogistix report · $_monthName\n')
      ..writeln('Collected ${money(collected)} · Expenses ${money(spent)} · Profit ${money(collected - spent)}')
      ..writeln('${_trips.length} trips · ${_trips.fold<int>(0, (s, t) => s + t.carried)} passengers')
      ..writeln()
      ..writeln('By vehicle:');
    for (final r in _byVehicle) {
      b.writeln('${r.name}: ${money(r.collected)} in, ${money(r.spent)} out, ${money(r.profit)} profit');
    }
    b
      ..writeln()
      ..writeln('Drivers:');
    final drivers = _byDriver;
    for (var i = 0; i < drivers.length; i++) {
      b.writeln('${i + 1}. ${drivers[i].name}: ${drivers[i].trips} trips, ${money(drivers[i].collected)}');
    }
    return b.toString();
  }

  String _csv() {
    final b = StringBuffer('date,trip_no,driver,vehicle,category,from,to,passengers,km,amount\n');
    for (final t in _trips) {
      String q(String s) => '"${s.replaceAll('"', '""')}"';
      final truck = _fleet.truck(t.truckId);
      b.writeln([
        isoDay(t.startedAt.toLocal()),
        t.tripNo,
        q(_fleet.driver(t.driverId)?.displayName ?? ''),
        q(truck?.plate ?? ''),
        q(_fleet.category(truck?.categoryId)?.name ?? ''),
        q(t.pickupName),
        q(t.destName),
        t.carried,
        t.odometerKm ?? '',
        t.total.round(),
      ].join(','));
    }
    b.writeln();
    b.writeln('date,vehicle,category,paid_by,amount,note');
    for (final e in _expenses) {
      b.writeln([
        isoDay(e.spentAt.toLocal()),
        '"${_fleet.truck(e.truckId)?.plate ?? ''}"',
        e.category,
        e.paidBy,
        e.amount.round(),
        '"${(e.note ?? '').replaceAll('"', '""')}"',
      ].join(','));
    }
    return b.toString();
  }

  Future<void> _whatsApp() async {
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(_text())}');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      toast(context, tx('WhatsApp did not open. The report is copied instead.'));
      await Clipboard.setData(ClipboardData(text: _text()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final spent = _expenses.fold<double>(0, (s, e) => s + e.amount);
    final drivers = _byDriver;
    final now = DateTime.now();
    final isCurrent = _month.year == now.year && _month.month == now.month;
    return Scaffold(
      appBar: AppBar(
        title: Text(tx('Reports'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
          Row(children: [
            IconButton(
              onPressed: () {
                _month = DateTime(_month.year, _month.month - 1);
                _load();
              },
              icon: const Icon(Icons.chevron_left),
            ),
            Expanded(
              child: Text(_monthName,
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
            IconButton(
              onPressed: isCurrent
                  ? null
                  : () {
                      _month = DateTime(_month.year, _month.month + 1);
                      _load();
                    },
              icon: const Icon(Icons.chevron_right),
            ),
          ]),
          if (_loading) const LinearProgressIndicator(),
          const SizedBox(height: 8),
          Row(children: [
            StatTile('Collected', money(collected), dark: true),
            const SizedBox(width: 8),
            StatTile('Expenses', money(spent)),
            const SizedBox(width: 8),
            StatTile('Profit', money(collected - spent)),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            StatTile('Trips', '${_trips.length}'),
            const SizedBox(width: 8),
            StatTile('Passengers', '${_trips.fold<int>(0, (s, t) => s + t.carried)}'),
            const SizedBox(width: 8),
            StatTile('Cash short', money(_shortTotal)),
          ]),
          SectionTitle(tx('BY VEHICLE')),
          _table(_byVehicle),
          if (_fleet.categories.length > 1) ...[
            SectionTitle(tx('BY CATEGORY')),
            _table(_byCategory),
          ],
          SectionTitle(tx('DRIVER RANKING')),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            child: Column(children: [
              if (drivers.isEmpty) EmptyText(tx('No trips this month')),
              for (var i = 0; i < drivers.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(children: [
                    SizedBox(
                      width: 28,
                      child: Text('${i + 1}',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, color: i == 0 ? AppColors.lime600 : AppColors.muted)),
                    ),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(drivers[i].name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(txf('%s trips · %s pax · %s km', ['${drivers[i].trips}', '${drivers[i].pax}', '${drivers[i].km}']),
                            style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      ]),
                    ),
                    Text(money(drivers[i].collected), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ),
            ]),
          ),
          const SizedBox(height: 16),
          AppButton(tx('Share on WhatsApp'), onPressed: _trips.isEmpty ? null : _whatsApp),
          const SizedBox(height: 8),
          AppButton(
            tx('Copy as CSV (for Excel)'),
            kind: ButtonKind.outline,
            onPressed: _trips.isEmpty && _expenses.isEmpty
                ? null
                : () async {
                    await Clipboard.setData(ClipboardData(text: _csv()));
                    if (context.mounted) toast(context, tx('Copied. Paste into Excel or Google Sheets.'));
                  },
          ),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }

  Widget _table(List<_Row> rows) => AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        child: Column(children: [
          if (rows.isEmpty) EmptyText(tx('Nothing this month')),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(r.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text(txf('%s trips · in %s · out %s', ['${r.trips}', '${money(r.collected)}', '${money(r.spent)}']),
                        style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
                Text(money(r.profit),
                    style: TextStyle(fontWeight: FontWeight.w800, color: r.profit < 0 ? AppColors.danger : AppColors.ink)),
              ]),
            ),
        ]),
      );
}
