import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import '../../i18n.dart';

const vehicleSides = ['Front', 'Back', 'Left', 'Right', 'Inside'];

/// Owner adds a vehicle in 3 steps: details, photos, papers. The admin checks it before it goes on the road.
/// With [edit] the owner fixes a vehicle the admin sent back (or one still waiting) and sends it again.
class AddVehicleScreen extends StatefulWidget {
  final Truck? edit;
  const AddVehicleScreen({super.key, this.edit});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  int _step = 0;
  List<VehicleCategory> _categories = [];
  VehicleCategory? _category;
  final _plate = TextEditingController();
  final _make = TextEditingController();
  final _model = TextEditingController();
  final _colour = TextEditingController();
  final _year = TextEditingController();
  final _seats = TextEditingController();
  final Map<String, Photo?> _photos = {for (final s in vehicleSides) s: null};
  final Map<String, Photo?> _papers = {};
  final Map<String, DateTime?> _expiry = {};
  String _feePlan = 'monthly';
  bool _busy = false;
  String? _error;

  bool get _editing => widget.edit != null;

  @override
  void initState() {
    super.initState();
    final t = widget.edit;
    if (t != null) {
      _plate.text = t.plate;
      _make.text = t.make ?? '';
      _model.text = t.model ?? '';
      _colour.text = t.colour ?? '';
      _year.text = t.year?.toString() ?? '';
      _seats.text = t.seats?.toString() ?? '';
      _feePlan = t.feePlan;
    }
    _load();
  }

  @override
  void dispose() {
    for (final c in [_plate, _make, _model, _colour, _year, _seats]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await db.from('vehicle_categories').select().eq('active', true).order('name');
      final list = rows.map(VehicleCategory.fromMap).toList();
      if (!mounted) return;
      setState(() {
        _categories = list;
        _category = list.where((c) => c.id == widget.edit?.categoryId).firstOrNull ?? list.firstOrNull;
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  bool _detailsOk() {
    if (_category == null || _plate.text.trim().length < 4 || _make.text.trim().isEmpty) {
      setState(() => _error = 'Choose the type and type the number plate and make.');
      return false;
    }
    return true;
  }

  bool _photosOk() {
    if (_editing) return true; // the old photos stay unless new ones are taken
    final missing = vehicleSides.take(4).where((s) => _photos[s] == null).toList();
    if (missing.isNotEmpty) {
      setState(() => _error = 'Take the ${missing.join(', ').toLowerCase()} photo${missing.length > 1 ? 's' : ''}.');
      return false;
    }
    return true;
  }

  bool _papersOk() {
    if (_editing) return true;
    for (final k in truckDocKinds.where((k) => k.required)) {
      if (_papers[k.key] == null) {
        setState(() => _error = 'Add the ${k.name.toLowerCase()} photo.');
        return false;
      }
      if (k.hasExpiry && _expiry[k.key] == null) {
        setState(() => _error = 'Choose the end date of the ${k.name.toLowerCase()}.');
        return false;
      }
    }
    return true;
  }

  void _next() {
    setState(() => _error = null);
    if (_step == 0 && !_detailsOk()) return;
    if (_step == 1 && !_photosOk()) return;
    setState(() => _step++);
  }

  Future<void> _send() async {
    if (!_papersOk()) return;
    final me = appState.profile;
    if (me == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final newPhotos = [for (final s in vehicleSides) if (_photos[s] != null) _photos[s]!.path];
      final values = {
        'plate': _plate.text.trim().toUpperCase(),
        'make': _make.text.trim(),
        'model': _model.text.trim(),
        'colour': _colour.text.trim().isEmpty ? null : _colour.text.trim(),
        'year': int.tryParse(_year.text.trim()),
        'seats': int.tryParse(_seats.text.trim()),
        'category_id': _category!.id,
        'fee_plan': _feePlan,
        if (newPhotos.isNotEmpty || !_editing) 'photos': newPhotos,
      };
      String truckId;
      if (_editing) {
        truckId = widget.edit!.id;
        await db.from('trucks').update(values).eq('id', truckId);
      } else {
        final row = await db
            .from('trucks')
            .insert({...values, 'owner_id': me.id, 'status': 'pending', 'active': false})
            .select()
            .single();
        truckId = row['id'] as String;
      }
      for (final k in truckDocKinds) {
        final photo = _papers[k.key];
        if (photo == null) continue;
        await db.from('documents').insert({
          'truck_id': truckId,
          'kind': k.key,
          'front_path': photo.path,
          'expires_on': _expiry[k.key] == null ? null : _isoDay(_expiry[k.key]!),
          'status': 'pending',
        });
      }
      if (!mounted) return;
      toast(context, tx('Sent to the admin. You get a message when it is approved.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      final m = e.toString().toLowerCase();
      setState(() => _error = m.contains('duplicate') || m.contains('23505')
          ? 'A vehicle with this number plate is already in the system.'
          : friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = _editing ? 'Fix and send again' : 'Add vehicle';
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text('$title (${_step + 1} of 3)', style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        LinearProgressIndicator(value: (_step + 1) / 3, color: AppColors.lime, backgroundColor: AppColors.line),
        const SizedBox(height: 12),
        if (_editing && widget.edit!.reviewNote != null) ...[
          AppCard(
            borderColor: AppColors.warning,
            child: Text(txf('Admin: %s', ['${widget.edit!.reviewNote}']), style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 12),
        ],
        ..._stepWidgets(),
        const SizedBox(height: 12),
        ErrorLine(_error),
        const SizedBox(height: 8),
        Row(children: [
          if (_step > 0) ...[
            Expanded(child: AppButton(tx('Back'), kind: ButtonKind.outline, onPressed: () => setState(() => _step--))),
            const SizedBox(width: 8),
          ],
          Expanded(
            flex: 2,
            child: _step < 2
                ? AppButton(tx('Next'), onPressed: _next)
                : AppButton(tx('Send to the admin'), loading: _busy, onPressed: _send),
          ),
        ]),
        const SizedBox(height: 8),
        Text(tx('The admin checks every vehicle before it goes on the road.'),
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
      ]),
    );
  }

  List<Widget> _stepWidgets() {
    if (_step == 0) return _details();
    if (_step == 1) return _photosStep();
    return _papersStep();
  }

  List<Widget> _details() => [
        SectionTitle(tx('TYPE')),
        const SizedBox(height: 4),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in _categories)
            InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() => _category = c),
              child: Container(
                width: 100,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: c.id == _category?.id ? AppColors.lime100 : AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: c.id == _category?.id ? AppColors.navy : AppColors.line, width: 2),
                ),
                child: Column(children: [
                  VehicleArt(c.name, width: 76),
                  Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy)),
                  Text(c.seats > 0 ? txf('%s seats', ['${c.seats}']) : tx('Goods'), style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                ]),
              ),
            ),
        ]),
        const SizedBox(height: 12),
        _input('NUMBER PLATE', _plate, hint: 'e.g. MZ 4521', caps: true),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _input('MAKE', _make, hint: 'Toyota')),
          const SizedBox(width: 8),
          Expanded(child: _input('MODEL', _model, hint: 'Hilux')),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _input('COLOUR', _colour, hint: 'White')),
          const SizedBox(width: 8),
          Expanded(child: _input('YEAR', _year, hint: '2014', digits: true)),
          const SizedBox(width: 8),
          Expanded(child: _input('SEATS', _seats, hint: '${_category?.seats ?? ''}', digits: true)),
        ]),
        const SizedBox(height: 12),
        _feePicker(),
      ];

  Widget _feePicker() {
    final c = _category;
    String price(String plan) => c == null
        ? ''
        : switch (plan) {
            'weekly' => '${money(c.feeWeekly)} a week',
            'monthly' => '${money(c.feeMonthly)} a month',
            _ => '${money(c.feePerTrip)} a trip',
          };
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        FieldLabel(tx('EFULOGISTIX FEE · HOW DO YOU WANT TO PAY?')),
        const SizedBox(height: 6),
        for (final plan in Truck.feePlanNames.keys)
          RadioListTile<String>(
            contentPadding: EdgeInsets.zero,
            dense: true,
            value: plan,
            groupValue: _feePlan,
            onChanged: (v) => setState(() => _feePlan = v ?? _feePlan),
            title: Text(Truck.feePlanNames[plan]!, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(price(plan)),
          ),
        Text(tx('Prices are set by the admin for each type of vehicle. You can change the plan later.'),
            style: TextStyle(fontSize: 12, color: AppColors.muted)),
      ]),
    );
  }

  List<Widget> _photosStep() => [
        SectionTitle(tx('PHOTOS OF THE VEHICLE')),
        if (_editing)
          Text(tx('Take new photos only if the admin asked for them.'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 0.85,
          children: [
            for (final s in vehicleSides)
              PhotoSlot(
                label: s == 'Inside' ? 'Inside (optional)' : s,
                fileLabel: 'vehicle_${s.toLowerCase()}',
                photo: _photos[s],
                allowGallery: true,
                height: 90,
                onTaken: (p) => setState(() => _photos[s] = p),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(tx('Tap to take a photo · hold to pick from the gallery. Show the number plate in the front or back photo.'),
            style: TextStyle(fontSize: 12, color: AppColors.muted)),
      ];

  List<Widget> _papersStep() => [
        SectionTitle(tx('PAPERS')),
        const SizedBox(height: 4),
        for (final k in truckDocKinds) ...[
          AppCard(
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                width: 96,
                child: PhotoSlot(
                  label: _papers[k.key] == null ? 'Photo' : 'Photo',
                  fileLabel: 'truck_${k.key}',
                  photo: _papers[k.key],
                  allowGallery: true,
                  onTaken: (p) => setState(() => _papers[k.key] = p),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${k.name}${k.required && !_editing ? '' : ' (optional)'}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(k.help, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  if (k.hasExpiry) ...[
                    const SizedBox(height: 6),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.event, size: 18),
                      label: Text(_expiry[k.key] == null ? tx('End date') : txf('Ends %s %s', ['${shortDate(_expiry[k.key]!)}', '${_expiry[k.key]!.year}'])),
                      onPressed: () async {
                        final now = DateTime.now();
                        final d = await showDatePicker(
                            context: context,
                            initialDate: _expiry[k.key] ?? now.add(const Duration(days: 180)),
                            firstDate: now,
                            lastDate: now.add(const Duration(days: 365 * 5)));
                        if (d != null) setState(() => _expiry[k.key] = d);
                      },
                    ),
                  ],
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 8),
        ],
      ];

  Widget _input(String label, TextEditingController c, {String? hint, bool digits = false, bool caps = false}) => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FieldLabel(label),
          TextField(
            controller: c,
            keyboardType: digits ? TextInputType.number : TextInputType.text,
            textCapitalization: caps ? TextCapitalization.characters : TextCapitalization.words,
            inputFormatters: digits ? [FilteringTextInputFormatter.digitsOnly] : null,
            decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ]),
      );
}

String _isoDay(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// One vehicle of the owner: approval, photos, papers (send a new paper any time), fee plan.
class VehicleDetailScreen extends StatefulWidget {
  final Truck truck;
  final String? category;
  const VehicleDetailScreen({super.key, required this.truck, this.category});

  @override
  State<VehicleDetailScreen> createState() => _VehicleDetailScreenState();
}

class _VehicleDetailScreenState extends State<VehicleDetailScreen> {
  late Truck _t = widget.truck;
  List<Doc> _docs = [];
  VehicleCategory? _cat;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Future.wait<dynamic>([
        db.from('trucks').select().eq('id', _t.id).single(),
        db.from('documents').select().eq('truck_id', _t.id).order('created_at', ascending: false),
        db.from('vehicle_categories').select(),
      ]);
      if (!mounted) return;
      setState(() {
        _t = Truck.fromMap(r[0] as Map<String, dynamic>);
        _docs = (r[1] as List).map((m) => Doc.fromMap(Map<String, dynamic>.from(m as Map))).toList();
        _cat = (r[2] as List)
            .map((m) => VehicleCategory.fromMap(Map<String, dynamic>.from(m as Map)))
            .where((c) => c.id == _t.categoryId)
            .firstOrNull;
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _newPaper(DocKind k) async {
    final sent = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => _NewPaperScreen(truck: _t, kind: k)));
    if (sent == true) _load();
  }

  Future<void> _setPlan(String plan) async {
    try {
      await db.from('trucks').update({'fee_plan': plan}).eq('id', _t.id);
      await _load();
      if (mounted) toast(context, txf('Fee plan: %s (from the next period)', ['${Truck.feePlanNames[plan]}']));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _t;
    final (status, color) = t.approved
        ? (t.active ? 'On the road' : 'Approved · off road', AppColors.lime600)
        : t.rejected
            ? ('Sent back by the admin', AppColors.danger)
            : ('Waiting for the admin', AppColors.warning);
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(t.plate, style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (_loading) const LinearProgressIndicator(),
          AppCard(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              VehicleTile(_cat?.name ?? widget.category, width: 72),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t.plate, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  Text([if (_cat != null) _cat!.name, if (t.looks.isNotEmpty) t.looks, if (t.year != null) '${t.year}'].join(' · '),
                      style: const TextStyle(color: AppColors.muted)),
                  const SizedBox(height: 6),
                  StatusPill(status, color: color),
                ]),
              ),
            ]),
          ),
          if (t.reviewNote != null && !t.approved) ...[
            const SizedBox(height: 8),
            AppCard(borderColor: AppColors.warning, child: Text(txf('Admin: %s', ['${t.reviewNote}']))),
          ],
          if (!t.approved) ...[
            const SizedBox(height: 8),
            AppButton(t.rejected ? tx('Fix and send again') : tx('Change details'), kind: ButtonKind.outline, onPressed: () async {
              final sent = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => AddVehicleScreen(edit: t)));
              if (sent == true) _load();
            }),
          ],
          if (t.photos.isNotEmpty) ...[
            SectionTitle(tx('PHOTOS')),
            SizedBox(
              height: 90,
              child: ListView(scrollDirection: Axis.horizontal, children: [
                for (final p in t.photos) Padding(padding: const EdgeInsets.only(right: 8), child: StoredImage(p, height: 90, width: 120)),
              ]),
            ),
          ],
          SectionTitle(tx('PAPERS')),
          Text(tx('A new paper goes to the admin to check. The vehicle keeps running meanwhile.'),
              style: TextStyle(fontSize: 12, color: AppColors.muted)),
          const SizedBox(height: 6),
          for (final k in truckDocKinds) ...[_paper(k), const SizedBox(height: 8)],
          SectionTitle(tx('EFULOGISTIX FEE')),
          AppCard(
            child: Column(children: [
              for (final plan in Truck.feePlanNames.keys)
                RadioListTile<String>(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  value: plan,
                  groupValue: t.feePlan,
                  onChanged: (v) {
                    if (v != null && v != t.feePlan) _setPlan(v);
                  },
                  title: Text(Truck.feePlanNames[plan]!, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: _cat == null
                      ? null
                      : Text(switch (plan) {
                          'weekly' => '${money(_cat!.feeWeekly)} a week',
                          'monthly' => '${money(_cat!.feeMonthly)} a month',
                          _ => '${money(_cat!.feePerTrip)} for each trip',
                        }),
                ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _paper(DocKind k) {
    final list = _docs.where((d) => d.kind == k.key).toList();
    final current = list.where((d) => d.status == 'approved').firstOrNull;
    final waiting = list.where((d) => d.status == 'pending').firstOrNull;
    final rejected = list.isNotEmpty && list.first.status == 'rejected' ? list.first : null;
    String line;
    Color color;
    if (waiting != null) {
      line = 'New paper waiting for the admin';
      color = AppColors.warning;
    } else if (rejected != null) {
      line = 'Not accepted${rejected.note != null ? ': ${rejected.note}' : ''} · send again';
      color = AppColors.danger;
    } else if (current == null) {
      line = k.required ? 'Missing' : 'Not added';
      color = k.required ? AppColors.danger : AppColors.muted;
    } else if (current.expired) {
      line = 'Expired ${shortDate(current.expiresOn!)} · send the new one';
      color = AppColors.danger;
    } else {
      line = current.expiresOn == null ? 'Approved ✓' : 'Approved ✓ · ends ${shortDate(current.expiresOn!)} ${current.expiresOn!.year}';
      color = AppColors.lime600;
    }
    return AppCard(
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(k.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text(line, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600)),
          ]),
        ),
        TextButton(onPressed: () => _newPaper(k), child: Text(current == null && waiting == null ? tx('Add') : tx('Update'))),
      ]),
    );
  }
}

class _NewPaperScreen extends StatefulWidget {
  final Truck truck;
  final DocKind kind;
  const _NewPaperScreen({required this.truck, required this.kind});

  @override
  State<_NewPaperScreen> createState() => _NewPaperScreenState();
}

class _NewPaperScreenState extends State<_NewPaperScreen> {
  Photo? _photo;
  DateTime? _ends;
  final _number = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _number.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_photo == null || (widget.kind.hasExpiry && _ends == null)) {
      setState(() => _error = widget.kind.hasExpiry ? 'Take the photo and choose the end date.' : 'Take the photo.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.from('documents').insert({
        'truck_id': widget.truck.id,
        'kind': widget.kind.key,
        'front_path': _photo!.path,
        'number': _number.text.trim().isEmpty ? null : _number.text.trim(),
        'expires_on': _ends == null ? null : _isoDay(_ends!),
        'status': 'pending',
      });
      if (!mounted) return;
      toast(context, tx('Sent to the admin. The vehicle keeps running meanwhile.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.surface100,
        appBar: AppBar(
          title: Text('${widget.kind.name} · ${widget.truck.plate}', style: const TextStyle(fontWeight: FontWeight.w800)),
          backgroundColor: AppColors.navy,
          foregroundColor: Colors.white,
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text(widget.kind.help, style: const TextStyle(color: AppColors.muted)),
          const SizedBox(height: 10),
          PhotoSlot(
            label: tx('Photo of the paper'),
            fileLabel: 'truck_${widget.kind.key}',
            photo: _photo,
            allowGallery: true,
            height: 200,
            onTaken: (p) => setState(() => _photo = p),
          ),
          const SizedBox(height: 10),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              FieldLabel(tx('NUMBER ON THE PAPER (OPTIONAL)')),
              TextField(controller: _number, decoration: const InputDecoration(border: InputBorder.none, isDense: true)),
            ]),
          ),
          if (widget.kind.hasExpiry) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.event),
              label: Text(_ends == null ? tx('Choose the end date') : txf('Ends %s %s', ['${shortDate(_ends!)}', '${_ends!.year}'])),
              onPressed: () async {
                final now = DateTime.now();
                final d = await showDatePicker(
                    context: context, initialDate: now.add(const Duration(days: 365)), firstDate: now, lastDate: now.add(const Duration(days: 365 * 5)));
                if (d != null) setState(() => _ends = d);
              },
            ),
          ],
          const SizedBox(height: 12),
          ErrorLine(_error),
          const SizedBox(height: 8),
          AppButton(tx('Send to the admin'), loading: _busy, onPressed: _send),
        ]),
      );
}
