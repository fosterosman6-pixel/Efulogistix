import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import 'trip_route.dart';

const _alertIcons = <String, IconData>{
  'overspeed': Icons.speed,
  'long_stop': Icons.timer_outlined,
  'unrecorded_stop': Icons.wrong_location_outlined,
  'mileage': Icons.straighten,
  'cash_short': Icons.payments_outlined,
  'truck_change': Icons.swap_horiz,
  'no_signal': Icons.signal_cellular_off,
  'service_due': Icons.oil_barrel_outlined,
  'paper_expiry': Icons.description_outlined,
  'document_expiry': Icons.badge_outlined,
};

/// Alerts: things that need a look. Managers approve truck changes and mark alerts done; vehicle owners only see.
class AlertsTab extends StatefulWidget {
  final VoidCallback? onChanged;
  const AlertsTab({super.key, this.onChanged});

  @override
  State<AlertsTab> createState() => _AlertsTabState();
}

class _AlertsTabState extends State<AlertsTab> {
  final _fleet = FleetLookup();
  List<AppAlert> _alerts = [];
  bool _showDone = false;
  bool _loading = true;
  LiveUpdates? _live;

  @override
  void initState() {
    super.initState();
    _fleet.load().catchError((_) {}).whenComplete(_load);
    _live = LiveUpdates('alerts', ['alerts'], _load);
  }

  @override
  void dispose() {
    _live?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await db
          .from('alerts')
          .select()
          .eq('resolved', _showDone)
          .order('created_at', ascending: false)
          .limit(100);
      if (mounted) setState(() => _alerts = rows.map(AppAlert.fromMap).toList());
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _markAllSeen() async {
    if (!canManage) return;
    try {
      await db.from('alerts').update({'seen': true}).eq('seen', false);
      await _load();
      widget.onChanged?.call();
    } catch (_) {}
  }

  Future<void> _resolve(AppAlert a) async {
    try {
      await db.from('alerts').update({'resolved': true, 'seen': true}).eq('id', a.id);
      await _load();
      widget.onChanged?.call();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _open(AppAlert a) async {
    if (canManage && !a.seen) {
      db.from('alerts').update({'seen': true}).eq('id', a.id).then((_) => widget.onChanged?.call()).catchError((_) {});
    }
    if (a.kind == 'truck_change' && a.refId != null) {
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => TruckChangeReview(changeId: a.refId!)));
      await _load();
      widget.onChanged?.call();
    } else if (a.tripId != null) {
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => TripRouteScreen(tripId: a.tripId!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.navy,
      child: SafeArea(
        bottom: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 12, 12),
            child: Row(children: [
              const Expanded(
                child: Text('Alerts', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
              ),
              if (canManage && !_showDone)
                TextButton(
                  onPressed: _markAllSeen,
                  child: const Text('Mark all seen', style: TextStyle(color: AppColors.lime, fontWeight: FontWeight.w700)),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(children: [
              _tabChip('Open', !_showDone, () => _switch(false)),
              const SizedBox(width: 8),
              _tabChip('Done', _showDone, () => _switch(true)),
            ]),
          ),
          Expanded(
            child: Container(
              color: AppColors.surface100,
              child: RefreshIndicator(
                onRefresh: () async {
                  try {
                    await db.rpc('run_checks');
                  } catch (_) {}
                  await _load();
                },
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (_loading) const LinearProgressIndicator(),
                    if (!_loading && _alerts.isEmpty)
                      EmptyText(_showDone ? 'Nothing marked done yet.' : 'All quiet. No alerts need a look.'),
                    for (final a in _alerts) ...[_card(a), const SizedBox(height: 10)],
                  ],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  void _switch(bool done) {
    setState(() {
      _showDone = done;
      _loading = true;
    });
    _load();
  }

  Widget _tabChip(String text, bool selected, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? AppColors.lime : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: selected ? AppColors.lime : AppColors.onNavyMuted),
          ),
          child: Text(text,
              style: TextStyle(color: selected ? AppColors.navy : Colors.white, fontWeight: FontWeight.w700)),
        ),
      );

  Widget _card(AppAlert a) {
    final urgent = {'overspeed', 'cash_short', 'truck_change', 'mileage', 'unrecorded_stop'}.contains(a.kind);
    final who = [
      if (a.driverId != null) _fleet.name(a.driverId),
      if (a.truckId != null) _fleet.plateWithCategory(a.truckId),
    ].where((s) => s.isNotEmpty).join(' · ');
    return AppCard(
      borderColor: !a.resolved && !a.seen ? (urgent ? AppColors.danger : AppColors.warning) : null,
      child: InkWell(
        onTap: () => _open(a),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: urgent ? const Color(0xFFFDECEA) : const Color(0xFFFFF4E0),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_alertIcons[a.kind] ?? Icons.notifications, color: urgent ? AppColors.danger : AppColors.warning),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(a.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                if (a.detail != null) Text(a.detail!, style: const TextStyle(fontSize: 13)),
                Text(
                  '${who.isEmpty ? '' : '$who · '}${dayLabel(a.createdAt)} ${clock(a.createdAt)}',
                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ]),
            ),
            if (!a.seen && !a.resolved) const StatusPill('New', color: AppColors.danger),
          ]),
          if (!a.resolved && (a.kind == 'truck_change' || canManage)) ...[
            const SizedBox(height: 10),
            Row(children: [
              if (a.kind == 'truck_change')
                Expanded(
                  child: AppButton(canManage ? 'Review change' : 'See change', height: 40, onPressed: () => _open(a)),
                )
              else if (a.tripId != null)
                Expanded(
                  child: AppButton('See on map', kind: ButtonKind.outline, height: 40, onPressed: () => _open(a)),
                ),
              if (canManage && a.kind != 'truck_change') ...[
                if (a.tripId != null) const SizedBox(width: 8),
                Expanded(child: AppButton('Mark done', kind: ButtonKind.navy, height: 40, onPressed: () => _resolve(a))),
              ],
            ]),
          ],
        ]),
      ),
    );
  }
}

/// A driver asked to move to another vehicle: both mileage photos, the new vehicle's 4 photos, approve or decline.
class TruckChangeReview extends StatefulWidget {
  final String changeId;
  const TruckChangeReview({super.key, required this.changeId});

  @override
  State<TruckChangeReview> createState() => _TruckChangeReviewState();
}

class _TruckChangeReviewState extends State<TruckChangeReview> {
  final _fleet = FleetLookup();
  TruckChange? _c;
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final row = await db.from('truck_changes').select().eq('id', widget.changeId).single();
      if (mounted) setState(() => _c = TruckChange.fromMap(row));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  Future<void> _decide(bool approve) async {
    final c = _c!;
    final ok = await confirmDialog(
      context,
      approve ? 'Approve change?' : 'Decline change?',
      approve
          ? '${_fleet.name(c.driverId)} ends the shift on ${_fleet.plateWithCategory(c.fromTruck)} at ${c.outKm} km '
              'and starts on ${_fleet.plateWithCategory(c.toTruck)} at ${c.inKm} km.'
          : '${_fleet.name(c.driverId)} stays on ${_fleet.plateWithCategory(c.fromTruck)}.',
      yes: approve ? 'Approve' : 'Decline',
    );
    if (!ok) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('decide_truck_change', params: {'p_id': c.id, 'p_approve': approve});
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = friendlyError(e);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Truck change', style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: c == null
          ? Center(child: _error == null ? const CircularProgressIndicator() : ErrorLine(_error))
          : ListView(padding: const EdgeInsets.all(16), children: [
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(
                      child: Text(_fleet.name(c.driverId),
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    ),
                    StatusPill(
                      c.status == 'pending' ? 'Waiting' : (c.status == 'approved' ? 'Approved' : 'Declined'),
                      color: c.status == 'pending'
                          ? AppColors.warning
                          : (c.status == 'approved' ? AppColors.lime600 : AppColors.danger),
                    ),
                  ]),
                  const SizedBox(height: 4),
                  Text('${_fleet.plateWithCategory(c.fromTruck)}  →  ${_fleet.plateWithCategory(c.toTruck)}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.navy)),
                  Text('Reason: ${c.reason}${c.note != null ? ' · "${c.note}"' : ''}'),
                  if (c.parkedAt != null) Text('Old vehicle parked at ${c.parkedAt}'),
                  Text('Asked ${dayLabel(c.createdAt)} ${clock(c.createdAt)}',
                      style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
              const SectionTitle('MILEAGE'),
              Row(children: [
                Expanded(child: _odo('Old vehicle out', c.outKm, c.outPhoto)),
                const SizedBox(width: 8),
                Expanded(child: _odo('New vehicle in', c.inKm, c.inPhoto)),
              ]),
              const SectionTitle('NEW VEHICLE · 4 SIDES'),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 4 / 3,
                children: [for (final p in c.inTruckPhotos) StoredImage(p, height: 120)],
              ),
              const SizedBox(height: 16),
              ErrorLine(_error),
              if (c.status == 'pending' && canManage) ...[
                AppButton('Approve change', loading: _busy, onPressed: _busy ? null : () => _decide(true)),
                const SizedBox(height: 8),
                AppButton('Decline', kind: ButtonKind.outline, onPressed: _busy ? null : () => _decide(false)),
              ],
              if (c.status == 'pending' && !canManage)
                const Text('Waiting for the manager to approve.', style: TextStyle(color: AppColors.muted)),
            ]),
    );
  }

  Widget _odo(String label, int km, String path) => AppCard(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          StoredImage(path, height: 90),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          Text('$km km', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ]),
      );
}
