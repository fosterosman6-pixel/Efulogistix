import 'package:flutter/material.dart';
import '../../icon_art.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../home_ui.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../../profile_header.dart';
import '../../vehicle_art.dart';
import '../chat_screen.dart';
import 'add_vehicle.dart';
import 'alerts_tab.dart';
import 'fleet_data.dart';
import 'handins_tab.dart';
import 'more_tab.dart';
import 'trip_route.dart';
import 'trips_tab.dart';
import '../../i18n.dart';

/// The vehicle owner's app: add vehicles (the admin checks them), see what each one earned and where it is,
/// confirm the drivers' daily hand-ins, pay the drivers' wallets on Monday and the EfuLogistix fee.
class VehicleOwnerHome extends StatefulWidget {
  const VehicleOwnerHome({super.key});

  @override
  State<VehicleOwnerHome> createState() => _VehicleOwnerHomeState();
}

class _VehicleOwnerHomeState extends State<VehicleOwnerHome> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final body = switch (_tab) {
      0 => MyVehiclesTab(goTo: (i) => setState(() => _tab = i)),
      1 => const TripsTab(),
      2 => const HandInsTab(),
      3 => const AlertsTab(),
      _ => const MoreTab(),
    };
    return Scaffold(
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          NavigationDestination(icon: const NavArt('car', Icons.directions_car), selectedIcon: const NavArt('car', Icons.directions_car, selected: true), label: tx('My vehicles')),
          NavigationDestination(icon: const NavArt('route', Icons.route), selectedIcon: const NavArt('route', Icons.route, selected: true), label: tx('Trips')),
          NavigationDestination(icon: const NavArt('cash', Icons.payments), selectedIcon: const NavArt('cash', Icons.payments, selected: true), label: tx('Cash')),
          NavigationDestination(icon: const NavArt('siren', Icons.notifications), selectedIcon: const NavArt('siren', Icons.notifications, selected: true), label: tx('Alerts')),
          NavigationDestination(icon: const NavArt('menu', Icons.menu), selectedIcon: const NavArt('menu', Icons.menu, selected: true), label: tx('More')),
        ],
      ),
    );
  }
}

class _VehicleNumbers {
  int trips = 0;
  int pax = 0;
  int km = 0;
  double collected = 0;
  double spent = 0;
  double get profit => collected - spent;
}

class MyVehiclesTab extends StatefulWidget {
  final void Function(int tab)? goTo; // switch the bottom tab (1 trips, 2 cash, 3 alerts)
  const MyVehiclesTab({super.key, this.goTo});

  @override
  State<MyVehiclesTab> createState() => _MyVehiclesTabState();
}

class _MyVehiclesTabState extends State<MyVehiclesTab> {
  final _fleet = FleetLookup();
  Period _period = Period.today;
  List<Trip> _trips = [];
  List<Trip> _running = [];
  List<Expense> _expenses = [];
  List<TruckLocation> _locations = [];
  List<Trip> _chartTrips = []; // completed trips for the chart (last 7 days, or this month)
  bool _loading = true;
  int _cashWaiting = 0;
  LiveUpdates? _live;
  RealtimeChannel? _posChannel;

  @override
  void initState() {
    super.initState();
    _load();
    _live = LiveUpdates('owner', ['trips'], _load);
    // positions are applied the moment they arrive, no waiting for a reload
    _posChannel = db
        .channel('owner-live-trucks')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'truck_locations',
          callback: (payload) {
            final row = payload.newRecord;
            if (row.isEmpty || !mounted) return;
            final loc = TruckLocation.fromMap(row);
            if (!_fleet.trucks.any((t) => t.id == loc.truckId)) return;
            setState(() => _locations = [..._locations.where((l) => l.truckId != loc.truckId), loc]);
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    _live?.dispose();
    final c = _posChannel;
    if (c != null) db.removeChannel(c);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final from = isoUtc(periodStart(_period));
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('trips').select().eq('status', 'completed').gte('started_at', from),
        db.from('trips').select().eq('status', 'in_progress'),
        db.from('expenses').select().gte('spent_at', from),
        db.from('truck_locations').select(),
        db.from('trips').select().eq('status', 'completed').gte('started_at', isoUtc(_chartStart)),
      ]);
      if (!mounted) return;
      // only this owner's vehicles (the database also limits this)
      final mine = _fleet.trucks.map((t) => t.id).toSet();
      setState(() {
        _trips = r[0].map(Trip.fromMap).where((t) => mine.contains(t.truckId)).toList();
        _running = r[1].map(Trip.fromMap).where((t) => mine.contains(t.truckId)).toList();
        _expenses = r[2].map(Expense.fromMap).where((e) => mine.contains(e.truckId)).toList();
        _locations = r[3].map(TruckLocation.fromMap).where((l) => mine.contains(l.truckId)).toList();
        _chartTrips = r[4].map(Trip.fromMap).where((t) => mine.contains(t.truckId)).toList();
      });
    } catch (_) {}
    try {
      final waiting = await db.from('hand_ins').select('id').isFilter('received', null);
      if (mounted) setState(() => _cashWaiting = waiting.length);
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  _VehicleNumbers _numbers(String truckId) {
    final n = _VehicleNumbers();
    for (final t in _trips.where((t) => t.truckId == truckId)) {
      n.trips++;
      n.pax += t.carried;
      n.km += t.odometerKm ?? 0;
      n.collected += t.total;
    }
    for (final e in _expenses.where((e) => e.truckId == truckId)) {
      n.spent += e.amount;
    }
    return n;
  }

  /// First day of the chart: the 1st of the month for "This month", otherwise 7 days back.
  DateTime get _chartStart {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return _period == Period.month ? DateTime(now.year, now.month, 1) : today.subtract(const Duration(days: 6));
  }

  /// Money earned per day from [_chartStart] to today.
  List<(DateTime, double)> get _daily {
    final start = _chartStart;
    final now = DateTime.now();
    final days = DateTime(now.year, now.month, now.day).difference(start).inDays + 1;
    final totals = List<double>.filled(days, 0);
    for (final t in _chartTrips) {
      final d = t.startedAt;
      final i = DateTime(d.year, d.month, d.day).difference(start).inDays;
      if (i >= 0 && i < days) totals[i] += t.total;
    }
    return [for (var i = 0; i < days; i++) (start.add(Duration(days: i)), totals[i])];
  }

  Widget _chart() {
    final data = _daily;
    final top = data.fold<double>(0, (m, d) => d.$2 > m ? d.$2 : m);
    final sum = data.fold<double>(0, (s, d) => s + d.$2);
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final many = data.length > 10;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(
            child: Text(_period == Period.month ? tx('Earned each day this month') : tx('Earned each day · last 7 days'),
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ),
          Text(money(sum), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lime600)),
        ]),
        if (top > 0)
          Text(txf('Best day %s', ['${money(top)}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        const SizedBox(height: 12),
        SizedBox(
          height: 130,
          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            for (var i = 0; i < data.length; i++)
              Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: many ? 1 : 4),
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    if (!many && data[i].$2 > 0)
                      FittedBox(
                        child: Text(_short(data[i].$2),
                            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.navy)),
                      ),
                    const SizedBox(height: 2),
                    Container(
                      height: top == 0 ? 2 : 2 + 92 * (data[i].$2 / top),
                      decoration: BoxDecoration(
                        color: i == data.length - 1 ? AppColors.lime : AppColors.navy,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                      ),
                    ),
                    const SizedBox(height: 4),
                    SizedBox(
                      height: 14,
                      child: FittedBox(
                        child: Text(
                          many
                              ? ((data[i].$1.day == 1 || data[i].$1.day % 5 == 0) ? '${data[i].$1.day}' : '')
                              : (i == data.length - 1 ? 'Today' : names[data[i].$1.weekday - 1]),
                          style: TextStyle(
                              fontSize: 11,
                              color: i == data.length - 1 ? AppColors.lime600 : AppColors.muted,
                              fontWeight: i == data.length - 1 ? FontWeight.w800 : FontWeight.w500),
                        ),
                      ),
                    ),
                  ]),
                ),
              ),
          ]),
        ),
        if (top == 0)
          Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(tx('No completed trips yet in these days.'),
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ),
      ]),
    );
  }

  /// 64500 -> "64.5k"
  String _short(double v) {
    if (v >= 1000000) return '${(v / 1000000).toStringAsFixed(1)}m';
    if (v >= 1000) return '${(v / 1000).toStringAsFixed(v >= 100000 ? 0 : 1)}k';
    return v.round().toString();
  }

  Trip? _runningOf(String truckId) => _running.where((t) => t.truckId == truckId).firstOrNull;
  TruckLocation? _locationOf(String truckId) => _locations.where((l) => l.truckId == truckId).firstOrNull;

  @override
  Widget build(BuildContext context) {
    final trucks = _fleet.trucks;
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final spent = _expenses.fold<double>(0, (s, e) => s + e.amount);
    final markers = <MapTruck>[
      for (final l in _locations)
        MapTruck(l.truckId, LatLng(l.lat, l.lng), _fleet.truck(l.truckId)?.plate ?? '', idle: _runningOf(l.truckId) == null,
            kind: vehicleKind(_fleet.category(_fleet.truck(l.truckId)?.categoryId)?.name)),
    ];
    return Container(
      color: AppColors.surface100,
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const ProfileHeader(),
                  const SizedBox(height: 14),
                  _periodSwitch(),
                  const SizedBox(height: 14),
                  Text(tx('Earned'), style: TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                  Text(money(collected), style: const TextStyle(color: AppColors.lime, fontSize: 34, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Row(children: [
                    _headStat(money(spent), tx('Expenses')),
                    _headStat(money(collected - spent), tx('Profit')),
                    _headStat('${_trips.length}', tx('Trips')),
                  ]),
                ]),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          HomeBody(children: [
            if (trucks.isNotEmpty) ...[
              HomeLabel(tx('Money and fleet at a glance')),
              TileRow([
                GlanceTile(
                    value: '${_running.length} / ${trucks.where((t) => t.approved).length}',
                    label: tx('Vehicles on a trip now'),
                    icon: Icons.directions_car_outlined,
                    art: 'car',
                    color: AppColors.lime600,
                    highlight: true,
                    onTap: () => widget.goTo?.call(1)),
                GlanceTile(
                    value: '$_cashWaiting',
                    label: tx('Cash hand-ins to confirm'),
                    icon: Icons.payments_outlined,
                    art: 'cash',
                    color: _cashWaiting > 0 ? AppColors.warning : AppColors.navy,
                    onTap: () => widget.goTo?.call(2)),
              ]),
              if (_warningCount() > 0) ...[
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => widget.goTo?.call(3),
                  child: AppCard(
                    borderColor: AppColors.danger,
                    child: Row(children: [
                      const Icon(Icons.notifications_active_outlined, color: AppColors.danger),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Text(_warningCount() == 1 ? tx('1 paper or servicing alert needs you') : txf('%s papers or servicing alerts need you', ['${_warningCount()}']),
                              style: const TextStyle(fontWeight: FontWeight.w700))),
                      const Icon(Icons.chevron_right),
                    ]),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ],
            if (markers.isNotEmpty) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: SizedBox(
                    height: 200,
                    child: FleetMap(
                        trucks: markers,
                        bottomPadding: 10,
                        interactive: false,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FullMapScreen(trucks: markers))))),
              ),
              const SizedBox(height: 12),
            ],
              if (trucks.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    Expanded(child: HomeLabel(trucks.length == 1 ? tx('Your vehicle') : txf('Your %s vehicles', ['${trucks.length}']))),
                    TextButton.icon(onPressed: _addVehicle, icon: const Icon(Icons.add, size: 18), label: Text(tx('Add vehicle'))),
                  ]),
                ),
              if (!_loading && trucks.isEmpty)
                EmptyText(tx('No vehicles yet. Tap "Add vehicle": add the details, photos and papers, and the admin checks it.')),
              for (final t in trucks.where((t) => !t.approved)) ...[_waitingCard(t), const SizedBox(height: 12)],
              for (final t in trucks.where((t) => t.approved)) ...[_vehicleCard(t), const SizedBox(height: 12)],
              if (trucks.isNotEmpty) ...[_chart(), const SizedBox(height: 12)],
              if (trucks.isEmpty && !_loading)
                AppButton(tx('Add vehicle'), height: 52, onPressed: _addVehicle),
              Text(
                tx('The office matches drivers with your vehicles. Drivers hand in each day\'s money to you: confirm it in Cash.'),
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 12),
              ),
          ]),
        ]),
      ),
    );
  }

  int _warningCount() {
    final now = DateTime.now();
    var n = 0;
    for (final t in _fleet.trucks.where((t) => t.approved)) {
      if ((t.oilLeftKm ?? 99999) < 500) n++;
      if (t.insuranceTo != null && t.insuranceTo!.difference(now).inDays < 30) n++;
      if (t.cofTo != null && t.cofTo!.difference(now).inDays < 30) n++;
    }
    return n;
  }

  Widget _periodSwitch() => Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(color: AppColors.navy700, borderRadius: BorderRadius.circular(999)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          for (final p in Period.values)
            GestureDetector(
              onTap: () {
                setState(() => _period = p);
                _load();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: p == _period ? AppColors.lime : Colors.transparent,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  switch (p) { Period.today => tx('Today'), Period.week => tx('This week'), Period.month => tx('This month') },
                  style: TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w700, color: p == _period ? AppColors.navy : Colors.white),
                ),
              ),
            ),
        ]),
      );

  Widget _headStat(String value, String label) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          Text(label, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
        ]),
      );

  Future<void> _addVehicle() async {
    final sent = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AddVehicleScreen()));
    if (sent == true) _load();
  }

  Future<void> _openVehicle(Truck t) async {
    await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => VehicleDetailScreen(truck: t, category: _fleet.category(t.categoryId)?.name)));
    _load();
  }

  /// A vehicle the admin has not approved yet (or sent back).
  Widget _waitingCard(Truck t) {
    final category = _fleet.category(t.categoryId)?.name;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _openVehicle(t),
      child: AppCard(
        borderColor: t.rejected ? AppColors.danger : AppColors.warning,
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          VehicleTile(category, width: 56),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.plate, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text([if (category != null) category, if (t.looks.isNotEmpty) t.looks].join(' · '),
                  style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              if (t.rejected && t.reviewNote != null)
                Text(txf('Admin: %s', ['${t.reviewNote}']), style: const TextStyle(fontSize: 13, color: AppColors.danger)),
            ]),
          ),
          StatusPill(t.rejected ? tx('Fix and send again') : tx('Admin checking'),
              color: t.rejected ? AppColors.danger : AppColors.warning),
        ]),
      ),
    );
  }

  Widget _vehicleCard(Truck t) {
    final n = _numbers(t.id);
    final running = _runningOf(t.id);
    final loc = _locationOf(t.id);
    final drivers = _fleet.driversOf(t.id);
    final category = _fleet.category(t.categoryId)?.name;

    String status;
    Color statusColor;
    if (!t.active) {
      status = 'Off road';
      statusColor = AppColors.muted;
    } else if (running != null) {
      status = 'On trip to ${running.destName}';
      statusColor = AppColors.lime600;
    } else if (loc != null) {
      final mins = DateTime.now().difference(loc.updatedAt).inMinutes;
      status = 'Parked · ${mins < 1 ? 'now' : mins < 120 ? '$mins min ago' : 'since ${clock(loc.updatedAt)}'}';
      statusColor = AppColors.navy;
    } else {
      status = 'Not on the road yet';
      statusColor = AppColors.muted;
    }

    final warnings = <String>[
      if ((t.oilLeftKm ?? 99999) <= 0) 'Oil change overdue',
      if ((t.oilLeftKm ?? 99999) > 0 && (t.oilLeftKm ?? 99999) < 500) 'Oil change in ${t.oilLeftKm} km',
      if (t.insuranceTo != null && t.insuranceTo!.isBefore(DateTime.now())) 'Insurance expired',
      if (t.insuranceTo != null && !t.insuranceTo!.isBefore(DateTime.now()) &&
          t.insuranceTo!.difference(DateTime.now()).inDays < 30)
        'Insurance ends ${shortDate(t.insuranceTo!)}',
      if (t.cofTo != null && t.cofTo!.isBefore(DateTime.now())) 'COF expired',
      if (t.cofTo != null && !t.cofTo!.isBefore(DateTime.now()) && t.cofTo!.difference(DateTime.now()).inDays < 30)
        'COF ends ${shortDate(t.cofTo!)}',
    ];

    return AppCard(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          VehicleTile(category, width: 56),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.plate, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text([if (category != null) category, if (t.model != null) t.model!].join(' · '),
                  style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              const SizedBox(height: 6),
              StatusPill(status, color: statusColor),
            ]),
          ),
          IconButton(
            tooltip: tx('Papers, photos and fee plan'),
            onPressed: () => _openVehicle(t),
            icon: const Icon(Icons.chevron_right),
          ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          _num(money(n.collected), tx('Earned'), strong: true),
          _num(money(n.spent), tx('Expenses')),
          _num(money(n.profit), tx('Profit')),
        ]),
        const SizedBox(height: 8),
        Text(txf('%s trips · %s passengers · %s km', ['${n.trips}', '${n.pax}', '${n.km}']) +
            '',
            style: const TextStyle(fontSize: 13, color: AppColors.muted)),
        const Divider(height: 20),
        if (drivers.isEmpty)
          Text(tx('No driver yet · the office will match one and invite you both to meet'),
              style: TextStyle(color: AppColors.muted))
        else
          for (final d in drivers)
            Row(children: [
              const IconArt('badge', size: 24, fallback: Icons.person_outline),
              const SizedBox(width: 6),
              Expanded(child: Text(txf('Driver: %s', ['${d.displayName}']), style: const TextStyle(fontWeight: FontWeight.w600))),
              IconButton(
                tooltip: tx('Message'),
                visualDensity: VisualDensity.compact,
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(peerId: d.id, title: d.firstName))),
                icon: const Icon(Icons.chat_bubble_outline, color: AppColors.navy),
              ),
              if (d.phone != null)
                IconButton(
                  tooltip: tx('Call driver'),
                  visualDensity: VisualDensity.compact,
                  onPressed: () => launchUrl(Uri.parse('tel:${d.phone}')),
                  icon: const IconArt('call', size: 26, fallback: Icons.call),
                ),
            ]),
        if (warnings.isNotEmpty) ...[
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final w in warnings) StatusPill(w, color: w.contains('expired') || w.contains('overdue') ? AppColors.danger : AppColors.warning),
          ]),
        ],
        if (running != null) ...[
          const SizedBox(height: 10),
          AppButton(tx('See the trip on the map'),
              kind: ButtonKind.outline,
              height: 44,
              onPressed: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => TripRouteScreen(tripId: running.id)))),
        ],
      ]),
    );
  }

  Widget _num(String value, String label, {bool strong = false}) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value,
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: strong ? AppColors.lime600 : AppColors.ink)),
          ),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]),
      );
}
