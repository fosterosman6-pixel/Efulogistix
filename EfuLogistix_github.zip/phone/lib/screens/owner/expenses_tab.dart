import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../expense.dart';
import 'fleet_data.dart';

const _icons = {
  'fuel': Icons.local_gas_station,
  'repair': Icons.build,
  'tyre': Icons.tire_repair,
  'other': Icons.receipt_long,
};

/// Fuel & expenses: today's spending and profit, per truck this month.
class ExpensesTab extends StatefulWidget {
  const ExpensesTab({super.key});

  @override
  State<ExpensesTab> createState() => _ExpensesTabState();
}

class _ExpensesTabState extends State<ExpensesTab> {
  final _fleet = FleetLookup();
  List<Expense> _month = [];
  double _incomeToday = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    try {
      await _fleet.load();
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db
            .from('expenses')
            .select()
            .gte('spent_at', isoUtc(periodStart(Period.month)))
            .order('spent_at', ascending: false),
        db.from('trips').select('total').neq('status', 'cancelled').gte('started_at', isoUtc(periodStart(Period.today))),
      ]);
      if (!mounted) return;
      setState(() {
        _month = results[0].map(Expense.fromMap).toList();
        _incomeToday = results[1].fold<double>(0, (s, r) => s + toDouble(r['total']));
      });
    } catch (_) {}
  }

  Future<void> _add() async {
    final saved = await Navigator.of(context)
        .push<bool>(MaterialPageRoute(fullscreenDialog: true, builder: (_) => const ExpenseScreen()));
    if (saved == true) _reload();
  }

  @override
  Widget build(BuildContext context) {
    final todayStart = periodStart(Period.today);
    final today = _month.where((e) => !e.spentAt.isBefore(todayStart)).toList();
    final spentToday = today.fold<double>(0, (s, e) => s + e.amount);
    final perTruck = [
      for (final t in _fleet.trucks)
        (
          truck: t,
          total: _month.where((e) => e.truckId == t.id).fold<double>(0, (s, e) => s + e.amount),
          kinds: _month
              .where((e) => e.truckId == t.id)
              .map((e) => (expenseNames[e.category] ?? e.category).toLowerCase())
              .toSet()
              .join(' + '),
        ),
    ].where((r) => r.total > 0 || r.truck.active).toList()
      ..sort((a, b) => b.total.compareTo(a.total));
    final recent = today.isNotEmpty ? today : _month.take(20).toList();

    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      appBar: AppBar(backgroundColor: AppColors.surface, foregroundColor: AppColors.ink, elevation: 0),
      floatingActionButton: !canManage
          ? null
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(width: double.infinity, child: AppButton('+ Add expense', height: 56, onPressed: _add)),
            ),
      body: SafeArea(
        top: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Fuel & expenses', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  Row(children: [
                    StatTile('Spent today', money(spentToday), dark: true),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(12)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('Profit today', style: TextStyle(fontSize: 12, color: AppColors.navy)),
                          Text(money(_incomeToday - spentToday),
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.navy)),
                        ]),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: _reload,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  children: [
                    const SectionTitle('PER VEHICLE THIS MONTH'),
                    AppCard(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      child: Column(children: [
                        if (perTruck.isEmpty) const EmptyText('No vehicles yet'),
                        for (var i = 0; i < perTruck.length; i++)
                          Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              border:
                                  i == perTruck.length - 1 ? null : const Border(bottom: BorderSide(color: AppColors.line)),
                            ),
                            child: Row(children: [
                              Expanded(
                                child: Text.rich(TextSpan(children: [
                                  TextSpan(text: perTruck[i].truck.plate, style: const TextStyle(fontWeight: FontWeight.w700)),
                                  TextSpan(text: perTruck[i].kinds.isEmpty ? ' · nothing yet' : ' · ${perTruck[i].kinds}'),
                                ]), style: const TextStyle(fontSize: 15)),
                              ),
                              Text(money(perTruck[i].total),
                                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                      ]),
                    ),
                    SectionTitle(today.isNotEmpty ? 'TODAY' : 'LATEST THIS MONTH'),
                    if (recent.isEmpty) const EmptyText('No expenses this month'),
                    for (final e in recent) ...[
                      AppCard(
                        child: Row(children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(10)),
                            child: Icon(_icons[e.category] ?? Icons.receipt_long, size: 20, color: AppColors.navy),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(
                                '${expenseNames[e.category] ?? e.category}'
                                '${e.litres != null ? ' ${e.litres!.toStringAsFixed(e.litres! % 1 == 0 ? 0 : 1)} L' : ''}'
                                ' · ${_fleet.truck(e.truckId)?.plate ?? ''}',
                                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                              ),
                              Text(
                                '${_fleet.name(e.createdBy)} · ${e.paidBy == 'office' ? 'office paid' : 'driver paid'}${e.note != null ? ' · ${e.note}' : ''} · '
                                '${today.isNotEmpty ? clock(e.spentAt) : shortDate(e.spentAt)}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 13, color: AppColors.muted),
                              ),
                            ]),
                          ),
                          if (e.receiptPath != null) ...[
                            StoredImage(e.receiptPath, height: 40, width: 40),
                            const SizedBox(width: 8),
                          ],
                          Text(money(e.amount), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                        ]),
                      ),
                      const SizedBox(height: 8),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
