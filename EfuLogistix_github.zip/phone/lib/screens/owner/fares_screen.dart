import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';

/// Fares set by the admin, per vehicle category. View only here; the admin changes them in the admin panel.
class FaresScreen extends StatefulWidget {
  const FaresScreen({super.key});

  @override
  State<FaresScreen> createState() => _FaresScreenState();
}

class _FaresScreenState extends State<FaresScreen> {
  final _fleet = FleetLookup();
  List<RouteFare> _routes = [];
  List<GoodsPrice> _goods = [];
  String? _category;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db.from('routes').select().eq('active', true).order('from_name').order('to_name'),
        db.from('goods_prices').select().eq('active', true).order('label'),
      ]);
      if (!mounted) return;
      setState(() {
        _routes = results[0].map(RouteFare.fromMap).toList();
        _goods = results[1].map(GoodsPrice.fromMap).toList();
      });
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final shown = _routes.where((r) => _category == null || r.categoryId == null || r.categoryId == _category).toList();
    final byFrom = <String, List<RouteFare>>{};
    for (final r in shown) {
      byFrom.putIfAbsent(r.fromName, () => []).add(r);
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fares', style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Fares are set by the admin. Drivers cannot change them.',
              style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [
            ChoiceChipButton('All', selected: _category == null, onTap: () => setState(() => _category = null)),
            for (final c in _fleet.categories.where((c) => c.active))
              ChoiceChipButton(c.name, selected: _category == c.id, onTap: () => setState(() => _category = c.id)),
          ]),
          if (_loading) const LinearProgressIndicator(),
          if (!_loading && shown.isEmpty) const EmptyText('No fares yet'),
          for (final e in byFrom.entries) ...[
            SectionTitle('FROM ${e.key.toUpperCase()}'),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(children: [
                for (final r in e.value)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(r.toName, style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text(
                            '${_fleet.category(r.categoryId)?.name ?? 'Any vehicle'}'
                            '${r.km != null ? ' · ${r.km!.round()} km' : ''}',
                            style: const TextStyle(fontSize: 12, color: AppColors.muted),
                          ),
                        ]),
                      ),
                      Text(money(r.fare), style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                  ),
              ]),
            ),
          ],
          if (_goods.isNotEmpty) ...[
            const SectionTitle('GOODS'),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(children: [
                for (final g in _goods)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: Row(children: [
                      Expanded(child: Text(g.label, style: const TextStyle(fontWeight: FontWeight.w600))),
                      Text(money(g.price), style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                  ),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}
