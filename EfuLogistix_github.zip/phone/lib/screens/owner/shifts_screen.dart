import 'package:flutter/material.dart';
import '../../i18n.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import 'trip_route.dart';

/// Shifts by day: who drove which vehicle, odometer against GPS, and mileage checks.
class ShiftsScreen extends StatefulWidget {
  const ShiftsScreen({super.key});

  @override
  State<ShiftsScreen> createState() => _ShiftsScreenState();
}

class _ShiftsScreenState extends State<ShiftsScreen> {
  final _fleet = FleetLookup();
  DateTime _day = DateTime.now();
  List<Shift> _shifts = [];
  Set<String> _mismatch = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fleet.load().catchError((_) {}).whenComplete(_load);
  }

  Future<void> _load() async {
    final from = DateTime(_day.year, _day.month, _day.day);
    final to = from.add(const Duration(days: 1));
    try {
      final rows = await db
          .from('shifts')
          .select()
          .gte('started_at', isoUtc(from))
          .lt('started_at', isoUtc(to))
          .order('started_at');
      final shifts = rows.map(Shift.fromMap).toList();
      var mismatch = <String>{};
      if (shifts.isNotEmpty) {
        final bad = await db
            .from('odometer_readings')
            .select('shift_id')
            .eq('mismatch', true)
            .inFilter('shift_id', shifts.map((s) => s.id).toList());
        mismatch = bad.map((r) => r['shift_id'].toString()).toSet();
      }
      if (!mounted) return;
      setState(() {
        _shifts = shifts;
        _mismatch = mismatch;
      });
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tx('Shifts & mileage'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
        actions: [
          TextButton.icon(
            onPressed: () async {
              final d = await showDatePicker(
                  context: context, initialDate: _day, firstDate: DateTime(2024), lastDate: DateTime.now());
              if (d != null) {
                setState(() {
                  _day = d;
                  _loading = true;
                });
                _load();
              }
            },
            icon: const Icon(Icons.calendar_today, size: 18),
            label: Text(dayLabel(_day)),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
          if (_loading) const LinearProgressIndicator(),
          if (!_loading && _shifts.isEmpty) EmptyText(tx('No shifts on this day.')),
          for (final s in _shifts) ...[_card(s), const SizedBox(height: 10)],
        ]),
      ),
    );
  }

  Widget _card(Shift s) {
    final odo = s.odometerKm;
    final check = _mismatch.contains(s.id);
    return InkWell(
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShiftDetailScreen(shiftId: s.id)));
        _load();
      },
      child: AppCard(
        borderColor: check && s.review == 'open' ? AppColors.warning : null,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(
              child: Text('${_fleet.name(s.driverId)} · ${_fleet.plateWithCategory(s.truckId)}',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            ),
            if (s.onDuty)
              StatusPill(tx('On duty'), color: AppColors.lime600)
            else if (s.review == 'approved')
              StatusPill(tx('Approved'), color: AppColors.navy)
            else if (s.review == 'flagged')
              StatusPill(tx('Flagged'), color: AppColors.danger)
            else if (check)
              StatusPill(tx('Check km'), color: AppColors.warning)
            else
              StatusPill(tx('To review'), color: AppColors.muted),
          ]),
          const SizedBox(height: 4),
          Text(
            '${clock(s.startedAt)}–${s.onDuty ? 'now' : clock(s.endedAt)} · km ${s.startKm} → ${s.endKm ?? '…'}'
            '${odo != null ? ' · $odo km on odometer' : ''} · ${s.gpsKm.round()} km by GPS'
            '${s.endReason == 'truck_change' ? ' · changed vehicle' : ''}',
            style: const TextStyle(fontSize: 13, color: AppColors.muted),
          ),
        ]),
      ),
    );
  }
}

/// One shift: every mileage photo against GPS, the 4 vehicle photos, the trips, approve or flag.
class ShiftDetailScreen extends StatefulWidget {
  final String shiftId;
  const ShiftDetailScreen({super.key, required this.shiftId});

  @override
  State<ShiftDetailScreen> createState() => _ShiftDetailScreenState();
}

class _ShiftDetailScreenState extends State<ShiftDetailScreen> {
  final _fleet = FleetLookup();
  Shift? _shift;
  List<Reading> _readings = [];
  List<Trip> _trips = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db.from('shifts').select().eq('id', widget.shiftId),
        db.from('odometer_readings').select().eq('shift_id', widget.shiftId).order('taken_at'),
        db.from('trips').select().eq('shift_id', widget.shiftId).neq('status', 'cancelled').order('started_at'),
      ]);
      if (!mounted) return;
      setState(() {
        _shift = results[0].isEmpty ? null : Shift.fromMap(results[0].first);
        _readings = results[1].map(Reading.fromMap).toList();
        _trips = results[2].map(Trip.fromMap).toList();
        if (_shift == null) _error = 'Shift not found.';
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  Future<void> _review(String review) async {
    String? note;
    if (review == 'flagged') {
      final c = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tx('Flag this shift')),
          content: TextField(controller: c, autofocus: true, decoration: plainInput('What is wrong? e.g. 40 km not explained')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Flag'))),
          ],
        ),
      );
      if (ok != true) return;
      note = c.text.trim();
    }
    try {
      await db.from('shifts').update({
        'review': review,
        'review_note': note,
        'reviewed_by': appState.profile?.id,
      }).eq('id', widget.shiftId);
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _shift;
    final collected = _trips.fold<double>(0, (sum, t) => sum + t.total);
    final tripKm = _trips.fold<int>(0, (sum, t) => sum + (t.odometerKm ?? 0));
    return Scaffold(
      appBar: AppBar(
        title: Text(tx('Shift'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: s == null
          ? Center(child: _error == null ? const CircularProgressIndicator() : ErrorLine(_error))
          : ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
              Text('${_fleet.name(s.driverId)} · ${_fleet.plateWithCategory(s.truckId)}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text('${dayLabel(s.startedAt)} · ${clock(s.startedAt)}–${s.onDuty ? 'now' : clock(s.endedAt)}',
                  style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              Row(children: [
                StatTile('Odometer', s.odometerKm == null ? '—' : '${s.odometerKm} km', dark: true),
                const SizedBox(width: 8),
                StatTile('GPS', '${s.gpsKm.round()} km'),
                const SizedBox(width: 8),
                StatTile('On trips', '$tripKm km'),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                StatTile('Trips', '${_trips.length}'),
                const SizedBox(width: 8),
                StatTile('Collected', money(collected)),
              ]),
              if (s.reviewNote != null && s.reviewNote!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(txf('Note: %s', ['${s.reviewNote}']), style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
              ],
              SectionTitle(tx('MILEAGE PHOTOS')),
              if (_readings.isEmpty) EmptyText(tx('No readings yet')),
              for (final r in _readings) ...[
                AppCard(
                  borderColor: r.mismatch ? AppColors.warning : null,
                  child: Row(children: [
                    StoredImage(r.photoPath, height: 56, width: 80),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(txf('%s · typed %s km', ['${r.kindName}', '${r.km}']),
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                        Text(
                          '${clock(r.takenAt)}'
                          '${r.gpsSinceLastKm != null ? ' · GPS ${r.gpsSinceLastKm!.round()} km since last' : ''}'
                          '${r.expectedKm != null ? ' · expected about ${r.expectedKm}' : ''}',
                          style: const TextStyle(fontSize: 12, color: AppColors.muted),
                        ),
                      ]),
                    ),
                    StatusPill(r.mismatch ? tx('Check') : tx('Match'), color: r.mismatch ? AppColors.warning : AppColors.lime600),
                  ]),
                ),
                const SizedBox(height: 8),
              ],
              if (s.startTruckPhotos.isNotEmpty) ...[
                SectionTitle(tx('VEHICLE PHOTOS AT START')),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 4 / 3,
                  children: [for (final p in s.startTruckPhotos) StoredImage(p, height: 120)],
                ),
              ],
              if (s.truckPhotos.isNotEmpty) ...[
                SectionTitle(tx('VEHICLE PHOTOS')),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 4 / 3,
                  children: [for (final p in s.truckPhotos) StoredImage(p, height: 120)],
                ),
              ],
              SectionTitle(tx('TRIPS')),
              if (_trips.isEmpty) EmptyText(tx('No trips')),
              for (final t in _trips) ...[
                InkWell(
                  onTap: () =>
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => TripRouteScreen(tripId: t.id))),
                  child: AppCard(
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('#${t.tripNo} ${t.pickupName} → ${t.destName}',
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                          Text(
                            '${clock(t.startedAt)}–${t.running ? 'now' : clock(t.endedAt)} · ${t.carried} pax'
                            '${t.odometerKm != null ? ' · ${t.odometerKm} km' : ''}',
                            style: const TextStyle(fontSize: 12, color: AppColors.muted),
                          ),
                        ]),
                      ),
                      Text(money(t.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                  ),
                ),
                const SizedBox(height: 8),
              ],
              if (canManage && !s.onDuty) ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: AppButton(s.review == 'approved' ? tx('Approved ✓') : tx('Approve'),
                        onPressed: s.review == 'approved' ? null : () => _review('approved')),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: AppButton(tx('Flag'), kind: ButtonKind.danger, onPressed: () => _review('flagged')),
                  ),
                ]),
              ],
            ]),
    );
  }
}
