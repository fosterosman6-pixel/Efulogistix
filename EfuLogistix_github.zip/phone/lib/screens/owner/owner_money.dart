import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import '../../i18n.dart';

class _DriverPay {
  final Profile? driver;
  final String driverId;
  final List<WalletEntry> entries = [];
  double owed = 0; // short hand-ins kept as owed
  _DriverPay(this.driverId, this.driver);
  double get balance => entries.fold<double>(0, (s, e) => s + e.amount);
  List<WalletEntry> get unpaidEarns {
    // earnings since the last payout
    final sorted = [...entries]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
    final lastPay = sorted.lastIndexWhere((e) => e.kind == 'payout');
    return sorted.skip(lastPay + 1).where((e) => e.kind == 'earn').toList();
  }

  WalletEntry? get lastPayout {
    final p = entries.where((e) => e.kind == 'payout').toList()..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return p.firstOrNull;
  }
}

/// Owner pays each driver's wallet (10% of each day's money after expenses) every Monday.
/// A shortfall can be taken off before marking it paid.
class DriverPayScreen extends StatefulWidget {
  const DriverPayScreen({super.key});

  @override
  State<DriverPayScreen> createState() => _DriverPayScreenState();
}

class _DriverPayScreenState extends State<DriverPayScreen> {
  final _fleet = FleetLookup();
  List<_DriverPay> _pays = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      await _fleet.load();
      final rows = (await db.from('wallet_entries').select().eq('owner_id', me.id).order('created_at', ascending: false).limit(500))
          .map(WalletEntry.fromMap)
          .toList();
      final owed = (await db.from('hand_ins').select().eq('decision', 'owed')).map(HandIn.fromMap).toList();
      final ids = rows.map((r) => r.driverId).toSet().toList();
      final people = ids.isEmpty ? <Map<String, dynamic>>[] : await db.from('profiles').select().inFilter('id', ids);
      final byId = {for (final p in people.map(Profile.fromMap)) p.id: p};
      final map = <String, _DriverPay>{};
      for (final r in rows) {
        map.putIfAbsent(r.driverId, () => _DriverPay(r.driverId, byId[r.driverId])).entries.add(r);
      }
      for (final h in owed) {
        map[h.driverId]?.owed += h.short;
      }
      if (!mounted) return;
      setState(() => _pays = map.values.toList()..sort((a, b) => b.balance.compareTo(a.balance)));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _pay(_DriverPay d) async {
    final deduct = TextEditingController(text: d.owed > 0 ? d.owed.clamp(0, d.balance).round().toString() : '');
    final reference = TextEditingController();
    final note = TextEditingController(text: d.owed > 0 ? 'Short hand-in' : '');
    var method = 'cash';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) {
        final take = parseAmount(deduct.text);
        return AlertDialog(
          title: Text('Pay ${d.driver?.firstName ?? 'driver'}'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(txf('Wallet %s', ['${money(d.balance)}']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              if (d.owed > 0) Text(txf('Short hand-ins kept as owed: %s', ['${money(d.owed)}']), style: const TextStyle(color: AppColors.danger)),
              const SizedBox(height: 10),
              TextField(
                controller: deduct,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => setLocal(() {}),
                decoration: plainInput('Take off first (MWK, optional)'),
              ),
              const SizedBox(height: 8),
              TextField(controller: note, decoration: plainInput('Why (e.g. short hand-in 21 Oct)')),
              const SizedBox(height: 10),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final e in HandIn.methodNames.entries)
                  ChoiceChipButton(e.value, selected: method == e.key, onTap: () => setLocal(() => method = e.key)),
              ]),
              if (method != 'cash') ...[
                const SizedBox(height: 8),
                TextField(controller: reference, decoration: plainInput('Mobile money reference')),
              ],
              const SizedBox(height: 12),
              Text(txf('Pay now: %s', ['${money((d.balance - take).clamp(0, d.balance))}']),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.navy)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Mark paid'))),
          ],
        );
      }),
    );
    if (ok != true) return;
    try {
      await db.rpc('pay_wallet', params: {
        'p_driver': d.driverId,
        'p_deduct': parseAmount(deduct.text),
        'p_method': method,
        'p_reference': reference.text.trim(),
        'p_note': note.text.trim(),
      });
      if (mounted) toast(context, 'Marked paid. ${d.driver?.firstName ?? 'The driver'} gets a message.');
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  void _days(_DriverPay d) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        builder: (ctx, scroll) => ListView(controller: scroll, padding: const EdgeInsets.all(16), children: [
          Text(d.driver?.displayName ?? tx('Driver'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final e in d.entries)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${dayLabel(e.day)} · ${switch (e.kind) { 'earn' => 'earned', 'deduct' => 'taken off', _ => 'paid' }}'),
              subtitle: Text([if (e.note != null) e.note!, if (e.reference != null) 'ref ${e.reference}'].join(' · ')),
              trailing: Text(money(e.amount),
                  style: TextStyle(fontWeight: FontWeight.w800, color: e.amount >= 0 ? AppColors.lime600 : AppColors.navy)),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final due = _pays.where((p) => p.balance > 0).toList();
    final paid = _pays.where((p) => p.balance <= 0 && p.lastPayout != null).toList();
    final total = due.fold<double>(0, (s, p) => s + p.balance);
    final now = DateTime.now();
    final monday = DateTime(now.year, now.month, now.day).add(Duration(days: (8 - now.weekday) % 7));
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(tx('Driver pay'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
          if (_loading) const LinearProgressIndicator(),
          Row(children: [
            StatTile('Driver pay due', money(total), dark: true),
            const SizedBox(width: 8),
            StatTile(monday.day == now.day ? 'Pay day' : 'Next pay day', monday.day == now.day ? 'Today' : dayLabel(monday)),
          ]),
          SectionTitle(tx('10% OF EACH DAY\'S MONEY AFTER EXPENSES')),
          if (!_loading && due.isEmpty) EmptyText(tx('Nothing to pay. Confirm hand-ins in Cash to add the drivers\' 10%.')),
          for (final d in due) ...[_card(d, true), const SizedBox(height: 10)],
          if (paid.isNotEmpty) ...[
            SectionTitle(tx('PAID')),
            for (final d in paid) ...[_card(d, false), const SizedBox(height: 10)],
          ],
          AppCard(
            color: AppColors.lime100,
            child: Text(tx('If a driver handed in short, you can take it from their pay before marking it paid.'),
                style: TextStyle(fontSize: 13)),
          ),
        ]),
      ),
    );
  }

  Widget _card(_DriverPay d, bool due) {
    final days = d.unpaidEarns;
    final plate = _fleet.truck(d.driver?.truckId)?.plate;
    final last = d.lastPayout;
    return AppCard(
      borderColor: due ? AppColors.warning : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Avatar(d.driver, size: 44),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.driver?.displayName ?? tx('Driver'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text(
                  due
                      ? '${plate ?? ''}${plate != null ? ' · ' : ''}${days.length} ${days.length == 1 ? 'day' : 'days'}'
                      : 'Paid ${last == null ? '' : dayLabel(last.day)} · ${money(-(last?.amount ?? 0))}',
                  style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(money(due ? d.balance : -(last?.amount ?? 0)), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            StatusPill(due ? tx('Due') : tx('Paid ✓'), color: due ? AppColors.warning : AppColors.lime600),
          ]),
        ]),
        if (due) ...[
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: AppButton(tx('Mark paid'), height: 42, onPressed: () => _pay(d))),
            const SizedBox(width: 8),
            Expanded(child: AppButton(tx('See days'), kind: ButtonKind.outline, height: 42, onPressed: () => _days(d))),
          ]),
        ],
      ]),
    );
  }
}

/// EfuLogistix fee bills for the owner's vehicles (weekly, monthly or per trip).
class FeesScreen extends StatefulWidget {
  const FeesScreen({super.key});

  @override
  State<FeesScreen> createState() => _FeesScreenState();
}

class _FeesScreenState extends State<FeesScreen> {
  final _fleet = FleetLookup();
  List<FeeBill> _bills = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      await _fleet.load();
      final rows = await db.from('fee_bills').select().eq('owner_id', me.id).order('period_start', ascending: false).limit(100);
      if (mounted) setState(() => _bills = rows.map(FeeBill.fromMap).toList());
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _paid(FeeBill b) async {
    final reference = TextEditingController();
    var method = 'airtel_money';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(txf('I paid %s', ['${money(b.amount)}'])),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final e in HandIn.methodNames.entries)
                ChoiceChipButton(e.value, selected: method == e.key, onTap: () => setLocal(() => method = e.key)),
            ]),
            const SizedBox(height: 8),
            TextField(controller: reference, decoration: plainInput(method == 'cash' ? 'Receipt number (optional)' : 'Mobile money reference')),
            const SizedBox(height: 8),
            Text(tx('The office checks it and marks the bill paid.'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await db.rpc('report_fee_paid', params: {'p_id': b.id, 'p_method': method, 'p_reference': reference.text.trim()});
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final due = _bills.where((b) => b.due).fold<double>(0, (s, b) => s + b.amount);
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(tx('EfuLogistix fee'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
          if (_loading) const LinearProgressIndicator(),
          Row(children: [StatTile('To pay', money(due), dark: true)]),
          SectionTitle(tx('YOUR VEHICLES')),
          for (final t in _fleet.trucks.where((t) => t.approved)) ...[
            AppCard(
              child: Row(children: [
                Expanded(child: Text(_fleet.plateWithCategory(t.id), style: const TextStyle(fontWeight: FontWeight.w700))),
                Text(_planPrice(t), style: const TextStyle(color: AppColors.muted)),
              ]),
            ),
            const SizedBox(height: 6),
          ],
          Text(tx('Change the plan on the vehicle (My vehicles > tap the vehicle).'),
              style: TextStyle(fontSize: 12, color: AppColors.muted)),
          SectionTitle(tx('BILLS')),
          if (!_loading && _bills.isEmpty) EmptyText(tx('No bills yet.')),
          for (final b in _bills) ...[
            AppCard(
              borderColor: b.due && b.reportedAt == null ? AppColors.warning : null,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${_fleet.truck(b.truckId)?.plate ?? ''} · ${Truck.feePlanNames[b.plan] ?? b.plan}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text('${shortDate(b.periodStart)} – ${shortDate(b.periodEnd)}${b.plan == 'per_trip' ? ' · ${b.trips} trips' : ''}',
                          style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                    ]),
                  ),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(money(b.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    StatusPill(
                      b.status == 'paid'
                          ? tx('Paid ✓')
                          : b.status == 'waived'
                              ? tx('Waived')
                              : b.reportedAt != null
                                  ? tx('Checking')
                                  : tx('Due'),
                      color: b.status == 'due' ? AppColors.warning : AppColors.lime600,
                    ),
                  ]),
                ]),
                if (b.due && b.reportedAt == null) ...[
                  const SizedBox(height: 8),
                  AppButton(tx('I paid this'), kind: ButtonKind.outline, height: 40, onPressed: () => _paid(b)),
                ],
                if (b.reference != null)
                  Text(txf('Ref %s', ['${b.reference}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            const SizedBox(height: 8),
          ],
        ]),
      ),
    );
  }

  String _planPrice(Truck t) {
    final c = _fleet.category(t.categoryId);
    if (c == null) return Truck.feePlanNames[t.feePlan] ?? t.feePlan;
    return switch (t.feePlan) {
      'weekly' => 'Weekly · ${money(c.feeWeekly)}',
      'per_trip' => 'Per trip · ${money(c.feePerTrip)}',
      _ => 'Monthly · ${money(c.feeMonthly)}',
    };
  }
}
