import 'package:flutter/material.dart';
import '../../icon_art.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../theme.dart';
import '../profile_screen.dart';
import '../../widgets.dart';
import '../../notices.dart';
import '../../profile_header.dart';
import '../../menu_ui.dart';
import 'expenses_tab.dart';
import 'fares_screen.dart';
import 'fleet_tab.dart';
import 'owner_money.dart';
import 'reports_screen.dart';
import 'service_screen.dart';
import 'shifts_screen.dart';
import 'statement_screen.dart';
import '../support/support_screens.dart';
import '../../i18n.dart';

/// Everything else for a vehicle owner: my drivers, driver pay, fee, shifts and mileage, expenses, service, reports.
class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final p = appState.profile;
    final roleName = p?.roleName ?? '';
    void open(Widget screen) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    return Container(
      color: AppColors.surface,
      child: SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(0, 16, 0, 16), children: [
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => open(const MyProfileScreen()),
            child: AppCard(
            color: AppColors.navy,
            child: Row(children: [
              Avatar(p, size: 44),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p?.displayName ?? '',
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                  Text('$roleName${p?.email != null ? ' · ${p!.email}' : ''}',
                      style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                ]),
              ),
              const Icon(Icons.chevron_right, color: Colors.white),
            ]),
          ))),
          const SizedBox(height: 8),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Text(tx('You see only your own vehicles and your own drivers.'),
              style: TextStyle(color: AppColors.muted, fontSize: 13))),
          const SizedBox(height: 4),
          MenuHeading(tx('Money')),
          MenuRow(art: 'wallet', icon: Icons.account_balance_wallet_outlined, title: tx('Driver pay'), subtitle: tx('Drivers\' 10% wallet · pay every Monday'), onTap: () => open(const DriverPayScreen())),
          MenuRow(art: 'doc', icon: Icons.summarize_outlined, title: tx('Statement'), subtitle: tx('Profit per vehicle, fuel economy, copy to WhatsApp'), onTap: () => open(const StatementScreen())),
          MenuRow(art: 'fee', icon: Icons.receipt_long_outlined, title: tx('EfuLogistix fee'), subtitle: tx('Weekly, monthly or per trip'), onTap: () => open(const FeesScreen())),
          menuDivider,
          MenuHeading(tx('Day to day')),
          MenuRow(art: 'clipboard', icon: Icons.fact_check_outlined, title: tx('Shifts & mileage'), subtitle: tx('Odometer photos against GPS, approve or flag'), onTap: () => open(const ShiftsScreen())),
          MenuRow(art: 'fuel', icon: Icons.local_gas_station_outlined, title: tx('Fuel & expenses'), subtitle: tx('Receipts, who paid, per vehicle'), onTap: () => open(const ExpensesTab())),
          MenuRow(art: 'wrench', icon: Icons.build_outlined, title: tx('Service & papers'), subtitle: tx('Oil changes, insurance, COF'), onTap: () => open(const ServiceScreen())),
          MenuRow(art: 'badge', icon: Icons.badge_outlined, title: tx('My drivers'), subtitle: tx('Your vehicles and the drivers the office matched'), onTap: () => open(const FleetScreen())),
          menuDivider,
          MenuHeading(tx('Business')),
          MenuRow(art: 'chart', icon: Icons.bar_chart, title: tx('Reports'), subtitle: tx('Month totals, driver ranking, share on WhatsApp'), onTap: () => open(const ReportsScreen())),
          MenuRow(art: 'tag', icon: Icons.sell_outlined, title: tx('Fares'), subtitle: tx('Set by the admin, per vehicle category'), onTap: () => open(const FaresScreen())),
          MenuRow(art: 'bell', icon: Icons.notifications_none, title: tx('Messages'), subtitle: tx('From the office'), onTap: () => open(const NoticesScreen())),
          menuDivider,
          const SupportGroup(),
          menuDivider,
          const LogoutRow(),
          const SizedBox(height: 8),
          Text(tx('Matching drivers, fares and settings are done by the EfuLogistix office.'),
              textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 12)),
        ]),
      ),
    );
  }
}
