import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../../notices.dart';
import '../../profile_header.dart';
import 'expenses_tab.dart';
import 'fares_screen.dart';
import 'fleet_tab.dart';
import 'owner_money.dart';
import 'reports_screen.dart';
import 'service_screen.dart';
import 'shifts_screen.dart';
import 'statement_screen.dart';
import '../support/support_screens.dart';
import '../../i18n.dart';

/// Everything else for a vehicle owner: my drivers, driver pay, fee, shifts and mileage, expenses, service, reports.
class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final p = appState.profile;
    final roleName = p?.roleName ?? '';
    void open(Widget screen) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    return Container(
      color: AppColors.surface100,
      child: SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            color: AppColors.navy,
            child: Row(children: [
              Avatar(p, size: 44),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p?.displayName ?? '',
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                  Text('$roleName${p?.email != null ? ' · ${p!.email}' : ''}',
                      style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 8),
          Text(tx('You see only your own vehicles and your own drivers.'),
              style: TextStyle(color: AppColors.muted, fontSize: 13)),
          SectionTitle(tx('MONEY')),
          _item(Icons.account_balance_wallet_outlined, tx('Driver pay'), tx('Drivers\' 10% wallet · pay every Monday'),
              () => open(const DriverPayScreen())),
          _item(Icons.summarize_outlined, tx('Statement'), tx('Profit per vehicle, fuel economy, copy to WhatsApp'),
              () => open(const StatementScreen())),
          _item(Icons.receipt_long_outlined, tx('EfuLogistix fee'), tx('Weekly, monthly or per trip'), () => open(const FeesScreen())),
          SectionTitle(tx('DAY TO DAY')),
          _item(Icons.fact_check_outlined, tx('Shifts & mileage'), tx('Odometer photos against GPS, approve or flag'),
              () => open(const ShiftsScreen())),
          _item(Icons.local_gas_station_outlined, tx('Fuel & expenses'), tx('Receipts, who paid, per vehicle'),
              () => open(const ExpensesTab())),
          _item(Icons.build_outlined, tx('Service & papers'), tx('Oil changes, insurance, COF'),
              () => open(const ServiceScreen())),
          SectionTitle(tx('BUSINESS')),
          _item(Icons.bar_chart, tx('Reports'), tx('Month totals, driver ranking, share on WhatsApp'),
              () => open(const ReportsScreen())),
          _item(Icons.sell_outlined, tx('Fares'), tx('Set by the admin, per vehicle category'), () => open(const FaresScreen())),
          _item(Icons.badge_outlined, tx('My drivers'), tx('Your vehicles and the drivers the office matched'),
              () => open(const FleetScreen())),
          _item(Icons.notifications_outlined, tx('Messages'), tx('From the office'), () => open(const NoticesScreen())),
          _item(Icons.support_agent_outlined, tx('Help & support'), tx('Report a problem, call the office'),
              () => open(const SupportHomeScreen())),
          SectionTitle(tx('SETTINGS')),
          const AppCard(child: LanguageSwitch()),
          const SizedBox(height: 16),
          AppButton(tx('Sign out'), kind: ButtonKind.danger, onPressed: () => appState.signOut()),
          const SizedBox(height: 8),
          Text(tx('Matching drivers, fares and settings are done by the EfuLogistix office.'),
              textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _item(IconData icon, String title, String subtitle, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Material(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          child: ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: AppColors.navy),
            ),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
            trailing: const Icon(Icons.chevron_right),
            onTap: onTap,
          ),
        ),
      );
}
