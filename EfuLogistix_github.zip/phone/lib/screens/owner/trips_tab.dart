import 'package:flutter/material.dart';
import '../../profile_header.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import 'trip_route.dart';
import '../../i18n.dart';

/// Trips & money: totals for today / week / month, by driver, and the latest trips.
class TripsTab extends StatefulWidget {
  const TripsTab({super.key});

  @override
  State<TripsTab> createState() => _TripsTabState();
}

class _DriverTotal {
  final String driverId;
  final String truckId;
  int trips = 0;
  double total = 0;
  _DriverTotal(this.driverId, this.truckId);
}

class _TripsTabState extends State<TripsTab> {
  final _fleet = FleetLookup();
  Period _period = Period.today;
  List<Trip> _trips = [];
  double _spent = 0;
  LiveUpdates? _live;

  @override
  void initState() {
    super.initState();
    _reload();
    _live = LiveUpdates('trips', ['trips'], _load);
  }

  @override
  void dispose() {
    _live?.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    try {
      await _fleet.load();
    } catch (_) {}
    await _load();
  }

  Future<void> _load() async {
    final from = isoUtc(periodStart(_period));
    try {
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db.from('trips').select().neq('status', 'cancelled').gte('started_at', from).order('started_at', ascending: false),
        db.from('expenses').select('amount').gte('spent_at', from),
      ]);
      if (!mounted) return;
      setState(() {
        _trips = results[0].map(Trip.fromMap).toList();
        _spent = results[1].fold<double>(0, (s, r) => s + toDouble(r['amount']));
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final pax = _trips.fold<int>(0, (s, t) => s + t.carried);
    final byDriver = <String, _DriverTotal>{};
    for (final t in _trips) {
      final row = byDriver.putIfAbsent(t.driverId, () => _DriverTotal(t.driverId, t.truckId));
      row.trips++;
      row.total += t.total;
    }
    final drivers = byDriver.values.toList()..sort((a, b) => b.total.compareTo(a.total));

    return Container(
      color: AppColors.navy,
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
                        const Padding(padding: EdgeInsets.fromLTRB(20, 10, 8, 0), child: ProfileHeader()),
Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(
                      child: Text(tx('Trips & money'),
                          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                    ),
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(color: AppColors.navy700, borderRadius: BorderRadius.circular(999)),
                      child: Row(children: [
                        for (final p in Period.values)
                          GestureDetector(
                            onTap: () {
                              setState(() => _period = p);
                              _load();
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(
                                color: p == _period ? AppColors.lime : Colors.transparent,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                switch (p) { Period.today => 'Today', Period.week => 'Week', Period.month => 'Month' },
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: p == _period ? AppColors.navy : Colors.white,
                                ),
                              ),
                            ),
                          ),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  Text(tx('Collected'), style: TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                  Text(money(collected),
                      style: const TextStyle(color: AppColors.lime, fontSize: 34, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Row(children: [
                    _headStat('${_trips.length}', 'Trips'),
                    _headStat('$pax', 'Passengers'),
                    _headStat(money(collected - _spent), 'After expenses'),
                  ]),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: RefreshIndicator(
                  onRefresh: _reload,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      SectionTitle(tx('BY DRIVER')),
                      AppCard(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: Column(children: [
                          if (drivers.isEmpty) EmptyText(tx('No trips yet')),
                          for (var i = 0; i < drivers.length; i++)
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                border: i == drivers.length - 1
                                    ? null
                                    : const Border(bottom: BorderSide(color: AppColors.line)),
                              ),
                              child: Row(children: [
                                Expanded(
                                  child: Text.rich(TextSpan(children: [
                                    TextSpan(
                                        text: _fleet.name(drivers[i].driverId),
                                        style: const TextStyle(fontWeight: FontWeight.w700)),
                                    TextSpan(
                                        text: ' · ${_fleet.plateWithCategory(drivers[i].truckId)} · '
                                            '${drivers[i].trips} ${drivers[i].trips == 1 ? 'trip' : 'trips'}'),
                                  ]), style: const TextStyle(fontSize: 15)),
                                ),
                                Text(money(drivers[i].total),
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                              ]),
                            ),
                        ]),
                      ),
                      SectionTitle(tx('LATEST TRIPS')),
                      for (final t in _trips.take(50)) ...[
                        InkWell(
                          onTap: () => Navigator.of(context)
                              .push(MaterialPageRoute(builder: (_) => TripRouteScreen(tripId: t.id))),
                          child: AppCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                Expanded(
                                  child: Text('${t.pickupName} → ${t.destName}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                                ),
                                Text(money(t.total), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                              ]),
                              Text(
                                '#${t.tripNo} · ${_fleet.name(t.driverId)} · ${_fleet.truck(t.truckId)?.plate ?? ''} · ${t.carried} pax'
                                '${t.goods.isNotEmpty ? ' + ${t.goods.length} goods' : ''} · '
                                '${_period == Period.today ? '' : '${shortDate(t.startedAt)} '}'
                                '${t.running ? '${clock(t.startedAt)}, in progress' : '${clock(t.startedAt)}–${clock(t.endedAt)}'}',
                                style: const TextStyle(fontSize: 13, color: AppColors.muted),
                              ),
                            ],
                          ),
                        ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _headStat(String value, String label) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
          Text(label, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
        ]),
      );
}
