import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../app_state.dart';
import '../../demo/demo.dart';
import '../../format.dart';
import '../../models.dart';

/// Vehicles, categories and drivers, for showing names and plates next to trips.
class FleetLookup {
  List<Truck> trucks = [];
  List<Profile> drivers = [];
  List<Profile> owners = [];
  List<VehicleCategory> categories = [];

  /// A vehicle owner only sees their own vehicles; managers see all.
  Future<void> load() async {
    final me = appState.profile;
    final results = await Future.wait<List<Map<String, dynamic>>>([
      db.from('trucks').select().order('plate'),
      db.from('profiles').select().inFilter('role', ['driver', 'owner']).order('full_name'),
      db.from('vehicle_categories').select().order('name'),
    ]);
    trucks = results[0].map(Truck.fromMap).toList();
    if (me != null && me.isVehicleOwner) trucks = trucks.where((t) => t.ownerId == me.id).toList();
    final people = results[1].map(Profile.fromMap).toList();
    drivers = people.where((p) => p.isDriver).toList();
    owners = people.where((p) => p.isVehicleOwner).toList();
    categories = results[2].map(VehicleCategory.fromMap).toList();
  }

  Profile? owner(String? id) {
    for (final o in owners) {
      if (o.id == id) return o;
    }
    return null;
  }

  /// Drivers currently assigned to [truckId].
  List<Profile> driversOf(String truckId) => drivers.where((d) => d.truckId == truckId).toList();

  Truck? truck(String? id) {
    for (final t in trucks) {
      if (t.id == id) return t;
    }
    return null;
  }

  Profile? driver(String? id) {
    for (final d in drivers) {
      if (d.id == id) return d;
    }
    return null;
  }

  VehicleCategory? category(String? id) {
    for (final c in categories) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// "MZ 4521 · Matola"
  String plateWithCategory(String? truckId) {
    final t = truck(truckId);
    if (t == null) return '';
    final c = category(t.categoryId);
    return c == null ? t.plate : '${t.plate} · ${c.name}';
  }

  /// First name of a driver; entries made by a manager show "Office".
  String name(String? id) => driver(id)?.firstName ?? 'Office';

  List<Truck> get activeTrucks => trucks.where((t) => t.active).toList();
}

/// Calls [onChange] (at most every 2 s) when any of [tables] changes. Call `dispose` on the result.
class LiveUpdates {
  final RealtimeChannel _channel;
  Timer? _timer;

  LiveUpdates(String name, List<String> tables, void Function() onChange) : _channel = db.channel('live-$name') {
    for (final table in tables) {
      _channel.onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: table,
        callback: (_) {
          if (_timer != null) return;
          _timer = Timer(const Duration(seconds: 2), () {
            _timer = null;
            onChange();
          });
        },
      );
    }
    if (!Demo.on) _channel.subscribe(); // the demo has no live connection; screens refresh on their own
  }

  void dispose() {
    _timer?.cancel();
    db.removeChannel(_channel);
  }
}

/// "Wed 21 Oct" style day label.
String dayLabel(DateTime d) {
  return '${weekdayShort(d.weekday)} ${d.day} ${monthShort(d.month)}';
}

String isoDay(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
