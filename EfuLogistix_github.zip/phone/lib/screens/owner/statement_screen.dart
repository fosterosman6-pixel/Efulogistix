import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../theme.dart';
import '../../widgets.dart';

String _iso(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Owner statement: what each vehicle earned, what it cost, the EfuLogistix fee, the profit,
/// and fuel economy (km per litre). Pick this week, this month or last month.
class StatementScreen extends StatefulWidget {
  const StatementScreen({super.key});

  @override
  State<StatementScreen> createState() => _StatementScreenState();
}

class _StatementScreenState extends State<StatementScreen> {
  int _range = 1; // 0 week, 1 this month, 2 last month
  List<Map<String, dynamic>> _rows = [];
  final Map<String, Map<String, dynamic>> _fuel = {};
  final Map<String, Map<String, dynamic>> _target = {};
  bool _loading = true;
  String? _error;

  (DateTime, DateTime) get _dates {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    switch (_range) {
      case 0:
        return (today.subtract(Duration(days: today.weekday - 1)), today);
      case 2:
        final first = DateTime(today.year, today.month - 1, 1);
        return (first, DateTime(today.year, today.month, 0));
      default:
        return (DateTime(today.year, today.month, 1), today);
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final (from, to) = _dates;
    try {
      final rows = await db.rpc('owner_statement', params: {'p_from': _iso(from), 'p_to': _iso(to)});
      final list = List<Map<String, dynamic>>.from(rows as List);
      _fuel.clear();
      _target.clear();
      for (final r in list) {
        try {
          final tp = await db.rpc('target_progress', params: {'p_truck': r['truck_id']});
          final tm = tp is List ? (tp.isEmpty ? null : tp.first) : tp;
          if (tm is Map) _target['${r['truck_id']}'] = Map<String, dynamic>.from(tm);
        } catch (_) {}
        try {
          final f = await db.rpc('fuel_economy', params: {'p_truck': r['truck_id'], 'p_from': _iso(from), 'p_to': _iso(to)});
          final m = f is List ? (f.isEmpty ? null : f.first) : f;
          if (m is Map) _fuel['${r['truck_id']}'] = Map<String, dynamic>.from(m);
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _rows = list;
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = friendlyError(e);
          _loading = false;
        });
      }
    }
  }

  num _sum(String k) => _rows.fold<num>(0, (s, r) => s + (num.tryParse('${r[k]}') ?? 0));

  String _summary() {
    final (from, to) = _dates;
    final b = StringBuffer('EfuLogistix statement ${shortDate(from)} - ${shortDate(to)}\n');
    for (final r in _rows) {
      b.writeln('${r['plate']}: collected ${money(num.tryParse('${r['collected']}'))}, '
          'costs ${money((num.tryParse('${r['driver_costs']}') ?? 0) + (num.tryParse('${r['other_costs']}') ?? 0))}, '
          'fee ${money(num.tryParse('${r['fees']}'))}, profit ${money(num.tryParse('${r['profit']}'))}');
    }
    b.write('TOTAL profit ${money(_sum('profit'))}');
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final (from, to) = _dates;
    final profit = _sum('profit');
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(title: const Text('Statement'), actions: [
        IconButton(
          tooltip: 'Copy summary',
          icon: const Icon(Icons.copy),
          onPressed: _rows.isEmpty
              ? null
              : () {
                  Clipboard.setData(ClipboardData(text: _summary()));
                  toast(context, 'Copied. Paste it in WhatsApp.');
                },
        ),
      ]),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Wrap(spacing: 8, children: [
            for (final e in const {0: 'This week', 1: 'This month', 2: 'Last month'}.entries)
              ChoiceChipButton(e.value, selected: _range == e.key, onTap: () {
                setState(() => _range = e.key);
                _load();
              }),
          ]),
          const SizedBox(height: 4),
          Text('${shortDate(from)} - ${shortDate(to)}', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 12),
          if (_loading) const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator())),
          ErrorLine(_error),
          if (!_loading && _error == null && _rows.isEmpty) const EmptyText('No vehicles yet.'),
          if (!_loading && _rows.isNotEmpty) ...[
            AppCard(
              color: AppColors.navy,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('PROFIT', style: TextStyle(color: AppColors.onNavyMuted, fontWeight: FontWeight.w700, fontSize: 12)),
                Text(money(profit),
                    style: TextStyle(
                        color: profit < 0 ? const Color(0xFFFFB4AB) : AppColors.lime, fontSize: 30, fontWeight: FontWeight.w900)),
                Text('Collected ${money(_sum('collected'))}  ·  Costs ${money(_sum('driver_costs') + _sum('other_costs'))}  ·  Fee ${money(_sum('fees'))}',
                    style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
              ]),
            ),
            const SizedBox(height: 12),
            for (final r in _rows) _truck(r),
            const SizedBox(height: 8),
            const Text('Collected is the money drivers handed in. Costs are what the driver and the office paid. Fee is the EfuLogistix fee billed in these dates.',
                style: TextStyle(color: AppColors.muted, fontSize: 12)),
          ],
        ]),
      ),
    );
  }

  Future<void> _setTarget(Map<String, dynamic> r) async {
    final cur = num.tryParse('${_target['${r['truck_id']}']?['target']}');
    final ctl = TextEditingController(text: cur == null ? '' : cur.round().toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Weekly target · ${r['plate']}'),
        content: TextField(
          controller: ctl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'Money to hand in per week, e.g. 250000', prefixText: 'K '),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    final value = parseAmount(ctl.text);
    final empty = ctl.text.trim().isEmpty;
    ctl.dispose();
    if (ok != true) return;
    try {
      await db.rpc('set_truck_target', params: {'p_truck': r['truck_id'], 'p_amount': empty ? null : value});
      _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Widget _truck(Map<String, dynamic> r) {
    final tg = _target['${r['truck_id']}'];
    final tgValue = num.tryParse('${tg?['target']}');
    final tgGot = num.tryParse('${tg?['collected']}') ?? 0;
    final profit = num.tryParse('${r['profit']}') ?? 0;
    final f = _fuel['${r['truck_id']}'];
    final kmpl = num.tryParse('${f?['km_per_litre']}');
    final cpk = num.tryParse('${f?['cost_per_km']}');
    Widget line(String a, String b, {bool bold = false}) => Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(children: [
            Expanded(child: Text(a, style: const TextStyle(color: AppColors.muted))),
            Text(b, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w600)),
          ]),
        );
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('${r['plate']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
            Text('${r['trips']} trips · ${r['passengers']} passengers', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          ]),
          line('Collected', money(num.tryParse('${r['collected']}'))),
          line('Driver costs', money(num.tryParse('${r['driver_costs']}'))),
          line('Office costs (fuel, repairs)', money(num.tryParse('${r['other_costs']}'))),
          line('EfuLogistix fee', money(num.tryParse('${r['fees']}'))),
          const Divider(),
          line('Profit', money(profit), bold: true),
          const SizedBox(height: 8),
          if (tgValue != null && tgValue > 0) ...[
            Text('Weekly target: ${money(tgGot)} of ${money(tgValue)} (${(tgGot * 100 / tgValue).round()}%)',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: (tgGot / tgValue).clamp(0, 1).toDouble(),
                minHeight: 8,
                color: AppColors.lime600,
                backgroundColor: AppColors.lime100,
              ),
            ),
          ],
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              onPressed: () => _setTarget(r),
              child: Text(tgValue == null ? 'Set a weekly target' : 'Change target'),
            ),
          ),
          if (kmpl != null || cpk != null) ...[
            const SizedBox(height: 6),
            Text('Fuel: ${kmpl != null ? '$kmpl km per litre' : 'no litres recorded'}${cpk != null ? ' · ${money(cpk)} per km' : ''}',
                style: const TextStyle(color: AppColors.lime600, fontWeight: FontWeight.w700, fontSize: 13)),
          ],
        ]),
      ),
    );
  }
}
