import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import '../../i18n.dart';

Map<String, String> get serviceKinds => {'oil': tx('Oil change'), 'repair': tx('Repair'), 'tyre': tx('Tyres'), 'papers': tx('Papers'), 'other': tx('Other')};

/// Service: next oil change by km, insurance and COF dates, and service history.
class ServiceScreen extends StatefulWidget {
  const ServiceScreen({super.key});

  @override
  State<ServiceScreen> createState() => _ServiceScreenState();
}

class _ServiceScreenState extends State<ServiceScreen> {
  final _fleet = FleetLookup();
  List<Map<String, dynamic>> _history = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final rows = await db.from('service_records').select().order('done_on', ascending: false).limit(50);
      if (mounted) setState(() => _history = rows);
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _add(Truck t) async {
    var kind = 'oil';
    final km = TextEditingController(text: t.currentKm?.toString() ?? '');
    final cost = TextEditingController();
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(txf('Service · %s', ['${t.plate}'])),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final e in serviceKinds.entries)
                  ChoiceChipButton(e.value, selected: kind == e.key, onTap: () => setLocal(() => kind = e.key)),
              ]),
              const SizedBox(height: 10),
              TextField(
                controller: km,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: plainInput('Odometer km'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: cost,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: plainInput('Cost (MWK)'),
              ),
              const SizedBox(height: 8),
              TextField(controller: note, decoration: plainInput('Note, e.g. garage name, parts')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Save'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await db.from('service_records').insert({
        'truck_id': t.id,
        'kind': kind,
        'km': int.tryParse(km.text),
        'cost': parseAmount(cost.text),
        'note': note.text.trim().isEmpty ? null : note.text.trim(),
      });
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final trucks = _fleet.activeTrucks;
    return Scaffold(
      appBar: AppBar(
        title: Text(tx('Service & papers'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
          if (_loading) const LinearProgressIndicator(),
          if (!_loading && trucks.isEmpty) const EmptyText('No vehicles yet'),
          for (final t in trucks) ...[_truckCard(t), const SizedBox(height: 10)],
          SectionTitle(tx('HISTORY')),
          if (_history.isEmpty) EmptyText(tx('No service saved yet')),
          for (final r in _history)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${serviceKinds[r['kind']] ?? r['kind']} · ${_fleet.truck(r['truck_id'] as String?)?.plate ?? ''}',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(
                        '${r['done_on']}${r['km'] != null ? ' · ${r['km']} km' : ''}${r['note'] != null ? ' · ${r['note']}' : ''}',
                        style: const TextStyle(fontSize: 12, color: AppColors.muted),
                      ),
                    ]),
                  ),
                  Text(money(toDouble(r['cost'])), style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _truckCard(Truck t) {
    final left = t.oilLeftKm;
    final used = (left == null) ? null : (1 - left / t.oilIntervalKm).clamp(0.0, 1.0);
    final oilColor = left == null
        ? AppColors.muted
        : left <= 0
            ? AppColors.danger
            : left < 500
                ? AppColors.warning
                : AppColors.lime600;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(
            child: Text(_fleet.plateWithCategory(t.id), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ),
          Text(t.currentKm == null ? '' : '${t.currentKm} km', style: const TextStyle(color: AppColors.muted)),
        ]),
        const SizedBox(height: 8),
        Text(
          left == null
              ? tx('Oil: no oil change saved yet')
              : left <= 0
                  ? txf('Oil change overdue by %s km', ['${-left}'])
                  : txf('Oil change in %s km', ['${left}']),
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: oilColor),
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: used ?? 0,
            minHeight: 8,
            color: oilColor,
            backgroundColor: AppColors.line,
          ),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _paper('Insurance', t.insuranceTo)),
          Expanded(child: _paper('COF', t.cofTo)),
        ]),
        if (canManage) ...[
          const SizedBox(height: 8),
          AppButton(tx('+ Add service'), kind: ButtonKind.outline, height: 40, onPressed: () => _add(t)),
        ],
      ]),
    );
  }

  Widget _paper(String label, DateTime? to) {
    if (to == null) return Text(txf('%s: not set', ['${label}']), style: const TextStyle(fontSize: 13, color: AppColors.muted));
    final days = to.difference(DateTime.now()).inDays;
    final color = days < 0 ? AppColors.danger : (days < 30 ? AppColors.warning : AppColors.ink);
    return Text(
      '$label: ${shortDate(to)} ${to.year}${days < 0 ? ' · expired' : days < 30 ? ' · $days days' : ''}',
      style: TextStyle(fontSize: 13, color: color, fontWeight: days < 30 ? FontWeight.w700 : FontWeight.w400),
    );
  }
}
