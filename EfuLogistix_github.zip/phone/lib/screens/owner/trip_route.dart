import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';

/// One trip on the map with every drop-off and pickup point, in order, plus its mileage photos.
class TripRouteScreen extends StatefulWidget {
  final String tripId;
  const TripRouteScreen({super.key, required this.tripId});

  @override
  State<TripRouteScreen> createState() => _TripRouteScreenState();
}

class _TripRouteScreenState extends State<TripRouteScreen> {
  final _fleet = FleetLookup();
  Trip? _trip;
  List<TripStop> _stops = [];
  List<Reading> _readings = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await _fleet.load();
      final row = await db.from('trips').select().eq('id', widget.tripId).single();
      final stops = await db.from('trip_stops').select().eq('trip_id', widget.tripId).order('at');
      final readings = await db.from('odometer_readings').select().eq('trip_id', widget.tripId).order('taken_at');
      if (!mounted) return;
      setState(() {
        _trip = Trip.fromMap(row);
        _stops = stops.map(TripStop.fromMap).toList();
        _readings = readings.map(Reading.fromMap).toList();
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _trip;
    return Scaffold(
      appBar: AppBar(
        title: Text(t == null ? 'Trip' : 'Trip #${t.tripNo}', style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: t == null
          ? Center(child: _error == null ? const CircularProgressIndicator() : ErrorLine(_error))
          : ListView(
              children: [
                Container(
                  color: AppColors.surface,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: Text(
                    '${_fleet.name(t.driverId)} · ${_fleet.plateWithCategory(t.truckId)} · ${t.pickupName} → ${t.destName} · '
                    '${clock(t.startedAt)}–${t.running ? 'now' : clock(t.endedAt)} · ${money(t.total)}',
                    style: const TextStyle(color: AppColors.muted),
                  ),
                ),
                SizedBox(
                  height: 340,
                  child: FleetMap(
                    end: LatLng(t.destLat, t.destLng),
                    endLabel: '${t.destName}${t.running ? '' : ' · end'}',
                    bottomPadding: 20,
                    stops: [
                      if (t.pickupLat != null && t.pickupLng != null)
                        MapStop(LatLng(t.pickupLat!, t.pickupLng!), '${t.pickupName} · ${t.passengers} on', 0),
                      for (var i = 0; i < _stops.length; i++)
                        if (_stops[i].lat != null && _stops[i].lng != null)
                          MapStop(
                            LatLng(_stops[i].lat!, _stops[i].lng!),
                            _stops[i].auto
                                ? 'Unrecorded stop'
                                : '${_stops[i].placeName ?? 'Stop'} · ${_stops[i].dropped} off · ${_stops[i].picked} on',
                            i + 1,
                            auto: _stops[i].auto,
                          ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Row(children: [
                      StatTile('Collected', money(t.total), dark: true),
                      const SizedBox(width: 8),
                      StatTile('Carried', '${t.carried}'),
                      const SizedBox(width: 8),
                      StatTile('Odometer · GPS',
                          '${t.odometerKm?.toString() ?? '—'} · ${t.gpsKm?.round().toString() ?? '—'} km'),
                    ]),
                    const SectionTitle('STOPS IN ORDER'),
                    AppCard(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      child: Column(children: [
                        _stopRow('Start', '${t.pickupName} · ${clock(t.startedAt)}',
                            '${t.passengers} on${t.goods.isNotEmpty ? ' · ${t.goods.length} goods' : ''}${t.startKm != null ? ' · km ${t.startKm}' : ''}',
                            money(t.passengers * t.farePerPassenger + t.goodsTotal)),
                        for (var i = 0; i < _stops.length; i++)
                          _stopRow(
                            _stops[i].auto ? '?' : '${i + 1}',
                            '${_stops[i].placeName ?? 'Stop'} · ${clock(_stops[i].at)}'
                                '${_stops[i].kmFromStart != null ? ' · ${_stops[i].kmFromStart!.round()} km' : ''}',
                            _stops[i].auto
                                ? 'Truck stood still, the driver saved no stop'
                                : '${_stops[i].dropped} off · ${_stops[i].picked} on'
                                    '${_stops[i].pickedTo != null && _stops[i].picked > 0 ? ' to ${_stops[i].pickedTo}' : ''}'
                                    '${_stops[i].goodsOff != null ? ' · off: ${_stops[i].goodsOff}' : ''}',
                            money(_stops[i].amount),
                            warn: _stops[i].auto,
                          ),
                        if (!t.running)
                          _stopRow('End', '${t.destName} · ${clock(t.endedAt)}',
                              'all off${t.endKm != null ? ' · km ${t.endKm}' : ''}', money(t.total)),
                      ]),
                    ),
                    if (_readings.isNotEmpty) ...[
                      const SectionTitle('MILEAGE PHOTOS'),
                      for (final r in _readings) ...[
                        AppCard(
                          borderColor: r.mismatch ? AppColors.warning : null,
                          child: Row(children: [
                            StoredImage(r.photoPath, height: 56, width: 80),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text('${r.kindName} · typed ${r.km} km',
                                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                                Text(
                                  '${clock(r.takenAt)}${r.expectedKm != null ? ' · GPS expects about ${r.expectedKm}' : ''}',
                                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                                ),
                              ]),
                            ),
                            StatusPill(r.mismatch ? 'Check' : 'Match',
                                color: r.mismatch ? AppColors.warning : AppColors.lime600),
                          ]),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ]),
                ),
              ],
            ),
    );
  }

  Widget _stopRow(String n, String title, String detail, String amount, {bool warn = false}) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.line))),
        child: Row(children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: warn ? AppColors.warning : AppColors.navy, shape: BoxShape.circle),
            child: Text(n.length > 2 ? n.substring(0, 1) : n,
                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              Text(detail, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          Text(amount, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
        ]),
      );
}
