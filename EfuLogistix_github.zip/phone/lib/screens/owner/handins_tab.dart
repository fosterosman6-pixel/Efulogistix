import 'package:flutter/material.dart';
import '../../icon_art.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../home_ui.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'fleet_data.dart';
import 'owner_money.dart';
import '../../i18n.dart';

/// Cash hand-ins by day: expected (trips − driver expenses) against what the owner received.
/// Drivers hand in 100% to the vehicle owner, who confirms it here; the driver's 10% then goes to their wallet.
class HandInsTab extends StatefulWidget {
  const HandInsTab({super.key});

  @override
  State<HandInsTab> createState() => _HandInsTabState();
}

class _HandInsTabState extends State<HandInsTab> {
  final _fleet = FleetLookup();
  DateTime _day = DateTime.now();
  List<HandIn> _rows = [];
  List<HandIn> _earlier = []; // still waiting from other days
  bool _loading = true;
  LiveUpdates? _live;

  @override
  void initState() {
    super.initState();
    _fleet.load().catchError((_) {}).whenComplete(_load);
    _live = LiveUpdates('handins', ['hand_ins'], _load);
  }

  @override
  void dispose() {
    _live?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await db.from('hand_ins').select().eq('day', isoDay(_day)).order('created_at');
      if (mounted) setState(() => _rows = rows.map(HandIn.fromMap).toList());
    } catch (_) {}
    try {
      final old = await db.from('hand_ins').select().isFilter('received', null).neq('day', isoDay(_day)).order('day');
      if (mounted) setState(() => _earlier = old.map(HandIn.fromMap).toList());
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _receive(HandIn h) async {
    final amount = TextEditingController(text: h.method == 'cash' ? '' : h.expected.round().toString());
    final reference = TextEditingController(text: h.reference ?? '');
    final note = TextEditingController();
    var method = h.method;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(txf('Received from %s', ['${_fleet.name(h.driverId)}'])),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(txf('Expected %s', ['${money(h.expected)}']), style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              TextField(
                controller: amount,
                autofocus: true,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: plainInput('Amount received (MWK)'),
              ),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final e in HandIn.methodNames.entries)
                  ChoiceChipButton(e.value, selected: method == e.key, onTap: () => setLocal(() => method = e.key)),
              ]),
              if (method != 'cash') ...[
                const SizedBox(height: 8),
                TextField(controller: reference, decoration: plainInput('Mobile money reference')),
              ],
              const SizedBox(height: 8),
              TextField(controller: note, decoration: plainInput('Note, e.g. puncture paid, no receipt')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Save'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await db.rpc('receive_hand_in', params: {
        'p_id': h.id,
        'p_amount': parseAmount(amount.text),
        'p_method': method,
        'p_reference': reference.text.trim(),
        'p_note': note.text.trim(),
      });
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _decide(HandIn h, String decision) async {
    try {
      await db.rpc('decide_shortfall', params: {'p_id': h.id, 'p_decision': decision});
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final expected = _rows.fold<double>(0, (s, h) => s + h.expected);
    final received = _rows.fold<double>(0, (s, h) => s + (h.received ?? 0));
    final waiting = _rows.where((h) => h.waiting).fold<double>(0, (s, h) => s + h.expected);
    final short = _rows.fold<double>(0, (s, h) => s + h.short);
    return Container(
      color: AppColors.navy,
      child: SafeArea(
        bottom: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 12, 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                  child: Text(tx('Cash hand-ins'), style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                ),
                TextButton.icon(
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: _day,
                      firstDate: DateTime(2024),
                      lastDate: DateTime.now(),
                    );
                    if (d != null) {
                      setState(() => _day = d);
                      _load();
                    }
                  },
                  icon: const IconArt('calendar', size: 26, fallback: Icons.calendar_today),
                  label: Text(dayLabel(_day), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                _head('Expected', money(expected), Colors.white),
                _head('Received', money(received), AppColors.lime),
                _head('Waiting', money(waiting), const Color(0xFFF2B544)),
                _head('Short', money(short), const Color(0xFFFFB4A9)),
              ]),
              if (appState.profile?.isVehicleOwner ?? false) ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: _navButton(Icons.account_balance_wallet_outlined, 'wallet', 'Driver pay',
                        () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DriverPayScreen()))),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _navButton(Icons.receipt_long_outlined, 'fee', 'EfuLogistix fee',
                        () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FeesScreen()))),
                  ),
                ]),
              ],
            ]),
          ),
          Expanded(
            child: Container(
              color: AppColors.surface100,
              child: RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (_loading) const LinearProgressIndicator(),
                    if (_earlier.isNotEmpty) ...[
                      HomeLabel(tx('Still waiting from earlier days')),
                      for (final h in _earlier) ...[
                        Padding(
                          padding: const EdgeInsets.only(left: 4, bottom: 4),
                          child: Text(dayLabel(h.day), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.warning)),
                        ),
                        _card(h),
                        const SizedBox(height: 10),
                      ],
                      HomeLabel(dayLabel(_day)),
                    ],
                    if (!_loading && _rows.isEmpty) EmptyText(tx('No drivers have ended a shift on this day yet.')),
                    for (final h in _rows) ...[_card(h), const SizedBox(height: 10)],
                  ],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _navButton(IconData icon, String art, String text, VoidCallback onTap) => OutlinedButton.icon(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          side: const BorderSide(color: AppColors.onNavyMuted),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        icon: IconArt(art, size: 26, fallback: icon),
        label: FittedBox(fit: BoxFit.scaleDown, child: Text(tx(text), maxLines: 1, style: const TextStyle(fontWeight: FontWeight.w700))),
      );

  Widget _head(String label, String value, Color color) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: TextStyle(color: color, fontSize: 17, fontWeight: FontWeight.w800)),
          ),
          Text(label, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
        ]),
      );

  Widget _card(HandIn h) {
    final shortBy = h.short;
    final status = h.waiting
        ? StatusPill(tx('Waiting'), color: AppColors.warning)
        : shortBy > 0
            ? StatusPill(txf('Short %s', ['${money(shortBy)}']), color: AppColors.danger)
            : StatusPill(tx('Received ✓'), color: AppColors.lime600);
    return AppCard(
      borderColor: (!h.waiting && shortBy > 0 && h.decision == null) ? AppColors.danger : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(
            child: Text('${_fleet.name(h.driverId)} · ${_fleet.plateWithCategory(h.truckId)}',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          ),
          status,
        ]),
        const SizedBox(height: 4),
        Text(
          txf('%s trips %s − expenses %s = %s expected', ['${h.trips}', '${money(h.collected)}', '${money(h.driverExpenses)}', '${money(h.expected)}']),
          style: const TextStyle(fontSize: 13, color: AppColors.muted),
        ),
        if (!h.waiting)
          Text(
            'Received ${money(h.received)} · ${h.methodName}${h.reference != null ? ' · ${h.reference}' : ''}'
            '${h.receivedAt != null ? ' · ${clock(h.receivedAt)}' : ''}${h.note != null ? ' · "${h.note}"' : ''}',
            style: const TextStyle(fontSize: 13),
          ),
        if (h.decision != null)
          Text(h.decision == 'owed' ? tx('Kept as owed by the driver') : tx('Accepted as an expense'),
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.navy)),
        if (canConfirmCash && h.waiting) ...[
          const SizedBox(height: 8),
          AppButton(h.method == 'cash' ? tx('Mark cash received') : txf('Confirm %s payment', ['${h.methodName}']),
              height: 44, onPressed: () => _receive(h)),
        ],
        if (canConfirmCash && !h.waiting && shortBy > 0 && h.decision == null) ...[
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: AppButton(tx('Accept as expense'),
                  kind: ButtonKind.outline, height: 42, onPressed: () => _decide(h, 'accepted_as_expense')),
            ),
            const SizedBox(width: 8),
            Expanded(child: AppButton(tx('Keep as owed'), kind: ButtonKind.navy, height: 42, onPressed: () => _decide(h, 'owed'))),
          ]),
        ],
      ]),
    );
  }
}
