import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_lock.dart';
import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../widgets.dart';

const _reasons = <String, String>{
  'driver_late': 'Driver was late',
  'overcharged': 'Charged too much',
  'lost_goods': 'Lost or damaged goods',
  'safety': 'Safety problem',
  'payment': 'Payment problem',
  'vehicle': 'Vehicle problem',
  'app_problem': 'App problem',
  'other': 'Something else',
};

String _when(dynamic v) {
  final d = DateTime.tryParse('$v')?.toLocal();
  return d == null ? '' : '${shortDate(d)} ${clock(d)}';
}

String _statusText(String s) => switch (s) {
      'in_progress' => tr('st_progress'),
      'solved' => tr('st_solved'),
      _ => tr('st_open'),
    };

Color _statusColor(String s) => switch (s) {
      'in_progress' => AppColors.warning,
      'solved' => AppColors.lime600,
      _ => AppColors.danger,
    };

/// Help for every role: call or WhatsApp the office, report a problem, follow your reports.
class SupportHomeScreen extends StatefulWidget {
  const SupportHomeScreen({super.key});

  @override
  State<SupportHomeScreen> createState() => _SupportHomeScreenState();
}

class _SupportHomeScreenState extends State<SupportHomeScreen> {
  List<Map<String, dynamic>> _tickets = [];
  String _officePhone = '';
  String? _myCode;
  int _invited = 0;
  final _friendCode = TextEditingController();
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final rows = await db.from('support_tickets').select().order('created_at', ascending: false).limit(50);
      try {
        final r = await db.rpc('my_referral');
        final m = r is List ? (r.isEmpty ? null : r.first) : r;
        if (m is Map) {
          _myCode = m['code']?.toString();
          _invited = (m['people'] as num?)?.toInt() ?? 0;
        }
      } catch (_) {}
      try {
        final settings = await db.from('app_settings').select('office_phone').limit(1);
        _officePhone = settings.isEmpty ? '' : (settings.first['office_phone'] ?? '').toString();
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _tickets = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = friendlyError(e);
          _loading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _friendCode.dispose();
    super.dispose();
  }

  Future<void> _useCode() async {
    final c = _friendCode.text.trim();
    if (c.isEmpty) return;
    try {
      await db.rpc('use_referral', params: {'p_code': c});
      _friendCode.clear();
      if (mounted) toast(context, tx('Thank you. Your friend has been told.'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _open(Uri uri) async {
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
        toast(context, tx('Could not open that on this phone.'));
      }
    } catch (_) {
      if (mounted) toast(context, tx('Could not open that on this phone.'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final phone = _officePhone.trim();
    final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(title: Text(tr('help_support'))),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('something_wrong'), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(tr('tell_office'), style: TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              AppButton(tr('report_problem'), onPressed: () async {
                final sent = await Navigator.of(context)
                    .push<bool>(MaterialPageRoute(builder: (_) => const ReportProblemScreen()));
                if (sent == true) _load();
              }),
              if (digits.isNotEmpty) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: AppButton(tx('Call office'),
                        kind: ButtonKind.outline, onPressed: () => _open(Uri.parse('tel:$phone'))),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppButton('WhatsApp',
                        kind: ButtonKind.outline, onPressed: () => _open(Uri.parse('https://wa.me/$digits'))),
                  ),
                ]),
              ],
            ]),
          ),
          const SizedBox(height: 10),
          Material(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            child: ListTile(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              leading: const Icon(Icons.lock_outline, color: AppColors.navy),
              title: Text(tx('App lock (PIN)'), style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(tx('Keep your money and records safe on this phone')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AppLockSettingsScreen())),
            ),
          ),
          if (_myCode != null) ...[
            SectionTitle(tx('INVITE FRIENDS')),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text(txf('Your code: %s', ['${_myCode}']),
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  ),
                  IconButton(
                    tooltip: tx('Copy'),
                    icon: const Icon(Icons.copy),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: txf('Join me on EfuLogistix. Use my code %s when you sign up.', ['${_myCode}'])));
                      toast(context, tx('Copied. Paste it in WhatsApp.'));
                    },
                  ),
                ]),
                Text(_invited == 0 ? tx('Nobody has used it yet.') : '$_invited ${_invited == 1 ? 'person has' : 'people have'} joined with your code.',
                    style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _friendCode,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(hintText: tx('Got a friend\'s code?'), isDense: true, border: OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 8),
                  AppButton(tx('Use'), height: 44, onPressed: _useCode),
                ]),
              ]),
            ),
          ],
          SectionTitle(tr('my_reports')),
          if (_loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          if (_error != null) ErrorLine(_error),
          if (!_loading && _error == null && _tickets.isEmpty) EmptyText(tr('no_reports')),
          for (final t in _tickets)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Material(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                child: ListTile(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  title: Text('#${t['ticket_no']} · ${_reasons[t['reason']] ?? t['reason']}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${t['body'] ?? t['subject'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  trailing: Text(_statusText('${t['status']}'),
                      style: TextStyle(color: _statusColor('${t['status']}'), fontWeight: FontWeight.w800, fontSize: 12)),
                  onTap: () async {
                    await Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => TicketScreen(ticketId: '${t['id']}')));
                    _load();
                  },
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

class ReportProblemScreen extends StatefulWidget {
  final String? tripId;
  final String? bookingId;
  const ReportProblemScreen({super.key, this.tripId, this.bookingId});

  @override
  State<ReportProblemScreen> createState() => _ReportProblemScreenState();
}

class _ReportProblemScreenState extends State<ReportProblemScreen> {
  String _reason = 'other';
  final _body = TextEditingController();
  Photo? _photo;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _body.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_body.text.trim().length < 5) {
      setState(() => _error = 'Write a few words about what happened.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('report_problem', params: {
        'p_reason': _reason,
        'p_body': _body.text.trim(),
        'p_trip': widget.tripId,
        'p_booking': widget.bookingId,
        'p_photo': _photo?.path,
      });
      if (!mounted) return;
      toast(context, tx('Sent. The office will reply here.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.surface100,
        appBar: AppBar(title: Text(tr('report_problem'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          FieldLabel(tx('What is it about?')),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in _reasons.entries)
              ChoiceChipButton(e.value, selected: _reason == e.key, onTap: () => setState(() => _reason = e.key)),
          ]),
          if (_reason == 'safety')
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text(tx('Safety reports go to the office straight away. In danger, call the police first.'),
                  style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
            ),
          const SizedBox(height: 16),
          FieldLabel(tx('What happened?')),
          const SizedBox(height: 8),
          TextField(
            controller: _body,
            minLines: 4,
            maxLines: 8,
            maxLength: 800,
            decoration: InputDecoration(border: OutlineInputBorder(), hintText: tx('Write it in your own words')),
          ),
          const SizedBox(height: 8),
          PhotoSlot(
            label: tx('Add a photo (optional)'),
            fileLabel: 'support',
            photo: _photo,
            allowGallery: true,
            onTaken: (p) => setState(() => _photo = p),
          ),
          const SizedBox(height: 12),
          ErrorLine(_error),
          const SizedBox(height: 8),
          AppButton(tr('send_report'), loading: _busy, onPressed: _send),
        ]),
      );
}

/// One report: its details and the conversation with the office.
class TicketScreen extends StatefulWidget {
  final String ticketId;
  const TicketScreen({super.key, required this.ticketId});

  @override
  State<TicketScreen> createState() => _TicketScreenState();
}

class _TicketScreenState extends State<TicketScreen> {
  Map<String, dynamic>? _ticket;
  List<Map<String, dynamic>> _msgs = [];
  final _reply = TextEditingController();
  bool _sending = false;
  String? _error;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 10), (_) => _load());
  }

  @override
  void dispose() {
    _poll?.cancel();
    _reply.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final t = await db.from('support_tickets').select().eq('id', widget.ticketId).maybeSingle();
      final m = await db.from('support_messages').select().eq('ticket_id', widget.ticketId).order('created_at');
      if (!mounted) return;
      setState(() {
        _ticket = t;
        _msgs = List<Map<String, dynamic>>.from(m);
      });
    } catch (_) {}
  }

  Future<void> _send() async {
    final text = _reply.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _sending = true;
      _error = null;
    });
    try {
      await db.rpc('ticket_reply', params: {'p_ticket': widget.ticketId, 'p_body': text});
      _reply.clear();
      await _load();
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _ticket;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(title: Text(t == null ? tx('Report') : 'Report #${t['ticket_no']}')),
      body: t == null
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Expanded(
                child: ListView(padding: const EdgeInsets.all(16), children: [
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(
                          child: Text(_reasons[t['reason']] ?? '${t['reason']}',
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                        ),
                        Text(_statusText('${t['status']}'),
                            style: TextStyle(color: _statusColor('${t['status']}'), fontWeight: FontWeight.w800)),
                      ]),
                      const SizedBox(height: 6),
                      Text('${t['body'] ?? ''}'),
                      const SizedBox(height: 6),
                      Text(_when(t['created_at']),
                          style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  for (final m in _msgs)
                    Align(
                      alignment: m['from_staff'] == true ? Alignment.centerLeft : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                        decoration: BoxDecoration(
                          color: m['from_staff'] == true ? AppColors.surface : AppColors.lime100,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          if (m['from_staff'] == true)
                            Text(tx('EfuLogistix office'),
                                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.navy700)),
                          Text('${m['body']}'),
                        ]),
                      ),
                    ),
                ]),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                  child: Column(children: [
                    ErrorLine(_error),
                    Row(children: [
                      Expanded(
                        child: TextField(
                          controller: _reply,
                          minLines: 1,
                          maxLines: 4,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(), hintText: tx('Write a message'), isDense: true),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filled(
                        onPressed: _sending ? null : _send,
                        icon: const Icon(Icons.send),
                      ),
                    ]),
                  ]),
                ),
              ),
            ]),
    );
  }
}
