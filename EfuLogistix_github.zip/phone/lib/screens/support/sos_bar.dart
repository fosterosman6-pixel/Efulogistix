import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../here.dart';
import '../../i18n.dart';
import '../../location.dart';
import '../../theme.dart';
import '../../widgets.dart';

/// Two big buttons for the driver: SOS (danger) and Breakdown. The office and the vehicle owner are
/// told at once, with the place on the map.
class SosBar extends StatelessWidget {
  final bool compact;
  const SosBar({super.key, this.compact = false});

  Future<void> _send(BuildContext context, String kind) async {
    final title = tr(kind == 'sos' ? 'sos_title' : 'breakdown_title');
    final text = tr(kind == 'sos' ? 'sos_text' : 'breakdown_text');
    final noteCtl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(text),
          if (kind == 'breakdown')
            TextField(controller: noteCtl, decoration: InputDecoration(hintText: tx('What is wrong? (flat tyre, engine...)'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('cancel'))),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(kind == 'sos' ? tr('sos_title').replaceAll('?', '') : tr('send'), style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    final note = noteCtl.text.trim();
    noteCtl.dispose();
    if (ok != true || !context.mounted) return;
    double? lat, lng;
    try {
      final p = Here.instance.point.value ?? await currentPoint();
      lat = p?.latitude;
      lng = p?.longitude;
    } catch (_) {}
    try {
      await db.rpc('raise_incident', params: {'p_kind': kind, 'p_lat': lat, 'p_lng': lng, 'p_note': note.isEmpty ? null : note});
      if (context.mounted) toast(context, kind == 'sos' ? tx('SOS sent. Help is being arranged.') : tx('Breakdown reported.'));
    } catch (e) {
      if (context.mounted) toast(context, txf('Could not send: %s. Call the office.', ['${friendlyError(e)}']));
    }
  }

  Widget _pill(String text, IconData icon, Color bg, Color fg, VoidCallback onTap) => Material(
        color: bg,
        elevation: 2,
        shadowColor: const Color(0x330A2253),
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, size: 16, color: fg),
              const SizedBox(width: 5),
              Text(text, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 13)),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => compact
      ? Row(mainAxisSize: MainAxisSize.min, children: [
          _pill(tr('sos'), Icons.sos, AppColors.danger, Colors.white, () => _send(context, 'sos')),
          const SizedBox(width: 6),
          _pill(tr('breakdown'), Icons.build_circle_outlined, Colors.white, AppColors.navy, () => _send(context, 'breakdown')),
        ])
      : Row(children: [
        Expanded(
          child: AppButton(tr('sos'), kind: ButtonKind.danger, height: 44, onPressed: () => _send(context, 'sos')),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: AppButton(tr('breakdown'), kind: ButtonKind.outline, height: 44, onPressed: () => _send(context, 'breakdown')),
        ),
      ]);
}
