import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../here.dart';
import '../../i18n.dart';
import '../../location.dart';
import '../../theme.dart';
import '../../widgets.dart';

/// Two big buttons for the driver: SOS (danger) and Breakdown. The office and the vehicle owner are
/// told at once, with the place on the map.
class SosBar extends StatelessWidget {
  const SosBar({super.key});

  Future<void> _send(BuildContext context, String kind) async {
    final title = tr(kind == 'sos' ? 'sos_title' : 'breakdown_title');
    final text = tr(kind == 'sos' ? 'sos_text' : 'breakdown_text');
    final noteCtl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(text),
          if (kind == 'breakdown')
            TextField(controller: noteCtl, decoration: InputDecoration(hintText: tx('What is wrong? (flat tyre, engine...)'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr('cancel'))),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(kind == 'sos' ? tr('sos_title').replaceAll('?', '') : tr('send'), style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    final note = noteCtl.text.trim();
    noteCtl.dispose();
    if (ok != true || !context.mounted) return;
    double? lat, lng;
    try {
      final p = Here.instance.point.value ?? await currentPoint();
      lat = p?.latitude;
      lng = p?.longitude;
    } catch (_) {}
    try {
      await db.rpc('raise_incident', params: {'p_kind': kind, 'p_lat': lat, 'p_lng': lng, 'p_note': note.isEmpty ? null : note});
      if (context.mounted) toast(context, kind == 'sos' ? tx('SOS sent. Help is being arranged.') : tx('Breakdown reported.'));
    } catch (e) {
      if (context.mounted) toast(context, txf('Could not send: %s. Call the office.', ['${friendlyError(e)}']));
    }
  }

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
          child: AppButton(tr('sos'), kind: ButtonKind.danger, height: 44, onPressed: () => _send(context, 'sos')),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: AppButton(tr('breakdown'), kind: ButtonKind.outline, height: 44, onPressed: () => _send(context, 'breakdown')),
        ),
      ]);
}
