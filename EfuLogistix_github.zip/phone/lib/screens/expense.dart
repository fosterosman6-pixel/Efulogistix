import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_state.dart';
import '../capture.dart';
import '../format.dart';
import '../models.dart';
import '../outbox.dart';
import '../photos.dart';
import '../theme.dart';
import '../widgets.dart';
import '../i18n.dart';

/// Add fuel or another expense. Drivers add for their own truck and shift (counted against their
/// cash hand-in); the manager records money paid by the office.
class ExpenseScreen extends StatefulWidget {
  final String? shiftId;
  const ExpenseScreen({super.key, this.shiftId});

  @override
  State<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  final _litres = TextEditingController();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  List<Truck> _trucks = [];
  String? _truckId;
  String _category = 'fuel';
  Photo? _receipt;
  bool _busy = false;
  String? _error;

  bool get _isManager => appState.profile?.isManager ?? false;

  @override
  void initState() {
    super.initState();
    _truckId = appState.truck?.id;
    if (_isManager) _loadTrucks();
  }

  @override
  void dispose() {
    _litres.dispose();
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _loadTrucks() async {
    try {
      final rows = await db.from('trucks').select().eq('active', true).order('plate');
      if (!mounted) return;
      setState(() {
        _trucks = rows.map(Truck.fromMap).toList();
        if (_truckId == null && _trucks.isNotEmpty) _truckId = _trucks.first.id;
      });
    } catch (_) {}
  }

  Future<void> _save() async {
    setState(() => _error = null);
    final amount = parseAmount(_amount.text);
    if (_truckId == null) {
      setState(() => _error = _isManager ? 'Ask the admin to add a truck first.' : 'You have no truck yet. Ask the manager.');
      return;
    }
    if (amount <= 0) {
      setState(() => _error = 'Enter the amount spent.');
      return;
    }
    setState(() => _busy = true);
    try {
      await Outbox.instance.insert('expenses', {
        'truck_id': _truckId,
        'created_by': appState.profile?.id,
        'category': _category,
        'litres': _category == 'fuel' && _litres.text.trim().isNotEmpty
            ? double.tryParse(_litres.text.trim().replaceAll(',', '.'))
            : null,
        'amount': amount,
        'note': _note.text.trim().isEmpty ? null : _note.text.trim(),
        'shift_id': _isManager ? null : widget.shiftId,
        'paid_by': _isManager ? 'office' : 'driver',
        'receipt_path': _receipt?.path,
        'spent_at': DateTime.now().toUtc().toIso8601String(),
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _input(String label, TextEditingController c,
          {TextInputType? type, List<TextInputFormatter>? formatters, String? hint, double size = 16}) =>
      AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FieldLabel(label),
            TextField(
              controller: c,
              keyboardType: type,
              inputFormatters: formatters,
              decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true),
              style: TextStyle(fontSize: size, fontWeight: size > 16 ? FontWeight.w800 : FontWeight.w600),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isManager ? tx('Office expense') : tx('Add expense'), style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface100,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (_isManager)
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FieldLabel(tx('TRUCK')),
                    const SizedBox(height: 8),
                    if (_trucks.isEmpty) Text(tx('No trucks yet'), style: TextStyle(color: AppColors.muted)),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final t in _trucks)
                        ChoiceChipButton(t.plate, selected: t.id == _truckId, onTap: () => setState(() => _truckId = t.id)),
                    ]),
                  ],
                ),
              )
            else
              Text('For truck ${appState.truck?.plate ?? '—'} · counted in your cash hand-in',
                  style: const TextStyle(color: AppColors.muted)),
            const SizedBox(height: 12),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FieldLabel(tx('TYPE')),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final entry in expenseNames.entries)
                      ChoiceChipButton(entry.value,
                          selected: entry.key == _category, onTap: () => setState(() => _category = entry.key)),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 12),
            if (_category == 'fuel') ...[
              _input('LITRES', _litres, type: const TextInputType.numberWithOptions(decimal: true), hint: 'e.g. 10'),
              const SizedBox(height: 12),
            ],
            _input('AMOUNT (MWK)', _amount,
                type: TextInputType.number, formatters: [FilteringTextInputFormatter.digitsOnly], hint: '0', size: 24),
            const SizedBox(height: 12),
            _input('NOTE (OPTIONAL)', _note, hint: 'e.g. Mangochi filling station'),
            const SizedBox(height: 12),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                FieldLabel(tx('RECEIPT PHOTO')),
                const SizedBox(height: 8),
                SizedBox(
                  width: 120,
                  child: PhotoSlot(
                    label: tx('Receipt'),
                    fileLabel: 'receipt',
                    photo: _receipt,
                    height: 100,
                    onTaken: (p) => setState(() => _receipt = p),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            ErrorLine(_error),
            const SizedBox(height: 8),
            AppButton(tx('Save expense'), loading: _busy, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
