import 'package:flutter/material.dart';

import '../i18n.dart';
import '../theme.dart';

/// Privacy policy and terms of use, shown inside the app (reachable from sign-in and My profile).
enum LegalKind { privacy, terms }

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.kind});
  final LegalKind kind;

  static const _updated = '4 November 2026';

  static const _privacy = <(String, String)>[
    ('Who we are',
        'EfuLogistix is a transport app for matola, minibus, lorry, taxi and kabaza services in Mangochi and surrounding areas, Malawi. It connects passengers, drivers, vehicle owners and the EfuLogistix office. In this policy "we" means EfuLogistix.'),
    ('What we collect',
        '• Your name, phone number, email and profile photo.\n• Your location while the app is in use, and for drivers while on duty, so trips can be tracked and passengers can see the vehicle.\n• Your bookings, trips, fares, hand-ins, fees and wallet records.\n• Photos and papers you upload: driving licence, vehicle papers, vehicle photos, mileage photos.\n• Messages, photos and voice notes you send in chat or to support.\n• Your phone model and a notification token so we can send alerts.'),
    ('Why we use it',
        'To run bookings and trips, show vehicles on the map, check drivers and vehicles before they go on the road, keep records of money, send you alerts and reminders (for example booking updates, document expiry, service due), give support, keep the service safe and fair, and meet the law.'),
    ('Who can see it',
        '• Passengers and drivers on the same booking see each other\'s name, phone and live location for that trip only.\n• Vehicle owners see their own vehicles, their own drivers and the trips and money for those vehicles.\n• EfuLogistix managers and admin see what they need to run the service.\n• Documents and chat files are kept in private storage and are opened only by people who are allowed to.'),
    ('Services we use',
        'We store data with Supabase, show maps with Google Maps, and send notifications through Firebase. These providers handle data for us and may store it outside Malawi. We do not sell your personal information and we do not show advertising.'),
    ('How long we keep it',
        'We keep your account while it is active. Trip, money and booking records are kept as long as we need them for accounts, disputes and the law. Ask us to delete your account and we will remove what we are not required to keep.'),
    ('Your rights',
        'You can ask to see, correct or delete your information, and you can object to how we use it, as allowed by Malawi\'s data protection law. You can change your name, phone and photo in My profile. For anything else, use Support in the app.'),
    ('Permissions',
        'The app may ask for location (trips and maps), camera and photos (profile, papers, mileage, scanning tickets), microphone (voice notes) and notifications. You can turn these off in your phone settings, but some features will stop working.'),
    ('Security',
        'We use sign-in accounts, access rules and private storage to protect your data. No system is perfectly safe, so please keep your password private and tell us if you think someone else is using your account.'),
    ('Children',
        'EfuLogistix is for adults. Children may travel with an adult who books for them.'),
    ('Changes and contact',
        'If this policy changes we will update the date below and tell you in the app for big changes. Questions or requests: open Support in the app, or visit the EfuLogistix office in Mangochi.'),
  ];

  static const _terms = <(String, String)>[
    ('Using EfuLogistix',
        'By creating an account or using the app you agree to these terms. You must give true information and keep your sign-in private. You are responsible for what happens under your account.'),
    ('What the app does',
        'EfuLogistix lets passengers book seats, hire a whole vehicle or send goods; lets drivers run trips; and lets vehicle owners and the office manage vehicles and money. The journey itself is carried out by the driver and vehicle owner, not by the app.'),
    ('Passengers',
        'Be at the pick-up point on time. Pay the fare shown, in cash to the driver, by mobile money or on your account, as the booking says. Seat bookings can be cancelled free of charge. Do not carry illegal or dangerous goods, and follow the driver\'s safety instructions.'),
    ('Drivers',
        'You must hold a valid licence and only drive a vehicle you have been assigned. Keep your papers up to date, record trips, mileage and cash honestly, hand money over as agreed, and drive safely and within the law. Fake photos, false records or sharing your account can lead to removal.'),
    ('Vehicle owners',
        'Only add vehicles you own or are allowed to run. The admin checks each vehicle and its papers before it goes on the road, and may stop a vehicle with missing or expired papers. EfuLogistix charges the fee agreed with you (weekly, monthly or per trip). Drivers hand the day\'s money to you directly.'),
    ('Fees and payments',
        'Fares, fees and any wallet balance are shown in the app in Malawi Kwacha. We may change fares and fees; changes apply to new bookings. Payments made outside the app are between you and the other person.'),
    ('Behaviour',
        'No harassment, fraud, abuse, threats, fake bookings, or misuse of chat and support. Do not try to break, copy or interfere with the app. We may suspend or close accounts that break these rules.'),
    ('Safety and responsibility',
        'We work to keep the app available and accurate, but live maps, times and alerts can be late or wrong, for example when the signal is weak. To the extent the law allows, EfuLogistix is not responsible for delays, road conditions, accidents, loss or damage during a journey; those matters are between you and the driver or owner, and we will help where we can. Nothing here removes rights you have under Malawi law.'),
    ('Your content',
        'You keep ownership of the photos, messages and papers you upload. You allow us to store and use them to run the service as described in the Privacy Policy.'),
    ('Ending your account',
        'You can stop using the app at any time and ask us to delete your account. We may suspend or end access if these terms are broken or the law requires it.'),
    ('Changes, law and contact',
        'We may update these terms and will update the date below; using the app after a change means you accept it. These terms follow the laws of Malawi. Questions: use Support in the app or visit the EfuLogistix office in Mangochi.'),
  ];

  @override
  Widget build(BuildContext context) {
    final privacy = kind == LegalKind.privacy;
    final items = privacy ? _privacy : _terms;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(tx(privacy ? 'Privacy policy' : 'Terms and conditions'), style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(18), children: [
          Text('${tx('Last updated')}: $_updated', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 10),
          for (var i = 0; i < items.length; i++) ...[
            Text('${i + 1}. ${tx(items[i].$1)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.navy)),
            const SizedBox(height: 4),
            Text(items[i].$2, style: const TextStyle(fontSize: 14.5, height: 1.4)),
            const SizedBox(height: 16),
          ],
        ]),
      ),
    );
  }
}

/// Two small links: Privacy policy and Terms and conditions.
class LegalLinks extends StatelessWidget {
  const LegalLinks({super.key});

  @override
  Widget build(BuildContext context) {
    void open(LegalKind k) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LegalScreen(kind: k)));
    return Wrap(alignment: WrapAlignment.center, crossAxisAlignment: WrapCrossAlignment.center, children: [
      TextButton(onPressed: () => open(LegalKind.privacy), child: Text(tx('Privacy policy'))),
      const Text('·', style: TextStyle(color: AppColors.muted)),
      TextButton(onPressed: () => open(LegalKind.terms), child: Text(tx('Terms and conditions'))),
    ]);
  }
}
