import 'package:flutter/material.dart';

import '../app_state.dart';
import '../capture.dart';
import '../i18n.dart';
import '../photos.dart';
import '../profile_header.dart';
import '../theme.dart';
import '../widgets.dart';
import 'driver/documents.dart';
import 'legal.dart';

/// My profile: picture, name, phone, truck, language, documents and sign out.
class MyProfileScreen extends StatefulWidget {
  const MyProfileScreen({super.key});

  @override
  State<MyProfileScreen> createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen> {
  late final TextEditingController _name;
  late final TextEditingController _phone;
  bool _busy = false;
  bool _photoBusy = false;

  @override
  void initState() {
    super.initState();
    final me = appState.profile;
    _name = TextEditingController(text: me?.hasName == true ? me!.fullName!.trim() : '');
    _phone = TextEditingController(text: me?.phone ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _changePicture() async {
    final me = appState.profile;
    if (me == null || _photoBusy) return;
    final gallery = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_camera_outlined), title: Text(tx('Take a photo')), onTap: () => Navigator.pop(ctx, false)),
          ListTile(leading: const Icon(Icons.photo_library_outlined), title: Text(tx('Choose from gallery')), onTap: () => Navigator.pop(ctx, true)),
        ]),
      ),
    );
    if (gallery == null) return;
    setState(() => _photoBusy = true);
    try {
      final photo = await takePhoto('avatar', allowGallery: gallery, front: true);
      if (photo != null) {
        await db.from('profiles').update({'avatar_path': photo.path}).eq('id', me.id);
        await appState.refresh();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _photoBusy = false);
    }
  }

  Future<void> _save() async {
    final me = appState.profile;
    if (me == null || _busy) return;
    if (_name.text.trim().isEmpty) {
      toast(context, tx('Type your full name.'));
      return;
    }
    setState(() => _busy = true);
    try {
      await db.from('profiles').update({'full_name': _name.text.trim(), 'phone': _phone.text.trim()}).eq('id', me.id);
      await appState.refresh();
      if (mounted) toast(context, tx('Saved'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) {
          final me = appState.profile;
          final truck = appState.truck;
          final driver = me?.role == 'driver';
          return Scaffold(
            backgroundColor: AppColors.surface100,
            appBar: AppBar(
              title: Text(tx('My profile'), style: const TextStyle(fontWeight: FontWeight.w800)),
              backgroundColor: AppColors.surface,
              foregroundColor: AppColors.ink,
              elevation: 0,
            ),
            body: ListView(padding: const EdgeInsets.all(16), children: [
              Center(
                child: GestureDetector(
                  onTap: _changePicture,
                  child: Stack(children: [
                    Avatar(me, size: 96),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(color: AppColors.navy, shape: BoxShape.circle),
                        child: _photoBusy
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 6),
              Center(child: Text(tx('Tap the picture to change it'), style: const TextStyle(fontSize: 12, color: AppColors.muted))),
              const SizedBox(height: 16),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  FieldLabel(tx('FULL NAME')),
                  TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: plainInput(tx('Your full name'))),
                  const SizedBox(height: 12),
                  FieldLabel(tx('PHONE')),
                  TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: plainInput(tx('Phone number'))),
                  const SizedBox(height: 12),
                  FieldLabel(tx('EMAIL')),
                  Text(me?.email ?? '—', style: const TextStyle(fontSize: 15)),
                  if (driver) ...[
                    const SizedBox(height: 12),
                    FieldLabel(tx('TRUCK')),
                    Text(truck == null ? tx('No truck yet') : '${truck.plate}${truck.model != null ? ' · ${truck.model}' : ''}',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  ],
                  const SizedBox(height: 14),
                  AppButton(tx('Save'), height: 50, loading: _busy, onPressed: _save),
                ]),
              ),
              const SizedBox(height: 12),
              AppCard(
                child: Row(children: [
                  Expanded(child: Text(tx('Language'), style: const TextStyle(fontWeight: FontWeight.w700))),
                  const LanguageSwitch(),
                ]),
              ),
              if (driver) ...[
                const SizedBox(height: 12),
                AppButton(tr('documents'),
                    kind: ButtonKind.outline,
                    height: 48,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocumentsScreen()))),
              ],
              const SizedBox(height: 12),
              AppButton(tx('Sign out'), kind: ButtonKind.outline, height: 48, onPressed: () {
                Navigator.of(context).popUntil((r) => r.isFirst);
                appState.signOut();
              }),
              const SizedBox(height: 4),
              const LegalLinks(),
            ]),
          );
        },
      );
}
