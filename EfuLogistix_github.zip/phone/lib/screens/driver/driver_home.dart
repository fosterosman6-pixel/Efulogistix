import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../models.dart';
import '../../notices.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import 'documents.dart';
import 'new_trip.dart';
import 'start_shift.dart';
import 'truck_change.dart';
import 'waiting_vehicle.dart';
import '../../i18n.dart';

/// Bump this to make the driver home reload (e.g. after the end of day from another screen).
final driverRefresh = ValueNotifier<int>(0);

/// Driver home: documents first, then start shift, then trips. A pending truck change waits here.
class DriverHome extends StatefulWidget {
  const DriverHome({super.key});

  @override
  State<DriverHome> createState() => DriverHomeState();
}

class DriverHomeState extends State<DriverHome> {
  bool _loading = true;
  String _missing = '';
  Shift? _shift;
  TruckChange? _pendingChange;
  String? _error;

  @override
  void initState() {
    super.initState();
    driverRefresh.addListener(reload);
    reload();
  }

  @override
  void dispose() {
    driverRefresh.removeListener(reload);
    super.dispose();
  }

  Future<void> reload() async {
    if (!mounted) return;
    final me = appState.profile;
    if (me == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await appState.loadProfile(); // truck may have changed
      final missing = await db.rpc('missing_documents', params: {'p_driver': me.id});
      final shiftRow =
          await db.from('shifts').select().eq('driver_id', me.id).eq('status', 'on_duty').maybeSingle();
      final changeRow = await db
          .from('truck_changes')
          .select()
          .eq('driver_id', me.id)
          .eq('status', 'pending')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
      _missing = (missing ?? '').toString();
      _shift = shiftRow == null ? null : Shift.fromMap(shiftRow);
      _pendingChange = changeRow == null ? null : TruckChange.fromMap(changeRow);
      NoticeCenter.instance.start();
      if (_shift != null) {
        final problem = await Tracking.instance.start();
        if (problem != null) _error = problem;
      } else {
        await Tracking.instance.stop();
      }
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.navy)));
    }
    if (_error != null && _shift == null && _missing.isEmpty) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ErrorLine(_error),
                const SizedBox(height: 12),
                AppButton(tx('Try again'), onPressed: reload),
              ]),
            ),
          ),
        ),
      );
    }
    if (_missing.isNotEmpty) return DocumentsScreen(onChanged: reload, blocking: true, missing: _missing);
    if (appState.profile?.truckId == null && _shift == null) return WaitingForVehicleScreen(onChanged: reload);
    if (_pendingChange != null) return TruckChangeWaiting(change: _pendingChange!, onDone: reload);
    if (_shift == null) return StartShiftScreen(onStarted: reload);
    return NewTripScreen(shift: _shift!, onChanged: reload, notice: _error);
  }
}
