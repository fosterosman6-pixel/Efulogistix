import 'dart:async';

import 'package:flutter/material.dart';
import '../../icon_art.dart';
import '../chat_screen.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../route_preview.dart';
import 'package:latlong2/latlong.dart' hide Path;
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import '../tickets.dart';
import 'trip_start.dart';
import '../../i18n.dart';

/// How many bookings are waiting for this driver (for the badge on the trip screen).
Future<int> openPickupCount() async {
  final me = appState.profile;
  if (me == null) return 0;
  try {
    final rows = await db.from('bookings').select('id').eq('driver_id', me.id).inFilter('status', ['assigned', 'picked_up']);
    var offers = 0;
    try {
      offers = (await db.rpc('my_offers') as List).length;
    } catch (_) {}
    return rows.length + offers;
  } catch (_) {
    return 0;
  }
}

/// Bookings the office gave to this driver: picked up, no-show, delivered (with the receiver's code).
/// Cash bookings are added to the running trip, so they are part of the day's hand-in.
class PickupsScreen extends StatefulWidget {
  const PickupsScreen({super.key});

  @override
  State<PickupsScreen> createState() => _PickupsScreenState();
}

class _PickupsScreenState extends State<PickupsScreen> {
  List<Booking> _list = [];
  List<Map<String, dynamic>> _offers = [];
  Timer? _poll;
  Timer? _tick; // counts the answer-within seconds down on hire requests
  DateTime _offersAt = DateTime.now();
  Map<String, Profile> _people = {};
  final Map<String, TextEditingController> _codes = {};
  final Map<String, TextEditingController> _kms = {};
  String? _busy;
  bool _loading = true;
  bool _tripRunning = false;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) => _load());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _offers.isNotEmpty) setState(() {});
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    for (final c in [..._codes.values, ..._kms.values]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('driver_id', me.id)
          .inFilter('status', ['assigned', 'picked_up'])
          .order('pickup_at');
      final list = rows.map(Booking.fromMap).toList();
      List<Map<String, dynamic>> offers = [];
      try {
        offers = List<Map<String, dynamic>>.from(await db.rpc('my_offers') as List);
      } catch (_) {}
      final ids = list.map((b) => b.passengerId).whereType<String>().toSet().toList();
      final people = ids.isEmpty ? <Map<String, dynamic>>[] : await db.from('profiles').select().inFilter('id', ids);
      final trip = await db.from('trips').select('id').eq('driver_id', me.id).eq('status', 'in_progress').maybeSingle();
      if (!mounted) return;
      setState(() {
        _list = list;
        _offers = offers;
        _offersAt = DateTime.now();
        _people = {for (final p in people.map(Profile.fromMap)) p.id: p};
        _tripRunning = trip != null;
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  /// Cash bookings count in the day's total only when a trip is running, so start one first.
  Future<bool> _ensureTrip(Booking b) async {
    if (!_tripRunning && b.payMethod == 'cash') {
      final me = appState.profile;
      final truck = appState.truck;
      if (me != null && truck != null) {
        try {
          final shift = await db.from('shifts').select('id').eq('driver_id', me.id).eq('status', 'on_duty').maybeSingle();
          if (shift != null && mounted) {
            final pick = b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null;
            final dest = b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : (pick ?? const LatLng(0, 0));
            final draft = TripDraft(
              shiftId: shift['id'] as String,
              routeId: null,
              pickupName: b.pickupName,
              pickupPoint: pick,
              destName: b.destName,
              dest: dest,
              passengers: 0,
              fare: 0,
              goods: const [],
              plannedKm: null,
            );
            final tripId = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => TripStartScreen(draft: draft)));
            if (tripId == null) return false; // cancelled: nobody is marked on board yet
            _tripRunning = true;
          }
        } catch (_) {}
      }
    }
    return true;
  }

  Future<void> _answer(Map<String, dynamic> o, bool accept) async {
    setState(() => _busy = '${o['offer_id']}');
    try {
      await db.rpc('answer_offer', params: {'p_offer': o['offer_id'], 'p_accept': accept});
      if (mounted) toast(context, accept ? tx('Accepted. Go to the pick-up point.') : tx('Declined.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
      await _load();
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// More than 2 km from [lat],[lng] on the map? Ask the driver to confirm (never blocks: coordinates can be rough).
  Future<bool> _farOk(double? lat, double? lng, String title, String body, String yes) async {
    final here = Tracking.instance.position.value;
    if (lat == null || lng == null || here == null) return true;
    final away = const Distance().as(LengthUnit.Kilometer, here, LatLng(lat, lng));
    return away <= 2 || await confirmDialog(context, tx(title), tx(body), yes: tx(yes));
  }

  Future<void> _arrived(Booking b) async {
    if (!await _farOk(b.pickupLat, b.pickupLng, 'Are you at the pick-up?',
        'You are more than 2 km from the pick-up point on the map. If you are really there, tap Yes. The office will be told.', 'Yes, I am here')) {
      return;
    }
    setState(() => _busy = b.id);
    try {
      await db.rpc('booking_arrived', params: {'p_id': b.id});
      if (mounted) toast(context, tx('The passenger has been told you are here.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// The trip cannot be finished (breakdown, accident, blocked road, passenger problem).
  Future<void> _cannotFinish(Booking b) async {
    final reasons = <String, String>{
      'breakdown': tx('Vehicle broke down'),
      'accident': tx('Accident'),
      'road_blocked': tx('Road blocked'),
      'passenger_problem': tx('Problem with the passenger'),
      'other': tx('Other'),
    };
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(tx("Why can't you finish?")),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
            child: Text(tx('The trip stops here. The passenger pays only for the distance driven and the office is told.'),
                style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          ),
          for (final e in reasons.entries) SimpleDialogOption(onPressed: () => Navigator.pop(ctx, e.key), child: Text(e.value)),
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx), child: Text(tx('Cancel'), style: const TextStyle(color: AppColors.muted))),
        ],
      ),
    );
    if (reason == null || !mounted) return;
    setState(() => _busy = b.id);
    try {
      final here = Tracking.instance.position.value;
      await db.rpc('fail_trip', params: {
        'p_id': b.id,
        'p_reason': reason,
        'p_lat': here?.latitude,
        'p_lng': here?.longitude,
        'p_all': reason != 'passenger_problem',
      });
      if (mounted) toast(context, tx('Trip stopped. The office has been told.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  Future<void> _navigate(double? lat, double? lng, String name) async {
    final dest = lat != null && lng != null ? '$lat,$lng' : Uri.encodeComponent('$name, Malawi');
    // Turn-by-turn navigation in Google Maps first; the web directions page is the fallback.
    try {
      final ok = await launchUrl(Uri.parse('google.navigation:q=$dest&mode=d'), mode: LaunchMode.externalApplication);
      if (ok) return;
    } catch (_) {}
    try {
      await launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=driving'),
          mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) toast(context, tx('Could not open maps.'));
    }
  }

  Widget _offerCard(Map<String, dynamic> o) {
    final busy = _busy == '${o['offer_id']}';
    final price = (o['price'] as num?)?.toDouble() ?? 0;
    final left = ((o['seconds_left'] as num?)?.toInt() ?? 0) - DateTime.now().difference(_offersAt).inSeconds;
    return AppCard(
      borderColor: AppColors.lime,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(tx('NEW HIRE REQUEST'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.lime600)),
        const SizedBox(height: 4),
        Text('${o['pickup_name']} → ${o['dest_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        Text('${money(price)}${o['km'] != null ? ' · ${kmText((o['km'] as num).toDouble())}' : ''} · ${left > 0 ? '${tx('answer within')} ${left}s' : tx('Time is up')}',
            style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        const SizedBox(height: 8),
        RoutePreview(
          from: o['pickup_lat'] != null && o['pickup_lng'] != null ? LatLng((o['pickup_lat'] as num).toDouble(), (o['pickup_lng'] as num).toDouble()) : null,
          fromName: '${o['pickup_name']}',
          to: o['dest_lat'] != null && o['dest_lng'] != null ? LatLng((o['dest_lat'] as num).toDouble(), (o['dest_lng'] as num).toDouble()) : null,
          toName: '${o['dest_name']}',
          height: 130,
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: AppButton(tx('Accept'), height: 44, loading: busy, onPressed: left <= 0 ? null : () => _answer(o, true))),
          const SizedBox(width: 8),
          Expanded(child: AppButton(tx('Decline'), kind: ButtonKind.outline, height: 44, onPressed: busy ? null : () => _answer(o, false))),
        ]),
      ]),
    );
  }

  Future<void> _step(Booking b, String step) async {
    if (step == 'no_show' &&
        !await confirmDialog(context, tx('Mark as no-show?'), tx('Only if you waited and the passenger did not come.'), yes: tx('No-show'))) {
      return;
    }
    if (step == 'completed' && b.destLat != null && b.destLng != null) {
      // finishing more than 2 km from the drop-off is allowed (coordinates can be rough) but the office is told
      final here = Tracking.instance.position.value;
      if (here != null) {
        final away = const Distance().as(LengthUnit.Kilometer, here, LatLng(b.destLat!, b.destLng!));
        if (away > 2 &&
            !await confirmDialog(context, tx('Are you at the drop-off?'),
                tx('You are more than 2 km from the drop-off on the map. If you are really there, tap Yes. The office will be told.'),
                yes: tx('Yes, finish'))) {
          return;
        }
      }
    }
    if (step == 'picked_up' && b.kind != 'seat' &&
        !await _farOk(b.pickupLat, b.pickupLng, 'Are you at the pick-up?',
            'You are more than 2 km from the pick-up point on the map. If you are really there, tap Yes. The office will be told.', 'Yes, I am here')) {
      return;
    }
    if (step == 'picked_up' && b.kind == 'goods') {
      // a cash parcel is added to the running trip, so start one first
      if (!await _ensureTrip(b)) return;
    }
    if (step == 'picked_up' && b.kind == 'hire') {
      // a hire has one customer with the car: no ticket, the driver just starts it
      if (!await _ensureTrip(b)) return;
    }
    if (step == 'picked_up' && b.kind == 'seat') {
      // people are marked on board only by the ticket: scan the QR or type the 8 digits
      if (!await _ensureTrip(b)) return;
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
      await _load();
      return;
    }
    setState(() => _busy = b.id);
    try {
      await db.rpc('booking_step', params: {
        'p_id': b.id,
        'p_step': step,
        'p_code': _codes[b.id]?.text.trim(),
        'p_km': double.tryParse(_kms[b.id]?.text.trim() ?? ''),
      });
      if (mounted) {
        toast(
            context,
            switch (step) {
              'picked_up' => 'On board',
              'no_show' => 'Marked as no-show',
              _ => b.kind == 'goods' ? 'Delivered' : 'Done',
            });
      }
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// Ends a hire in one small step: the km driven (and the receiver's code when there is one), then Done.
  Future<void> _finishHire(Booking b) async {
    final code = _codes.putIfAbsent(b.id, TextEditingController.new);
    final km = _kms.putIfAbsent(b.id, TextEditingController.new);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tx('Finish trip')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(tx('Type the km driven, then tap Done.'), style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          const SizedBox(height: 12),
          TextField(
            controller: km,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
                labelText: tx('Km driven (odometer)'), hintText: kmText(b.km), border: const OutlineInputBorder(), isDense: true),
          ),
          if (b.receiverName != null) ...[
            const SizedBox(height: 12),
            TextField(
              controller: code,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
              decoration: InputDecoration(
                  labelText: txf('Code from %s', ['${b.receiverName}']), border: const OutlineInputBorder(), isDense: true),
            ),
          ],
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Done'))),
        ],
      ),
    );
    if (ok == true && mounted) _step(b, 'completed');
  }

  @override
  Widget build(BuildContext context) {
    final seats = _list.where((b) => b.kind == 'seat').fold<int>(0, (s, b) => s + b.seats);
    final goods = _list.where((b) => b.kind == 'goods').length;
    final truck = appState.truck;
    final cat = appState.category;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 20, 16),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const BackButton(color: Colors.white),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 10),
                      Text('${truck?.plate ?? ''}${cat != null ? ' · ${cat.name.toUpperCase()}' : ''}',
                          style: const TextStyle(color: AppColors.lime, fontSize: 13, fontWeight: FontWeight.w700)),
                      Text(tx('Booked pickups'), style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                      Text(txf('%s booked seats · %s goods', ['$seats', '$goods']) + (cat != null && cat.seats > 0 ? txf(' · %s seats left for walk-ins', ['${cat.seats - seats}']) : ''),
                          style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              for (final o in _offers) ...[_offerCard(o), const SizedBox(height: 10)],
              if (!_loading && _list.isEmpty && _offers.isEmpty) EmptyText(tx('No booked pickups. The office sends them here.')),
              if (!_tripRunning && _list.isNotEmpty)
                Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text(tx('Passengers board by scanning their ticket. The trip starts with the first one.'),
                      style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
                ),
              if (!_list.any((x) => x.status == 'assigned' && x.kind == 'seat'))
              AppButton(tx('Scan passenger ticket'),
                  kind: ButtonKind.navy,
                  height: 46,
                  onPressed: () async {
                    final first = _list.where((x) => x.status == 'assigned' && x.kind != 'goods' && x.payMethod == 'cash');
                    if (first.isNotEmpty && !await _ensureTrip(first.first)) return;
                    if (!mounted) return;
                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
                    _load();
                  }),
              if (!_list.any((x) => x.status == 'assigned' && x.kind == 'seat')) const SizedBox(height: 10),
              for (final b in _list) ...[_card(b), const SizedBox(height: 10)],
              Text(tx('Picked-up cash passengers are added to the trip total automatically.'),
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _card(Booking b) {
    final p = _people[b.passengerId];
    final who = p?.displayName ?? b.callerName ?? 'Passenger';
    final phone = p?.phone ?? b.callerPhone;
    final busy = _busy == b.id;
    final paid = b.payMethod == 'cash' ? '${money(b.amount)} · ${tx('cash to you')}' : '${money(b.amount)} · ${b.payName} ✓';
    final title = switch (b.kind) {
      'goods' => '${b.goodsText} → ${b.receiverName ?? ''}',
      'hire' => '${tx('Hire')} · $who',
      _ => '$who · ${b.seats} ${b.seats == 1 ? tx('seat') : tx('seats')}',
    };
    final where = switch (b.kind) {
      'goods' => txf('Deliver at %s', [b.destName]) + '${b.receiverPhone != null ? ' · ${b.receiverPhone}' : ''}',
      'hire' => '${b.pickupName} → ${b.destName}${b.tripType != null ? ' · ${Booking.tripTypeNames[b.tripType] ?? ''}' : ''}',
      _ => txf('Waits at %s', [b.pickupName]),
    };
    final goodsLoaded = b.kind == 'goods' && b.status == 'picked_up';
    final hireOn = b.kind == 'hire' && b.status == 'picked_up';
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: 52,
            child: Text(clock(b.pickupAt), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text(where, style: const TextStyle(fontSize: 13)),
              Text(paid, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              if (b.note != null) Text(txf('Note: %s', ['${b.note}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          if (b.status == 'picked_up' && b.kind != 'goods') StatusPill(tx('On board ✓'), color: AppColors.lime600),
        ]),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: RoutePreview(
            from: b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null,
            fromName: b.pickupName,
            to: b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : null,
            toName: b.destName,
            live: b.status == 'picked_up',
            height: b.status == 'picked_up' ? 380 : 160,
          ),
        ),
        const SizedBox(height: 10),
        if (b.status == 'assigned')
          Row(children: [
            if (b.arrivedAt == null) ...[
              Expanded(
                  child: AppButton(tx('Navigate'),
                      kind: ButtonKind.outline, height: 46, onPressed: () => _navigate(b.pickupLat, b.pickupLng, b.pickupName))),
              const SizedBox(width: 8),
              Expanded(child: AppButton(tx("I've arrived"), height: 46, loading: busy, onPressed: () => _arrived(b))),
            ] else
              Expanded(
                  child: AppButton(b.kind == 'goods' ? tx('Loaded') : b.kind == 'hire' ? tx('Start trip') : tx('Scan ticket'),
                      height: 48, loading: busy, onPressed: () => _step(b, 'picked_up'))),
            if (b.passengerId != null)
              IconButton(
                tooltip: tx('Message'),
                icon: const IconArt('chat', size: 28, fallback: Icons.chat_bubble_outline),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(bookingId: b.id, title: title))),
              ),
            PopupMenuButton<String>(
              tooltip: tx('More'),
              icon: const Icon(Icons.more_vert, color: AppColors.navy),
              onSelected: (v) {
                switch (v) {
                  case 'scan':
                    _step(b, 'picked_up');
                  case 'nav':
                    _navigate(b.pickupLat, b.pickupLng, b.pickupName);
                  case 'noshow':
                    _step(b, 'no_show');
                  case 'call':
                    launchUrl(Uri.parse('tel:$phone'));
                }
              },
              itemBuilder: (_) => [
                if (b.arrivedAt == null) PopupMenuItem(value: 'scan', child: Text(b.kind == 'goods' ? tx('Loaded') : b.kind == 'hire' ? tx('Start trip') : tx('Scan ticket'))),
                if (b.arrivedAt != null) PopupMenuItem(value: 'nav', child: Text(tx('Navigate'))),
                if (b.kind != 'goods') PopupMenuItem(value: 'noshow', child: Text(tx('No-show'))),
                if (phone != null) PopupMenuItem(value: 'call', child: Text(tx('Call'))),
              ],
            ),
          ]),
        if (goodsLoaded)
          Row(children: [
            Expanded(
              child: TextField(
                controller: _codes.putIfAbsent(b.id, TextEditingController.new),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                decoration: InputDecoration(labelText: tx('Receiver\'s code'), border: OutlineInputBorder(), isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
                child: AppButton(tx('Delivered'), kind: ButtonKind.navy, height: 46, loading: busy, onPressed: () => _step(b, 'completed'))),
          ]),
        if (b.status == 'picked_up') ...[
          AppButton(tx('Navigate to drop-off'),
              kind: ButtonKind.outline, height: 46, onPressed: () => _navigate(b.destLat, b.destLng, b.destName)),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: busy ? null : () => _cannotFinish(b),
            icon: const Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 18),
            label: Text(tx("Can't finish this trip"), style: const TextStyle(color: AppColors.danger)),
          ),
        ],
        if (hireOn)
          AppButton(tx('Finish trip'), kind: ButtonKind.navy, height: 48, loading: busy, onPressed: () => _finishHire(b)),
        if (b.status == 'picked_up' && b.kind == 'seat')
          AppButton(tx('Dropped off · done'), kind: ButtonKind.outline, height: 40, loading: busy, onPressed: () => _step(b, 'completed')),
      ]),
    );
  }
}

/// Header button with the number of booked pickups; opens the pickups list.
class PickupsButton extends StatefulWidget {
  const PickupsButton({super.key});

  @override
  State<PickupsButton> createState() => _PickupsButtonState();
}

class _PickupsButtonState extends State<PickupsButton> {
  int _n = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final n = await openPickupCount();
    if (mounted) setState(() => _n = n);
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: _n == 0 ? tx('Booked pickups') : txf('%s booked pickups', ['$_n']),
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PickupsScreen()));
          _load();
        },
        icon: Badge(
          isLabelVisible: _n > 0,
          backgroundColor: AppColors.lime,
          textColor: AppColors.navy,
          label: Text('$_n'),
          child: const Icon(Icons.event_seat_outlined, color: Colors.white),
        ),
      );
}
