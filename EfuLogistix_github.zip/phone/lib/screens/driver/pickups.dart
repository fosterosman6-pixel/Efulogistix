import 'dart:async';

import 'package:flutter/material.dart';
import '../../icon_art.dart';
import '../chat_screen.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../arrival_card.dart';
import '../../capture.dart';
import '../../photos.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../models.dart';
import '../../route_preview.dart';
import 'package:latlong2/latlong.dart' hide Path;
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import '../tickets.dart';
import 'driver_route.dart';
import 'trip_start.dart';
import '../../i18n.dart';
import '../../leg_status.dart';
import 'walkin.dart';
import '../passenger/catalog.dart' show isoDate;

/// How many bookings are waiting for this driver (for the badge on the trip screen).
Future<int> openPickupCount() async {
  final me = appState.profile;
  if (me == null) return 0;
  try {
    final rows = await db.from('bookings').select('id').eq('driver_id', me.id).inFilter('status', ['assigned', 'picked_up']);
    var offers = 0;
    try {
      offers = (await db.rpc('my_offers') as List).length;
    } catch (_) {}
    return rows.length + offers;
  } catch (_) {
    return 0;
  }
}

/// Bookings the office gave to this driver: picked up, no-show, delivered (with the receiver's code).
/// Cash bookings are added to the running trip, so they are part of the day's hand-in.
class PickupsScreen extends StatefulWidget {
  const PickupsScreen({super.key});

  @override
  State<PickupsScreen> createState() => _PickupsScreenState();
}

class _PickupsScreenState extends State<PickupsScreen> {
  List<Booking> _list = [];
  List<Map<String, dynamic>> _offers = [];
  Timer? _poll;
  Timer? _tick; // counts the answer-within seconds down on hire requests
  DateTime _offersAt = DateTime.now();
  Map<String, Profile> _people = {};
  final Map<String, TextEditingController> _codes = {};
  final Set<String> _proofTaken = {};

  /// A photo of the goods handed over: proof of delivery for the sender.
  Future<void> _proofPhoto(Booking b) async {
    try {
      final p = await takePhoto('delivery');
      if (p == null) return;
      await db.rpc('set_delivery_photo', params: {'p_booking': b.id, 'p_path': p.path});
      if (mounted) setState(() => _proofTaken.add(b.id));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }
  final Map<String, TextEditingController> _kms = {};
  String? _busy;
  bool _loading = true;
  bool _tripRunning = false;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) => _load());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && (_offers.isNotEmpty || _list.any((b) => b.status == 'assigned' && b.arrivedAt != null))) setState(() {});
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    for (final c in [..._codes.values, ..._kms.values]) {
      c.dispose();
    }
    super.dispose();
  }

  int _walkQueued = 0; // walk-ins saved on this phone, waiting for signal

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      _walkQueued = await flushWalkIns();
    } catch (_) {}
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('driver_id', me.id)
          .inFilter('status', ['assigned', 'picked_up'])
          .order('pickup_at');
      final list = rows.map(Booking.fromMap).toList();
      List<Map<String, dynamic>> offers = [];
      try {
        offers = List<Map<String, dynamic>>.from(await db.rpc('my_offers') as List);
      } catch (_) {}
      final ids = list.map((b) => b.passengerId).whereType<String>().toSet().toList();
      final people = ids.isEmpty ? <Map<String, dynamic>>[] : await db.from('profiles').select().inFilter('id', ids);
      final trip = await db.from('trips').select('id').eq('driver_id', me.id).eq('status', 'in_progress').maybeSingle();
      if (!mounted) return;
      setState(() {
        _list = list;
        _offers = offers;
        _offersAt = DateTime.now();
        _people = {for (final p in people.map(Profile.fromMap)) p.id: p};
        _tripRunning = trip != null;
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  /// Cash bookings count in the day's total only when a trip is running, so start one first.
  Future<bool> _ensureTrip(Booking b) async {
    if (!_tripRunning && b.payMethod == 'cash') {
      final me = appState.profile;
      final truck = appState.truck;
      if (me != null && truck != null) {
        try {
          final shift = await db.from('shifts').select('id').eq('driver_id', me.id).eq('status', 'on_duty').maybeSingle();
          if (shift != null && mounted) {
            final pick = b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null;
            final dest = b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : (pick ?? const LatLng(0, 0));
            final draft = TripDraft(
              shiftId: shift['id'] as String,
              routeId: null,
              pickupName: b.pickupName,
              pickupPoint: pick,
              destName: b.destName,
              dest: dest,
              passengers: 0,
              fare: 0,
              goods: const [],
              plannedKm: null,
            );
            final tripId = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => TripStartScreen(draft: draft)));
            if (tripId == null) return false; // cancelled: nobody is marked on board yet
            _tripRunning = true;
          }
        } catch (_) {}
      }
    }
    return true;
  }

  Future<void> _answer(Map<String, dynamic> o, bool accept) async {
    setState(() => _busy = '${o['offer_id']}');
    try {
      await db.rpc('answer_offer', params: {'p_offer': o['offer_id'], 'p_accept': accept});
      if (mounted) toast(context, accept ? tx('Accepted. Go to the pick-up point.') : tx('Declined.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
      await _load();
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// More than 2 km from [lat],[lng] on the map? Ask the driver to confirm (never blocks: coordinates can be rough).
  Future<bool> _farOk(double? lat, double? lng, String title, String body, String yes) async {
    final here = Tracking.instance.position.value;
    if (lat == null || lng == null || here == null) return true;
    final away = const Distance().as(LengthUnit.Kilometer, here, LatLng(lat, lng));
    return away <= 2 || await confirmDialog(context, tx(title), tx(body), yes: tx(yes));
  }

  Future<void> _arrived(Booking b) async {
    if (!await _farOk(b.pickupLat, b.pickupLng, 'Are you at the pick-up?',
        'You are more than 2 km from the pick-up point on the map. If you are really there, tap Yes. The office will be told.', 'Yes, I am here')) {
      return;
    }
    setState(() => _busy = b.id);
    try {
      await db.rpc('booking_arrived', params: {'p_id': b.id});
      if (mounted) toast(context, tx('The passenger has been told you are here.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// The trip cannot be finished (breakdown, accident, blocked road, passenger problem).
  Future<void> _cannotFinish(Booking b) async {
    final reasons = <String, String>{
      'breakdown': tx('Vehicle broke down'),
      'accident': tx('Accident'),
      'road_blocked': tx('Road blocked'),
      'passenger_problem': tx('Problem with the passenger'),
      'other': tx('Other'),
    };
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(tx("Why can't you finish?")),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
            child: Text(tx('The trip stops here. The passenger pays only for the distance driven and the office is told.'),
                style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          ),
          for (final e in reasons.entries) SimpleDialogOption(onPressed: () => Navigator.pop(ctx, e.key), child: Text(e.value)),
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx), child: Text(tx('Cancel'), style: const TextStyle(color: AppColors.muted))),
        ],
      ),
    );
    if (reason == null || !mounted) return;
    setState(() => _busy = b.id);
    try {
      final here = Tracking.instance.position.value;
      await db.rpc('fail_trip', params: {
        'p_id': b.id,
        'p_reason': reason,
        'p_lat': here?.latitude,
        'p_lng': here?.longitude,
        'p_all': reason != 'passenger_problem',
      });
      if (mounted) toast(context, tx('Trip stopped. The office has been told.'));
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// After a passenger is scanned on board: show the route line to where that passenger gets off.
  Future<void> _showRoute(Object? scanned) async {
    if (scanned is! Map || !mounted) return;
    final no = toInt(scanned['booking_no']);
    final hit = _list.where((x) => x.bookingNo == no).firstOrNull;
    if (hit == null || (hit.destLat == 0 && hit.destLng == 0)) return;
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => DriverRouteScreen(booking: hit, passengerName: '${scanned['name'] ?? ''}')));
  }

  Future<void> _navigate(double? lat, double? lng, String name) async {
    final dest = lat != null && lng != null ? '$lat,$lng' : Uri.encodeComponent('$name, Malawi');
    // Turn-by-turn navigation in Google Maps first; the web directions page is the fallback.
    try {
      final ok = await launchUrl(Uri.parse('google.navigation:q=$dest&mode=d'), mode: LaunchMode.externalApplication);
      if (ok) return;
    } catch (_) {}
    try {
      await launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=driving'),
          mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) toast(context, tx('Could not open maps.'));
    }
  }

  Widget _offerCard(Map<String, dynamic> o) {
    final busy = _busy == '${o['offer_id']}';
    final price = (o['price'] as num?)?.toDouble() ?? 0;
    final left = ((o['seconds_left'] as num?)?.toInt() ?? 0) - DateTime.now().difference(_offersAt).inSeconds;
    final pickup = o['pickup_lat'] != null && o['pickup_lng'] != null ? LatLng((o['pickup_lat'] as num).toDouble(), (o['pickup_lng'] as num).toDouble()) : null;
    final me = Tracking.instance.position.value ?? Here.instance.point.value;
    final away = pickup != null && me != null && inMalawi(me) ? distanceKm(me, pickup) : null;
    final seats = (o['seats'] as num?)?.toInt() ?? 0;
    final when = DateTime.tryParse('${o['pickup_at']}')?.toLocal();
    final now = when == null || when.difference(DateTime.now()).inMinutes < 10;
    final tripType = Booking.tripTypeNames['${o['trip_type']}'];
    final mm = (left ~/ 60).toString();
    final ss = (left % 60).toString().padLeft(2, '0');
    return AppCard(
      borderColor: AppColors.lime,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Text(tx('NEW HIRE REQUEST'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.lime600)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: left > 0 ? AppColors.danger : AppColors.muted, borderRadius: BorderRadius.circular(20)),
            child: Text(left > 0 ? '⏱ ${tx('Answer in')} $mm:$ss' : tx('Time is up'),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
          ),
        ]),
        const SizedBox(height: 8),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tx('YOU EARN'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.muted)),
              Text(money(price), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
            ]),
          ),
          if (tripType != null) StatusPill(tripType, color: AppColors.lime600),
        ]),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(border: Border.all(color: AppColors.line, width: 1.5), borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            const Icon(Icons.person_outline, color: AppColors.navy),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${o['passenger_name'] ?? tx('Passenger')}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                if (seats > 0)
                  Text(seats == 1 ? tx('1 passenger') : txf('%s passengers', ['$seats']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(border: Border.all(color: AppColors.line, width: 1.5), borderRadius: BorderRadius.circular(12)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('🟢 '),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${tx('PICK-UP')} · ${now ? tx('NOW') : clock(when!)}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.muted)),
                  Text('${o['pickup_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  if (away != null)
                    Text(txf('%s from you', [kmText(away)]), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
            ]),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('🏁 '),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tx('DROP-OFF'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.muted)),
                  Text('${o['dest_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                ]),
              ),
            ]),
            if ('${o['note'] ?? ''}'.trim().isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(txf('Note: %s', ['${o['note']}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ],
          ]),
        ),
        const SizedBox(height: 8),
        RoutePreview(
          from: pickup,
          fromName: '${o['pickup_name']}',
          to: o['dest_lat'] != null && o['dest_lng'] != null ? LatLng((o['dest_lat'] as num).toDouble(), (o['dest_lng'] as num).toDouble()) : null,
          toName: '${o['dest_name']}',
          height: MediaQuery.of(context).size.height * 0.34,
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(flex: 6, child: AppButton(tx('Accept'), height: 48, loading: busy, onPressed: left <= 0 ? null : () => _answer(o, true))),
          const SizedBox(width: 8),
          Expanded(flex: 5, child: AppButton(tx('Decline'), kind: ButtonKind.outline, height: 48, onPressed: busy ? null : () => _answer(o, false))),
        ]),
      ]),
    );
  }

  Future<void> _step(Booking b, String step, {bool skipTicket = false}) async {
    if (step == 'no_show' &&
        !await confirmDialog(context, tx('Mark as no-show?'), tx('Only if you waited and the passenger did not come.'), yes: tx('No-show'))) {
      return;
    }
    if (step == 'completed' && b.destLat != null && b.destLng != null) {
      // finishing more than 2 km from the drop-off is allowed (coordinates can be rough) but the office is told
      final here = Tracking.instance.position.value;
      if (here != null) {
        final away = const Distance().as(LengthUnit.Kilometer, here, LatLng(b.destLat!, b.destLng!));
        if (away > 2 &&
            !await confirmDialog(context, tx('Are you at the drop-off?'),
                tx('You are more than 2 km from the drop-off on the map. If you are really there, tap Yes. The office will be told.'),
                yes: tx('Yes, finish'))) {
          return;
        }
      }
    }
    if (step == 'picked_up' && b.kind != 'seat' &&
        !await _farOk(b.pickupLat, b.pickupLng, 'Are you at the pick-up?',
            'You are more than 2 km from the pick-up point on the map. If you are really there, tap Yes. The office will be told.', 'Yes, I am here')) {
      return;
    }
    if (step == 'picked_up' && b.kind == 'goods') {
      // a cash parcel is added to the running trip, so start one first
      if (!await _ensureTrip(b)) return;
    }
    if (step == 'picked_up' && b.kind == 'hire') {
      // a hire booked in the app has a ticket: scan it or type the 8 digits. Phone bookings have none, so the driver just starts it.
      if (!await _ensureTrip(b)) return;
      if (b.passengerId != null && !skipTicket) {
        if (!mounted) return;
        final got = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
        await _load();
        await _showRoute(got);
        return;
      }
    }
    if (step == 'picked_up' && b.kind == 'seat') {
      // people are marked on board only by the ticket: scan the QR or type the 8 digits
      if (!await _ensureTrip(b)) return;
      if (!mounted) return;
      final got = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
      await _load();
      await _showRoute(got);
      return;
    }
    setState(() => _busy = b.id);
    try {
      await db.rpc('booking_step', params: {
        'p_id': b.id,
        'p_step': step,
        'p_code': _codes[b.id]?.text.trim(),
        'p_km': double.tryParse(_kms[b.id]?.text.trim() ?? ''),
      });
      if (mounted) {
        toast(
            context,
            switch (step) {
              'picked_up' => 'On board',
              'no_show' => 'Marked as no-show',
              _ => b.kind == 'goods' ? 'Delivered' : 'Done',
            });
      }
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  /// Ends a hire in one small step: the km driven (and the receiver's code when there is one), then Done.
  Future<void> _finishHire(Booking b) async {
    final code = _codes.putIfAbsent(b.id, TextEditingController.new);
    final km = _kms.putIfAbsent(b.id, TextEditingController.new);
    final booked = b.km == null || b.km! <= 0 ? null : b.km!.ceil();
    final gps = Tracking.instance.tripKm;
    final gpsKm = gps >= 0.5 ? gps.round() : null;
    if (km.text.trim().isEmpty && booked != null) km.text = '$booked'; // one tap on Done in the usual case
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tx('Finish trip')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(tx('How many km did you drive? Tap one below or type it, then tap Done.'), style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 4, children: [
            if (booked != null) ActionChip(label: Text('${tx('Booked')} $booked km'), onPressed: () => km.text = '$booked'),
            if (gpsKm != null) ActionChip(label: Text('GPS $gpsKm km'), onPressed: () => km.text = '$gpsKm'),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: km,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
                labelText: tx('Km driven on this trip'), suffixText: 'km', border: const OutlineInputBorder(), isDense: true),
          ),
          const SizedBox(height: 6),
          Text('${tx('Price')}: ${money(b.price)} · ${tx('the final price follows the km')}', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          if (b.receiverName != null) ...[
            const SizedBox(height: 12),
            TextField(
              controller: code,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
              decoration: InputDecoration(
                  labelText: txf('Code from %s', ['${b.receiverName}']), border: const OutlineInputBorder(), isDense: true),
            ),
          ],
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Done'))),
        ],
      ),
    );
    if (ok == true && mounted) _step(b, 'completed');
  }

  @override
  Widget build(BuildContext context) {
    final seats = _list.where((b) => b.kind == 'seat').fold<int>(0, (s, b) => s + b.seats);
    final goods = _list.where((b) => b.kind == 'goods').length;
    final truck = appState.truck;
    final cat = appState.category;
    // the top scan button is for seat tickets and walk-ins: a hire or a parcel does not need it
    final hireOnly = seats == 0 && goods == 0 && (_offers.isNotEmpty || _list.any((x) => x.kind == 'hire'));
    final showScan = (_list.isEmpty && _offers.isEmpty) || (!_list.any((x) => x.status == 'assigned' && x.kind == 'seat') && _list.any((x) => x.kind == 'seat'));
    return Scaffold(
      backgroundColor: AppColors.surface100,
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 20, 16),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const BackButton(color: Colors.white),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 10),
                      Text('${truck?.plate ?? ''}${cat != null ? ' · ${cat.name.toUpperCase()}' : ''}',
                          style: const TextStyle(color: AppColors.lime, fontSize: 13, fontWeight: FontWeight.w700)),
                      Text(tx('Booked pickups'), style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                      Text(hireOnly ? tx('Hire trip') : txf('%s booked seats · %s goods', ['$seats', '$goods']) + (cat != null && cat.seats > 0 ? txf(' · %s seats left for walk-ins', ['${cat.seats - seats}']) : ''),
                          style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              for (final o in _offers) ...[_offerCard(o), const SizedBox(height: 10)],
              if (!_loading && _list.isEmpty && _offers.isEmpty) EmptyText(tx('No booked pickups. The office sends them here.')),
              if (!_tripRunning && _list.any((x) => x.kind == 'seat' && x.status == 'assigned'))
                Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text(tx('Passengers board by scanning their ticket. The trip starts with the first one.'),
                      style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
                ),
              if (showScan)
              AppButton(tx('Scan passenger ticket'),
                  kind: ButtonKind.navy,
                  height: 46,
                  onPressed: () async {
                    final first = _list.where((x) => x.status == 'assigned' && x.kind != 'goods' && x.payMethod == 'cash');
                    if (first.isNotEmpty && !await _ensureTrip(first.first)) return;
                    if (!mounted) return;
                    final got = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
                    await _load();
                    await _showRoute(got);
                  }),
              if (showScan) const SizedBox(height: 10),
              if (_walkQueued > 0)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFFFF0C9), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFF0C24A), width: 2)),
                  child: Text(txf('No signal. %s walk-in(s) saved on this phone. They are sent when signal returns.', ['$_walkQueued']),
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: Color(0xFF7A5200))),
                ),
              if (!hireOnly) ...[
                AppButton(tx('Add walk-in passenger'),
                    height: 46,
                    onPressed: () async {
                      // the departure of the seat bookings on this trip; none yet = the driver picks it on the next screen
                      final dep = _list.where((x) => x.kind == 'seat' && x.departureId != null && x.status != 'completed').map((x) => x.departureId).firstOrNull;
                      // the running trip's own route decides the departure and the stretch of road; no running trip = the old pick list
                      Map? route;
                      try {
                        final r = await db.rpc('driver_walkin_route', params: {'p_day': isoDate(DateTime.now())});
                        if (r is Map) route = r;
                      } catch (_) {}
                      if (!mounted) return;
                      final res = await Navigator.of(context).push<Map<String, dynamic>>(MaterialPageRoute(
                          builder: (_) => WalkInScreen(
                                departureId: route != null ? '${route['departure_id']}' : dep,
                                routeFrom: route == null ? null : toInt(route['from_pos']),
                                routeTo: route == null ? null : toInt(route['to_pos']),
                              )));
                      if (res == null) return;
                      await _load();
                      if (!mounted) return;
                      final id = res['id'] as String?;
                      if (res['queued'] == true) {
                        toast(context, tx('No signal. Saved on this phone. It is sent when signal returns.'));
                      } else if (id != null) {
                        final label = '${res['label']}';
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          duration: const Duration(minutes: 2),
                          showCloseIcon: true,
                          content: Text(txf('Walk-in added · %s', [label])),
                          action: SnackBarAction(
                            label: tx('UNDO'),
                            onPressed: () async {
                              try {
                                await db.rpc('driver_undo_walkin', params: {'p_booking': id});
                                await _load();
                              } catch (e) {
                                if (mounted) toast(context, friendlyError(e));
                              }
                            },
                          ),
                        ));
                      }
                    }),
                const SizedBox(height: 10),
              ],
              ..._listWidgets(),
              Text(tx('Picked-up cash passengers are added to the trip total automatically.'),
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ]),
      ),
    );
  }

  /// Seat bookings on the same departure become ONE trip with several stops; everything else keeps its own card.
  List<Widget> _listWidgets() {
    final groups = <String, List<Booking>>{};
    for (final b in _list) {
      if (b.kind == 'seat' && b.departureId != null) {
        groups.putIfAbsent('${b.departureId}|${b.travelOn}', () => []).add(b);
      }
    }
    final out = <Widget>[];
    final done = <String>{};
    for (final b in _list) {
      final key = '${b.departureId}|${b.travelOn}';
      final g = b.kind == 'seat' && b.departureId != null ? groups[key] : null;
      if (g == null || g.length < 2) {
        out.add(_card(b));
      } else if (done.add(key)) {
        out.add(_tripCard(g));
      } else {
        continue;
      }
      out.add(const SizedBox(height: 10));
    }
    return out;
  }

  static LatLng? _pt(double? la, double? ln) => la == null || ln == null || (la == 0 && ln == 0) ? null : LatLng(la, ln);

  /// One trip, many stops: every pick-up and drop-off in road order (nearest the start first).
  Widget _tripCard(List<Booking> g) {
    // the far end of the road: the drop-off farthest from the average pick-up
    final picks = g.map((b) => _pt(b.pickupLat, b.pickupLng)).whereType<LatLng>().toList();
    final drops = g.map((b) => _pt(b.destLat, b.destLng)).whereType<LatLng>().toList();
    LatLng? far;
    if (picks.isNotEmpty && drops.isNotEmpty) {
      final mid = LatLng(picks.map((p) => p.latitude).reduce((a, b) => a + b) / picks.length,
          picks.map((p) => p.longitude).reduce((a, b) => a + b) / picks.length);
      far = drops.reduce((a, b) => distanceKm(mid, a) >= distanceKm(mid, b) ? a : b);
    }
    final farPt = far;
    double fromStart(double? la, double? ln) {
      final p = _pt(la, ln);
      return farPt == null || p == null ? 0 : -distanceKm(farPt, p); // smaller = nearer the start
    }

    final pickOrder = [...g]..sort((a, b) => fromStart(a.pickupLat, a.pickupLng).compareTo(fromStart(b.pickupLat, b.pickupLng)));
    final dropOrder = [...g]..sort((a, b) => fromStart(a.destLat, a.destLng).compareTo(fromStart(b.destLat, b.destLng)));
    final first = pickOrder.first;
    final last = dropOrder.last;
    // one sequence in road order: people get on and off all along the way (at the same place, drop-offs go first so the seat is free)
    final events = <(bool, Booking, double)>[
      for (final b in g) (true, b, fromStart(b.pickupLat, b.pickupLng)),
      for (final b in g)
        (false, b, [fromStart(b.destLat, b.destLng), fromStart(b.pickupLat, b.pickupLng)].reduce((x, y) => x > y ? x : y)), // never before own pick-up
    ];
    events.sort((a, b) {
      final c = a.$3.compareTo(b.$3);
      if (c != 0) return c;
      if (a.$1 != b.$1) return a.$1 ? 1 : -1;
      return 0;
    });
    final seats = g.fold<int>(0, (s, b) => s + b.seats);
    final cash = g.where((b) => b.payMethod == 'cash').fold<double>(0, (s, b) => s + b.amount);
    String who(Booking b) => _people[b.passengerId]?.displayName ?? b.callerName ?? tx('Passenger');

    Future<void> navigateAll() async {
      final stops = <LatLng?>[
        for (final e in events)
          if (!e.$1) _pt(e.$2.destLat, e.$2.destLng) else if (e.$2.status == 'assigned') _pt(e.$2.pickupLat, e.$2.pickupLng),
      ].whereType<LatLng>().toList();
      if (stops.isEmpty) return;
      final dest = stops.last;
      final via = stops.take(stops.length - 1).map((p) => '${p.latitude},${p.longitude}').join('|');
      try {
        await launchUrl(
            Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${dest.latitude},${dest.longitude}'
                '${via.isEmpty ? '' : '&waypoints=${Uri.encodeComponent(via)}'}&travelmode=driving'),
            mode: LaunchMode.externalApplication);
      } catch (_) {
        if (mounted) toast(context, tx('Could not open maps.'));
      }
    }

    Widget row(int n, bool pick, Booking b) {
      final busy = _busy == b.id;
      final phone = _people[b.passengerId]?.phone ?? b.callerPhone;
      final onBoard = b.status == 'picked_up';
      Widget action;
      if (pick) {
        action = onBoard
            ? StatusPill(tx('On board ✓'), color: AppColors.lime600)
            : AppButton(tx('Scan ticket'), height: 40, loading: busy, onPressed: () => _step(b, 'picked_up'));
      } else {
        action = AppButton(tx('Dropped off'), kind: ButtonKind.outline, height: 40, loading: busy, onPressed: onBoard ? () => _step(b, 'completed') : null);
      }
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: pick ? AppColors.navy : Colors.white, shape: BoxShape.circle, border: Border.all(color: AppColors.navy, width: 2)),
            child: Text('$n', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: pick ? Colors.white : AppColors.navy)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${pick ? tx('Pick up') : tx('Drop off')} ${who(b)}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text(
                  pick
                      ? '${b.pickupName} · ${b.seats} ${b.seats == 1 ? tx('seat') : tx('seats')}'
                      : '${b.destName} · ${money(b.amount)}${b.payMethod == 'cash' ? ' · ${tx('cash')}' : ''}',
                  style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              if (pick && b.transferNote != null)
                Text(b.transferNote!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.warning)),
              if (pick && b.leg == 2) LegStatusBox(key: ValueKey('ls${b.id}'), bookingId: b.id, leg: 2),
              if (pick && !onBoard)
                Row(children: [
                  if (b.passengerId != null)
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const IconArt('chat', size: 22, fallback: Icons.chat_bubble_outline),
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(bookingId: b.id, title: who(b)))),
                    ),
                  if (phone != null)
                    IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const IconArt('call', size: 22, fallback: Icons.call_outlined),
                        onPressed: () => launchUrl(Uri.parse('tel:$phone'))),
                  TextButton(onPressed: busy ? null : () => _step(b, 'no_show'), child: Text(tx('No-show'), style: const TextStyle(color: AppColors.danger, fontSize: 12))),
                ]),
            ]),
          ),
          const SizedBox(width: 8),
          action,
        ]),
      );
    }

    var n = 0;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${clock(first.pickupAt)} · ${first.pickupName} → ${last.destName}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 2),
          Text('${g.length} ${tx('passengers')} · $seats ${seats == 1 ? tx('seat') : tx('seats')}${cash > 0 ? ' · ${money(cash)} ${tx('cash')}' : ''}',
              style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: RoutePreview(
              from: _pt(first.pickupLat, first.pickupLng),
              fromName: first.pickupName,
              to: _pt(last.destLat, last.destLng),
              toName: last.destName,
              height: MediaQuery.of(context).size.height * 0.3,
            ),
          ),
          const SizedBox(height: 10),
          AppButton(tx('Navigate the whole trip'), kind: ButtonKind.navy, height: 48, onPressed: navigateAll),
        ]),
      ),
      const SizedBox(height: 10),
      AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          for (final e in events) row(++n, e.$1, e.$2),
        ]),
      ),
    ]);
  }

  Widget _card(Booking b) {
    final p = _people[b.passengerId];
    final who = p?.displayName ?? b.callerName ?? 'Passenger';
    final phone = p?.phone ?? b.callerPhone;
    final busy = _busy == b.id;
    final paid = b.payMethod == 'cash' ? '${money(b.amount)} · ${tx('cash to you')}' : '${money(b.amount)} · ${b.payName} ✓';
    final title = switch (b.kind) {
      'goods' => '${b.goodsText} → ${b.receiverName ?? ''}',
      'hire' => '${tx('Hire')} · $who',
      _ => '$who · ${b.seats} ${b.seats == 1 ? tx('seat') : tx('seats')}',
    };
    final where = switch (b.kind) {
      'goods' => txf('Deliver at %s', [b.destName]) + '${b.receiverPhone != null ? ' · ${b.receiverPhone}' : ''}',
      'hire' => '${b.pickupName} → ${b.destName}${b.tripType != null ? ' · ${Booking.tripTypeNames[b.tripType] ?? ''}' : ''}',
      _ => txf('Waits at %s', [b.pickupName]),
    };
    final goodsLoaded = b.kind == 'goods' && b.status == 'picked_up';
    final hireOn = b.kind == 'hire' && b.status == 'picked_up';
    final me = Tracking.instance.position.value ?? Here.instance.point.value;
    final headingToPickup = b.status == 'assigned' && b.arrivedAt == null && b.kind != 'goods' && me != null && inMalawi(me);
    // no-show only after waiting 5 minutes at the pick-up
    final waited = b.arrivedAt == null ? null : DateTime.now().difference(b.arrivedAt!);
    final noShowLeft = waited == null ? null : (const Duration(minutes: 5) - waited);
    final noShowReady = noShowLeft != null && noShowLeft.isNegative;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: 52,
            child: Text(clock(b.pickupAt), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text(where, style: const TextStyle(fontSize: 13)),
              Text(paid, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              if (b.note != null) Text(txf('Note: %s', ['${b.note}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              if (b.transferNote != null)
                Text(b.transferNote!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.warning)),
              if (b.leg == 2) LegStatusBox(key: ValueKey('ls${b.id}'), bookingId: b.id, leg: 2),
              if (b.kind == 'goods' && (b.goodsSize != null || b.fragile || b.declaredValue != null))
                Text(
                    [
                      if (b.goodsSize != null) tx(b.goodsSize == 'small' ? 'Small' : b.goodsSize == 'large' ? 'Large' : 'Medium'),
                      if (b.fragile) '⚠ ${tx('Fragile')}',
                      if (b.declaredValue != null) '${tx('Value')} ${money(b.declaredValue!)}',
                    ].join(' · '),
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.warning)),
              if (b.kind == 'goods' && b.goodsPhoto != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: StoredImage(b.goodsPhoto, height: 90, width: 120),
                ),
            ]),
          ),
          if (b.status == 'picked_up' && b.kind != 'goods') StatusPill(tx('On board ✓'), color: AppColors.lime600),
        ]),
        if (b.status == 'assigned' && b.arrivedAt != null && b.kind != 'goods' && p != null) ...[
          const SizedBox(height: 10),
          FullPhotoCard(person: p, tag: 'Your passenger', height: 260),
        ],
        const SizedBox(height: 10),
        if (headingToPickup && me != null && b.pickupLat != null && b.pickupLng != null)
          // on the way to the passenger: the road from here to the pick-up, with the distance and time
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: RoutePreview(
              from: LatLng((me.latitude * 1000).round() / 1000, (me.longitude * 1000).round() / 1000), // rounded so the road is not reloaded at every GPS fix
              fromName: tx('You'),
              to: LatLng(b.pickupLat!, b.pickupLng!),
              toName: b.pickupName,
              height: MediaQuery.of(context).size.height * 0.44, // the map takes most of the screen
            ),
          )
        else
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: RoutePreview(
              from: b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null,
              fromName: b.pickupName,
              to: b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : null,
              toName: b.destName,
              live: b.status == 'picked_up',
              fitRoute: b.status == 'picked_up',
              height: MediaQuery.of(context).size.height * (b.status == 'picked_up' ? 0.5 : 0.44),
            ),
          ),
        const SizedBox(height: 10),
        if (b.status == 'picked_up' && b.kind == 'hire' && b.payMethod == 'cash') ...[
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(tx('CASH TO COLLECT'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.lime)),
                  Text(money(b.amount), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white)),
                ]),
              ),
              if (b.passengerId != null)
                IconButton(
                  icon: const IconArt('chat', size: 28, fallback: Icons.chat_bubble_outline),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(bookingId: b.id, title: title))),
                ),
              if (phone != null) IconButton(icon: const IconArt('call', size: 28, fallback: Icons.call_outlined), onPressed: () => launchUrl(Uri.parse('tel:$phone'))),
            ]),
          ),
          const SizedBox(height: 10),
        ],
        if (b.status == 'assigned') ...[
          // big buttons on one line; Message, Call and No-show underneath, so the words never wrap
          Row(children: [
            if (b.arrivedAt == null) ...[
              Expanded(
                  child: AppButton(tx('Navigate'),
                      kind: ButtonKind.outline, height: 50, onPressed: () => _navigate(b.pickupLat, b.pickupLng, b.pickupName))),
              const SizedBox(width: 8),
              Expanded(child: AppButton(tx("I've arrived"), height: 50, loading: busy, onPressed: () => _arrived(b))),
            ] else
              Expanded(
                  child: AppButton(b.kind == 'goods' ? tx('Loaded') : (b.kind == 'hire' && b.passengerId == null) ? tx('Start trip') : tx('Scan ticket'),
                      height: 52, loading: busy, onPressed: () => _step(b, 'picked_up'))),
          ]),
          const SizedBox(height: 4),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            if (b.passengerId != null)
              TextButton.icon(
                icon: const IconArt('chat', size: 24, fallback: Icons.chat_bubble_outline),
                label: Text(tx('Message')),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(bookingId: b.id, title: title))),
              ),
            if (phone != null)
              TextButton.icon(
                icon: const IconArt('call', size: 24, fallback: Icons.call_outlined),
                label: Text(tx('Call')),
                onPressed: () => launchUrl(Uri.parse('tel:$phone')),
              ),
            if (b.kind == 'hire' && b.passengerId != null && b.arrivedAt != null)
              TextButton(
                onPressed: busy ? null : () => _step(b, 'picked_up', skipTicket: true),
                child: Text(tx('Start without ticket')),
              ),
            if (b.kind != 'goods')
              TextButton(
                onPressed: noShowReady ? () => _step(b, 'no_show') : null,
                child: Text(
                    noShowReady || noShowLeft == null
                        ? tx('No-show')
                        : '${tx('No-show')} · ${noShowLeft.inMinutes + 1} min',
                    style: TextStyle(color: noShowReady ? AppColors.danger : AppColors.muted)),
              ),
          ]),
        ],
        if (goodsLoaded)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: AppButton(_proofTaken.contains(b.id) ? '${tx('Photo of delivery')} ✓' : tx('Photo of delivery'),
                kind: ButtonKind.outline, height: 42, onPressed: () => _proofPhoto(b)),
          ),
        if (goodsLoaded)
          Row(children: [
            Expanded(
              child: TextField(
                controller: _codes.putIfAbsent(b.id, TextEditingController.new),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                decoration: InputDecoration(labelText: tx('Receiver\'s code'), border: OutlineInputBorder(), isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
                child: AppButton(tx('Delivered'), kind: ButtonKind.navy, height: 46, loading: busy, onPressed: () => _step(b, 'completed'))),
          ]),
        if (b.status == 'picked_up') ...[
          AppButton(tx('Navigate to drop-off'),
              kind: ButtonKind.outline, height: 46, onPressed: () => _navigate(b.destLat, b.destLng, b.destName)),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: busy ? null : () => _cannotFinish(b),
            icon: const Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 18),
            label: Text(tx('Problem with this trip'), style: const TextStyle(color: AppColors.danger)),
          ),
        ],
        if (hireOn)
          AppButton(tx('Finish trip'), height: 52, loading: busy, onPressed: () => _finishHire(b)),
        if (b.status == 'picked_up' && b.kind == 'seat')
          AppButton(tx('Dropped off · done'), kind: ButtonKind.outline, height: 40, loading: busy, onPressed: () => _step(b, 'completed')),
      ]),
    );
  }
}

/// Header button with the number of booked pickups; opens the pickups list.
class PickupsButton extends StatefulWidget {
  const PickupsButton({super.key});

  @override
  State<PickupsButton> createState() => _PickupsButtonState();
}

class _PickupsButtonState extends State<PickupsButton> {
  int _n = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final n = await openPickupCount();
    if (mounted) setState(() => _n = n);
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: _n == 0 ? tx('Booked pickups') : txf('%s booked pickups', ['$_n']),
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PickupsScreen()));
          _load();
        },
        icon: Badge(
          isLabelVisible: _n > 0,
          backgroundColor: AppColors.lime,
          textColor: AppColors.navy,
          label: Text('$_n'),
          child: const Icon(Icons.event_seat_outlined, color: Colors.white),
        ),
      );
}
