import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../tickets.dart';
import '../../i18n.dart';

/// How many bookings are waiting for this driver (for the badge on the trip screen).
Future<int> openPickupCount() async {
  final me = appState.profile;
  if (me == null) return 0;
  try {
    final rows = await db.from('bookings').select('id').eq('driver_id', me.id).inFilter('status', ['assigned', 'picked_up']);
    return rows.length;
  } catch (_) {
    return 0;
  }
}

/// Bookings the office gave to this driver: picked up, no-show, delivered (with the receiver's code).
/// Cash bookings are added to the running trip, so they are part of the day's hand-in.
class PickupsScreen extends StatefulWidget {
  const PickupsScreen({super.key});

  @override
  State<PickupsScreen> createState() => _PickupsScreenState();
}

class _PickupsScreenState extends State<PickupsScreen> {
  List<Booking> _list = [];
  Map<String, Profile> _people = {};
  final Map<String, TextEditingController> _codes = {};
  final Map<String, TextEditingController> _kms = {};
  String? _busy;
  bool _loading = true;
  bool _tripRunning = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [..._codes.values, ..._kms.values]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('driver_id', me.id)
          .inFilter('status', ['assigned', 'picked_up'])
          .order('pickup_at');
      final list = rows.map(Booking.fromMap).toList();
      final ids = list.map((b) => b.passengerId).whereType<String>().toSet().toList();
      final people = ids.isEmpty ? <Map<String, dynamic>>[] : await db.from('profiles').select().inFilter('id', ids);
      final trip = await db.from('trips').select('id').eq('driver_id', me.id).eq('status', 'in_progress').maybeSingle();
      if (!mounted) return;
      setState(() {
        _list = list;
        _people = {for (final p in people.map(Profile.fromMap)) p.id: p};
        _tripRunning = trip != null;
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _step(Booking b, String step) async {
    if (step == 'no_show' &&
        !await confirmDialog(context, tx('Mark as no-show?'), tx('Only if you waited and the passenger did not come.'), yes: tx('No-show'))) {
      return;
    }
    setState(() => _busy = b.id);
    try {
      await db.rpc('booking_step', params: {
        'p_id': b.id,
        'p_step': step,
        'p_code': _codes[b.id]?.text.trim(),
        'p_km': double.tryParse(_kms[b.id]?.text.trim() ?? ''),
      });
      if (mounted) {
        toast(
            context,
            switch (step) {
              'picked_up' => b.payMethod == 'cash' && _tripRunning ? 'On board · added to this trip' : 'On board',
              'no_show' => 'Marked as no-show',
              _ => b.kind == 'goods' ? 'Delivered' : 'Done',
            });
      }
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final seats = _list.where((b) => b.kind == 'seat').fold<int>(0, (s, b) => s + b.seats);
    final goods = _list.where((b) => b.kind == 'goods').length;
    final truck = appState.truck;
    final cat = appState.category;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 20, 16),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const BackButton(color: Colors.white),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 10),
                      Text('${truck?.plate ?? ''}${cat != null ? ' · ${cat.name.toUpperCase()}' : ''}',
                          style: const TextStyle(color: AppColors.lime, fontSize: 13, fontWeight: FontWeight.w700)),
                      Text(tx('Booked pickups'), style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                      Text('$seats booked seats · $goods goods${cat != null && cat.seats > 0 ? ' · ${cat.seats - seats} seats left for walk-ins' : ''}',
                          style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (!_loading && _list.isEmpty) EmptyText(tx('No booked pickups. The office sends them here.')),
              if (!_tripRunning && _list.isNotEmpty)
                Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text(tx('Start the trip first, so cash bookings are added to it when you tap Picked up.'),
                      style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
                ),
              AppButton(tx('Scan passenger ticket'),
                  kind: ButtonKind.navy,
                  height: 46,
                  onPressed: () async {
                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScanTicketScreen()));
                    _load();
                  }),
              const SizedBox(height: 10),
              for (final b in _list) ...[_card(b), const SizedBox(height: 10)],
              Text(tx('Picked-up cash passengers are added to the trip total automatically.'),
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _card(Booking b) {
    final p = _people[b.passengerId];
    final who = p?.displayName ?? b.callerName ?? 'Passenger';
    final phone = p?.phone ?? b.callerPhone;
    final busy = _busy == b.id;
    final paid = b.payMethod == 'cash' ? '${money(b.amount)} · cash to you' : '${money(b.amount)} · ${b.payName} ✓';
    final title = switch (b.kind) {
      'goods' => '${b.goodsText} → ${b.receiverName ?? ''}',
      'hire' => 'Hire · $who',
      _ => '$who · ${b.seats} ${b.seats == 1 ? 'seat' : 'seats'}',
    };
    final where = switch (b.kind) {
      'goods' => 'Deliver at ${b.destName}${b.receiverPhone != null ? ' · ${b.receiverPhone}' : ''}',
      'hire' => '${b.pickupName} → ${b.destName}${b.tripType != null ? ' · ${Booking.tripTypeNames[b.tripType] ?? ''}' : ''}',
      _ => 'Waits at ${b.pickupName}',
    };
    final goodsLoaded = b.kind == 'goods' && b.status == 'picked_up';
    final hireOn = b.kind == 'hire' && b.status == 'picked_up';
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: 52,
            child: Text(clock(b.pickupAt), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text(where, style: const TextStyle(fontSize: 13)),
              Text(paid, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              if (b.note != null) Text(txf('Note: %s', ['${b.note}']), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          if (b.status == 'picked_up' && b.kind == 'seat') StatusPill(tx('On board ✓'), color: AppColors.lime600),
        ]),
        const SizedBox(height: 10),
        if (b.status == 'assigned')
          Row(children: [
            Expanded(
                child: AppButton(b.kind == 'goods' ? tx('Loaded') : tx('Picked up'),
                    height: 42, loading: busy, onPressed: () => _step(b, 'picked_up'))),
            const SizedBox(width: 8),
            if (b.kind != 'goods')
              Expanded(
                  child: AppButton(tx('No-show'), kind: ButtonKind.outline, height: 42, onPressed: busy ? null : () => _step(b, 'no_show'))),
            if (phone != null) ...[
              const SizedBox(width: 8),
              IconButton.filled(
                tooltip: tx('Call'),
                style: IconButton.styleFrom(backgroundColor: AppColors.navy),
                onPressed: () => launchUrl(Uri.parse('tel:$phone')),
                icon: const Icon(Icons.call, color: Colors.white),
              ),
            ],
          ]),
        if (goodsLoaded)
          Row(children: [
            Expanded(
              child: TextField(
                controller: _codes.putIfAbsent(b.id, TextEditingController.new),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                decoration: InputDecoration(labelText: tx('Receiver\'s code'), border: OutlineInputBorder(), isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
                child: AppButton(tx('Delivered'), kind: ButtonKind.navy, height: 46, loading: busy, onPressed: () => _step(b, 'completed'))),
          ]),
        if (hireOn && b.receiverName != null) ...[
          TextField(
            controller: _codes.putIfAbsent(b.id, TextEditingController.new),
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
            decoration: InputDecoration(
                labelText: txf('Code from %s', ['${b.receiverName}']), border: const OutlineInputBorder(), isDense: true),
          ),
          const SizedBox(height: 8),
        ],
        if (hireOn)
          Row(children: [
            Expanded(
              child: TextField(
                controller: _kms.putIfAbsent(b.id, TextEditingController.new),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                    labelText: tx('Km driven (odometer)'), hintText: kmText(b.km), border: const OutlineInputBorder(), isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(child: AppButton(tx('Done'), kind: ButtonKind.navy, height: 46, loading: busy, onPressed: () => _step(b, 'completed'))),
          ]),
        if (b.status == 'picked_up' && b.kind == 'seat')
          AppButton(tx('Dropped off · done'), kind: ButtonKind.outline, height: 40, loading: busy, onPressed: () => _step(b, 'completed')),
      ]),
    );
  }
}

/// Header button with the number of booked pickups; opens the pickups list.
class PickupsButton extends StatefulWidget {
  const PickupsButton({super.key});

  @override
  State<PickupsButton> createState() => _PickupsButtonState();
}

class _PickupsButtonState extends State<PickupsButton> {
  int _n = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final n = await openPickupCount();
    if (mounted) setState(() => _n = n);
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: _n == 0 ? 'Booked pickups' : '$_n booked pickups',
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PickupsScreen()));
          _load();
        },
        icon: Badge(
          isLabelVisible: _n > 0,
          backgroundColor: AppColors.lime,
          textColor: AppColors.navy,
          label: Text('$_n'),
          child: const Icon(Icons.event_seat_outlined, color: Colors.white),
        ),
      );
}
