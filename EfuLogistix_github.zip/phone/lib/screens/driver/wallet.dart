import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../../i18n.dart';

/// Driver wallet: 10% of each day's money after expenses, added when the owner confirms the hand-in,
/// paid out by the owner every Monday.
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  List<WalletEntry> _rows = [];
  Map<String, HandIn> _handIns = {};
  Map<String, String> _plates = {};
  Map<String, String> _owners = {};
  double _pct = 10;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = (await db.from('wallet_entries').select().eq('driver_id', me.id).order('created_at', ascending: false).limit(200))
          .map(WalletEntry.fromMap)
          .toList();
      final hids = rows.map((r) => r.handInId).whereType<String>().toList();
      final ownerIds = rows.map((r) => r.ownerId).whereType<String>().toSet().toList();
      final r = await Future.wait<List<Map<String, dynamic>>>([
        hids.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('hand_ins').select().inFilter('id', hids),
        ownerIds.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('profiles').select().inFilter('id', ownerIds),
        db.from('trucks').select('id, plate'),
        db.from('app_settings').select(),
      ]);
      if (!mounted) return;
      setState(() {
        _rows = rows;
        _handIns = {for (final h in r[0].map(HandIn.fromMap)) h.id: h};
        _owners = {for (final p in r[1].map(Profile.fromMap)) p.id: p.displayName};
        _plates = {for (final t in r[2]) t['id'].toString(): (t['plate'] ?? '').toString()};
        if (r[3].isNotEmpty) _pct = toDouble(r[3].first['wallet_pct'] ?? 10);
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final balance = _rows.fold<double>(0, (s, r) => s + r.amount);
    final earns = _rows.where((r) => r.kind == 'earn').toList();
    double since(DateTime from) => earns.where((r) => !r.day.isBefore(from)).fold<double>(0, (s, r) => s + r.amount);
    final today = periodStart(Period.today);
    final week = periodStart(Period.week);
    final month = periodStart(Period.month);
    final now = DateTime.now();
    final nextMonday = DateTime(now.year, now.month, now.day).add(Duration(days: (8 - now.weekday) % 7 == 0 ? 7 : (8 - now.weekday) % 7));
    final thisWeek = earns.where((r) => !r.day.isBefore(week)).toList();
    final paid = _rows.where((r) => r.kind != 'earn').toList();
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(tx('My wallet'), style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(txf('Balance · paid to you on Monday %s', ['${shortDate(nextMonday)}']),
                  style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
              Text(money(balance), style: const TextStyle(color: AppColors.lime, fontSize: 40, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Row(children: [
                _head(money(since(today)), 'Today'),
                _head(money(since(week)), 'This week'),
                _head(money(since(month)), 'This month'),
              ]),
            ]),
          ),
          if (_loading) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              ErrorLine(_error),
              AppCard(
                color: AppColors.lime100,
                child: Text(
                  'You earn ${_pct.round()}% of each day\'s money after expenses. Hand in the full amount to the owner; '
                  'your ${_pct.round()}% is added when the owner confirms, and paid every Monday.',
                  style: const TextStyle(fontSize: 13),
                ),
              ),
              SectionTitle(tx('THIS WEEK')),
              if (thisWeek.isEmpty) EmptyText(tx('Nothing yet this week.')),
              if (thisWeek.isNotEmpty)
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(children: [for (final r in thisWeek) _earnLine(r)]),
                ),
              if (paid.isNotEmpty) ...[
                SectionTitle(tx('PAID TO YOU AND TAKEN OFF')),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(children: [
                    for (final r in paid.take(30))
                      _line(
                        '${shortDate(r.day)} · ${r.kind == 'payout' ? 'paid' : 'taken off'}${r.ownerId != null ? ' by ${_owners[r.ownerId] ?? 'owner'}' : ' by the office'}',
                        [if (r.method != null) HandIn.methodNames[r.method] ?? r.method!, if (r.reference != null) 'ref ${r.reference}', if (r.kind == 'deduct' && r.note != null) r.note!]
                            .join(' · '),
                        money(-r.amount),
                        r.kind == 'payout' ? AppColors.navy : AppColors.danger,
                      ),
                  ]),
                ),
              ],
              if (earns.length > thisWeek.length) ...[
                SectionTitle(tx('EARLIER')),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(children: [for (final r in earns.where((r) => r.day.isBefore(week)).take(40)) _earnLine(r)]),
                ),
              ],
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _earnLine(WalletEntry r) {
    final h = r.handInId == null ? null : _handIns[r.handInId];
    final detail = h == null
        ? (r.note ?? '')
        : '${money(h.collected)} − ${money(h.driverExpenses)} = ${money(h.expected)} × ${_pct.round()}%';
    return _line('${_weekdayName(r.day)} ${shortDate(r.day)}${h != null ? ' · ${_plates[h.truckId] ?? ''}' : ''}', detail,
        '+ ${money(r.amount)}', AppColors.lime600);
  }

  Widget _line(String title, String sub, String amount, Color color) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.line))),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          Text(amount, style: TextStyle(fontWeight: FontWeight.w800, color: color)),
        ]),
      );

  Widget _head(String v, String l) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(v, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
          Text(l, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
        ]),
      );

  String _weekdayName(DateTime d) => const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d.weekday - 1];
}
