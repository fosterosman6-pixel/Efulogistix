import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../expense.dart';
import 'driver_home.dart';
import 'end_shift.dart';

/// Trip summary: money from the rank, money from stops on the way, and this shift so far.
class TripEndScreen extends StatefulWidget {
  final String tripId;
  const TripEndScreen({super.key, required this.tripId});

  @override
  State<TripEndScreen> createState() => _TripEndScreenState();
}

class _TripEndScreenState extends State<TripEndScreen> {
  Trip? _trip;
  List<TripStop> _stops = [];
  Shift? _shift;
  int _shiftTrips = 0;
  double _shiftTotal = 0;
  List<Map<String, dynamic>> _riders = []; // completed passenger bookings of this trip
  final Map<String, int> _rated = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final row = await db.from('trips').select().eq('id', widget.tripId).single();
      final trip = Trip.fromMap(row);
      final stops = await db.from('trip_stops').select().eq('trip_id', trip.id).order('at');
      Shift? shift;
      var trips = 0;
      var total = 0.0;
      if (trip.shiftId != null) {
        final s = await db.from('shifts').select().eq('id', trip.shiftId!).maybeSingle();
        shift = s == null ? null : Shift.fromMap(s);
        final rows = await db.from('trips').select('total').eq('shift_id', trip.shiftId!).eq('status', 'completed');
        trips = rows.length;
        total = rows.fold<double>(0, (a, r) => a + toDouble(r['total']));
      }
      try {
        final rs = await db
            .from('bookings')
            .select('id, booking_no, kind, passenger_id, caller_name, status')
            .eq('trip_id', trip.id)
            .eq('status', 'completed')
            .inFilter('kind', ['hire', 'seat']);
        _riders = rs.where((r) => r['passenger_id'] != null).toList();
        if (_riders.isNotEmpty) {
          final done = await db.from('passenger_ratings').select('booking_id, stars').inFilter('booking_id', [for (final r in _riders) r['id']]);
          for (final d in done) {
            _rated['${d['booking_id']}'] = (d['stars'] as num).toInt();
          }
        }
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _trip = trip;
        _stops = stops.map(TripStop.fromMap).toList();
        _shift = shift;
        _shiftTrips = trips;
        _shiftTotal = total;
      });
    } catch (_) {}
  }

  Future<void> _ratePassenger(Map<String, dynamic> r) async {
    var stars = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(tx('Rate the passenger')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 1; i <= 5; i++)
                IconButton(
                  onPressed: () => setLocal(() => stars = i),
                  icon: Icon(i <= stars ? Icons.star : Icons.star_border, color: AppColors.warning, size: 34),
                ),
            ]),
            TextField(
              controller: comment,
              maxLines: 3,
              maxLength: 300,
              decoration: InputDecoration(hintText: tx('Tell us more (optional)'), border: const OutlineInputBorder()),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Not now'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
          ],
        ),
      ),
    );
    final text = comment.text.trim();
    comment.dispose();
    if (ok != true) return;
    try {
      await db.rpc('rate_passenger', params: {'p_booking': r['id'], 'p_stars': stars, 'p_comment': text.isEmpty ? null : text});
      if (mounted) {
        toast(context, tx('Thank you for rating.'));
        setState(() => _rated['${r['id']}'] = stars);
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  void _newTripFrom(Trip t) {
    appState.nextPickup.value = PickupPrefill(t.destName, LatLng(t.destLat, t.destLng));
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  Future<void> _endDay() async {
    final s = _shift;
    if (s == null) return;
    final ended = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => EndShiftScreen(shift: s)));
    if (ended == true && mounted) {
      Navigator.of(context).popUntil((r) => r.isFirst);
      driverRefresh.value++;
    }
  }

  Widget _line(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 15))),
          Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final t = _trip;
    if (t == null) return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.navy)));
    final minutes = t.endedAt == null ? 0.0 : t.endedAt!.difference(t.startedAt).inSeconds / 60;
    final realStops = _stops.where((s) => !s.auto).toList();
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              child: Column(children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle),
                  child: const Icon(Icons.check, size: 34, color: AppColors.navy),
                ),
                const SizedBox(height: 8),
                Text(tr('trip_ended'), style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                Text('${t.pickupName} → ${t.destName}',
                    textAlign: TextAlign.center, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
              ]),
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: ListView(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
                  children: [
                    AppCard(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        FieldLabel(txf('TRIP #%s SUMMARY', ['${t.tripNo}'])),
                        const SizedBox(height: 12),
                        _line('At ${t.pickupName}: ${t.passengers} × ${money(t.farePerPassenger)}',
                            money(t.passengers * t.farePerPassenger)),
                        for (final g in t.goods) _line(g.label, money(g.amount)),
                        for (final s in realStops)
                          _line('${s.placeName ?? 'Stop'}: ${s.picked} on × ${money(s.fareEach)}', money(s.amount)),
                        const Divider(color: AppColors.line, height: 20),
                        Row(children: [
                          Expanded(
                            child: Text(tr('to_hand_in'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                          ),
                          Text(money(t.total),
                              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppColors.navy)),
                        ]),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    Row(children: [
                      StatTile('Distance', t.odometerKm == null ? kmText(t.gpsKm) : '${t.odometerKm} km'),
                      const SizedBox(width: 8),
                      StatTile('Time', durationText(minutes)),
                      const SizedBox(width: 8),
                      StatTile('Carried', '${t.carried}'),
                    ]),
                    const SizedBox(height: 12),
                    AppCard(
                      color: AppColors.lime100,
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(tx('This shift so far'),
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.navy)),
                        Text(txf('%s trips · %s', ['${_shiftTrips}', '${money(_shiftTotal)}']), style: const TextStyle(fontSize: 14)),
                      ]),
                    ),
                    if (_riders.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      AppCard(
                        padding: const EdgeInsets.all(16),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          Text(tx('Rate your passengers'),
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.navy)),
                          for (final r in _riders)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(children: [
                                Expanded(child: Text('${r['caller_name'] ?? tx('Passenger')} · #${r['booking_no']}')),
                                if (_rated.containsKey('${r['id']}'))
                                  Row(children: [
                                    for (var i = 1; i <= 5; i++)
                                      Icon(i <= _rated['${r['id']}']! ? Icons.star : Icons.star_border, color: AppColors.warning, size: 18),
                                  ])
                                else
                                  TextButton(onPressed: () => _ratePassenger(r), child: Text(tx('Rate'))),
                              ]),
                            ),
                        ]),
                      ),
                    ],
                    const SizedBox(height: 16),
                    AppButton(txf('New trip from %s', ['${t.destName}']), height: 56, onPressed: () => _newTripFrom(t)),
                    const SizedBox(height: 8),
                    AppButton(tr('add_expense'),
                        kind: ButtonKind.ghost,
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                            fullscreenDialog: true, builder: (_) => ExpenseScreen(shiftId: t.shiftId)))),
                    if (_shift != null) AppButton(tr('end_of_day'), kind: ButtonKind.outline, onPressed: _endDay),
                    AppButton(tx('Go to home screen'),
                        kind: ButtonKind.ghost, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
