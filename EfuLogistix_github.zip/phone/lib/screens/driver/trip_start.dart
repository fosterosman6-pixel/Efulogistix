import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';

/// Everything chosen on the New trip screen.
class TripDraft {
  final String shiftId;
  final String? routeId;
  final String pickupName;
  final LatLng? pickupPoint;
  final String destName;
  final LatLng dest;
  final int passengers;
  final double fare;
  final List<GoodsItem> goods;
  final double? plannedKm;
  final double? cargoKg;

  TripDraft({
    required this.shiftId,
    required this.routeId,
    required this.pickupName,
    required this.pickupPoint,
    required this.destName,
    required this.dest,
    required this.passengers,
    required this.fare,
    required this.goods,
    required this.plannedKm,
    this.cargoKg,
  });

  double get goodsTotal => goods.fold<double>(0, (s, g) => s + g.amount);
  double get total => passengers * fare + goodsTotal;
}

/// Passengers loaded: mileage photo + km, then the trip starts. Returns the new trip id.
class TripStartScreen extends StatefulWidget {
  final TripDraft draft;
  const TripStartScreen({super.key, required this.draft});

  @override
  State<TripStartScreen> createState() => _TripStartScreenState();
}

class _TripStartScreenState extends State<TripStartScreen> {
  final _odo = OdoController();
  bool _busy = false;
  String? _error;
  String? _tripId; // kept if the trip was saved but the mileage step failed, so a retry does not repeat it

  @override
  void dispose() {
    _odo.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final d = widget.draft;
    final me = appState.profile;
    final truck = appState.truck;
    setState(() => _error = null);
    if (me == null || truck == null) return;
    if (!_odo.ready) {
      setState(() => _error = 'Take the mileage photo and type the km.');
      return;
    }
    setState(() => _busy = true);
    try {
      final here = Tracking.instance.position.value ?? d.pickupPoint;
      _tripId ??= (await db
          .from('trips')
          .insert({
            'driver_id': me.id,
            'truck_id': truck.id,
            'shift_id': d.shiftId,
            'route_id': d.routeId,
            'pickup_name': d.pickupName,
            'pickup_lat': here?.latitude,
            'pickup_lng': here?.longitude,
            'dest_name': d.destName,
            'dest_lat': d.dest.latitude,
            'dest_lng': d.dest.longitude,
            'passengers': d.passengers,
            'fare_per_passenger': d.fare,
            'goods': d.goods.map((g) => g.toMap()).toList(),
            'goods_total': d.goodsTotal,
            'planned_km': d.plannedKm,
            'cargo_kg': d.cargoKg,
          })
          .select('id')
          .single())['id'] as String;
      final tripId = _tripId!;
      final since = await Tracking.instance.takeSinceReading();
      await db.rpc('record_trip_reading', params: {
        'p_trip': tripId,
        'p_kind': 'trip_start',
        'p_km': _odo.value,
        'p_photo': _odo.photo!.path,
        'p_lat': here?.latitude,
        'p_lng': here?.longitude,
        'p_gps_since': since,
      });
      Tracking.instance.setTrip(tripId);
      if (mounted) Navigator.of(context).pop(tripId);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.draft;
    final truck = appState.truck;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              IconButton(
                tooltip: tx('Back'),
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
              ),
            ]),
            NavyHeader(
              top: 'ON DUTY · ${truck?.plate ?? ''}',
              title: tr('start_route'),
              subtitle: tx('Passengers loaded. Record the mileage before you drive.'),
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: ListView(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 32 + MediaQuery.of(context).viewPadding.bottom),
                  children: [
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${d.pickupName} → ${d.destName}',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                        Text(txf('%s passengers · %s goods · %s', ['${d.passengers}', '${d.goods.length}', '${money(d.total)}']),
                            style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    OdometerCapture(
                      controller: _odo,
                      photoLabel: 'trip_start',
                      hint: truck?.currentKm == null
                          ? null
                          : 'Last recorded ${truck!.currentKm} km · GPS since then '
                              '${Tracking.instance.sinceReadingKm.toStringAsFixed(1)} km',
                      onChanged: () => setState(() {}),
                    ),
                    const SizedBox(height: 12),
                    AppCard(
                      color: AppColors.lime100,
                      child: Text(tx('The manager sees this photo next to the number you type, and the km the GPS measured.'),
                          style: TextStyle(fontSize: 13, color: AppColors.navy)),
                    ),
                    const SizedBox(height: 12),
                    ErrorLine(_error),
                    const SizedBox(height: 8),
                    AppButton(tr('start_route'), height: 56, loading: _busy, onPressed: _start),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
