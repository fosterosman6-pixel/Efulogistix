import 'package:flutter/material.dart';

import '../../i18n.dart';
import '../../notices.dart';
import '../../theme.dart';
import '../support/support_screens.dart';
import 'pickups.dart';
import 'wallet.dart';

/// Bottom menu for the driver's main screens: Home, Pickups, Wallet, Messages, Help.
class DriverNavBar extends StatelessWidget {
  const DriverNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    void open(Widget page) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    return NavigationBar(
      selectedIndex: 0,
      height: 64,
      backgroundColor: AppColors.surface,
      onDestinationSelected: (i) {
        switch (i) {
          case 1:
            open(const PickupsScreen());
          case 2:
            open(const WalletScreen());
          case 3:
            open(const NoticesScreen());
          case 4:
            open(const SupportHomeScreen());
        }
      },
      destinations: [
        NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: tx('Home')),
        NavigationDestination(icon: const Icon(Icons.confirmation_number_outlined), selectedIcon: const Icon(Icons.confirmation_number), label: tx('Pickups')),
        NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), selectedIcon: const Icon(Icons.account_balance_wallet), label: tx('Wallet')),
        NavigationDestination(icon: const Icon(Icons.notifications_outlined), selectedIcon: const Icon(Icons.notifications), label: tx('Messages')),
        NavigationDestination(icon: const Icon(Icons.support_agent_outlined), selectedIcon: const Icon(Icons.support_agent), label: tx('Help')),
      ],
    );
  }
}
