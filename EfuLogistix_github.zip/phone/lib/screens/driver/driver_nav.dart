import 'package:flutter/material.dart';
import '../../icon_art.dart';

import '../../i18n.dart';
import '../../notices.dart';
import '../../theme.dart';
import '../support/support_screens.dart';
import 'pickups.dart';
import 'wallet.dart';

/// Bottom menu for the driver's main screens: Home, Pickups, Wallet, Messages, Help.
class DriverNavBar extends StatelessWidget {
  const DriverNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    void open(Widget page) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    return NavigationBar(
      selectedIndex: 0,
      height: 64,
      backgroundColor: AppColors.surface,
      onDestinationSelected: (i) {
        switch (i) {
          case 1:
            open(const PickupsScreen());
          case 2:
            open(const WalletScreen());
          case 3:
            open(const NoticesScreen());
          case 4:
            open(const SupportHomeScreen());
        }
      },
      destinations: [
        NavigationDestination(icon: const NavArt('home', Icons.home), selectedIcon: const NavArt('home', Icons.home, selected: true), label: tx('Home')),
        NavigationDestination(icon: const NavArt('ticket', Icons.confirmation_number), selectedIcon: const NavArt('ticket', Icons.confirmation_number, selected: true), label: tx('Pickups')),
        NavigationDestination(icon: const NavArt('wallet', Icons.account_balance_wallet), selectedIcon: const NavArt('wallet', Icons.account_balance_wallet, selected: true), label: tx('Wallet')),
        NavigationDestination(icon: const NavArt('bell', Icons.notifications), selectedIcon: const NavArt('bell', Icons.notifications, selected: true), label: tx('Messages')),
        NavigationDestination(icon: const NavArt('headset', Icons.support_agent), selectedIcon: const NavArt('headset', Icons.support_agent, selected: true), label: tx('Help')),
      ],
    );
  }
}
