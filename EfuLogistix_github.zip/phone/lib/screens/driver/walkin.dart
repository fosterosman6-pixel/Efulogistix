import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../here.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../passenger/catalog.dart' show isoDate, navyBar, TotalBox;

// ---- walk-ins saved on the phone when there is no signal -------------------------------------------------------------

const _queueKey = 'walkin_queue';

Future<List<Map<String, dynamic>>> walkInQueue() async {
  try {
    final raw = (await SharedPreferences.getInstance()).getString(_queueKey);
    if (raw == null) return [];
    return [for (final e in jsonDecode(raw) as List) Map<String, dynamic>.from(e as Map)];
  } catch (_) {
    return [];
  }
}

Future<void> _saveQueue(List<Map<String, dynamic>> q) async {
  try {
    await (await SharedPreferences.getInstance()).setString(_queueKey, jsonEncode(q));
  } catch (_) {}
}

bool _isOffline(Object e) => e is! PostgrestException;

/// Sends the walk-ins saved on the phone. Returns how many are still waiting.
Future<int> flushWalkIns() async {
  final q = await walkInQueue();
  if (q.isEmpty) return 0;
  final left = <Map<String, dynamic>>[];
  for (final item in q) {
    try {
      await db.rpc('driver_add_walkin', params: {'p': item['p']});
    } catch (e) {
      if (_isOffline(e)) {
        left.add(item); // still no signal: try again later
      }
      // a refusal from the database (full car, wrong depot) is dropped: the driver was told at loading time
    }
  }
  await _saveQueue(left);
  return left.length;
}

Future<Map<String, dynamic>?> _cached(String key) async {
  try {
    final raw = (await SharedPreferences.getInstance()).getString(key);
    return raw == null ? null : Map<String, dynamic>.from(jsonDecode(raw) as Map);
  } catch (_) {
    return null;
  }
}

Future<void> _cache(String key, Object value) async {
  try {
    await (await SharedPreferences.getInstance()).setString(key, jsonEncode(value));
  } catch (_) {}
}

/// The driver adds a walk-in passenger who boards now. Only depots on this trip's own road (no change of car).
/// Seats left, depots and prices come from the database; the last copy is kept so it still works with no signal.
class WalkInScreen extends StatefulWidget {
  final String? departureId; // null = the driver picks the departure first
  const WalkInScreen({super.key, this.departureId});

  @override
  State<WalkInScreen> createState() => _WalkInScreenState();
}

class _WalkInScreenState extends State<WalkInScreen> {
  final _day = DateTime.now();
  final _ref = TextEditingController();
  final _phone = TextEditingController();
  bool _loading = true, _busy = false, _allDrops = false;
  String? _error;
  List<Map<String, dynamic>> _deps = [];
  String? _depId;
  Map<String, dynamic>? _info;
  List<Map<String, dynamic>> _drops = []; // depots to get off at from the boarding depot, with prices
  int? _fromPos, _toPos;
  int _seats = 1;
  String _pay = 'cash';
  int _queued = 0; // seats of walk-ins saved on this phone for this departure
  String _airtel = '', _mpamba = '';

  @override
  void initState() {
    super.initState();
    _depId = widget.departureId;
    _start();
  }

  @override
  void dispose() {
    _ref.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      await flushWalkIns();
      try {
        final s = await db.from('app_settings').select('airtel_number, mpamba_number').limit(1);
        if (s.isNotEmpty) {
          _airtel = '${s.first['airtel_number'] ?? ''}';
          _mpamba = '${s.first['mpamba_number'] ?? ''}';
          await _cache('wi_numbers', {'a': _airtel, 'm': _mpamba});
        }
      } catch (_) {
        final n = await _cached('wi_numbers');
        _airtel = '${n?['a'] ?? ''}';
        _mpamba = '${n?['m'] ?? ''}';
      }
      if (_depId == null) {
        try {
          final rows = await db.rpc('driver_walkin_departures', params: {'p_day': isoDate(_day)});
          _deps = [for (final r in (rows as List)) Map<String, dynamic>.from(r as Map)];
          await _cache('wi_deps_${isoDate(_day)}', {'rows': _deps});
        } catch (e) {
          if (!_isOffline(e)) rethrow;
          final c = await _cached('wi_deps_${isoDate(_day)}');
          _deps = [for (final r in (c?['rows'] as List? ?? [])) Map<String, dynamic>.from(r as Map)];
        }
      } else {
        await _loadInfo();
      }
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadInfo() async {
    final key = 'wi_info_${_depId}_${isoDate(_day)}';
    try {
      final r = await db.rpc('driver_walkin_info', params: {'p_departure': _depId, 'p_day': isoDate(_day)});
      _info = Map<String, dynamic>.from(r as Map);
      await _cache(key, _info!);
    } catch (e) {
      if (!_isOffline(e)) rethrow;
      _info = await _cached(key);
      if (_info == null) throw 'There is no signal and this trip was not opened before. Try again with signal.';
    }
    final q = await walkInQueue();
    _queued = q.where((x) => x['dep'] == _depId).fold<int>(0, (s, x) => s + toInt(x['seats']));
    _fromPos = _nearestBoarding();
    _toPos = null;
    _seats = 1;
    await _loadDrops();
  }

  /// The boarding depot nearest to the driver (the first depot when the position is not known).
  int? _nearestBoarding() {
    final here = Here.instance.point.value;
    final list = _boardStops;
    if (list.isEmpty) return null;
    if (here == null) return toInt(list.first['pos']);
    const dist = Distance();
    Map<String, dynamic>? best;
    var bestD = double.infinity;
    for (final s in list) {
      final lat = (s['lat'] as num?)?.toDouble(), lng = (s['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) continue;
      final d = dist(here, LatLng(lat, lng));
      if (d < bestD) {
        bestD = d;
        best = s;
      }
    }
    return toInt((best ?? list.first)['pos']);
  }

  Future<void> _loadDrops() async {
    final from = _fromPos;
    if (from == null) {
      _drops = [];
      return;
    }
    final key = 'wi_drops_${_depId}_$from';
    try {
      final rows = await db.rpc('driver_walkin_drops', params: {'p_departure': _depId, 'p_from_pos': from});
      _drops = [for (final r in (rows as List)) Map<String, dynamic>.from(r as Map)];
      await _cache(key, {'rows': _drops});
    } catch (e) {
      if (!_isOffline(e)) rethrow;
      final c = await _cached(key);
      _drops = [for (final r in (c?['rows'] as List? ?? [])) Map<String, dynamic>.from(r as Map)];
    }
  }

  List<Map<String, dynamic>> get _stops => [for (final s in (_info?['stops'] as List? ?? [])) Map<String, dynamic>.from(s as Map)];

  List<Map<String, dynamic>> get _boardStops {
    final all = _stops;
    return [for (var i = 0; i < all.length - 1; i++) if (all[i]['can_board'] == true) all[i]];
  }

  int get _left => toInt(_info?['seats_left']) - _queued;

  Map<String, dynamic>? get _drop => _drops.where((d) => toInt(d['pos']) == _toPos).firstOrNull;

  double? get _fare => _drop == null ? null : toDouble(_drop!['fare']);

  Future<void> _add() async {
    final drop = _drop;
    if (_fromPos == null || drop == null) return;
    if (_pay != 'cash' && _ref.text.trim().isEmpty) {
      setState(() => _error = tx('Type the mobile money reference.'));
      return;
    }
    final payload = {
      'departure_id': _depId,
      'travel_on': isoDate(_day),
      'from_pos': _fromPos,
      'to_pos': _toPos,
      'seats': _seats,
      'pay_method': _pay,
      'pay_reference': _ref.text.trim(),
      'phone': _phone.text.trim(),
    };
    final total = (_fare ?? 0) * _seats;
    final label = '${drop['name']} · ${money(total)}';
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      String? id;
      var queued = false;
      try {
        id = '${await db.rpc('driver_add_walkin', params: {'p': payload})}';
      } catch (e) {
        if (!_isOffline(e)) rethrow;
        // no signal: keep it on the phone and send it later
        final q = await walkInQueue();
        q.add({'p': payload, 'dep': _depId, 'seats': _seats, 'label': label});
        await _saveQueue(q);
        queued = true;
      }
      if (!mounted) return;
      final phone = _phone.text.trim();
      if (phone.isNotEmpty && !queued) {
        final text = 'EfuLogistix receipt: ${_info?['from_name']} to ${drop['name']}, $_seats seat${_seats == 1 ? '' : 's'}, ${money(total)} ${_pay == 'cash' ? 'paid in cash' : 'paid'}. Thank you.';
        final send = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text(tx('Send receipt by SMS?')),
            content: Text(text),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Skip'))),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
            ],
          ),
        );
        if (send == true) await launchUrl(Uri(scheme: 'sms', path: phone, queryParameters: {'body': text}));
      }
      if (!mounted) return;
      Navigator.of(context).pop({'id': id, 'label': label, 'queued': queued});
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _chip(Map<String, dynamic> d) {
    final sel = toInt(d['pos']) == _toPos;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => setState(() => _toPos = toInt(d['pos'])),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: sel ? AppColors.navy : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.navy, width: 2),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text('${d['name']}'.replaceAll(' Depot', ''), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: sel ? Colors.white : AppColors.navy)),
          Text(money(toDouble(d['fare'])), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: sel ? AppColors.lime : AppColors.navy)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final info = _info;
    final total = _fare == null ? null : _fare! * _seats;
    final canAdd = info != null && _fromPos != null && _fare != null && _left >= _seats && !_busy;
    final shown = _allDrops ? _drops : _drops.take(4).toList();
    final number = _pay == 'airtel_money' ? _airtel : _pay == 'tnm_mpamba' ? _mpamba : '';
    return Scaffold(
      appBar: navyBar('Walk-in passenger'),
      backgroundColor: AppColors.surface100,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              if (_error != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700))),
              if (info == null) ...[
                FieldLabel(tx('WHICH DEPARTURE ARE YOU LOADING?')),
                if (_deps.isEmpty) EmptyText(tx('No departure for your vehicle today.')),
                for (final d in _deps) ...[
                  const SizedBox(height: 8),
                  AppCard(
                    child: InkWell(
                      onTap: () async {
                        setState(() {
                          _depId = '${d['departure_id']}';
                          _loading = true;
                          _error = null;
                        });
                        try {
                          await _loadInfo();
                        } catch (e) {
                          _error = friendlyError(e);
                          _depId = null;
                        }
                        if (mounted) setState(() => _loading = false);
                      },
                      child: Row(children: [
                        Text('${d['leaves_at']}'.substring(0, 5), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                        const SizedBox(width: 12),
                        Expanded(child: Text('${d['from_name']} → ${d['to_name']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                        Text(txf('%s left', ['${toInt(d['seats']) - toInt(d['booked'])}']), style: const TextStyle(color: AppColors.muted)),
                      ]),
                    ),
                  ),
                ],
              ] else ...[
                AppCard(
                  child: Row(children: [
                    const Icon(Icons.directions_bus_outlined, color: AppColors.lime600),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text('${'${info['leaves_at']}'.substring(0, 5)} · ${info['from_name']} → ${info['to_name']}\n${txf('%s seats left', ['$_left'])}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ]),
                ),
                if (_left < 1) Padding(padding: const EdgeInsets.only(top: 10), child: Text(tx('The car is full.'), style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800))),
                const SizedBox(height: 10),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    FieldLabel(tx('BOARDS AT')),
                    DropdownButton<int>(
                      isExpanded: true,
                      underline: const SizedBox.shrink(),
                      value: _boardStops.any((s) => toInt(s['pos']) == _fromPos) ? _fromPos : null,
                      items: [for (final s in _boardStops) DropdownMenuItem<int>(value: toInt(s['pos']), child: Text('${s['name']}', style: const TextStyle(fontWeight: FontWeight.w700)))],
                      onChanged: (v) async {
                        setState(() {
                          _fromPos = v;
                          _toPos = null;
                          _drops = [];
                        });
                        try {
                          await _loadDrops();
                        } catch (e) {
                          _error = friendlyError(e);
                        }
                        if (mounted) setState(() {});
                      },
                    ),
                  ]),
                ),
                const SizedBox(height: 10),
                FieldLabel(tx('GETS OFF AT · TAP ONE')),
                const SizedBox(height: 6),
                if (_drops.isEmpty) EmptyText(tx('No depot ahead on this trip.')),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final d in shown) _chip(d),
                  if (_drops.length > 4)
                    ActionChip(
                      label: Text(_allDrops ? tx('Fewer depots') : tx('More depots')),
                      onPressed: () => setState(() => _allDrops = !_allDrops),
                    ),
                ]),
                const SizedBox(height: 10),
                AppCard(
                  child: Row(children: [
                    Expanded(child: Text(tx('Seats'), style: const TextStyle(fontWeight: FontWeight.w800))),
                    IconButton(onPressed: _seats > 1 ? () => setState(() => _seats--) : null, icon: const Icon(Icons.remove_circle_outline)),
                    Text('$_seats', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                    IconButton(onPressed: _seats < _left ? () => setState(() => _seats++) : null, icon: const Icon(Icons.add_circle_outline)),
                  ]),
                ),
                const SizedBox(height: 10),
                FieldLabel(tx('HOW THEY PAY')),
                const SizedBox(height: 4),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  ChoiceChipButton(tx('Cash to me'), selected: _pay == 'cash', onTap: () => setState(() => _pay = 'cash')),
                  ChoiceChipButton('Airtel Money', selected: _pay == 'airtel_money', onTap: () => setState(() => _pay = 'airtel_money')),
                  ChoiceChipButton('TNM Mpamba', selected: _pay == 'tnm_mpamba', onTap: () => setState(() => _pay = 'tnm_mpamba')),
                ]),
                if (_pay != 'cash') ...[
                  const SizedBox(height: 8),
                  if (number.isNotEmpty)
                    AppCard(
                      color: const Color(0xFFFFF6DD),
                      borderColor: const Color(0xFFF0C24A),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(txf('Passenger sends %s to', [total == null ? '' : money(total)]), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF5A4300))),
                        Text(number, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                      ]),
                    ),
                  const SizedBox(height: 8),
                  TextField(controller: _ref, textCapitalization: TextCapitalization.characters, decoration: InputDecoration(labelText: tx('Mobile money reference'), border: const OutlineInputBorder())),
                ],
                const SizedBox(height: 10),
                TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tx('Phone (optional)'), border: const OutlineInputBorder())),
                const SizedBox(height: 14),
                if (total != null) TotalBox('PRICE', money(total), txf('%s seats · from your road price list', ['$_seats'])),
                const SizedBox(height: 12),
                AppButton(total == null ? tx('Choose where they get off') : txf('Board · %s', [money(total)]), loading: _busy, onPressed: canAdd ? _add : null),
              ],
            ]),
    );
  }
}
