import 'package:flutter/material.dart';
import '../support/support_screens.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../widgets.dart';

/// Driver documents: what is required, what is uploaded and what the admin approved.
class DocumentsScreen extends StatefulWidget {
  final VoidCallback? onChanged;
  final bool blocking; // shown before the driver may go on duty
  final String missing;
  const DocumentsScreen({super.key, this.onChanged, this.blocking = false, this.missing = ''});

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  List<Doc> _docs = [];
  bool _loading = true;
  final _kinName = TextEditingController();
  final _kinPhone = TextEditingController();
  final _kinRelation = TextEditingController();
  bool _savingKin = false;

  @override
  void initState() {
    super.initState();
    final me = appState.profile;
    _kinName.text = me?.nextOfKinName ?? '';
    _kinPhone.text = me?.nextOfKinPhone ?? '';
    _kinRelation.text = me?.nextOfKinRelation ?? '';
    _load();
  }

  @override
  void dispose() {
    _kinName.dispose();
    _kinPhone.dispose();
    _kinRelation.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db.from('documents').select().eq('driver_id', me.id).order('created_at', ascending: false);
      if (mounted) setState(() => _docs = rows.map(Doc.fromMap).toList());
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Doc? _latest(String kind) {
    for (final d in _docs) {
      if (d.kind == kind) return d;
    }
    return null;
  }

  Future<void> _saveKin() async {
    final me = appState.profile;
    if (me == null) return;
    if (_kinName.text.trim().isEmpty || _kinPhone.text.trim().isEmpty) {
      toast(context, tx('Enter the name and phone of your next of kin.'));
      return;
    }
    setState(() => _savingKin = true);
    try {
      await db.from('profiles').update({
        'next_of_kin_name': _kinName.text.trim(),
        'next_of_kin_phone': _kinPhone.text.trim(),
        'next_of_kin_relation': _kinRelation.text.trim(),
      }).eq('id', me.id);
      await appState.refresh();
      if (mounted) toast(context, tx('Next of kin saved.'));
      widget.onChanged?.call();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _savingKin = false);
    }
  }

  Future<void> _open(DocKind kind) async {
    final saved = await Navigator.of(context)
        .push<bool>(MaterialPageRoute(builder: (_) => DocUploadScreen(kind: kind)));
    if (saved == true) {
      await _load();
      widget.onChanged?.call();
    }
  }

  Widget _status(Doc? d) {
    if (d == null) return StatusPill(tx('Missing'), color: AppColors.danger);
    if (d.status == 'approved' && d.expired) return StatusPill(tx('Expired'), color: AppColors.danger);
    return switch (d.status) {
      'approved' => StatusPill(tx('Approved'), color: AppColors.lime600),
      'rejected' => StatusPill(tx('Rejected'), color: AppColors.danger),
      _ => StatusPill(tx('Waiting for admin'), color: AppColors.warning),
    };
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            NavyHeader(
              top: widget.blocking ? tx('BEFORE YOUR FIRST SHIFT') : tx('DRIVER'),
              title: tr('documents'),
              subtitle: widget.blocking
                  ? tx('Upload these and wait for the admin to approve them. Then you can go on duty.')
                  : tx('Keep your licence and permit up to date.'),
              actions: [
                const LanguageSwitch(),
                IconButton(
                    tooltip: tx('Help & support'),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SupportHomeScreen())),
                    icon: const Icon(Icons.support_agent, color: Colors.white)),
                if (widget.blocking)
                  IconButton(
                      tooltip: tx('Sign out'),
                      onPressed: () => appState.signOut(),
                      icon: const Icon(Icons.logout, color: Colors.white)),
              ],
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: RefreshIndicator(
                  onRefresh: () async {
                    await _load();
                    widget.onChanged?.call();
                  },
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (_loading) const LinearProgressIndicator(),
                      SectionTitle(tx('REQUIRED')),
                      for (final k in driverDocKinds.where((k) => k.required)) ...[_docCard(k), const SizedBox(height: 8)],
                      AppCard(
                        borderColor: (me?.nextOfKinName ?? '').isEmpty ? AppColors.danger : null,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(tx('Next of kin'), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                            const SizedBox(height: 8),
                            TextField(controller: _kinName, decoration: plainInput('Name')),
                            const SizedBox(height: 8),
                            TextField(
                                controller: _kinPhone,
                                keyboardType: TextInputType.phone,
                                decoration: plainInput('Phone')),
                            const SizedBox(height: 8),
                            TextField(controller: _kinRelation, decoration: plainInput('Relationship, e.g. wife, brother')),
                            const SizedBox(height: 8),
                            AppButton(tx('Save next of kin'), kind: ButtonKind.navy, height: 44, loading: _savingKin, onPressed: _saveKin),
                          ],
                        ),
                      ),
                      SectionTitle(tx('OPTIONAL / RECOMMENDED')),
                      for (final k in driverDocKinds.where((k) => !k.required)) ...[_docCard(k), const SizedBox(height: 8)],
                      if (widget.blocking) ...[
                        const SizedBox(height: 8),
                        AppButton(tx('Check again'), onPressed: () => widget.onChanged?.call()),
                      ],
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _docCard(DocKind k) {
    final d = _latest(k.key);
    return AppCard(
      child: InkWell(
        onTap: () => _open(k),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(k.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              Text(
                d == null
                    ? k.help
                    : [
                        if (d.number != null) d.number!,
                        if (d.licenceClass != null) 'class ${d.licenceClass}',
                        if (d.expiresOn != null) 'to ${shortDate(d.expiresOn!)} ${d.expiresOn!.year}',
                        if (d.status == 'rejected' && d.note != null) 'Admin: ${d.note}',
                      ].join(' · ').ifEmpty(k.help),
                style: const TextStyle(fontSize: 13, color: AppColors.muted),
              ),
            ]),
          ),
          const SizedBox(width: 8),
          _status(d),
          const Icon(Icons.chevron_right, color: AppColors.muted),
        ]),
      ),
    );
  }
}

extension on String {
  String ifEmpty(String other) => isEmpty ? other : this;
}

/// Upload one document: photos (front/back), number, licence class, expiry date.
class DocUploadScreen extends StatefulWidget {
  final DocKind kind;
  const DocUploadScreen({super.key, required this.kind});

  @override
  State<DocUploadScreen> createState() => _DocUploadScreenState();
}

class _DocUploadScreenState extends State<DocUploadScreen> {
  Photo? _front;
  Photo? _back;
  final _number = TextEditingController();
  String? _class;
  DateTime? _expires;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _number.dispose();
    super.dispose();
  }

  Future<void> _pick({required bool back, required bool gallery}) async {
    try {
      final p = await takePhoto('doc_${widget.kind.key}${back ? '_back' : ''}',
          allowGallery: gallery, front: widget.kind.selfie);
      if (p != null) setState(() => back ? _back = p : _front = p);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _save() async {
    final k = widget.kind;
    setState(() => _error = null);
    String? problem;
    if (_front == null) {
      problem = k.selfie ? 'Take the photo of your face.' : 'Take the photo of the front.';
    } else if (k.hasBack && _back == null) {
      problem = 'Take the photo of the back.';
    } else if (k.hasExpiry && _expires == null) {
      problem = 'Choose the expiry date.';
    }
    if (problem != null) {
      setState(() => _error = problem);
      return;
    }
    setState(() => _busy = true);
    try {
      await db.from('documents').insert({
        'driver_id': appState.profile?.id,
        'kind': k.key,
        'front_path': _front!.path,
        'back_path': _back?.path,
        'number': _number.text.trim().isEmpty ? null : _number.text.trim(),
        'licence_class': _class,
        'expires_on': _expires == null
            ? null
            : '${_expires!.year}-${_expires!.month.toString().padLeft(2, '0')}-${_expires!.day.toString().padLeft(2, '0')}',
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _photoBox(String label, Photo? p, bool back) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FieldLabel(label),
            const SizedBox(height: 8),
            Container(
              height: 160,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(color: AppColors.surface100, borderRadius: BorderRadius.circular(10)),
              child: p == null
                  ? const Center(child: Icon(Icons.badge_outlined, size: 40, color: AppColors.muted))
                  : Image.memory(p.bytes, fit: BoxFit.cover),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: AppButton(tx('Camera'), kind: ButtonKind.navy, height: 44, onPressed: () => _pick(back: back, gallery: false)),
              ),
              if (!widget.kind.selfie) ...[
                const SizedBox(width: 8),
                Expanded(
                  child: AppButton(tx('Gallery'), kind: ButtonKind.outline, height: 44, onPressed: () => _pick(back: back, gallery: true)),
                ),
              ],
            ]),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final k = widget.kind;
    return Scaffold(
      appBar: AppBar(
        title: Text(k.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.surface100,
        foregroundColor: AppColors.ink,
        elevation: 0,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(k.help, style: const TextStyle(color: AppColors.muted)),
            const SizedBox(height: 12),
            _photoBox(k.selfie ? 'YOUR FACE' : 'FRONT', _front, false),
            if (k.hasBack) ...[const SizedBox(height: 12), _photoBox('BACK', _back, true)],
            if (!k.selfie) ...[
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FieldLabel(tx('NUMBER (OPTIONAL)')),
                  TextField(controller: _number, decoration: const InputDecoration(border: InputBorder.none, isDense: true)),
                ]),
              ),
            ],
            if (k.key == 'licence') ...[
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FieldLabel(tx('LICENCE CLASS')),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final c in const ['A1', 'A', 'B', 'C1', 'C', 'D1', 'D', 'EB', 'EC1', 'EC', 'ED1', 'ED'])
                      ChoiceChipButton(c, selected: _class == c, onTap: () => setState(() => _class = c)),
                  ]),
                ]),
              ),
            ],
            if (k.hasExpiry) ...[
              const SizedBox(height: 12),
              AppCard(
                child: InkWell(
                  onTap: () async {
                    final now = DateTime.now();
                    final d = await showDatePicker(
                      context: context,
                      initialDate: _expires ?? now.add(const Duration(days: 365)),
                      firstDate: DateTime(now.year - 1),
                      lastDate: DateTime(now.year + 15),
                    );
                    if (d != null) setState(() => _expires = d);
                  },
                  child: Row(children: [
                    Expanded(child: FieldLabel(tx('EXPIRY DATE'))),
                    Text(_expires == null ? tx('Choose') : '${shortDate(_expires!)} ${_expires!.year}',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.navy)),
                  ]),
                ),
              ),
            ],
            const SizedBox(height: 12),
            ErrorLine(_error),
            const SizedBox(height: 8),
            AppButton(tx('Send to admin'), height: 56, loading: _busy, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
