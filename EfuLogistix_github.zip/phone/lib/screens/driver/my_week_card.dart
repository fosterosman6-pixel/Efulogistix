import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../../i18n.dart';

/// Driver: today's takings, this week, rating and the vehicle's weekly target.
class MyWeekCard extends StatefulWidget {
  const MyWeekCard({super.key});

  @override
  State<MyWeekCard> createState() => _MyWeekCardState();
}

class _MyWeekCardState extends State<MyWeekCard> {
  Map<String, dynamic>? _w;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await db.rpc('my_week');
      if (mounted) setState(() => _w = Map<String, dynamic>.from(r as Map));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final w = _w;
    if (w == null) return const SizedBox.shrink();
    final target = toDouble(w['target']);
    final vehicleWeek = toDouble(w['vehicle_week']);
    final pct = target > 0 ? (vehicleWeek / target).clamp(0.0, 1.0) : null;
    final rating = w['rating'];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FieldLabel(tx('MY WEEK')),
          const SizedBox(height: 8),
          Row(children: [
            _stat(tx('Today'), money(toDouble(w['today']))),
            _stat(tx('This week'), money(toDouble(w['week']))),
            _stat(tx('Trips'), '${w['trips']}'),
            _stat(tx('Rating'), rating == null ? '–' : '$rating ★'),
          ]),
          if (pct != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: pct,
                minHeight: 10,
                backgroundColor: AppColors.surface100,
                color: pct >= 1 ? AppColors.lime600 : AppColors.lime,
              ),
            ),
            const SizedBox(height: 4),
            Text(
                pct >= 1
                    ? tx('Weekly target reached. Well done!')
                    : txf('Vehicle target: %s of %s (%s%)', [money(vehicleWeek), money(target), '${(pct * 100).round()}']),
                style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          ],
        ]),
      ),
    );
  }

  Widget _stat(String label, String value) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
        ]),
      );
}
