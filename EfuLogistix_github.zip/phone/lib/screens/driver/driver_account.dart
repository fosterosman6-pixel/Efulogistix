import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../i18n.dart';
import '../../menu_ui.dart';
import '../../notices.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../chat_screen.dart';
import '../profile_screen.dart';
import 'documents.dart';
import 'wallet.dart';

/// Driver account page: General and Support, then Log out.
class DriverAccountScreen extends StatelessWidget {
  const DriverAccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    void open(Widget s) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => s));
    final ownerId = appState.truck?.ownerId;
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(title: Text(tx('Account'), style: const TextStyle(fontWeight: FontWeight.w800)), backgroundColor: AppColors.navy, foregroundColor: Colors.white),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
          Container(color: AppColors.navy, padding: const EdgeInsets.fromLTRB(20, 4, 8, 18), child: const ProfileHeader()),
          MenuHeading(tx('General')),
          MenuRow(art: 'person', icon: Icons.person_outline, title: tx('My profile'), onTap: () => open(const MyProfileScreen())),
          MenuRow(art: 'doc', icon: Icons.folder_open_outlined, title: tr('documents'), onTap: () => open(const DocumentsScreen())),
          MenuRow(art: 'wallet', icon: Icons.account_balance_wallet_outlined, title: tx('My wallet'), onTap: () => open(const WalletScreen())),
          MenuRow(art: 'bell', icon: Icons.notifications_none, title: tx('Messages'), onTap: () => open(const NoticesScreen())),
          if (ownerId != null)
            MenuRow(icon: Icons.chat_bubble_outline, title: tx('Message the owner'), onTap: () => open(ChatScreen(peerId: ownerId, title: tx('Owner')))),
          menuDivider,
          const SupportGroup(),
          menuDivider,
          const LogoutRow(),
        ]),
      ),
    );
  }
}
