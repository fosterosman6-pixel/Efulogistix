import 'package:flutter/material.dart';

import '../../theme.dart';

/// A pill with a knob the driver drags to the end. Calls [onDone] once, then springs back.
class SlideToConfirm extends StatefulWidget {
  final String label;
  final VoidCallback onDone;
  const SlideToConfirm({super.key, required this.label, required this.onDone});

  @override
  State<SlideToConfirm> createState() => _SlideToConfirmState();
}

class _SlideToConfirmState extends State<SlideToConfirm> {
  double _x = 0;
  static const double _knob = 48;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, c) {
        final max = (c.maxWidth - _knob - 8).clamp(1.0, 2000.0);
        return Container(
          height: 56,
          decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(28)),
          child: Stack(alignment: Alignment.centerLeft, children: [
            Center(
              child: Opacity(
                opacity: (1 - _x / max).clamp(0.2, 1.0),
                child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
            ),
            Positioned(
              left: 4 + _x,
              child: GestureDetector(
                onHorizontalDragUpdate: (d) => setState(() => _x = (_x + d.delta.dx).clamp(0.0, max)),
                onHorizontalDragEnd: (_) {
                  final done = _x >= max * 0.9;
                  setState(() => _x = 0);
                  if (done) widget.onDone();
                },
                child: Container(
                  width: _knob,
                  height: _knob,
                  decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle),
                  child: const Icon(Icons.chevron_right, color: AppColors.navy, size: 30),
                ),
              ),
            ),
          ]),
        );
      });
}
