import 'package:flutter/material.dart';
import '../support/support_screens.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'documents.dart';
import 'wallet.dart';
import '../../i18n.dart';

/// Documents approved, no vehicle yet: the driver waits for the office to match them with a vehicle.
/// When a meeting is set, it shows the vehicle, its owner, the time and the place.
class WaitingForVehicleScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const WaitingForVehicleScreen({super.key, required this.onChanged});

  @override
  State<WaitingForVehicleScreen> createState() => _WaitingForVehicleScreenState();
}

class _WaitingForVehicleScreenState extends State<WaitingForVehicleScreen> {
  DriverMatch? _match;
  Truck? _truck;
  Profile? _owner;
  String? _category;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final row = await db
          .from('driver_matches')
          .select()
          .eq('driver_id', me.id)
          .eq('status', 'invited')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
      final m = row == null ? null : DriverMatch.fromMap(row);
      Truck? t;
      Profile? o;
      String? cat;
      if (m != null) {
        final tr = await db.from('trucks').select().eq('id', m.truckId).maybeSingle();
        t = tr == null ? null : Truck.fromMap(tr);
        if (t?.ownerId != null) {
          final pr = await db.from('profiles').select().eq('id', t!.ownerId!).maybeSingle();
          o = pr == null ? null : Profile.fromMap(pr);
        }
        if (t?.categoryId != null) {
          final c = await db.from('vehicle_categories').select().eq('id', t!.categoryId!).maybeSingle();
          cat = c?['name'] as String?;
        }
      }
      if (!mounted) return;
      setState(() {
        _match = m;
        _truck = t;
        _owner = o;
        _category = cat;
      });
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _check() async {
    setState(() => _loading = true);
    await appState.refresh();
    if (appState.profile?.truckId != null) {
      widget.onChanged();
      return;
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final m = _match;
    final t = _truck;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      body: RefreshIndicator(
        onRefresh: _check,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 8, 20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  ProfileHeader(actions: [
                    IconButton(
                        tooltip: tx('Help & support'),
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SupportHomeScreen())),
                        icon: const Icon(Icons.support_agent, color: Colors.white)),
                  ]),
                  const SizedBox(height: 14),
                  Text(tx('DOCUMENTS APPROVED ✓'), style: TextStyle(color: AppColors.lime, fontSize: 13, fontWeight: FontWeight.w800)),
                  Text(m == null ? tx('Waiting for a vehicle') : tx('Meet the owner at the office'),
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                  Text(
                      m == null
                          ? tx('The office matches you with a vehicle and invites you and the owner to meet.')
                          : tx('If you both agree, the vehicle is yours to drive.'),
                      style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
                ]),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (m != null && t != null) ...[
                AppCard(
                  borderColor: AppColors.lime,
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Row(children: [
                      VehicleTile(_category, width: 64),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t.plate, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          Text([if (_category != null) _category!, if (t.looks.isNotEmpty) t.looks].join(' · '),
                              style: const TextStyle(color: AppColors.muted)),
                        ]),
                      ),
                    ]),
                    const Divider(height: 24),
                    _row(Icons.event, '${_weekday(m.meetAt)} ${shortDate(m.meetAt)} · ${clock(m.meetAt)}'),
                    _row(Icons.place_outlined, m.place),
                    if (_owner != null)
                      Row(children: [
                        Expanded(child: _row(Icons.person_outline, txf('Owner: %s', ['${_owner!.displayName}']))),
                        if (_owner!.phone != null)
                          IconButton(
                            tooltip: tx('Call the owner'),
                            onPressed: () => launchUrl(Uri.parse('tel:${_owner!.phone}')),
                            icon: const Icon(Icons.call, color: AppColors.navy),
                          ),
                      ]),
                    if (m.note != null) _row(Icons.notes, m.note!),
                    const SizedBox(height: 6),
                    Text(tx('Bring your licence and national ID. The office marks Agreed or Not agreed after the meeting.'),
                        style: TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
                const SizedBox(height: 12),
              ] else ...[
                AppCard(
                  padding: EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(tx('What happens next'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    SizedBox(height: 8),
                    Text(tx('1. The office finds a vehicle that fits your licence.')),
                    Text(tx('2. You and the vehicle owner meet at the office.')),
                    Text(tx('3. If you agree, the vehicle is given to you in the app.')),
                    Text(tx('4. Each day you hand in the money to the owner; 10% goes to your wallet.')),
                  ]),
                ),
                const SizedBox(height: 12),
              ],
              AppButton(tx('Check again'), loading: _loading, onPressed: _check),
              const SizedBox(height: 8),
              AppButton(tx('My documents'),
                  kind: ButtonKind.outline,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocumentsScreen()))),
              const SizedBox(height: 8),
              AppButton(tx('My wallet'),
                  kind: ButtonKind.outline,
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WalletScreen()))),
              const SizedBox(height: 8),
              AppButton(tx('Sign out'), kind: ButtonKind.ghost, onPressed: () => appState.signOut()),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _row(IconData icon, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Icon(icon, size: 20, color: AppColors.navy),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600))),
        ]),
      );

  String _weekday(DateTime d) => const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d.weekday - 1];
}
