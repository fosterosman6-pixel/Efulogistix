import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../outbox.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';

/// End of day: 4 photos of the truck, mileage photo + km, and the cash to hand in.
class EndShiftScreen extends StatefulWidget {
  final Shift shift;
  const EndShiftScreen({super.key, required this.shift});

  @override
  State<EndShiftScreen> createState() => _EndShiftScreenState();
}

class _EndShiftScreenState extends State<EndShiftScreen> {
  final _odo = OdoController();
  final Map<String, Photo?> _sides = {'Front': null, 'Back': null, 'Left': null, 'Right': null};
  final _reference = TextEditingController();
  String _method = 'cash';
  int _trips = 0;
  int _passengers = 0;
  double _collected = 0;
  double _expenses = 0;
  bool _busy = false;
  String? _error;
  HandIn? _done;
  String? _ownerName; // money goes straight to the vehicle owner
  String? _ownerPhone;
  double _pct = 10; // driver's share into the wallet

  @override
  void initState() {
    super.initState();
    _loadTotals();
  }

  @override
  void dispose() {
    _odo.dispose();
    _reference.dispose();
    super.dispose();
  }

  Future<void> _loadOwner() async {
    try {
      final ownerId = appState.truck?.ownerId;
      if (ownerId != null) {
        final row = await db.from('profiles').select().eq('id', ownerId).maybeSingle();
        if (row != null && mounted) {
          final p = Profile.fromMap(row);
          setState(() {
            _ownerName = p.displayName;
            _ownerPhone = p.phone;
          });
        }
      }
      final st = await db.from('app_settings').select();
      if (st.isNotEmpty && mounted) setState(() => _pct = toDouble(st.first['wallet_pct'] ?? 10));
    } catch (_) {}
  }

  double get _share => ((_collected - _expenses) * _pct / 100).clamp(0, double.infinity).roundToDouble();

  Widget _walletCard(double share) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: AppCard(
          borderColor: AppColors.lime,
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.account_balance_wallet, color: AppColors.navy),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(txf('Your %s% today', ['${_pct.round()}']), style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(tx('Added to your wallet when the owner confirms · paid Monday'),
                    style: TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            Text('+ ${money(share)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.lime600)),
          ]),
        ),
      );

  String get _handTo => _ownerName == null ? tx('the office') : txf('the owner, %s', ['$_ownerName']);

  Future<void> _loadTotals() async {
    _loadOwner();
    try {
      await Outbox.instance.flush(); // make sure stops/expenses saved offline are counted
      final res = await db.rpc('shift_totals', params: {'p_shift': widget.shift.id});
      final row = res is List ? (res.isEmpty ? null : res.first) : res;
      if (row is Map && mounted) {
        setState(() {
          _trips = toInt(row['trips']);
          _passengers = toInt(row['passengers']);
          _collected = toDouble(row['collected']);
          _expenses = toDouble(row['driver_expenses']);
        });
      }
    } catch (_) {}
  }

  Future<void> _finish() async {
    setState(() => _error = null);
    if (_sides.values.any((p) => p == null)) {
      setState(() => _error = 'Take the 4 photos of the truck.');
      return;
    }
    if (!_odo.ready) {
      setState(() => _error = 'Take the mileage photo and type the km.');
      return;
    }
    if (_method != 'cash' && _reference.text.trim().isEmpty) {
      setState(() => _error = 'Type the mobile money reference.');
      return;
    }
    setState(() => _busy = true);
    try {
      final here = Tracking.instance.position.value;
      final since = await Tracking.instance.takeSinceReading();
      final id = await db.rpc('end_shift', params: {
        'p_km': _odo.value,
        'p_photo': _odo.photo!.path,
        'p_truck_photos': _sides.values.map((p) => p!.path).toList(),
        'p_lat': here?.latitude,
        'p_lng': here?.longitude,
        'p_gps_since': since,
        'p_method': _method,
        'p_reference': _reference.text.trim(),
      });
      await Tracking.instance.stop();
      final row = await db.from('hand_ins').select().eq('id', id.toString()).single();
      if (mounted) setState(() => _done = HandIn.fromMap(row));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final done = _done;
    final truck = appState.truck;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (done == null)
              Row(children: [
                IconButton(
                  tooltip: tx('Back'),
                  onPressed: () => Navigator.of(context).pop(false),
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                ),
              ]),
            NavyHeader(
              top: txf('ON DUTY %s – %s · %s', [clock(widget.shift.startedAt), clock(DateTime.now()), truck?.plate ?? '']),
              title: done == null ? tr('end_of_day') : tx('Off duty'),
              subtitle: done == null ? tx('Photos, mileage and cash hand-in, then go off duty.') : txf('Hand the full amount to %s.', ['${_handTo}']),
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: done != null ? _doneView(done) : _form(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _doneView(HandIn h) => ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          AppCard(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              FieldLabel(tr('to_hand_in').toUpperCase()),
              const SizedBox(height: 4),
              Text(money(h.expected), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: AppColors.navy)),
              Text(txf('%s trips · %s passengers · %s − expenses %s', ['${h.trips}', '${h.passengers}', '${money(h.collected)}', '${money(h.driverExpenses)}']),
                  style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 8),
              Text(txf('By %s', [h.methodName]) + (h.reference != null ? ' · ref ${h.reference}' : ''),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              if (_ownerName != null)
                Text(txf('To %s', ['$_ownerName']) + (_ownerPhone != null ? ' · $_ownerPhone' : ''), style: const TextStyle(color: AppColors.muted)),
            ]),
          ),
          _walletCard((h.expected * _pct / 100).clamp(0, double.infinity).roundToDouble()),
          const SizedBox(height: 16),
          AppButton(tx('Done'), height: 56, onPressed: () => Navigator.of(context).pop(true)),
        ],
      );

  Widget _form() => ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 32 + MediaQuery.of(context).viewPadding.bottom),
        children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              FieldLabel('1 · ${tr('truck_photos')}'),
              const SizedBox(height: 8),
              Row(children: [
                for (final side in _sides.keys) ...[
                  Expanded(
                    child: PhotoSlot(
                      label: side,
                      fileLabel: 'truck_${side.toLowerCase()}',
                      photo: _sides[side],
                      onTaken: (p) => setState(() => _sides[side] = p),
                    ),
                  ),
                  if (side != 'Right') const SizedBox(width: 6),
                ],
              ]),
            ]),
          ),
          const SizedBox(height: 12),
          OdometerCapture(
            controller: _odo,
            photoLabel: 'shift_end',
            hint: txf('On duty at %s km · GPS this shift %s+ km', ['${widget.shift.startKm}', '${widget.shift.gpsKm.round()}']),
            onChanged: () => setState(() {}),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              FieldLabel(tx('3 · CASH HAND-IN')),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: Text(txf('%s trips · %s passengers', ['${_trips}', '${_passengers}']), style: const TextStyle(fontSize: 14))),
                Text(money(_collected), style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 4),
              Row(children: [
                Expanded(child: Text(tx('Expenses you paid (receipt)'), style: TextStyle(fontSize: 14))),
                Text('− ${money(_expenses)}', style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
              const Divider(color: AppColors.line, height: 20),
              Row(children: [
                Expanded(
                    child: Text(_ownerName == null ? tr('to_hand_in') : tx('Hand in to the owner'),
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
                Text(money(_collected - _expenses),
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.navy)),
              ]),
              if (_ownerName != null)
                Text(txf('Owner: %s', ['$_ownerName']) + (_ownerPhone != null ? ' · $_ownerPhone' : ''),
                    style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final e in HandIn.methodNames.entries)
                  ChoiceChipButton(e.value, selected: _method == e.key, onTap: () => setState(() => _method = e.key)),
              ]),
              if (_method != 'cash') ...[
                const SizedBox(height: 8),
                TextField(controller: _reference, decoration: plainInput('Mobile money reference')),
              ],
            ]),
          ),
          _walletCard(_share),
          ValueListenableBuilder<int>(
            valueListenable: Outbox.instance.pending,
            builder: (context, n, _) => n == 0
                ? const SizedBox.shrink()
                : Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(trf('offline_waiting', '$n'),
                        style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
                  ),
          ),
          const SizedBox(height: 12),
          ErrorLine(_error),
          const SizedBox(height: 8),
          AppButton(tr('go_off_duty'), height: 56, loading: _busy, onPressed: _finish),
        ],
      );
}
