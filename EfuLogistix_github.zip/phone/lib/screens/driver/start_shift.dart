import 'dart:async';

import 'package:flutter/material.dart';
import '../../icon_art.dart';
import 'driver_nav.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../home_ui.dart';
import '../../vehicle_art.dart';
import '../../i18n.dart';
import '../../location.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import 'documents.dart';


/// Morning: the driver fetches the truck, photographs the mileage and goes on duty.
class StartShiftScreen extends StatefulWidget {
  final VoidCallback onStarted;
  const StartShiftScreen({super.key, required this.onStarted});

  @override
  State<StartShiftScreen> createState() => _StartShiftScreenState();
}

class _StartShiftScreenState extends State<StartShiftScreen> {
  final _odo = OdoController();
  final Map<String, Photo?> _sides = {'Front': null, 'Back': null, 'Left': null, 'Right': null};
  late Timer _clock;
  DateTime _now = DateTime.now();
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _clock = Timer.periodic(const Duration(seconds: 15), (_) => setState(() => _now = DateTime.now()));
  }

  @override
  void dispose() {
    _clock.cancel();
    _odo.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    setState(() => _error = null);
    if (appState.truck == null) {
      setState(() => _error = tx('You have no truck yet. Ask the manager to give you one.'));
      return;
    }
    if (!_odo.ready) {
      setState(() => _error = tx('Take the mileage photo and type the km.'));
      return;
    }
    if (_sides.values.any((p) => p == null)) {
      setState(() => _error = tx('Take the 4 live photos of the vehicle first: front, back, left and right.'));
      return;
    }
    setState(() => _busy = true);
    try {
      final problem = await ensureLocation();
      if (problem != null) {
        if (mounted) setState(() => _error = problem);
        return;
      }
      final here = await currentPoint();
      await db.rpc('start_shift', params: {
        'p_km': _odo.value,
        'p_photo': _odo.photo!.path,
        'p_lat': here?.latitude,
        'p_lng': here?.longitude,
        'p_truck_photos': _sides.values.map((p) => p!.path).toList(),
      });
      await Tracking.instance.takeSinceReading(); // start counting from this photo
      widget.onStarted();
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    final truck = appState.truck;
    return ValueListenableBuilder<String>(
      valueListenable: language,
      builder: (context, _, __) => Scaffold(
        backgroundColor: AppColors.navy,
        bottomNavigationBar: const DriverNavBar(),
        body: SafeArea(
          bottom: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              NavyHeader(
                top: truck == null ? tx('NO TRUCK ASSIGNED') : txf('OFF DUTY · %s', ['${truck.plate}']),
                title: tr('start_shift'),
                subtitle: language.value == 'ny'
                    ? txf('Hello %s. Check the truck, then go on duty.', ['${me?.firstName ?? ''}'])
                    : 'Good ${_now.hour < 12 ? 'morning' : _now.hour < 17 ? 'afternoon' : 'evening'}, '
                        '${me?.firstName ?? ''}. Check the truck, then go on duty.',
                actions: [
                  const LanguageSwitch(),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, color: Colors.white),
                    onSelected: (v) {
                      if (v == 'docs') {
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocumentsScreen()));
                      } else if (v == 'out') {
                        appState.signOut();
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'docs', child: Text(tr('documents'))),
                      PopupMenuItem(value: 'out', child: Text(tx('Sign out'))),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: ClipRRect(
 borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
 child: Container(
                  color: AppColors.surface100,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                    children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(
                          child: AppCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              FieldLabel(tr('on_duty_at')),
                              Text(clock(_now), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                              Text(txf('%s %s · phone time', [weekdayShort(_now.weekday), shortDate(_now)]),
                                  style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                            ]),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              FieldLabel(tr('truck')),
                              Text(truck?.plate ?? '—', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                              Text(truck?.model ?? '', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                              if (appState.category != null) ...[
                                const SizedBox(height: 6),
                                VehicleArt(appState.category!.name, width: 84),
                              ],
                            ]),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 4),
                      HomeLabel(tx('Where you are')),
                      const HomeMap(),
                      const SizedBox(height: 12),
                      OdometerCapture(
                        controller: _odo,
                        photoLabel: 'shift_start',
                        hint: truck?.currentKm == null ? null : txf('Last recorded: %s km', ['${truck!.currentKm}']),
                        onChanged: () => setState(() {}),
                      ),
                      const SizedBox(height: 12),
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          FieldLabel(tx('PHOTOS OF THE VEHICLE · ALL 4 SIDES')),
                          const SizedBox(height: 8),
                          Row(children: [
                            for (final side in _sides.keys) ...[
                              Expanded(
                                child: PhotoSlot(
                                  label: tx(switch (side) {
                                    'Front' => 'Front side',
                                    'Back' => 'Back side',
                                    'Left' => 'Left side',
                                    _ => 'Right side',
                                  }),
                                  fileLabel: 'start_truck_${side.toLowerCase()}',
                                  photo: _sides[side],
                                  onTaken: (p) => setState(() => _sides[side] = p),
                                ),
                              ),
                              if (side != 'Right') const SizedBox(width: 6),
                            ],
                          ]),
                          const SizedBox(height: 6),
                          Text(tx('Camera only. Take them now, standing next to the vehicle.'),
                              style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      Row(children: [
                        const IconArt('shield', size: 22, fallback: Icons.shield_outlined),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(tr('tracking_locked'), style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                        ),
                      ]),
                      const SizedBox(height: 12),
                      ErrorLine(_error),
                      const SizedBox(height: 8),
                      AppButton(tr('go_on_duty'), height: 56, loading: _busy, onPressed: _start),
                    ],
                  ),
                ),
 ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
