import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../location.dart';
import '../../models.dart';
import '../../outbox.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';

/// A stop on the way: how many got off, how many got on and where they are going.
/// Saved with the GPS point and time; works without signal (sent later).
class StopScreen extends StatefulWidget {
  final Trip trip;
  final List<TripStop> stops;
  const StopScreen({super.key, required this.trip, required this.stops});

  @override
  State<StopScreen> createState() => _StopScreenState();
}

class _StopScreenState extends State<StopScreen> {
  final _place = TextEditingController();
  final _fare = TextEditingController();
  final _goodsOff = TextEditingController();
  int _dropped = 0;
  int _picked = 0;
  List<RouteFare> _routes = [];
  List<GoodsPrice> _prices = [];
  RouteFare? _route;
  final List<GoodsItem> _goodsOn = [];
  bool _busy = false;
  String? _error;
  final DateTime _at = DateTime.now();

  int get _onBoardBefore =>
      widget.trip.passengers + widget.stops.fold<int>(0, (s, x) => s + x.picked - x.dropped);

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _place.dispose();
    _fare.dispose();
    _goodsOff.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    placeHere().then((name) {
      if (mounted && _place.text.isEmpty) setState(() => _place.text = name);
    });
    try {
      final r = await db.from('routes').select().eq('active', true);
      final g = await db.from('goods_prices').select().eq('active', true).order('label');
      if (mounted) {
        setState(() {
          _routes = r.map(RouteFare.fromMap).toList();
          _prices = g.map(GoodsPrice.fromMap).toList();
        });
      }
    } catch (_) {}
  }

  /// Fixed fares from this place (by name), e.g. Nkope → Monkey Bay.
  List<RouteFare> get _routesHere {
    final here = _place.text.trim().toLowerCase();
    if (here.isEmpty) return [];
    return _routes.where((r) => r.fromName.toLowerCase() == here).toList();
  }

  double get _fareValue => _route?.fare ?? parseAmount(_fare.text);
  double get _goodsTotal => _goodsOn.fold<double>(0, (s, g) => s + g.amount);
  double get _amount => _picked * _fareValue + _goodsTotal;

  Future<void> _save() async {
    setState(() => _error = null);
    if (_dropped == 0 && _picked == 0 && _goodsOn.isEmpty && _goodsOff.text.trim().isEmpty) {
      setState(() => _error = 'Nothing changed at this stop.');
      return;
    }
    if (_dropped > _onBoardBefore) {
      setState(() => _error = 'Only $_onBoardBefore passengers are on board.');
      return;
    }
    final seats = appState.truck?.seats ?? appState.category?.seats;
    if (seats != null && seats > 0 && _onBoardBefore - _dropped + _picked > seats) {
      setState(() => _error = 'This vehicle has $seats seats.');
      return;
    }
    if (_picked > 0 && _fareValue <= 0) {
      setState(() => _error = 'Choose where the new passengers are going, or type the fare.');
      return;
    }
    setState(() => _busy = true);
    try {
      final here = Tracking.instance.position.value ?? await currentPoint();
      await Outbox.instance.insert('trip_stops', {
        'trip_id': widget.trip.id,
        'place_name': _place.text.trim().isEmpty ? null : _place.text.trim(),
        'lat': here?.latitude,
        'lng': here?.longitude,
        'dropped': _dropped,
        'picked': _picked,
        'picked_to': _route?.toName ?? (_picked > 0 ? widget.trip.destName : null),
        'fare_each': _picked > 0 ? _fareValue : 0,
        'goods_off': _goodsOff.text.trim().isEmpty ? null : _goodsOff.text.trim(),
        'goods_on': _goodsOn.map((g) => g.toMap()).toList(),
        'goods_total': _goodsTotal,
        'km_from_start': (Tracking.instance.tripKm * 10).round() / 10,
        'at': _at.toUtc().toIso8601String(),
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.trip;
    final routesHere = _routesHere;
    final after = _onBoardBefore - _dropped + _picked;
    return ValueListenableBuilder<String>(
      valueListenable: language,
      builder: (context, _, __) => Scaffold(
        backgroundColor: AppColors.navy,
        body: SafeArea(
          bottom: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                IconButton(
                  tooltip: tx('Back'),
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                ),
              ]),
              NavyHeader(
                top: txf('TRIP #%s · %s → %s', ['${t.tripNo}', '${t.pickupName.toUpperCase()}', '${t.destName.toUpperCase()}']),
                title: tx('Stop'),
                subtitle: txf('%s · %s km from the start · GPS point saved', ['${clock(_at)}', '${Tracking.instance.tripKm.toStringAsFixed(0)}']),
              ),
              Expanded(
                child: Container(
                  color: AppColors.surface100,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                    children: [
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FieldLabel(tx('PLACE')),
                          TextField(
                            controller: _place,
                            onChanged: (_) => setState(() => _route = null),
                            decoration: InputDecoration(hintText: tx('Village or place'), border: InputBorder.none),
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      if (appState.category?.carriesPassengers ?? true)
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(
                            child: Counter(label: tr('dropped_off'), value: _dropped, onChanged: (v) => setState(() => _dropped = v))),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Counter(
                              label: tr('picked_up'),
                              value: _picked,
                              highlight: true,
                              onChanged: (v) => setState(() => _picked = v)),
                        ),
                      ]),
                      if (_picked > 0) ...[
                        const SizedBox(height: 12),
                        AppCard(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            FieldLabel(tr('going_to')),
                            const SizedBox(height: 8),
                            if (routesHere.isNotEmpty)
                              Wrap(spacing: 8, runSpacing: 8, children: [
                                for (final r in routesHere)
                                  ChoiceChipButton('${r.toName} · ${money(r.fare)}',
                                      selected: _route?.id == r.id, onTap: () => setState(() => _route = r)),
                              ]),
                            if (routesHere.isNotEmpty)
                              Padding(
                                padding: EdgeInsets.only(top: 6),
                                child: Text(tx('Fares from here are set by the admin.'),
                                    style: TextStyle(fontSize: 12, color: AppColors.muted)),
                              ),
                            if (routesHere.isEmpty || _route == null) ...[
                              const SizedBox(height: 8),
                              TextField(
                                controller: _fare,
                                keyboardType: TextInputType.number,
                                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                onChanged: (_) => setState(() {}),
                                decoration: plainInput('Fare each (MWK) to ${t.destName}'),
                              ),
                            ],
                          ]),
                        ),
                      ],
                      const SizedBox(height: 12),
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FieldLabel(tx('GOODS AT THIS STOP')),
                          const SizedBox(height: 8),
                          TextField(controller: _goodsOff, decoration: plainInput('Off, e.g. 3 bags maize')),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            for (var i = 0; i < _goodsOn.length; i++)
                              InputChip(
                                label: Text('On: ${_goodsOn[i].label} · ${money(_goodsOn[i].amount)}'),
                                backgroundColor: AppColors.lime100,
                                side: BorderSide.none,
                                shape: const StadiumBorder(),
                                onDeleted: () => setState(() => _goodsOn.removeAt(i)),
                              ),
                            for (final g in _prices)
                              ActionChip(
                                label: Text('+ ${g.label} ${money(g.price)}'),
                                shape: const StadiumBorder(side: BorderSide(color: AppColors.line)),
                                onPressed: () => setState(() => _goodsOn.add(GoodsItem(g.label, g.price))),
                              ),
                          ]),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      Row(children: [
                        StatTile('On board', '$_onBoardBefore → $after'),
                        const SizedBox(width: 8),
                        StatTile('This stop', money(_amount)),
                        const SizedBox(width: 8),
                        StatTile('Trip total', money(t.total + _amount), dark: true),
                      ]),
                      const SizedBox(height: 12),
                      ErrorLine(_error),
                      const SizedBox(height: 8),
                      AppButton(tr('save_stop'), height: 56, loading: _busy, onPressed: _save),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
