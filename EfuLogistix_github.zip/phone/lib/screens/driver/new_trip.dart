import 'dart:async';

import 'package:flutter/material.dart';
import 'driver_nav.dart';
import 'package:flutter/services.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../home_ui.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../notices.dart';
import '../../outbox.dart';
import '../../theme.dart';
import '../../tracking.dart';
import 'my_week_card.dart';
import '../../widgets.dart';
import '../expense.dart';
import 'documents.dart';
import 'pickups.dart';
import '../support/sos_bar.dart';
import '../support/support_screens.dart';
import 'wallet.dart';
import 'end_shift.dart';
import 'trip.dart';
import 'trip_start.dart';
import 'truck_change.dart';

/// On duty: pick the route (fare set by admin), count passengers and goods, then record mileage.
class NewTripScreen extends StatefulWidget {
  final Shift shift;
  final VoidCallback onChanged; // shift ended or truck changed
  final String? notice;
  const NewTripScreen({super.key, required this.shift, required this.onChanged, this.notice});

  @override
  State<NewTripScreen> createState() => _NewTripScreenState();
}

class _NewTripScreenState extends State<NewTripScreen> {
  List<RouteFare> _routes = [];
  List<GoodsPrice> _prices = [];
  String _from = 'Mangochi Main Rank';
  LatLng? _fromPoint;
  RouteFare? _route;
  bool _other = false;
  final _otherFare = TextEditingController();
  final _search = TextEditingController();
  List<Place> _results = [];
  Place? _place;
  bool _searching = false;
  Timer? _searchTimer;
  int _passengers = 0;
  final List<GoodsItem> _goods = [];
  final _goodsLabel = TextEditingController();
  final _goodsAmount = TextEditingController();
  final _cargoKg = TextEditingController();
  bool _addingGoods = false;
  int _shiftTrips = 0;
  double _shiftTotal = 0;
  List<Booking> _pickups = [];
  List<Map<String, dynamic>> _offers = [];
  Timer? _poll;
  String? _error;
  String? _runningId;

  @override
  void initState() {
    super.initState();
    Here.instance.refresh();
    _error = widget.notice;
    appState.nextPickup.addListener(_applyNextPickup);
    _applyNextPickup();
    _load();
    _checkRunningTrip();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) => _loadPickups());
  }

  @override
  void dispose() {
    _poll?.cancel();
    appState.nextPickup.removeListener(_applyNextPickup);
    _searchTimer?.cancel();
    for (final c in [_otherFare, _search, _goodsLabel, _goodsAmount, _cargoKg]) {
      c.dispose();
    }
    super.dispose();
  }

  bool _locating = false;

  /// Sets the pickup point to where the driver is right now.
  Future<void> _useHere() async {
    setState(() => _locating = true);
    await Here.instance.refresh(force: true);
    if (!mounted) return;
    final point = Here.instance.point.value;
    final name = Here.instance.name.value;
    setState(() {
      _locating = false;
      if (point == null) {
        _error = tx('Could not get your location. Switch on GPS and try again.');
      } else {
        _from = (name == null || name.startsWith('Location')) ? tx('My current location') : name;
        _fromPoint = point;
        _route = null;
        _error = null;
      }
    });
  }

  /// Lets the driver type the pickup place name by hand.
  Future<void> _editFrom() async {
    final c = TextEditingController(text: _from);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tx('Pickup place')),
        content: TextField(controller: c, autofocus: true, textCapitalization: TextCapitalization.words),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tx('Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: Text(tx('Save'))),
        ],
      ),
    );
    if (name == null || name.isEmpty || !mounted) return;
    setState(() {
      _from = name;
      _route = null;
    });
  }

  void _applyNextPickup() {
    final next = appState.nextPickup.value;
    if (next == null) return;
    appState.nextPickup.value = null;
    _reset();
    setState(() {
      _from = next.name;
      _fromPoint = next.point;
    });
    _loadTotals();
  }

  void _reset() {
    setState(() {
      _route = null;
      _other = false;
      _otherFare.clear();
      _search.clear();
      _results = [];
      _place = null;
      _passengers = 0;
      _goods.clear();
      _cargoKg.clear();
      _addingGoods = false;
      _error = null;
    });
  }

  /// Routes for this vehicle's category (or for any vehicle).
  List<RouteFare> get _myRoutes {
    final cat = appState.truck?.categoryId;
    return _routes.where((r) => r.categoryId == null || r.categoryId == cat).toList();
  }

  bool get _passengersOk => appState.category?.carriesPassengers ?? true;
  bool get _goodsOk => appState.category?.carriesGoods ?? true;
  int? get _seats {
    final s = appState.truck?.seats ?? appState.category?.seats;
    return (s == null || s == 0) ? null : s;
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait<List<Map<String, dynamic>>>([
        db.from('routes').select().eq('active', true).order('to_name'),
        db.from('goods_prices').select().eq('active', true).order('label'),
      ]);
      if (!mounted) return;
      setState(() {
        _routes = results[0].map(RouteFare.fromMap).toList();
        _prices = results[1].map(GoodsPrice.fromMap).toList();
        final froms = _fromNames;
        if (froms.isNotEmpty && !froms.contains(_from)) _from = froms.first;
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
    _loadTotals();
  }

  Future<void> _loadTotals() async {
    try {
      final rows = await db.from('trips').select('total').eq('shift_id', widget.shift.id).eq('status', 'completed');
      if (!mounted) return;
      setState(() {
        _shiftTrips = rows.length;
        _shiftTotal = rows.fold<double>(0, (s, r) => s + toDouble(r['total']));
      });
    } catch (_) {}
    _loadPickups();
  }

  Future<void> _loadPickups() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('driver_id', me.id)
          .inFilter('status', ['assigned', 'picked_up'])
          .order('pickup_at')
          .limit(20);
      if (!mounted) return;
      var offers = <Map<String, dynamic>>[];
      try {
        offers = List<Map<String, dynamic>>.from(await db.rpc('my_offers') as List);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _pickups = rows.map(Booking.fromMap).toList();
        _offers = offers;
      });
    } catch (_) {}
  }

  void _openPickups() =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PickupsScreen())).then((_) => _loadTotals());

  Widget _glance() {
    final waiting = _pickups.where((b) => b.status == 'assigned').length + _offers.length;
    final onBoard = _pickups.where((b) => b.status == 'picked_up').length;
    final next = _pickups.where((b) => b.status == 'assigned').take(2).toList();
    final aboard = _pickups.where((b) => b.status == 'picked_up').toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (_offers.isNotEmpty) ...[
        AppCard(
          borderColor: AppColors.lime,
          child: Row(children: [
            const Icon(Icons.notifications_active_outlined, color: AppColors.lime600),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                  _offers.length == 1
                      ? '${tx('New hire request')}: ${_offers.first['pickup_name']} → ${_offers.first['dest_name']}'
                      : txf('%s new hire requests', ['${_offers.length}']),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            TextButton(onPressed: _openPickups, child: Text(tx('Answer'))),
          ]),
        ),
        const SizedBox(height: 10),
      ],
      if (_runningId != null) ...[
        AppCard(
          borderColor: AppColors.warning,
          child: Row(children: [
            const Icon(Icons.local_shipping_outlined, color: AppColors.warning),
            const SizedBox(width: 10),
            Expanded(child: Text(tx('A trip is still running. End it before you go off duty.'), style: const TextStyle(fontWeight: FontWeight.w700))),
            TextButton(onPressed: () => _openTrip(_runningId!), child: Text(tx('Open'))),
          ]),
        ),
        const SizedBox(height: 10),
      ],
      HomeLabel(tx('Today at a glance')),
      TileRow([
        GlanceTile(
            value: money(_shiftTotal), label: tx('Earned this shift'), icon: Icons.payments_outlined, color: AppColors.lime600, highlight: true),
        GlanceTile(value: '$_shiftTrips', label: tx('Trips done'), icon: Icons.route_outlined),
      ]),
      TileRow([
        GlanceTile(
            value: '$waiting',
            label: tx('Pickups waiting'),
            icon: Icons.person_pin_circle_outlined,
            color: waiting > 0 ? AppColors.warning : AppColors.navy,
            onTap: _openPickups),
        GlanceTile(value: '$onBoard', label: tx('On board now'), icon: Icons.airline_seat_recline_normal, onTap: _openPickups),
      ]),
      HomeLabel(tx('Where you are and who is waiting')),
      HomeMap(stops: [
        for (var i = 0; i < _pickups.length; i++)
          if (_pickups[i].status == 'assigned' && _pickups[i].pickupLat != null && _pickups[i].pickupLng != null)
            MapStop(LatLng(_pickups[i].pickupLat!, _pickups[i].pickupLng!), _pickups[i].pickupName, i + 1),
      ]),
      if (next.isNotEmpty) ...[
        HomeLabel(tx('Next pickups')),
        AppCard(
          padding: EdgeInsets.zero,
          child: Column(children: [
            for (var i = 0; i < next.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              ListTile(
                dense: true,
                leading: const Icon(Icons.schedule, color: AppColors.lime600),
                title: Text(next[i].title, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(clock(next[i].pickupAt)),
                trailing: const Icon(Icons.chevron_right),
                onTap: _openPickups,
              ),
            ],
          ]),
        ),
        const SizedBox(height: 10),
      ],
      if (aboard.isNotEmpty) ...[
        HomeLabel(tx('On board now')),
        AppCard(
          padding: EdgeInsets.zero,
          child: Column(children: [
            for (var i = 0; i < aboard.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              ListTile(
                dense: true,
                leading: const Icon(Icons.airline_seat_recline_normal, color: AppColors.lime600),
                title: Text(aboard[i].title, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(tx('On board ✓')),
                trailing: const Icon(Icons.chevron_right),
                onTap: _openPickups,
              ),
            ],
          ]),
        ),
        const SizedBox(height: 10),
      ],
      HomeLabel(tx('Start a new trip')),
    ]);
  }

  Future<void> _checkRunningTrip() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final row =
          await db.from('trips').select('id').eq('driver_id', me.id).eq('status', 'in_progress').maybeSingle();
      if (mounted) setState(() => _runningId = row?['id'] as String?);
      if (row != null && mounted) _openTrip(row['id'] as String);
    } catch (_) {}
  }

  void _openTrip(String id) {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => TripScreen(tripId: id)))
        .then((_) async {
      _loadTotals();
      final me = appState.profile;
      if (me == null) return;
      try {
        final row = await db.from('trips').select('id').eq('driver_id', me.id).eq('status', 'in_progress').maybeSingle();
        if (mounted) setState(() => _runningId = row?['id'] as String?);
      } catch (_) {}
    });
  }

  List<String> get _fromNames {
    final set = <String>{for (final r in _myRoutes) r.fromName};
    return set.toList()..sort();
  }

  void _onSearch(String text) {
    setState(() => _place = null);
    _searchTimer?.cancel();
    if (text.trim().length < 2) {
      setState(() => _results = []);
      return;
    }
    setState(() => _results = quickMatches(text)); // known places at once, online ones follow
    _searchTimer = Timer(const Duration(milliseconds: 450), () async {
      setState(() => _searching = true);
      try {
        final found = await searchPlaces(text, near: _fromPoint ?? Tracking.instance.position.value);
        if (mounted) setState(() => _results = found);
      } catch (_) {
        if (mounted) setState(() => _results = []);
      } finally {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  double get _fare => _route?.fare ?? parseAmount(_otherFare.text);
  double get _goodsTotal => _goods.fold<double>(0, (s, g) => s + g.amount);
  /// Goods-only vehicles (lorry): the route fare is the price of the load.
  double get _total => _passengersOk ? _passengers * _fare + _goodsTotal : _fare + _goodsTotal;

  Future<void> _next() async {
    setState(() => _error = null);
    String destName;
    LatLng? dest;
    if (_route != null) {
      destName = _route!.toName;
      if (_route!.toLat != null && _route!.toLng != null) dest = LatLng(_route!.toLat!, _route!.toLng!);
    } else if (_place != null || _search.text.trim().isNotEmpty) {
      // a place picked from the list, or just the name typed in
      destName = _place?.name ?? _search.text.trim();
      dest = _place?.point ?? knownPlace(destName)?.point;
    } else {
      setState(() {
        _other = true;
        _error = 'Choose the route, or type where the trip goes under Other destination.';
      });
      return;
    }
    if (_route == null && _fare <= 0) {
      setState(() => _error = 'Type the fare each (MWK).');
      return;
    }
    if (_passengers == 0 && _goods.isEmpty && (_passengersOk || _fare <= 0)) {
      setState(() => _error = _passengersOk ? 'Add passengers or goods first.' : 'Add the goods you are carrying first.');
      return;
    }
    if (dest == null) {
      try {
        final found = await searchPlaces(destName, near: _fromPoint ?? Tracking.instance.position.value);
        if (found.isNotEmpty) dest = found.first.point;
      } catch (_) {}
    }
    if (!mounted) return;
    if (dest == null) {
      setState(() => _error = txf('Could not find %s on the map. Ask the admin to set its location.', [destName]));
      return;
    }
    final draft = TripDraft(
      shiftId: widget.shift.id,
      routeId: _route?.id,
      pickupName: _from,
      pickupPoint: _fromPoint ?? Tracking.instance.position.value,
      destName: destName,
      dest: dest,
      passengers: _passengers,
      fare: _fare,
      goods: [
        if (!_passengersOk && _fare > 0) GoodsItem(txf('Load to %s', [destName]), _fare),
        ..._goods,
      ],
      plannedKm: _route?.km,
      cargoKg: double.tryParse(_cargoKg.text.trim()),
    );
    final tripId = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => TripStartScreen(draft: draft)));
    if (tripId != null && mounted) {
      _reset();
      _openTrip(tripId);
    }
  }

  /// The driver stands at a place that is missing or wrong: send its position to the office to approve.
  Future<void> _suggestPlace() async {
    final me = appState.profile;
    final p = Tracking.instance.position.value ?? Here.instance.point.value;
    if (me == null) return;
    if (p == null) {
      toast(context, tx('Your location is not ready yet. Wait a moment and try again.'));
      return;
    }
    final name = TextEditingController();
    final detail = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tx('Save this place')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(tx('Stand at the place. Your position is sent to the office to add for everyone.'), style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          TextField(controller: name, decoration: InputDecoration(labelText: tx('Place name'))),
          TextField(controller: detail, decoration: InputDecoration(labelText: tx('Area (optional)'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
        ],
      ),
    );
    final n = name.text.trim();
    final d = detail.text.trim();
    name.dispose();
    detail.dispose();
    if (ok != true || n.isEmpty || !mounted) return;
    try {
      await db.from('place_suggestions').insert({
        'name': n,
        'detail': d,
        'lat': p.latitude,
        'lng': p.longitude,
        'suggested_by': me.id,
      });
      if (mounted) toast(context, tx('Sent to the office. Thank you.'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _menu(String v) async {
    final nav = Navigator.of(context);
    switch (v) {
      case 'expense':
        await nav.push(MaterialPageRoute(fullscreenDialog: true, builder: (_) => ExpenseScreen(shiftId: widget.shift.id)));
      case 'change':
        final sent = await nav.push<bool>(MaterialPageRoute(builder: (_) => TruckChangeScreen(shift: widget.shift)));
        if (sent == true) widget.onChanged();
      case 'end':
        final ended = await nav.push<bool>(MaterialPageRoute(builder: (_) => EndShiftScreen(shift: widget.shift)));
        if (ended == true) widget.onChanged();
      case 'place':
        await _suggestPlace();
      case 'docs':
        await nav.push(MaterialPageRoute(builder: (_) => const DocumentsScreen()));
      case 'pickups':
        await nav.push(MaterialPageRoute(builder: (_) => const PickupsScreen()));
      case 'wallet':
        await nav.push(MaterialPageRoute(builder: (_) => const WalletScreen()));
      case 'messages':
        await nav.push(MaterialPageRoute(builder: (_) => const NoticesScreen()));
      case 'help':
        await nav.push(MaterialPageRoute(builder: (_) => const SupportHomeScreen()));
      case 'out':
        await appState.signOut();
    }
  }

  @override
  Widget build(BuildContext context) {
    final truck = appState.truck;
    final froms = _fromNames;
    final routesHere = _myRoutes.where((r) => r.fromName == _from).toList();
    final category = appState.category;
    return ValueListenableBuilder<String>(
      valueListenable: language,
      builder: (context, _, __) => Scaffold(
        backgroundColor: AppColors.navy,
        bottomNavigationBar: const DriverNavBar(),
        body: SafeArea(
          bottom: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              NavyHeader(
                top: txf('ON DUTY · %s', [truck?.plate ?? '']) + (category != null ? ' · ${category.name.toUpperCase()}' : '') +
                    txf(' · since %s', [clock(widget.shift.startedAt)]),
                title: tr('new_trip'),
                subtitle: txf('This shift: %s trips · %s', ['${_shiftTrips}', '${money(_shiftTotal)}']),
                actions: [
                  const LanguageSwitch(),
                  const PickupsButton(),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, color: Colors.white),
                    onSelected: _menu,
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'expense', child: Text(tr('add_expense'))),
                      PopupMenuItem(value: 'change', child: Text(tr('change_truck'))),
                      PopupMenuItem(value: 'end', child: Text(tr('end_of_day'))),
                      PopupMenuItem(value: 'place', child: Text(tx('Save this place'))),
                      PopupMenuItem(value: 'docs', child: Text(tr('documents'))),
                      PopupMenuItem(value: 'pickups', child: Text(tx('Booked pickups'))),
                      PopupMenuItem(value: 'wallet', child: Text(tx('My wallet'))),
                      PopupMenuItem(value: 'messages', child: Text(tx('Messages'))),
                      PopupMenuItem(value: 'help', child: Text(tx('Help & support'))),
                      PopupMenuItem(value: 'out', child: Text(tx('Sign out'))),
                    ],
                  ),
                ],
              ),
              ValueListenableBuilder<int>(
                valueListenable: Outbox.instance.pending,
                builder: (context, n, _) => n == 0
                    ? const SizedBox.shrink()
                    : Container(
                        color: const Color(0xFFFFF4E0),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Text(trf('offline_waiting', '$n'),
                            style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
                      ),
              ),
              Expanded(
                child: ClipRRect(
 borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
 child: Container(
                  color: AppColors.surface100,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    children: [
                      const SosBar(),
                      const SizedBox(height: 4),
                      _glance(),
                      const MyWeekCard(),
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FieldLabel(tx('FROM (RANK)')),
                          const SizedBox(height: 6),
                          if (froms.isEmpty)
                            Text(_from, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))
                          else
                            Wrap(spacing: 8, runSpacing: 8, children: [
                              for (final f in {...froms, _from})
                                ChoiceChipButton(f, selected: f == _from, onTap: () => setState(() {
                                      _from = f;
                                      _route = null;
                                    })),
                            ]),
                          const SizedBox(height: 4),
                          Wrap(spacing: 4, children: [
                            TextButton.icon(
                              onPressed: _locating ? null : _useHere,
                              icon: _locating
                                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Icon(Icons.my_location, size: 18),
                              label: Text(tx('Use my current location')),
                            ),
                            TextButton.icon(
                              onPressed: _editFrom,
                              icon: const Icon(Icons.edit_outlined, size: 18),
                              label: Text(tx('Type a place')),
                            ),
                          ]),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          FieldLabel(tr('route')),
                          const SizedBox(height: 8),
                          if (routesHere.isEmpty)
                            Text(tx('No fixed routes from here yet. Use Other destination.'),
                                style: TextStyle(color: AppColors.muted, fontSize: 13)),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            for (final r in routesHere)
                              _RouteTile(
                                route: r,
                                selected: _route?.id == r.id,
                                onTap: () => setState(() {
                                  _route = r;
                                  _other = false;
                                }),
                              ),
                          ]),
                          const SizedBox(height: 8),
                          InkWell(
                            onTap: () => setState(() {
                              _other = !_other;
                              if (_other) _route = null;
                            }),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Text('${_other ? '−' : '+'} ${tr('other_destination')}',
                                  style: const TextStyle(color: AppColors.lime600, fontWeight: FontWeight.w700)),
                            ),
                          ),
                          if (_other) ...[
                            TextField(
                              controller: _search,
                              onChanged: _onSearch,
                              decoration: plainInput('Search a place').copyWith(
                                suffixIcon: _searching
                                    ? const Padding(
                                        padding: EdgeInsets.all(12),
                                        child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)))
                                    : null,
                              ),
                            ),
                            for (final p in _results)
                              InkWell(
                                onTap: () => setState(() {
                                  _place = p;
                                  _search.text = p.name;
                                  _results = [];
                                }),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Text('${p.name}${p.detail.isNotEmpty ? ' · ${p.detail}' : ''}',
                                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                                ),
                              ),
                            const SizedBox(height: 8),
                            TextField(
                              controller: _otherFare,
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              onChanged: (_) => setState(() {}),
                              decoration: plainInput('Fare each (MWK)'),
                            ),
                          ],
                        ]),
                      ),
                      const SizedBox(height: 12),
                      if (_passengersOk)
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(
                          child: Counter(
                            label: _seats == null ? tr('passengers') : txf('%s (MAX %s)', [tr('passengers'), '$_seats']),
                            value: _passengers,
                            onChanged: (v) {
                              if (_seats != null && v > _seats!) {
                                toast(context, txf('This vehicle has %s seats.', ['${_seats}']));
                                return;
                              }
                              setState(() => _passengers = v);
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              FieldLabel(tr('fare_each')),
                              const SizedBox(height: 8),
                              Row(children: [
                                Flexible(
                                  child: Text(money(_fare),
                                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                                ),
                                if (_route != null) ...[
                                  const SizedBox(width: 4),
                                  const Icon(Icons.lock_outline, size: 16, color: AppColors.muted, semanticLabel: 'Fare locked'),
                                ],
                              ]),
                            ]),
                          ),
                        ),
                      ]),
                      if (!_passengersOk)
                        AppCard(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(txf('LOAD PRICE %s', [money(_fare)]) + (_route != null ? tx(' (set by admin)') : ''),
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.navy)),
                            const SizedBox(height: 8),
                            FieldLabel(tx('LOAD WEIGHT (KG, OPTIONAL)')),
                            TextField(
                              controller: _cargoKg,
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              decoration: const InputDecoration(hintText: 'e.g. 3000', border: InputBorder.none),
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                            ),
                          ]),
                        ),
                      if (_goodsOk) const SizedBox(height: 12),
                      if (_goodsOk)
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FieldLabel(tr('goods')),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            for (var i = 0; i < _goods.length; i++)
                              InputChip(
                                label: Text('${_goods[i].label} · ${money(_goods[i].amount)}'),
                                backgroundColor: AppColors.lime100,
                                side: BorderSide.none,
                                shape: const StadiumBorder(),
                                onDeleted: () => setState(() => _goods.removeAt(i)),
                              ),
                          ]),
                          if (_prices.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(tx('Tap to add:'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
                            const SizedBox(height: 4),
                            Wrap(spacing: 8, runSpacing: 8, children: [
                              for (final g in _prices)
                                ActionChip(
                                  label: Text('${g.label} ${money(g.price)}'),
                                  shape: const StadiumBorder(side: BorderSide(color: AppColors.line)),
                                  onPressed: () => setState(() => _goods.add(GoodsItem(g.label, g.price))),
                                ),
                              ActionChip(
                                label: Text(tx('+ Other')),
                                shape: const StadiumBorder(side: BorderSide(color: AppColors.muted)),
                                onPressed: () => setState(() => _addingGoods = true),
                              ),
                            ]),
                          ] else if (!_addingGoods)
                            ActionChip(
                              label: Text(tx('+ Add')),
                              shape: const StadiumBorder(side: BorderSide(color: AppColors.muted)),
                              onPressed: () => setState(() => _addingGoods = true),
                            ),
                          if (_addingGoods) ...[
                            const SizedBox(height: 8),
                            TextField(controller: _goodsLabel, decoration: plainInput('e.g. 1 bicycle')),
                            const SizedBox(height: 8),
                            Row(children: [
                              Expanded(
                                child: TextField(
                                  controller: _goodsAmount,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                  decoration: plainInput('Charge (MWK)'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              AppButton(tx('Add'), kind: ButtonKind.navy, height: 44, onPressed: () {
                                if (_goodsLabel.text.trim().isEmpty) return;
                                setState(() {
                                  _goods.add(GoodsItem(_goodsLabel.text.trim(), parseAmount(_goodsAmount.text)));
                                  _goodsLabel.clear();
                                  _goodsAmount.clear();
                                  _addingGoods = false;
                                });
                              }),
                            ]),
                          ],
                        ]),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
                        child: Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(tr('trip_total'),
                                  style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12, fontWeight: FontWeight.w700)),
                              Text(
                                  _passengersOk
                                      ? '$_passengers × ${money(_fare)}${_goodsTotal > 0 ? txf(' + goods %s', [money(_goodsTotal)]) : ''}'
                                      : txf('Load %s', [money(_fare)]) + (_goodsTotal > 0 ? txf(' + goods %s', [money(_goodsTotal)]) : ''),
                                  style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                            ]),
                          ),
                          Text(money(_total),
                              style: const TextStyle(color: AppColors.lime, fontSize: 24, fontWeight: FontWeight.w800)),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      ErrorLine(_error),
                      const SizedBox(height: 8),
                      AppButton(tr('loaded_record'), height: 56, onPressed: _next),
                    ],
                  ),
                ),
 ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RouteTile extends StatelessWidget {
  final RouteFare route;
  final bool selected;
  final VoidCallback onTap;
  const _RouteTile({required this.route, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: selected ? AppColors.navy : AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: selected ? AppColors.navy : AppColors.line, width: 2),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(route.toName,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: selected ? Colors.white : AppColors.ink)),
              Text(txf('%s each', ['${money(route.fare)}']),
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: selected ? AppColors.lime : AppColors.muted)),
            ]),
          ),
        ),
      );
}
