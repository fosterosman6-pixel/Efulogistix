import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import '../support/sos_bar.dart';
import 'offload.dart';
import 'stop.dart';
import 'trip_end.dart';

const _rerouteEvery = Duration(minutes: 3);

/// Trip in progress: route, stops made so far, where the trip ends.
class TripScreen extends StatefulWidget {
  final String tripId;
  const TripScreen({super.key, required this.tripId});

  @override
  State<TripScreen> createState() => _TripScreenState();
}

class _TripScreenState extends State<TripScreen> {
  Trip? _trip;
  List<TripStop> _stops = [];
  List<LatLng>? _route;
  double? _leftKm;
  double? _leftMinutes;
  bool _cancelling = false;
  String? _error;
  DateTime _lastRouted = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    Tracking.instance.position.addListener(_onMove);
    _load();
  }

  @override
  void dispose() {
    Tracking.instance.position.removeListener(_onMove);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final row = await db.from('trips').select().eq('id', widget.tripId).single();
      final trip = Trip.fromMap(row);
      final stops = await db.from('trip_stops').select().eq('trip_id', trip.id).order('at');
      if (!mounted) return;
      if (!trip.running) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TripEndScreen(tripId: trip.id)));
        return;
      }
      Tracking.instance.setTripIfNone(trip.id);
      setState(() {
        _trip = trip;
        _stops = stops.map(TripStop.fromMap).toList();
      });
      final from = Tracking.instance.position.value ??
          (trip.pickupLat != null && trip.pickupLng != null ? LatLng(trip.pickupLat!, trip.pickupLng!) : null);
      if (from != null) _updateRoute(from);
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not open this trip.');
    }
  }

  void _onMove() {
    final here = Tracking.instance.position.value;
    if (!mounted || here == null) return;
    setState(() {});
    if (DateTime.now().difference(_lastRouted) > _rerouteEvery) _updateRoute(here);
  }

  Future<void> _updateRoute(LatLng from) async {
    final trip = _trip;
    if (trip == null) return;
    _lastRouted = DateTime.now();
    final dest = LatLng(trip.destLat, trip.destLng);
    final r = await getRoute(from, dest);
    if (!mounted) return;
    setState(() {
      if (r != null) {
        _route = r.points;
        _leftKm = r.km;
        _leftMinutes = r.minutes;
      } else {
        final straight = distanceKm(from, dest);
        _leftKm = straight;
        _leftMinutes = straight / 45 * 60;
      }
    });
  }

  Future<void> _stop() async {
    final trip = _trip;
    if (trip == null) return;
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => StopScreen(trip: trip, stops: _stops)));
    if (saved == true) _load();
  }

  Future<void> _offload() async {
    final trip = _trip;
    if (trip == null) return;
    final done = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => OffloadScreen(trip: trip)));
    if (done == true && mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TripEndScreen(tripId: trip.id)));
    }
  }

  Future<void> _cancel() async {
    final trip = _trip;
    if (trip == null) return;
    final ok = await confirmDialog(context, tx('Cancel this trip?'), tx('It will not count in today’s money.'), yes: tx('Cancel trip'));
    if (!ok) return;
    setState(() => _cancelling = true);
    try {
      await db.from('trips').update({
        'status': 'cancelled',
        'ended_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', trip.id);
      Tracking.instance.setTrip(null);
      await Tracking.instance.sendNow();
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final trip = _trip;
    if (trip == null) {
      return Scaffold(
        body: Center(
          child: _error == null
              ? const CircularProgressIndicator(color: AppColors.navy)
              : Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    ErrorLine(_error),
                    const SizedBox(height: 12),
                    AppButton(tx('Back'), onPressed: () => Navigator.of(context).pop()),
                  ]),
                ),
        ),
      );
    }
    final truck = appState.truck;
    final here = Tracking.instance.position.value;
    final eta = _leftMinutes == null ? null : DateTime.now().add(Duration(minutes: _leftMinutes!.round()));
    final onBoard = trip.passengers + _stops.fold<int>(0, (s, x) => s + x.picked - x.dropped);
    final mapStops = <MapStop>[
      if (trip.pickupLat != null && trip.pickupLng != null)
        MapStop(LatLng(trip.pickupLat!, trip.pickupLng!), '${trip.pickupName} · ${trip.passengers} on', 0),
      for (var i = 0; i < _stops.length; i++)
        if (_stops[i].lat != null && _stops[i].lng != null)
          MapStop(
            LatLng(_stops[i].lat!, _stops[i].lng!),
            _stops[i].auto
                ? 'Unrecorded stop'
                : '${_stops[i].placeName ?? 'Stop'} · ${_stops[i].dropped} off · ${_stops[i].picked} on',
            i + 1,
            auto: _stops[i].auto,
          ),
    ];
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: AppColors.mapGround,
        body: Stack(children: [
          Positioned.fill(
            child: FleetMap(
              route: _route,
              end: LatLng(trip.destLat, trip.destLng),
              endLabel: trip.destName,
              stops: mapStops,
              trucks: [if (here != null && truck != null) MapTruck(truck.id, here, truck.plate)],
              bottomPadding: 330,
            ),
          ),
          Positioned(
            top: 0,
            left: 16,
            right: 16,
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  Container(
                      width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(txf('Trip #%s in progress', ['${trip.tripNo}']),
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                  ),
                  Text(txf('Started %s', ['${clock(trip.startedAt)}']), style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                ]),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 16,
            right: 16,
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.only(top: 68),
                child: const SosBar(),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [BoxShadow(color: Color(0x260A2253), blurRadius: 16, offset: Offset(0, -4))],
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                  child: ValueListenableBuilder<String>(
                    valueListenable: language,
                    builder: (context, _, __) => Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              FieldLabel(tx('ENDS AT')),
                              Text(trip.destName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(clock(eta),
                                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.lime600)),
                            Text(
                              _leftKm == null ? tx('Finding route…') : txf('%s · %s left', ['${kmText(_leftKm)}', '${durationText(_leftMinutes ?? 0)}']),
                              style: const TextStyle(fontSize: 13, color: AppColors.muted),
                            ),
                          ]),
                        ]),
                        const SizedBox(height: 12),
                        Row(children: [
                          StatTile('On board', '$onBoard'),
                          const SizedBox(width: 8),
                          StatTile('Stops', '${_stops.where((s) => !s.auto).length}'),
                          const SizedBox(width: 8),
                          StatTile('Total', money(trip.total)),
                        ]),
                        const SizedBox(height: 10),
                        ErrorLine(_error),
                        AppButton(tr('stop_on_way'), kind: ButtonKind.outline, onPressed: _stop),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(
                            child: AppButton(tr('cancel'),
                                kind: ButtonKind.danger, loading: _cancelling, onPressed: _cancel),
                          ),
                          const SizedBox(width: 10),
                          Expanded(flex: 2, child: AppButton(tr('offload'), kind: ButtonKind.navy, onPressed: _offload)),
                        ]),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
