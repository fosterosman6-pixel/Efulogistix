import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../i18n.dart';
import '../../map_icons.dart';
import '../../models.dart';
import '../../nav.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../tracking.dart';
import '../../widgets.dart';
import '../support/sos_bar.dart';
import 'offload.dart';
import 'pickups.dart';
import 'stop.dart';
import 'trip_end.dart';

const _rerouteEvery = Duration(minutes: 3);

/// Trip in progress: route, stops made so far, where the trip ends.
class TripScreen extends StatefulWidget {
  final String tripId;
  const TripScreen({super.key, required this.tripId});

  @override
  State<TripScreen> createState() => _TripScreenState();
}

class _TripScreenState extends State<TripScreen> {
  Trip? _trip;
  List<TripStop> _stops = [];
  List<LatLng>? _route;
  double? _leftKm;
  double? _leftMinutes;
  bool _cancelling = false;
  String? _error;
  int _waiting = 0; // booked passengers/parcels still to collect (and new requests)
  int _aboard = 0;
  Timer? _poll;
  DateTime _lastRouted = DateTime.fromMillisecondsSinceEpoch(0);

  // turn-by-turn navigation
  bool _navigating = false;
  bool _voiceOn = true;
  List<NavStep> _steps = [];
  int _stepIdx = 0;
  final _spoken = <String>{};
  LatLng? _prev;
  double _heading = 0;
  final _sheet = DraggableScrollableController();
  List<Booking> _bk = [];
  LatLng? _target; // null = the trip's destination
  String? _targetLabel;
  String? _targetBooking;

  @override
  void initState() {
    super.initState();
    Tracking.instance.position.addListener(_onMove);
    _load();
    _loadBookings();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) => _loadBookings());
  }

  @override
  void dispose() {
    _poll?.cancel();
    TurnVoice.stop();
    _sheet.dispose();
    Tracking.instance.position.removeListener(_onMove);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final row = await db.from('trips').select().eq('id', widget.tripId).single();
      final trip = Trip.fromMap(row);
      final stops = await db.from('trip_stops').select().eq('trip_id', trip.id).order('at');
      if (!mounted) return;
      if (!trip.running) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TripEndScreen(tripId: trip.id)));
        return;
      }
      Tracking.instance.setTripIfNone(trip.id);
      setState(() {
        _trip = trip;
        _stops = stops.map(TripStop.fromMap).toList();
      });
      final from = Tracking.instance.position.value ??
          (trip.pickupLat != null && trip.pickupLng != null ? LatLng(trip.pickupLat!, trip.pickupLng!) : null);
      if (from != null) _updateRoute(from);
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not open this trip.');
    }
  }

  Future<void> _loadBookings() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db.from('bookings').select().eq('driver_id', me.id).inFilter('status', ['assigned', 'picked_up']);
      var offers = 0;
      try {
        offers = (await db.rpc('my_offers') as List).length;
      } catch (_) {}
      if (!mounted) return;
      final list = rows.map(Booking.fromMap).toList();
      // the booking we were navigating to is done (or cancelled): go back to the trip's destination
      if (_targetBooking != null && !list.any((b) => b.id == _targetBooking)) {
        _target = null;
        _targetLabel = null;
        _targetBooking = null;
        _spoken.clear();
        final here = Tracking.instance.position.value;
        if (here != null) _updateRoute(here);
      }
      setState(() {
        _bk = list;
        _waiting = rows.where((r) => r['status'] == 'assigned').length + offers;
        _aboard = rows.where((r) => r['status'] == 'picked_up').length;
      });
    } catch (_) {}
  }

  /// Booked pickups: scan tickets, mark parcels loaded, finish hires. Boarding adds to this trip's total.
  Future<void> _openBookings() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PickupsScreen()));
    _load();
    _loadBookings();
  }

  void _onMove() {
    final here = Tracking.instance.position.value;
    if (!mounted || here == null) return;
    final prev = _prev;
    if (prev == null) {
      _prev = here;
    } else {
      final b = MapIcons.bearing(prev.latitude, prev.longitude, here.latitude, here.longitude);
      if (b != null) {
        _heading = b;
        _prev = here;
      }
    }
    setState(() {});
    _followSteps(here);
    final since = DateTime.now().difference(_lastRouted);
    final off = _navigating && _route != null && _route!.isNotEmpty && _route!.every((q) => distanceKm(q, here) * 1000 > 70);
    if (since > (_navigating ? const Duration(seconds: 25) : _rerouteEvery) || (off && since > const Duration(seconds: 8))) {
      _updateRoute(here);
    }
  }

  NavStep? get _nextStep => _stepIdx < _steps.length ? _steps[_stepIdx] : null;

  /// Moves on to the next turn when the car reaches this one, and speaks it when it is near.
  void _followSteps(LatLng here) {
    final step = _nextStep;
    if (step == null) return;
    final d = distanceKm(here, step.at) * 1000;
    if (d < 18 && _stepIdx < _steps.length - 1) {
      setState(() => _stepIdx++);
      return;
    }
    if (!_navigating || !_voiceOn) return;
    final key = '${step.at.latitude.toStringAsFixed(4)},${step.at.longitude.toStringAsFixed(4)}';
    if (d < 260 && d > 120 && _spoken.add('far$key')) {
      TurnVoice.speak('In ${(d / 50).round() * 50} metres, ${step.text}');
    } else if (d <= 45 && _spoken.add('near$key')) {
      TurnVoice.speak(step.text);
    }
  }

  /// Where to navigate: the trip's destination, a booked pickup, or the drop-off of a passenger on board.
  Future<void> _chooseTarget() async {
    final trip = _trip;
    if (trip == null) return;
    final opts = <(String, String, LatLng?, String?)>[
      (tx('Trip destination'), trip.destName, null, null),
      for (final b in _bk)
        if (b.status == 'assigned' && b.pickupLat != null && b.pickupLng != null)
          (tx('Pick up'), '${b.pickupName} · ${b.seats} ${b.seats == 1 ? 'seat' : 'seats'}', LatLng(b.pickupLat!, b.pickupLng!), b.id)
        else if (b.status == 'picked_up' && b.destLat != null && b.destLng != null)
          (tx('Drop off'), b.destName, LatLng(b.destLat!, b.destLng!), b.id),
    ];
    if (opts.length == 1) return;
    final pick = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(16, 16, 16, 12), children: [
          Text(tx('Where to?'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (var i = 0; i < opts.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(i == 0 ? Icons.flag : (opts[i].$1 == tx('Pick up') ? Icons.person_pin_circle : Icons.place), color: AppColors.navy),
              title: Text(opts[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(opts[i].$1),
              onTap: () => Navigator.pop(ctx, i),
            ),
        ]),
      ),
    );
    if (pick == null) return;
    setState(() {
      _target = opts[pick].$3;
      _targetLabel = pick == 0 ? null : opts[pick].$2;
      _targetBooking = opts[pick].$4;
      _spoken.clear();
      _steps = [];
    });
    final here = Tracking.instance.position.value;
    if (here != null) _updateRoute(here);
  }

  Future<void> _startNav() async {
    if (_navigating == false) await _chooseTarget();
    if (!mounted) return;
    setState(() => _navigating = true);
    if (_voiceOn) TurnVoice.speak('Starting navigation');
    final here = Tracking.instance.position.value;
    if (here != null) _updateRoute(here);
    if (_sheet.isAttached) _sheet.animateTo(0.17, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
  }

  void _stopNav() {
    TurnVoice.stop();
    setState(() => _navigating = false);
    if (_sheet.isAttached) _sheet.animateTo(0.30, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
  }

  Future<void> _updateRoute(LatLng from) async {
    final trip = _trip;
    if (trip == null) return;
    _lastRouted = DateTime.now();
    final dest = _target ?? LatLng(trip.destLat, trip.destLng);
    final r = await getRoute(from, dest, steps: true);
    if (!mounted) return;
    setState(() {
      if (r != null) {
        _route = r.points;
        _steps = r.steps;
        _stepIdx = r.steps.length > 1 ? 1 : 0;
        _leftKm = r.km;
        _leftMinutes = r.minutes;
      } else {
        final straight = distanceKm(from, dest);
        _leftKm = straight;
        _leftMinutes = straight / 45 * 60;
      }
    });
  }

  Future<void> _stop() async {
    final trip = _trip;
    if (trip == null) return;
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => StopScreen(trip: trip, stops: _stops)));
    if (saved == true) _load();
  }

  Future<void> _offload() async {
    final trip = _trip;
    if (trip == null) return;
    final done = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => OffloadScreen(trip: trip)));
    if (done == true && mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => TripEndScreen(tripId: trip.id)));
    }
  }

  Future<void> _cancel() async {
    final trip = _trip;
    if (trip == null) return;
    if (_aboard > 0) {
      setState(() => _error = tx('Passengers or parcels are on board. Finish those bookings first.'));
      return;
    }
    final ok = await confirmDialog(context, tx('Cancel this trip?'), tx('It will not count in today’s money.'), yes: tx('Cancel trip'));
    if (!ok) return;
    setState(() => _cancelling = true);
    try {
      await db.from('trips').update({
        'status': 'cancelled',
        'ended_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', trip.id);
      Tracking.instance.setTrip(null);
      await Tracking.instance.sendNow();
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final trip = _trip;
    if (trip == null) {
      return Scaffold(
        body: Center(
          child: _error == null
              ? const CircularProgressIndicator(color: AppColors.navy)
              : Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    ErrorLine(_error),
                    const SizedBox(height: 12),
                    AppButton(tx('Back'), onPressed: () => Navigator.of(context).pop()),
                  ]),
                ),
        ),
      );
    }
    final truck = appState.truck;
    final here = Tracking.instance.position.value;
    final eta = _leftMinutes == null ? null : DateTime.now().add(Duration(minutes: _leftMinutes!.round()));
    final onBoard = trip.passengers + _stops.fold<int>(0, (s, x) => s + x.picked - x.dropped);
    final mapStops = <MapStop>[
      if (trip.pickupLat != null && trip.pickupLng != null)
        MapStop(LatLng(trip.pickupLat!, trip.pickupLng!), '${trip.pickupName} · ${trip.passengers} on', 0),
      for (var i = 0; i < _stops.length; i++)
        if (_stops[i].lat != null && _stops[i].lng != null)
          MapStop(
            LatLng(_stops[i].lat!, _stops[i].lng!),
            _stops[i].auto
                ? 'Unrecorded stop'
                : '${_stops[i].placeName ?? 'Stop'} · ${_stops[i].dropped} off · ${_stops[i].picked} on',
            i + 1,
            auto: _stops[i].auto,
          ),
    ];
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: AppColors.mapGround,
        body: Stack(children: [
          Positioned.fill(
            child: FleetMap(
              route: _route,
              end: LatLng(trip.destLat, trip.destLng),
              endLabel: trip.destName,
              stops: mapStops,
              trucks: [if (here != null && truck != null) MapTruck(truck.id, here, truck.plate, kind: vehicleKind(appState.category?.name))],
              bottomPadding: _navigating ? 130 : 230,
              follow: true,
              navBearing: _navigating ? _heading : null,
              me: here,
              meAsCar: true,
              meKind: vehicleKind(appState.category?.name),
            ),
          ),
          Positioned(
            top: 0,
            left: 12,
            right: 12,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(children: [
                  Flexible(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                      decoration: BoxDecoration(
                        color: AppColors.navy,
                        borderRadius: BorderRadius.circular(999),
                        boxShadow: const [BoxShadow(color: Color(0x330A2253), blurRadius: 8, offset: Offset(0, 2))],
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Container(width: 9, height: 9, decoration: const BoxDecoration(color: AppColors.lime, shape: BoxShape.circle)),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(txf('Trip #%s · %s', ['${trip.tripNo}', clock(trip.startedAt)]),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                        ),
                      ]),
                    ),
                  ),
                  const Spacer(),
                  const SosBar(compact: true),
                ]),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 10,
            right: 10,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: _navigating
                    ? Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: NavBanner(step: _nextStep, me: here, leftKm: _leftKm, leftMinutes: _leftMinutes, toLabel: _targetLabel ?? trip.destName),
                        ),
                        const SizedBox(height: 8),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          FloatingActionButton.small(
                            heroTag: 'navvoice',
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.navy,
                            onPressed: () {
                              setState(() => _voiceOn = !_voiceOn);
                              if (!_voiceOn) TurnVoice.stop();
                            },
                            child: Icon(_voiceOn ? Icons.volume_up : Icons.volume_off),
                          ),
                          const SizedBox(width: 8),
                          FloatingActionButton.small(
                            heroTag: 'navchange',
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.navy,
                            onPressed: _chooseTarget,
                            child: const Icon(Icons.alt_route),
                          ),
                          const SizedBox(width: 8),
                          FilledButton.icon(
                            style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.danger, elevation: 3),
                            onPressed: _stopNav,
                            icon: const Icon(Icons.close),
                            label: Text(tx('Exit')),
                          ),
                        ]),
                      ])
                    : Align(
                        alignment: Alignment.centerRight,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: AppColors.navy, foregroundColor: Colors.white, elevation: 3),
                          onPressed: _startNav,
                          icon: const Icon(Icons.navigation),
                          label: Text(tx('Navigate')),
                        ),
                      ),
              ),
            ),
          ),
          // The panel is a sheet: small at first so the map is wide, drag it up for the details and buttons.
          DraggableScrollableSheet(
            controller: _sheet,
            initialChildSize: 0.30,
            minChildSize: 0.17,
            maxChildSize: 0.66,
            snap: true,
            snapSizes: const [0.30, 0.66],
            builder: (context, scroll) => Container(
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [BoxShadow(color: Color(0x260A2253), blurRadius: 16, offset: Offset(0, -4))],
              ),
              child: ValueListenableBuilder<String>(
                valueListenable: language,
                builder: (context, _, __) => ListView(
                  controller: scroll,
                  padding: EdgeInsets.fromLTRB(20, 12, 20, 12 + MediaQuery.of(context).padding.bottom),
                  children: [
                    Center(
                      child: Container(
                          width: 40,
                          height: 4,
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2))),
                    ),
                    Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FieldLabel(tx(_target == null ? 'ENDS AT' : 'GOING TO')),
                          Text(_targetLabel ?? trip.destName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                        ]),
                      ),
                      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        Text(clock(eta), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.lime600)),
                        Text(
                          _leftKm == null ? tx('Finding route…') : txf('%s · %s left', ['${kmText(_leftKm)}', '${durationText(_leftMinutes ?? 0)}']),
                          style: const TextStyle(fontSize: 13, color: AppColors.muted),
                        ),
                      ]),
                    ]),
                    const SizedBox(height: 12),
                    Row(children: [
                      StatTile('On board', '$onBoard'),
                      const SizedBox(width: 8),
                      StatTile('Stops', '${_stops.where((s) => !s.auto).length}'),
                      const SizedBox(width: 8),
                      StatTile('Total', money(trip.total)),
                    ]),
                    const SizedBox(height: 10),
                    ErrorLine(_error),
                    AppButton(
                        _waiting + _aboard == 0
                            ? tx('Booked pickups')
                            : txf('Booked pickups · %s waiting · %s on board', ['$_waiting', '$_aboard']),
                        kind: _waiting > 0 ? ButtonKind.navy : ButtonKind.outline,
                        onPressed: _openBookings),
                    const SizedBox(height: 8),
                    AppButton(tr('stop_on_way'), kind: ButtonKind.outline, onPressed: _stop),
                    const SizedBox(height: 8),
                    Row(children: [
                      Expanded(
                        child: AppButton(tr('cancel'), kind: ButtonKind.danger, loading: _cancelling, onPressed: _cancel),
                      ),
                      const SizedBox(width: 10),
                      Expanded(flex: 2, child: AppButton(tr('offload'), kind: ButtonKind.navy, onPressed: _offload)),
                    ]),
                  ],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
