import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../here.dart';
import '../../i18n.dart';
import '../../map_panel.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';

/// Opens right after a passenger is scanned on board: the route line from the driver to the passenger's destination.
class DriverRouteScreen extends StatelessWidget {
  final Booking booking;
  final String? passengerName;
  const DriverRouteScreen({super.key, required this.booking, this.passengerName});

  Future<void> _navigate(BuildContext context) async {
    final dest = '${booking.destLat},${booking.destLng}';
    try {
      if (await launchUrl(Uri.parse('google.navigation:q=$dest&mode=d'), mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    try {
      await launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=driving'), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) toast(context, tx('Could not open maps.'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final to = LatLng(booking.destLat ?? 0, booking.destLng ?? 0);
    return Scaffold(
      appBar: AppBar(title: Text(tx('Route to the destination')), backgroundColor: AppColors.navy, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(
          child: ValueListenableBuilder<LatLng?>(
            valueListenable: Here.instance.point,
            builder: (context, me, _) => RouteMapView(from: me, fromName: tx('You'), to: to, toName: booking.destName),
          ),
        ),
        Container(
          color: AppColors.surface,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tx('Get off at'), style: const TextStyle(fontSize: 12, color: AppColors.muted, fontWeight: FontWeight.w700)),
              Text(booking.destName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.navy)),
              if (passengerName != null && passengerName!.isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 2), child: Text('$passengerName · #${booking.bookingNo}', style: const TextStyle(color: AppColors.muted))),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: AppButton(tx('Start navigation'), height: 48, onPressed: () => _navigate(context))),
                const SizedBox(width: 8),
                Expanded(child: AppButton(tx('Done'), kind: ButtonKind.outline, height: 48, onPressed: () => Navigator.of(context).pop())),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
