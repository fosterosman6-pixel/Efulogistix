import 'dart:async';

import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';

const _reasons = ['Breakdown', 'Puncture', 'Manager asked', 'Other'];

/// Change truck during a shift: mileage of the truck you leave and of the truck you take,
/// 4 photos of the new truck, then the manager approves.
class TruckChangeScreen extends StatefulWidget {
  final Shift shift;
  const TruckChangeScreen({super.key, required this.shift});

  @override
  State<TruckChangeScreen> createState() => _TruckChangeScreenState();
}

class _TruckChangeScreenState extends State<TruckChangeScreen> {
  String _reason = _reasons.first;
  final _note = TextEditingController();
  final _parkedAt = TextEditingController();
  final _out = OdoController();
  final _in = OdoController();
  final Map<String, Photo?> _sides = {'Front': null, 'Back': null, 'Left': null, 'Right': null};
  List<Truck> _trucks = [];
  Set<String> _inUse = {};
  String? _toTruck;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    placeHere().then((p) {
      if (mounted && _parkedAt.text.isEmpty) _parkedAt.text = p;
    });
  }

  @override
  void dispose() {
    _note.dispose();
    _parkedAt.dispose();
    _out.dispose();
    _in.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final trucks = await db.from('trucks').select().eq('active', true).order('plate');
      final busy = await db.from('shifts').select('truck_id').eq('status', 'on_duty');
      if (!mounted) return;
      setState(() {
        _trucks = trucks.map(Truck.fromMap).where((t) => t.id != widget.shift.truckId).toList();
        _inUse = {for (final r in busy) r['truck_id'] as String};
      });
    } catch (_) {}
  }

  Future<void> _send() async {
    setState(() => _error = null);
    final me = appState.profile;
    if (me == null) return;
    String? problem;
    if (!_out.ready) {
      problem = 'Take the mileage photo of the truck you are leaving, and type the km.';
    } else if (_toTruck == null) {
      problem = 'Choose the truck you are taking.';
    } else if (!_in.ready) {
      problem = 'Take the mileage photo of the new truck, and type the km.';
    } else if (_sides.values.any((p) => p == null)) {
      problem = 'Take the 4 photos of the new truck.';
    }
    if (problem != null) {
      setState(() => _error = problem);
      return;
    }
    setState(() => _busy = true);
    try {
      final here = Tracking.instance.position.value;
      await db.from('truck_changes').insert({
        'driver_id': me.id,
        'from_truck': widget.shift.truckId,
        'to_truck': _toTruck,
        'reason': _reason,
        'note': _note.text.trim().isEmpty ? null : _note.text.trim(),
        'out_km': _out.value,
        'out_photo': _out.photo!.path,
        'parked_at': _parkedAt.text.trim().isEmpty ? null : _parkedAt.text.trim(),
        'out_lat': here?.latitude,
        'out_lng': here?.longitude,
        'in_km': _in.value,
        'in_photo': _in.photo!.path,
        'in_truck_photos': _sides.values.map((p) => p!.path).toList(),
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final truck = appState.truck;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              IconButton(
                tooltip: 'Back',
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
              ),
            ]),
            NavyHeader(
              top: 'ON DUTY SINCE ${clock(widget.shift.startedAt)}',
              title: tr('change_truck'),
              subtitle: '${clock(DateTime.now())} · the manager must approve',
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  children: [
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        const FieldLabel('WHY?'),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, runSpacing: 8, children: [
                          for (final r in _reasons)
                            ChoiceChipButton(r, selected: r == _reason, onTap: () => setState(() => _reason = r)),
                        ]),
                        const SizedBox(height: 8),
                        TextField(controller: _note, decoration: plainInput('What happened? e.g. clutch slipping')),
                      ]),
                    ),
                    const SizedBox(height: 16),
                    SectionTitle('1 · LEAVING ${truck?.plate ?? ''}'),
                    OdometerCapture(controller: _out, photoLabel: 'change_out', onChanged: () => setState(() {})),
                    const SizedBox(height: 8),
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const FieldLabel('PARKED AT'),
                        TextField(
                            controller: _parkedAt,
                            decoration: const InputDecoration(hintText: 'e.g. Monkey Bay garage', border: InputBorder.none)),
                      ]),
                    ),
                    const SizedBox(height: 16),
                    const SectionTitle('2 · TAKING OVER'),
                    AppCard(
                      borderColor: AppColors.lime,
                      child: Wrap(spacing: 8, runSpacing: 8, children: [
                        if (_trucks.isEmpty) const Text('No other trucks', style: TextStyle(color: AppColors.muted)),
                        for (final t in _trucks)
                          Opacity(
                            opacity: _inUse.contains(t.id) ? 0.45 : 1,
                            child: ChoiceChipButton(
                              '${t.plate}${_inUse.contains(t.id) ? ' · in use' : ''}',
                              selected: _toTruck == t.id,
                              onTap: () {
                                if (_inUse.contains(t.id)) {
                                  toast(context, '${t.plate} is on duty with another driver.');
                                  return;
                                }
                                setState(() => _toTruck = t.id);
                              },
                            ),
                          ),
                      ]),
                    ),
                    const SizedBox(height: 8),
                    OdometerCapture(controller: _in, photoLabel: 'change_in', onChanged: () => setState(() {})),
                    const SizedBox(height: 8),
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        const FieldLabel('PHOTOS OF THE NEW TRUCK'),
                        const SizedBox(height: 8),
                        Row(children: [
                          for (final side in _sides.keys) ...[
                            Expanded(
                              child: PhotoSlot(
                                label: side,
                                fileLabel: 'new_truck_${side.toLowerCase()}',
                                photo: _sides[side],
                                onTaken: (p) => setState(() => _sides[side] = p),
                              ),
                            ),
                            if (side != 'Right') const SizedBox(width: 6),
                          ],
                        ]),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    AppCard(
                      color: const Color(0xFFFFF4E0),
                      child: const Text(
                          'Trips after the change count for the new truck. Money from today so far stays with the old one.',
                          style: TextStyle(fontSize: 13)),
                    ),
                    const SizedBox(height: 12),
                    ErrorLine(_error),
                    const SizedBox(height: 8),
                    AppButton(tr('send_to_owner'), height: 56, loading: _busy, onPressed: _send),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shown while the manager decides. Checks every 10 seconds.
class TruckChangeWaiting extends StatefulWidget {
  final TruckChange change;
  final VoidCallback onDone;
  const TruckChangeWaiting({super.key, required this.change, required this.onDone});

  @override
  State<TruckChangeWaiting> createState() => _TruckChangeWaitingState();
}

class _TruckChangeWaitingState extends State<TruckChangeWaiting> {
  Timer? _timer;
  String _status = 'pending';

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _check());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check() async {
    try {
      final row = await db.from('truck_changes').select('status').eq('id', widget.change.id).single();
      final s = (row['status'] ?? 'pending').toString();
      if (s != 'pending') {
        _timer?.cancel();
        setState(() => _status = s);
        if (s == 'approved') {
          await Tracking.instance.stop(); // restart on the new truck
          await Tracking.instance.takeSinceReading(); // the new truck's mileage photo is the new starting point
          await appState.refresh();
        }
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final decided = _status != 'pending';
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Icon(
                decided ? (_status == 'approved' ? Icons.check_circle : Icons.cancel) : Icons.hourglass_top,
                size: 56,
                color: decided ? (_status == 'approved' ? AppColors.lime600 : AppColors.danger) : AppColors.warning,
              ),
              const SizedBox(height: 12),
              Text(
                decided ? (_status == 'approved' ? 'Truck change approved' : 'Truck change declined') : tr('waiting_approval'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.navy),
              ),
              const SizedBox(height: 8),
              Text(
                decided
                    ? (_status == 'approved'
                        ? 'You are now on duty with the new truck.'
                        : 'Keep using your truck, or call the manager.')
                    : '${widget.change.reason} · sent ${clock(widget.change.createdAt)}',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              if (decided)
                AppButton('Continue', onPressed: widget.onDone)
              else
                AppButton('Check now', kind: ButtonKind.outline, onPressed: _check),
            ]),
          ),
        ),
      ),
    );
  }
}
