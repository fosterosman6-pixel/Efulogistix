import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../tracking.dart';
import '../../widgets.dart';

/// Arrived: passengers off, mileage photo + km, trip ends.
class OffloadScreen extends StatefulWidget {
  final Trip trip;
  const OffloadScreen({super.key, required this.trip});

  @override
  State<OffloadScreen> createState() => _OffloadScreenState();
}

class _OffloadScreenState extends State<OffloadScreen> {
  final _odo = OdoController();
  late Trip _trip = widget.trip;
  bool _busy = false;
  bool _readingSaved = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    db.from('trips').select().eq('id', widget.trip.id).single().then((row) {
      if (mounted) setState(() => _trip = Trip.fromMap(row));
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _odo.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    setState(() => _error = null);
    if (!_odo.ready) {
      setState(() => _error = 'Take the mileage photo and type the km.');
      return;
    }
    setState(() => _busy = true);
    try {
      final here = Tracking.instance.position.value;
      final gpsKm = (Tracking.instance.tripKm * 10).round() / 10;
      if (!_readingSaved) {
        final since = await Tracking.instance.takeSinceReading();
        await db.rpc('record_trip_reading', params: {
          'p_trip': _trip.id,
          'p_kind': 'trip_end',
          'p_km': _odo.value,
          'p_photo': _odo.photo!.path,
          'p_lat': here?.latitude,
          'p_lng': here?.longitude,
          'p_gps_since': since,
        });
        _readingSaved = true;
      }
      final start = _trip.startKm;
      await db.from('trips').update({
        'status': 'completed',
        'ended_at': DateTime.now().toUtc().toIso8601String(),
        'gps_km': gpsKm,
        'actual_km': start == null ? gpsKm : (_odo.value! - start),
      }).eq('id', _trip.id);
      Tracking.instance.setTrip(null);
      await Tracking.instance.sendNow();
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _trip;
    final typed = _odo.value;
    final odoKm = (typed != null && t.startKm != null) ? typed - t.startKm! : null;
    final gps = Tracking.instance.tripKm;
    final ok = odoKm == null ? null : (odoKm - gps).abs() <= 3 + gps * 0.1;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              IconButton(
                tooltip: 'Back',
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
              ),
            ]),
            NavyHeader(
              top: 'TRIP #${t.tripNo} · ARRIVED ${clock(DateTime.now())}',
              title: 'Offload at ${t.destName}',
              subtitle: 'Passengers off. Record the mileage to end the trip.',
            ),
            Expanded(
              child: Container(
                color: AppColors.surface100,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  children: [
                    OdometerCapture(
                      controller: _odo,
                      photoLabel: 'trip_end',
                      hint: t.startKm == null ? null : 'Trip started at ${t.startKm} km',
                      onChanged: () => setState(() {}),
                    ),
                    const SizedBox(height: 12),
                    Row(children: [
                      StatTile('Odometer', odoKm == null ? '—' : '$odoKm km'),
                      const SizedBox(width: 8),
                      StatTile('GPS', '${gps.round()} km'),
                      const SizedBox(width: 8),
                      StatTile('Check', ok == null ? '—' : (ok ? 'OK' : 'Check')),
                    ]),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
                      child: Row(children: [
                        Expanded(
                          child: Text(tr('cash_collected'),
                              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                        ),
                        Text(money(t.total),
                            style: const TextStyle(color: AppColors.lime, fontSize: 22, fontWeight: FontWeight.w800)),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    ErrorLine(_error),
                    const SizedBox(height: 8),
                    AppButton(tr('offload'), kind: ButtonKind.navy, height: 56, loading: _busy, onPressed: _finish),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
