import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

import '../app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import '../i18n.dart';

/// Passenger: the boarding ticket (QR code + the same 8 digits).
Future<void> showTicket(BuildContext context, String bookingId, int bookingNo) async {
  String? code;
  String? error;
  final prefs = await SharedPreferences.getInstance();
  try {
    code = (await db.rpc('my_ticket', params: {'p_booking': bookingId})).toString();
    await prefs.setString('ticket_$bookingId', code); // kept so the ticket still opens without signal
  } catch (e) {
    code = prefs.getString('ticket_$bookingId'); // no signal: use the saved ticket
    if (code == null) error = friendlyError(e);
  }
  if (!context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(txf('Boarding ticket · #%s', ['$bookingNo']), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(tx('Show this to the driver when you get in.'), style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 16),
          if (code != null) ...[
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(12),
              child: QrImageView(data: 'EFU-$code', size: 220, backgroundColor: Colors.white),
            ),
            const SizedBox(height: 14),
            Text('${code.substring(0, 4)} ${code.substring(4)}',
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: 4)),
            Text(tx('If the driver cannot scan, read out these digits.'),
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ] else
            Padding(padding: const EdgeInsets.all(20), child: Text(error ?? tx('No ticket.'), textAlign: TextAlign.center)),
        ]),
      ),
    ),
  );
}

/// Passenger: send a link so family can watch the car on a map.
Future<void> shareTrip(BuildContext context, String bookingId, String title, {String? parcelCode}) async {
  try {
    final url = (await db.rpc('share_trip', params: {'p_booking': bookingId})).toString();
    await Share.share(parcelCode != null && parcelCode.isNotEmpty
        ? 'Follow your parcel ($title) live on the map:\n$url\nCollection code: $parcelCode (give it to the driver when you receive it)'
        : 'Follow my trip ($title) live on the map:\n$url');
  } catch (e) {
    if (context.mounted) toast(context, friendlyError(e));
  }
}

/// Driver: scan the passenger's QR code (or type the 8 digits) to mark them on board.
class ScanTicketScreen extends StatefulWidget {
  const ScanTicketScreen({super.key});

  @override
  State<ScanTicketScreen> createState() => _ScanTicketScreenState();
}

class _ScanTicketScreenState extends State<ScanTicketScreen> {
  final _scanner = MobileScannerController(formats: const [BarcodeFormat.qrCode]);
  final _typed = TextEditingController();
  bool _busy = false;
  String? _result;
  bool _ok = false;

  @override
  void dispose() {
    _scanner.dispose();
    _typed.dispose();
    super.dispose();
  }

  Future<void> _board(String raw) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _result = null;
    });
    try {
      final r = Map<String, dynamic>.from(await db.rpc('board_by_code', params: {'p_code': raw}) as Map);
      final seats = (r['seats'] ?? 1).toString();
      setState(() {
        _ok = true;
        _result = r['already'] == true
            ? '${r['name']} is already on board.'
            : '${r['name']} is on board · $seats ${seats == '1' ? 'seat' : 'seats'} · #${r['booking_no']}';
      });
      _typed.clear();
    } catch (e) {
      setState(() {
        _ok = false;
        _result = friendlyError(e);
      });
    }
    // short pause so the same QR is not read twice
    await Future<void>.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tx('Scan ticket')), backgroundColor: AppColors.navy, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(
          child: MobileScanner(
            controller: _scanner,
            onDetect: (capture) {
              for (final b in capture.barcodes) {
                final v = b.rawValue ?? '';
                if (v.startsWith('EFU-')) {
                  _board(v);
                  break;
                }
              }
            },
          ),
        ),
        Container(
          color: AppColors.surface,
          padding: const EdgeInsets.all(16),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (_result != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(_result!,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: _ok ? AppColors.lime600 : AppColors.danger)),
                ),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _typed,
                    keyboardType: TextInputType.number,
                    maxLength: 9,
                    decoration: InputDecoration(labelText: tx('Or type the 8 digits'), counterText: ''),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(width: 110, child: AppButton(tx('Board'), loading: _busy, height: 48, onPressed: () => _board(_typed.text))),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
