import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'passenger/my_things.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

import '../app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import '../i18n.dart';

/// Passenger: the boarding ticket (QR code + the same 8 digits).
Future<void> showTicket(BuildContext context, String bookingId, int bookingNo) async {
  String? code;
  String? error;
  final prefs = await SharedPreferences.getInstance();
  try {
    code = (await db.rpc('my_ticket', params: {'p_booking': bookingId})).toString();
    await prefs.setString('ticket_$bookingId', code); // kept so the ticket still opens without signal
  } catch (e) {
    code = prefs.getString('ticket_$bookingId'); // no signal: use the saved ticket
    if (code == null) error = friendlyError(e);
  }
  if (!context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(txf('Boarding ticket · #%s', ['$bookingNo']), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(tx('Show this to the driver when you get in.'), style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 16),
          if (code != null) ...[
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(12),
              child: QrImageView(data: 'EFU-$code', size: 220, backgroundColor: Colors.white),
            ),
            const SizedBox(height: 14),
            Text('${code.substring(0, 4)} ${code.substring(4)}',
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: 4)),
            Text(tx('If the driver cannot scan, read out these digits.'),
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ] else
            Padding(padding: const EdgeInsets.all(20), child: Text(error ?? tx('No ticket.'), textAlign: TextAlign.center)),
        ]),
      ),
    ),
  );
}

/// Passenger: send a link so family can watch the car on a map.
Future<void> shareTrip(BuildContext context, String bookingId, String title, {String? parcelCode}) async {
  try {
    final url = (await db.rpc('share_trip', params: {'p_booking': bookingId})).toString();
    await Share.share(parcelCode != null && parcelCode.isNotEmpty
        ? 'Follow your parcel ($title) live on the map:\n$url\nCollection code: $parcelCode (give it to the driver when you receive it)'
        : 'Follow my trip ($title) live on the map:\n$url');
  } catch (e) {
    if (context.mounted) toast(context, friendlyError(e));
  }
}

/// Passenger: text the emergency contact a live link to the trip (set in Account > Emergency contact).
Future<void> alertEmergencyContact(BuildContext context, String bookingId, String title) async {
  try {
    final c = await EmergencyContact.load();
    if (c == null) {
      if (context.mounted) toast(context, tx('Set your emergency contact first: Account > Emergency contact.'));
      return;
    }
    final url = (await db.rpc('share_trip', params: {'p_booking': bookingId})).toString();
    final text = 'I want you to know where I am. Follow my EfuLogistix trip ($title) live on the map:\n$url';
    await launchUrl(Uri.parse('sms:${c.phone}?body=${Uri.encodeComponent(text)}'), mode: LaunchMode.externalApplication);
  } catch (e) {
    if (context.mounted) toast(context, friendlyError(e));
  }
}

/// Driver: scan the passenger's QR code (or type the 8 digits) to mark them on board.
class ScanTicketScreen extends StatefulWidget {
  const ScanTicketScreen({super.key});

  @override
  State<ScanTicketScreen> createState() => _ScanTicketScreenState();
}

class _ScanTicketScreenState extends State<ScanTicketScreen> {
  final _scanner = MobileScannerController(formats: const [BarcodeFormat.qrCode]);
  final _typed = TextEditingController();
  bool _busy = false;
  String? _result;
  bool _ok = false;
  // live dots on every QR code the camera sees
  List<List<Offset>> _found = [];
  List<bool> _foundOurs = [];
  Size _capSize = Size.zero;
  Timer? _dotTimer;

  @override
  void dispose() {
    _dotTimer?.cancel();
    _scanner.dispose();
    _typed.dispose();
    super.dispose();
  }

  /// Fallback when the live camera will not start: take a photo of the ticket with the phone's camera app and read the QR from it.
  Future<void> _scanPhoto() async {
    try {
      final shot = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90);
      if (shot == null) return;
      final cap = await _scanner.analyzeImage(shot.path);
      final code = cap?.barcodes.map((b) => b.rawValue ?? '').firstWhere((v) => v.startsWith('EFU-'), orElse: () => '') ?? '';
      if (code.isEmpty) {
        if (mounted) setState(() { _ok = false; _result = tx('No ticket code found in the photo. Try again, or type the 8 digits.'); });
        return;
      }
      await _board(code);
    } catch (_) {
      if (mounted) setState(() { _ok = false; _result = tx('Could not read the photo. Type the 8 digits instead.'); });
    }
  }

  Future<void> _board(String raw) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _result = null;
    });
    try {
      final r = Map<String, dynamic>.from(await db.rpc('board_by_code', params: {'p_code': raw}) as Map);
      final seats = (r['seats'] ?? 1).toString();
      setState(() {
        _ok = true;
        _result = r['already'] == true
            ? '${r['name']} is already on board.'
            : '${r['name']} is on board${seats == '0' ? '' : ' · $seats ${seats == '1' ? 'seat' : 'seats'}'} · #${r['booking_no']}';
      });
      _typed.clear();
      // the passenger is on board: show who it was for a moment, then close this screen
      await Future<void>.delayed(const Duration(milliseconds: 1300));
      if (mounted) Navigator.of(context).pop(r);
      return;
    } catch (e) {
      setState(() {
        _ok = false;
        _result = friendlyError(e);
      });
    }
    // short pause so the same QR is not read twice
    await Future<void>.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tx('Scan ticket')), backgroundColor: AppColors.navy, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(
          child: Stack(fit: StackFit.expand, children: [
          MobileScanner(
            controller: _scanner,
            errorBuilder: (context, error, child) {
              final denied = error.errorCode == MobileScannerErrorCode.permissionDenied;
              return Container(
                color: Colors.black,
                padding: const EdgeInsets.all(28),
                alignment: Alignment.center,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.no_photography_outlined, color: Colors.white, size: 44),
                  const SizedBox(height: 14),
                  Text(
                    denied
                        ? tx('Camera is blocked. Allow the camera for EfuLogistix in your phone settings, then try again. You can also type the 8 digits below.')
                        : tx('The camera could not start. Try again, or type the 8 digits below.'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  const SizedBox(height: 10),
                  Text('${error.errorCode.name}${error.errorDetails?.message != null ? ': ${error.errorDetails!.message}' : ''}',
                      textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () async {
                      try {
                        await _scanner.start();
                      } catch (_) {}
                      if (mounted) setState(() {});
                    },
                    child: Text(tx('Try again')),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54)),
                    onPressed: _scanPhoto,
                    icon: const Icon(Icons.photo_camera_outlined),
                    label: Text(tx('Take a photo of the ticket')),
                  ),
                ]),
              );
            },
            onDetect: (capture) {
              final withCorners = capture.barcodes.where((b) => b.corners.isNotEmpty).toList();
              if (mounted && withCorners.isNotEmpty && capture.size.width > 0) {
                setState(() {
                  _capSize = capture.size;
                  _found = withCorners.map((b) => b.corners).toList();
                  _foundOurs = withCorners.map((b) => (b.rawValue ?? '').startsWith('EFU-')).toList();
                });
                _dotTimer?.cancel();
                _dotTimer = Timer(const Duration(milliseconds: 700), () {
                  if (mounted) setState(() => _found = []);
                });
              }
              var seen = false;
              for (final b in capture.barcodes) {
                final v = b.rawValue ?? '';
                if (v.isEmpty) continue;
                seen = true;
                if (v.startsWith('EFU-')) {
                  _board(v);
                  return;
                }
              }
              // a QR code was read but it is not one of ours (shop label, parcel sticker ...): say so
              if (seen && !_busy && mounted) {
                setState(() {
                  _ok = false;
                  _result = tx('That QR code is not an EfuLogistix ticket.');
                });
              }
            },
          ),
          // dots on detected QR codes
          if (_found.isNotEmpty)
            IgnorePointer(
              child: CustomPaint(
                painter: _DotsPainter(_found, _foundOurs, _capSize),
                size: Size.infinite,
              ),
            ),
          // viewfinder: where to hold the ticket
          IgnorePointer(
            child: Center(
              child: Container(
                width: 240,
                height: 240,
                decoration: BoxDecoration(
                  border: Border.all(color: _busy ? AppColors.lime : Colors.white, width: 4),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            top: 16,
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
                child: Text(tx("Hold the phone steady, 20 cm from the passenger's ticket, inside the frame."),
                    textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
              ),
            ),
          ),
          Positioned(
            right: 12,
            bottom: 12,
            child: Column(children: [
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: Colors.black54),
                tooltip: tx('Light'),
                onPressed: () => _scanner.toggleTorch(),
                icon: const Icon(Icons.flashlight_on_outlined, color: Colors.white),
              ),
              const SizedBox(height: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: Colors.black54),
                tooltip: tx('Switch camera'),
                onPressed: () => _scanner.switchCamera(),
                icon: const Icon(Icons.cameraswitch_outlined, color: Colors.white),
              ),
            ]),
          ),
          ]),
        ),
        Container(
          color: AppColors.surface,
          padding: const EdgeInsets.all(16),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (_result != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(_result!,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: _ok ? AppColors.lime600 : AppColors.danger)),
                ),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _typed,
                    keyboardType: TextInputType.number,
                    maxLength: 9,
                    decoration: InputDecoration(labelText: tx('Or type the 8 digits'), counterText: ''),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(width: 110, child: AppButton(tx('Board'), loading: _busy, height: 48, onPressed: () => _board(_typed.text))),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}


/// Draws a dot on each corner and the middle of every QR code the camera has found.
/// Green = EfuLogistix ticket, amber = some other QR code.
class _DotsPainter extends CustomPainter {
  _DotsPainter(this.codes, this.ours, this.cap);
  final List<List<Offset>> codes;
  final List<bool> ours;
  final Size cap;

  @override
  void paint(Canvas canvas, Size size) {
    if (cap.width <= 0 || cap.height <= 0) return;
    // the preview fills the screen and is cropped to fit (BoxFit.cover)
    final scale = size.width / cap.width > size.height / cap.height ? size.width / cap.width : size.height / cap.height;
    final dx = (size.width - cap.width * scale) / 2;
    final dy = (size.height - cap.height * scale) / 2;
    Offset map(Offset o) => Offset(o.dx * scale + dx, o.dy * scale + dy);
    for (var i = 0; i < codes.length; i++) {
      final c = ours[i] ? const Color(0xFF7CFC00) : const Color(0xFFFFB300);
      final pts = codes[i].map(map).toList();
      final mid = Offset(pts.map((e) => e.dx).reduce((a, b) => a + b) / pts.length,
          pts.map((e) => e.dy).reduce((a, b) => a + b) / pts.length);
      final ring = Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 2;
      final fill = Paint()..color = c;
      for (final p in [...pts, mid]) {
        canvas.drawCircle(p, 8, fill);
        canvas.drawCircle(p, 8, ring);
      }
    }
  }

  @override
  bool shouldRepaint(_DotsPainter old) => true;
}
