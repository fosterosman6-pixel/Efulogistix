import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'driver/documents.dart';
import '../i18n.dart';

class PendingScreen extends StatefulWidget {
  const PendingScreen({super.key});

  @override
  State<PendingScreen> createState() => _PendingScreenState();
}

class _PendingScreenState extends State<PendingScreen> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final name = appState.profile?.displayName ?? 'driver';
    final driver = appState.profile?.isDriver ?? true;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(tx('Waiting for approval'),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.navy)),
                const SizedBox(height: 12),
                Text(
                  driver
                      ? 'Hi $name. Upload your documents (ID, licence, face photo). The admin checks them and approves '
                          'your account, then the office matches you with a vehicle.'
                      : 'Hi $name. The admin needs to approve your account. '
                          'If the admin already added you, make sure you signed up with the same email.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 15),
                ),
                const SizedBox(height: 20),
                if (driver) ...[
                  AppButton(tx('My documents'),
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocumentsScreen()))),
                  const SizedBox(height: 8),
                ],
                AppButton(tx('Check again'), kind: driver ? ButtonKind.outline : ButtonKind.lime, loading: _busy, onPressed: () async {
                  setState(() => _busy = true);
                  await appState.refresh();
                  if (mounted) setState(() => _busy = false);
                }),
                const SizedBox(height: 8),
                AppButton(tx('Sign out'), kind: ButtonKind.ghost, onPressed: appState.signOut),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
