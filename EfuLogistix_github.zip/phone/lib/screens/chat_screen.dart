import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app_state.dart';
import '../format.dart';
import '../i18n.dart';
import '../photos.dart';
import '../theme.dart';
import '../widgets.dart';

class _Msg {
  final String id;
  final String senderId;
  final String kind; // text, photo, voice
  final String body;
  final String? filePath;
  final int? seconds;
  final DateTime at;
  _Msg(Map<String, dynamic> m)
      : id = m['id'] as String,
        senderId = m['sender_id'] as String,
        kind = (m['kind'] ?? 'text') as String,
        body = (m['body'] ?? '') as String,
        filePath = m['file_path'] as String?,
        seconds = (m['seconds'] as num?)?.toInt(),
        at = DateTime.parse(m['created_at'] as String).toLocal();
}

/// Chat between two people: text, a photo or a voice note.
/// For a booking pass [bookingId] (passenger and driver). For owner and driver pass [peerId] (the other person).
class ChatScreen extends StatefulWidget {
  final String? bookingId;
  final String? peerId;
  final String title;
  const ChatScreen({super.key, this.bookingId, this.peerId, required this.title});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  final _recorder = AudioRecorder();
  final _player = AudioPlayer();
  List<_Msg> _msgs = [];
  bool _loading = true;
  bool _sending = false;
  bool _recording = false;
  DateTime? _recStart;
  Timer? _poll;
  Timer? _tick;
  RealtimeChannel? _channel;
  String? _playing; // message id being played

  String get _me => appState.profile?.id ?? '';

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 12), (_) => _load());
    _channel = db
        .channel('chat-${widget.bookingId ?? widget.peerId}')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'chat_messages', callback: (_) => _load())
        .subscribe();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = null);
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    final c = _channel;
    if (c != null) db.removeChannel(c);
    _recorder.dispose();
    _player.dispose();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final q = db.from('chat_messages').select();
      final rows = widget.bookingId != null
          ? await q.eq('booking_id', widget.bookingId!).order('created_at')
          : await q
              .isFilter('booking_id', null)
              .or('sender_id.eq.${widget.peerId},recipient_id.eq.${widget.peerId}')
              .order('created_at');
      final list = rows.map(_Msg.new).toList();
      if (!mounted) return;
      final grew = list.length != _msgs.length;
      setState(() {
        _msgs = list;
        _loading = false;
      });
      if (grew) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
        });
        db.rpc('read_chat', params: {'p_booking': widget.bookingId, 'p_peer': widget.peerId}).catchError((_) {});
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send({String kind = 'text', String? path, int? seconds}) async {
    final body = kind == 'text' ? _text.text.trim() : '';
    if (kind == 'text' && body.isEmpty) return;
    setState(() => _sending = true);
    try {
      await db.rpc('send_chat', params: {
        'p_booking': widget.bookingId,
        'p_peer': widget.peerId,
        'p_body': body,
        'p_kind': kind,
        'p_path': path,
        'p_seconds': seconds,
      });
      if (kind == 'text') _text.clear();
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<String> _upload(List<int> bytes, String ext, String type) async {
    final path = '$_me/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await db.storage.from('chat').uploadBinary(path, bytes is Uint8List ? bytes : Uint8List.fromList(bytes),
        fileOptions: FileOptions(contentType: type, upsert: false));
    return path;
  }

  Future<void> _attach() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_camera_outlined), title: Text(tx('Take a photo')), onTap: () => Navigator.pop(ctx, ImageSource.camera)),
          ListTile(leading: const Icon(Icons.photo_library_outlined), title: Text(tx('Choose from gallery')), onTap: () => Navigator.pop(ctx, ImageSource.gallery)),
        ]),
      ),
    );
    if (source == null) return;
    setState(() => _sending = true);
    try {
      final f = await ImagePicker().pickImage(source: source, maxWidth: 1600, imageQuality: 70);
      if (f == null) return;
      final path = await _upload(await f.readAsBytes(), 'jpg', 'image/jpeg');
      await _send(kind: 'photo', path: path);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final secs = DateTime.now().difference(_recStart ?? DateTime.now()).inSeconds;
      _tick?.cancel();
      final file = await _recorder.stop();
      setState(() => _recording = false);
      if (file == null) return;
      if (secs < 1) {
        toast(context, tx('Too short. Hold on a little longer.'));
        return;
      }
      setState(() => _sending = true);
      try {
        final path = await _upload(await File(file).readAsBytes(), 'm4a', 'audio/mp4');
        await _send(kind: 'voice', path: path, seconds: secs);
      } catch (e) {
        if (mounted) toast(context, friendlyError(e));
      } finally {
        if (mounted) setState(() => _sending = false);
      }
      return;
    }
    try {
      if (!await _recorder.hasPermission()) {
        if (mounted) toast(context, tx('Allow the microphone in your phone settings to send voice notes.'));
        return;
      }
      final file = '${Directory.systemTemp.path}/efu_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: file);
      _recStart = DateTime.now();
      _tick = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() {});
        if (DateTime.now().difference(_recStart!).inSeconds >= 120) _toggleRecord(); // 2 minutes is the longest note
      });
      setState(() => _recording = true);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _play(_Msg m) async {
    if (_playing == m.id) {
      await _player.stop();
      setState(() => _playing = null);
      return;
    }
    final url = await _signed(m.filePath);
    if (url == null) return;
    await _player.stop();
    setState(() => _playing = m.id);
    await _player.play(UrlSource(url));
  }

  final Map<String, String> _urls = {};
  Future<String?> _signed(String? path) async {
    if (path == null) return null;
    final c = _urls[path];
    if (c != null) return c;
    try {
      final u = await db.storage.from('chat').createSignedUrl(path, 3600);
      _urls[path] = u;
      return u;
    } catch (_) {
      return null;
    }
  }

  Future<void> _openPhoto(_Msg m) async {
    final url = await _signed(m.filePath);
    if (url == null || !mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(8),
        child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain)),
      ),
    );
  }

  Widget _bubble(_Msg m) {
    final mine = m.senderId == _me;
    Widget content;
    if (m.kind == 'photo') {
      content = FutureBuilder<String?>(
        future: _signed(m.filePath),
        builder: (context, snap) => GestureDetector(
          onTap: () => _openPhoto(m),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: snap.data == null
                ? Container(width: 200, height: 140, color: AppColors.line, child: const Center(child: Icon(Icons.image_outlined)))
                : Image.network(snap.data!, width: 200, height: 200, fit: BoxFit.cover),
          ),
        ),
      );
    } else if (m.kind == 'voice') {
      final on = _playing == m.id;
      content = InkWell(
        onTap: () => _play(m),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(on ? Icons.stop_circle_outlined : Icons.play_circle_fill, size: 34, color: mine ? AppColors.navy : AppColors.lime600),
          const SizedBox(width: 8),
          Text(tx('Voice note') + (m.seconds != null ? ' · ${m.seconds}s' : ''), style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      );
    } else {
      content = Text(m.body, style: const TextStyle(fontSize: 15));
    }
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: mine ? AppColors.lime100 : AppColors.surface, borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          content,
          const SizedBox(height: 2),
          Text(clock(m.at), style: const TextStyle(fontSize: 10, color: AppColors.muted)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final recSecs = _recording ? DateTime.now().difference(_recStart ?? DateTime.now()).inSeconds : 0;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _msgs.isEmpty
                  ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(tx('No messages yet. Say hello.'), style: const TextStyle(color: AppColors.muted))))
                  : ListView(controller: _scroll, padding: const EdgeInsets.all(12), children: [for (final m in _msgs) _bubble(m)]),
        ),
        SafeArea(
          top: false,
          child: Container(
            color: AppColors.surface,
            padding: const EdgeInsets.fromLTRB(6, 6, 6, 6),
            child: _recording
                ? Row(children: [
                    const Icon(Icons.fiber_manual_record, color: AppColors.danger),
                    const SizedBox(width: 8),
                    Expanded(child: Text('${tx('Recording')} · ${recSecs}s', style: const TextStyle(fontWeight: FontWeight.w700))),
                    FilledButton.icon(onPressed: _toggleRecord, icon: const Icon(Icons.send), label: Text(tx('Send'))),
                  ])
                : Row(children: [
                    IconButton(tooltip: tx('Photo'), onPressed: _sending ? null : _attach, icon: const Icon(Icons.attach_file)),
                    Expanded(
                      child: TextField(
                        controller: _text,
                        minLines: 1,
                        maxLines: 4,
                        maxLength: 1000,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: InputDecoration(hintText: tx('Message'), counterText: '', border: InputBorder.none),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    if (_text.text.trim().isEmpty)
                      IconButton(tooltip: tx('Voice note'), onPressed: _sending ? null : _toggleRecord, icon: const Icon(Icons.mic_none))
                    else
                      IconButton.filled(
                          style: IconButton.styleFrom(backgroundColor: AppColors.navy),
                          onPressed: _sending ? null : () => _send(),
                          icon: const Icon(Icons.send, color: Colors.white)),
                  ]),
          ),
        ),
      ]),
    );
  }
}
