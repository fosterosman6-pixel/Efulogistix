import 'package:flutter/material.dart';

import '../../format.dart';
import '../../i18n.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'catalog.dart';

/// Shown before a trip that needs a change of car is booked: both parts, what to pay and to whom.
/// Pops true when the passenger confirms.
class TransferPlanScreen extends StatelessWidget {
  final Map<String, dynamic> plan;
  final String payMethod; // cash or a cashless method
  final int seats;
  const TransferPlanScreen({super.key, required this.plan, required this.payMethod, required this.seats});

  @override
  Widget build(BuildContext context) {
    final legs = List<Map<String, dynamic>>.from((plan['legs'] as List).map((e) => Map<String, dynamic>.from(e as Map)));
    final walk = toDouble(plan['walk_km']);
    final cash = payMethod == 'cash';
    double fare(int i) => toDouble(legs[i]['fare']) * seats;
    final total = fare(0) + fare(1);
    final changeAt = '${legs[0]['to_name']}';
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: navyBar(tx('Your trip')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFFFFF6DD), border: Border.all(color: const Color(0xFFF0C24A), width: 2), borderRadius: BorderRadius.circular(14)),
          child: Text(txf('This trip needs one change of car at %s. We book both cars for you.', [changeAt]),
              style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF5A4300))),
        ),
        const SizedBox(height: 12),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            for (var i = 0; i < 2; i++) ...[
              if (i == 1)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(txf('Then walk or ride about %s km to %s', [walk.toStringAsFixed(1), '${legs[1]['from_name']}']),
                      style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 28,
                  height: 28,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: i == 0 ? AppColors.navy : AppColors.lime, shape: BoxShape.circle),
                  child: Text('${i + 1}', style: TextStyle(fontWeight: FontWeight.w800, color: i == 0 ? Colors.white : AppColors.navy)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${legs[i]['from_name']} → ${legs[i]['to_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    Text('${toDouble(legs[i]['km']).toStringAsFixed(1)} km', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
                Text(money(fare(i)), style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
            ],
          ]),
        ),
        const SizedBox(height: 12),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(cash ? tx('You pay in cash') : tx('You pay once'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              Text(money(total), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            ]),
            const SizedBox(height: 6),
            Text(
                cash
                    ? txf('Pay %s to the first driver and %s to the second driver. Each driver collects only their own part.', [money(fare(0)), money(fare(1))])
                    : tx('One payment covers both cars. We share it between the two drivers, so you never pay a driver.'),
                style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          ]),
        ),
        const SizedBox(height: 16),
        AppButton(cash ? tx('Book both cars') : txf('Pay %s and book', [money(total)]), onPressed: () => Navigator.of(context).pop(true)),
        const SizedBox(height: 8),
        AppButton(tx('Back'), kind: ButtonKind.outline, onPressed: () => Navigator.of(context).pop(false)),
      ]),
    );
  }
}
