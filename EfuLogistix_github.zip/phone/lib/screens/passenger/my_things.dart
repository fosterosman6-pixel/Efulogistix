import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:share_plus/share_plus.dart';

import '../../app_state.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../i18n.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'hire_car.dart' show PlaceSearch;

AppBar _bar(String title) => AppBar(
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      backgroundColor: AppColors.navy,
      foregroundColor: Colors.white,
    );

// ============================================================================ saved places

class SavedPlace {
  final String id;
  final String label;
  final Place place;
  SavedPlace(this.id, this.label, this.place);

  /// The signed-in person's saved places (Home, Work ...). Empty when there is no signal.
  static Future<List<SavedPlace>> load() async {
    try {
      final rows = await db.from('saved_places').select().order('created_at');
      return [
        for (final r in rows as List)
          SavedPlace(r['id'] as String, r['label'] as String,
              Place(r['name'] as String, r['label'] as String, LatLng((r['lat'] as num).toDouble(), (r['lng'] as num).toDouble())))
      ];
    } catch (_) {
      return [];
    }
  }
}

class SavedPlacesScreen extends StatefulWidget {
  const SavedPlacesScreen({super.key});

  @override
  State<SavedPlacesScreen> createState() => _SavedPlacesScreenState();
}

class _SavedPlacesScreenState extends State<SavedPlacesScreen> {
  List<SavedPlace>? _list;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await SavedPlace.load();
    if (mounted) setState(() => _list = l);
  }

  Future<void> _add([String? label]) async {
    final picked = await showSearch<Place?>(context: context, delegate: PlaceSearch(near: Here.instance.point.value));
    if (picked == null || !mounted) return;
    var name = label;
    if (name == null) {
      final ctl = TextEditingController();
      name = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tx('Name this place')),
          content: TextField(controller: ctl, autofocus: true, maxLength: 30, decoration: InputDecoration(hintText: tx('e.g. Mum\'s house'))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tx('Cancel'))),
            TextButton(onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: Text(tx('Save'))),
          ],
        ),
      );
      ctl.dispose();
    }
    if (name == null || name.isEmpty) return;
    try {
      await db.from('saved_places').insert({'label': name, 'name': picked.name, 'lat': picked.point.latitude, 'lng': picked.point.longitude});
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _remove(SavedPlace p) async {
    try {
      await db.from('saved_places').delete().eq('id', p.id);
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = _list;
    final labels = (list ?? []).map((p) => p.label).toSet();
    return Scaffold(
      appBar: _bar(tx('Saved places')),
      body: list == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(tx('They show first when you pick a place, so you do not have to type them.'), style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              for (final p in list)
                AppCard(
                  child: Row(children: [
                    Icon(p.label == 'Home' ? Icons.home_outlined : p.label == 'Work' ? Icons.work_outline : Icons.place_outlined, color: AppColors.navy),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(p.label, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text(p.place.name, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ]),
                    ),
                    IconButton(onPressed: () => _remove(p), icon: const Icon(Icons.delete_outline, color: AppColors.danger)),
                  ]),
                ),
              const SizedBox(height: 8),
              if (!labels.contains('Home')) AppButton(tx('Add Home'), kind: ButtonKind.outline, onPressed: () => _add('Home')),
              if (!labels.contains('Work')) ...[const SizedBox(height: 8), AppButton(tx('Add Work'), kind: ButtonKind.outline, onPressed: () => _add('Work'))],
              const SizedBox(height: 8),
              AppButton(tx('Add another place'), onPressed: list.length >= 10 ? null : () => _add()),
            ]),
    );
  }
}

// ============================================================================ emergency contact

class EmergencyContact {
  final String name;
  final String phone;
  const EmergencyContact(this.name, this.phone);

  static Future<EmergencyContact?> load() async {
    final me = appState.profile?.id;
    if (me == null) return null;
    try {
      final r = await db.from('profiles').select('emergency_name, emergency_phone').eq('id', me).maybeSingle();
      final phone = (r?['emergency_phone'] ?? '') as String;
      if (phone.trim().isEmpty) return null;
      return EmergencyContact((r?['emergency_name'] ?? '') as String, phone.trim());
    } catch (_) {
      return null;
    }
  }
}

class EmergencyContactScreen extends StatefulWidget {
  const EmergencyContactScreen({super.key});

  @override
  State<EmergencyContactScreen> createState() => _EmergencyContactScreenState();
}

class _EmergencyContactScreenState extends State<EmergencyContactScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  bool _busy = false;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    EmergencyContact.load().then((c) {
      if (!mounted) return;
      _name.text = c?.name ?? '';
      _phone.text = c?.phone ?? '';
      setState(() => _loaded = true);
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final me = appState.profile?.id;
    if (me == null) return;
    final phone = _phone.text.trim();
    if (phone.isNotEmpty && !RegExp(r'^\+?[0-9 ]{7,16}$').hasMatch(phone)) {
      toast(context, tx('Type a phone number, for example 0999 123 456.'));
      return;
    }
    setState(() => _busy = true);
    try {
      await db.from('profiles').update({'emergency_name': _name.text.trim(), 'emergency_phone': phone}).eq('id', me);
      if (mounted) {
        toast(context, tx('Saved.'));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _bar(tx('Emergency contact')),
        body: !_loaded
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(16), children: [
                Text(tx('On a trip, tap "Alert my emergency contact" to send them a live link to your car by SMS.'), style: const TextStyle(color: AppColors.muted)),
                const SizedBox(height: 16),
                TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: plainInput(tx('Name'))),
                const SizedBox(height: 12),
                TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: plainInput(tx('Phone number'))),
                const SizedBox(height: 16),
                AppButton(tx('Save'), height: 50, loading: _busy, onPressed: _save),
              ]),
      );
}

// ============================================================================ favourite drivers

class FavouriteDriver {
  final String id;
  final String name;
  FavouriteDriver(this.id, this.name);

  static Future<List<FavouriteDriver>> load() async {
    try {
      final rows = await db.from('favourite_drivers').select('driver_id');
      final ids = [for (final r in rows as List) r['driver_id'] as String];
      if (ids.isEmpty) return [];
      final people = await db.from('profiles').select('id, full_name').inFilter('id', ids);
      return [for (final p in people as List) FavouriteDriver(p['id'] as String, ((p['full_name'] ?? '') as String).trim().isEmpty ? tx('Driver') : (p['full_name'] as String).trim())];
    } catch (_) {
      return [];
    }
  }

  static Future<bool> isFavourite(String driverId) async {
    try {
      final r = await db.from('favourite_drivers').select('driver_id').eq('driver_id', driverId).maybeSingle();
      return r != null;
    } catch (_) {
      return false;
    }
  }

  static Future<void> set(String driverId, bool on) async {
    if (on) {
      await db.from('favourite_drivers').upsert({'driver_id': driverId}, onConflict: 'user_id,driver_id');
    } else {
      await db.from('favourite_drivers').delete().eq('driver_id', driverId);
    }
  }
}

class FavouriteDriversScreen extends StatefulWidget {
  const FavouriteDriversScreen({super.key});

  @override
  State<FavouriteDriversScreen> createState() => _FavouriteDriversScreenState();
}

class _FavouriteDriversScreenState extends State<FavouriteDriversScreen> {
  List<FavouriteDriver>? _list;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await FavouriteDriver.load();
    if (mounted) setState(() => _list = l);
  }

  @override
  Widget build(BuildContext context) {
    final list = _list;
    return Scaffold(
      appBar: _bar(tx('Favourite drivers')),
      body: list == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(tx('When you hire a car you can ask for one of them. The office tries to send that driver.'), style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              if (list.isEmpty) EmptyText(tx('No favourites yet. After a trip, tap the heart on the booking.')),
              for (final d in list)
                AppCard(
                  child: Row(children: [
                    const Icon(Icons.favorite, color: AppColors.danger),
                    const SizedBox(width: 12),
                    Expanded(child: Text(d.name, style: const TextStyle(fontWeight: FontWeight.w800))),
                    IconButton(
                        onPressed: () async {
                          await FavouriteDriver.set(d.id, false);
                          _load();
                        },
                        icon: const Icon(Icons.close)),
                  ]),
                ),
            ]),
    );
  }
}

// ============================================================================ invite friends

class InviteFriendsScreen extends StatefulWidget {
  const InviteFriendsScreen({super.key});

  @override
  State<InviteFriendsScreen> createState() => _InviteFriendsScreenState();
}

class _InviteFriendsScreenState extends State<InviteFriendsScreen> {
  String? _code;
  int _joined = 0;
  final _theirs = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _theirs.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final code = (await db.rpc('my_referral_code')).toString();
      final me = appState.profile?.id;
      final rows = await db.from('referrals').select('referred_id').eq('referrer_id', me ?? '');
      if (mounted) setState(() {
            _code = code;
            _joined = (rows as List).length;
          });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _use() async {
    final c = _theirs.text.trim();
    if (c.isEmpty) return;
    setState(() => _busy = true);
    try {
      await db.rpc('use_referral_code', params: {'p_code': c});
      if (mounted) {
        _theirs.clear();
        toast(context, tx('Thank you. Your friend has been told.'));
      }
    } catch (e) {
      final m = '$e'.toLowerCase();
      if (mounted) {
        toast(
            context,
            m.contains('bad_code')
                ? tx('That code is not right.')
                : m.contains('own_code')
                    ? tx('That is your own code.')
                    : m.contains('already_used')
                        ? tx('You have already used a code.')
                        : m.contains('not_new')
                            ? tx('Codes are for new passengers who have not travelled yet.')
                            : friendlyError(e));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _bar(tx('Invite friends')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            child: Column(children: [
              Text(tx('YOUR CODE'), style: const TextStyle(fontSize: 12, color: AppColors.muted, fontWeight: FontWeight.w800, letterSpacing: 1)),
              const SizedBox(height: 6),
              Text(_code ?? '…', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: 4, color: AppColors.navy)),
              const SizedBox(height: 4),
              Text(txf('%s friends have joined with your code', ['$_joined']), style: const TextStyle(color: AppColors.muted)),
            ]),
          ),
          const SizedBox(height: 12),
          AppButton(tx('Share my code'), onPressed: _code == null
              ? null
              : () => Share.share('Travel with EfuLogistix: book a seat, hire a car or send goods in Mangochi. When you sign up, use my code $_code.')),
          const SizedBox(height: 24),
          FieldLabel(tx('HAVE A FRIEND\'S CODE?')),
          TextField(controller: _theirs, textCapitalization: TextCapitalization.characters, decoration: plainInput(tx('Their code'))),
          const SizedBox(height: 8),
          AppButton(tx('Use code'), kind: ButtonKind.outline, loading: _busy, onPressed: _use),
        ]),
      );
}

// ============================================================================ notification settings

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  final Set<String> _muted = {};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    () async {
      try {
        final r = await db.from('notify_prefs').select('muted').maybeSingle();
        if (r != null) _muted.addAll([for (final m in (r['muted'] as List)) '$m']);
      } catch (_) {}
      if (mounted) setState(() => _loaded = true);
    }();
  }

  Future<void> _toggle(String kind, bool on) async {
    final before = {..._muted};
    setState(() => on ? _muted.remove(kind) : _muted.add(kind));
    try {
      await db.from('notify_prefs').upsert({'muted': _muted.toList()}, onConflict: 'user_id');
    } catch (e) {
      if (mounted) {
        setState(() => _muted..clear()..addAll(before));
        toast(context, friendlyError(e));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _bar(tx('Notification settings')),
        body: !_loaded
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(16), children: [
                Text(tx('Choose what buzzes your phone. Everything still shows in Messages. Safety messages always come through.'),
                    style: const TextStyle(color: AppColors.muted)),
                const SizedBox(height: 8),
                SwitchListTile(
                  value: !_muted.contains('booking'),
                  onChanged: (v) => _toggle('booking', v),
                  title: Text(tx('Booking updates'), style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(tx('Car assigned, car arrived, trip done')),
                ),
                SwitchListTile(
                  value: !_muted.contains('chat'),
                  onChanged: (v) => _toggle('chat', v),
                  title: Text(tx('Chat messages'), style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(tx('Messages from your driver')),
                ),
              ]),
      );
}
