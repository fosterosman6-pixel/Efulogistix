import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../location.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../map_panel.dart';
import '../../widgets.dart';
import 'catalog.dart';
import '../../i18n.dart';
import '../../route_preview.dart';
import '../../ride_find.dart';

/// Book seats on a route at a set departure time.
class BookSeatScreen extends StatefulWidget {
  const BookSeatScreen({super.key});

  @override
  State<BookSeatScreen> createState() => _BookSeatScreenState();
}

class _BookSeatScreenState extends State<BookSeatScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = where, 1 = when, 2 = seats, payment and confirm
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  Map<String, (int, int)> _seats = {};
  int _count = 1;
  String _pay = 'cash';

  // "My location": the depot nearest to where the passenger is now
  bool _useMine = false;
  bool _finding = false;
  String? _locError;
  LatLng? _me;
  LatLng? _depotPoint;
  double? _toDepotKm;
  double? _toDepotMin;

  // depot to depot on a road that has depots: the depots the passenger gets on and off at
  DepotPick? _fromPick, _toPick;
  int? get _fp => _fromPick?.pos;
  int? get _tp => _toPick?.pos;
  Map<String, FareQuote> _quotes = {}; // vehicle type id -> fare between the two depots
  String? _rideCat; // vehicle filter on the rides list (null = all)
  bool _quoting = false;
  bool _showOther = false; // show the ordinary routes that are not on the depot road

  Map<String, dynamic>? _stopAt(int? pos) {
    for (final s in _cat.stops) {
      if (s['pos'] == pos) return s;
    }
    return null;
  }

  bool get _depotFlow => _fromPick != null && _toPick != null && _fp != _tp;
  bool get _depotMode => _fp != null && _tp != null && _route?.corridorId != null;
  double? get _depotFare => _quotes[_route?.categoryId]?.fare;
  double? get _depotKm => _quotes[_route?.categoryId]?.km;

  String get _routeLabel => _depotMode
      ? '${_stopAt(_fp)?['place_name']} → ${_stopAt(_tp)?['place_name']}'
      : '${_route?.fromName} → ${_route?.toName}';

  String _key(String n) => n.toLowerCase().replaceAll('depot', '').replaceAll(RegExp(r'\s+'), ' ').trim();

  /// Ordinary routes that are not already covered by the depot road (both ends are depots on it).
  List<RouteFare> get _otherPlain {
    final keys = {for (final s in _cat.stops) _key('${s['place_name']}')};
    return _cat.plainBookable.where((r) => !(keys.contains(_key(r.fromName)) && keys.contains(_key(r.toName)))).toList();
  }

  bool _forward() => _fp != null && _tp != null && _fp! < _tp!;

  /// Vehicles' through routes that go the right way for the chosen depots.
  List<RouteFare> get _wayRoutes {
    if (!_depotFlow || _cat.stops.isEmpty) return [];
    final firstName = _cat.stops.first['place_name'];
    final fwd = _forward();
    return _cat.throughBookable.where((r) => (r.fromName == firstName) == fwd).toList();
  }

  /// Every departure on the chosen day, for every vehicle going that way, soonest first.
  List<(RouteFare, Departure)> get _rides {
    final out = <(RouteFare, Departure)>[
      for (final r in _wayRoutes)
        if (_rideCat == null || r.categoryId == _rideCat)
          for (final d in _cat.departuresOf(r.id, _day))
            if (!_gone(d)) (r, d),
    ];
    out.sort((a, b) {
      final c = a.$2.leavesAt.compareTo(b.$2.leavesAt);
      return c != 0 ? c : (_cat.category(a.$1.categoryId)?.name ?? '').compareTo(_cat.category(b.$1.categoryId)?.name ?? '');
    });
    return out;
  }

  double? get _cheapest {
    final f = [for (final r in _wayRoutes) _quotes[r.categoryId]?.fare].whereType<double>().toList();
    return f.isEmpty ? null : f.reduce((a, b) => a < b ? a : b);
  }

  /// Gets the fares between the two chosen depots for every vehicle type.
  Future<void> _depotChanged() async {
    _route = null;
    _dep = null;
    _quotes = {};
    final fp = _fp, tp = _tp;
    if (fp == null || tp == null || fp == tp || _cat.throughBookable.isEmpty) {
      if (mounted) setState(() {});
      return;
    }
    final corridor = _cat.throughBookable.first.corridorId;
    if (corridor == null) return;
    setState(() {
      _quoting = true;
      _error = null;
    });
    try {
      final q = await loadQuotes(corridor, fp, tp);
      if (mounted && fp == _fp && tp == _tp) setState(() => _quotes = q);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
    if (mounted) setState(() => _quoting = false);
  }

  /// Search sheet: any place, My location or a pin, matched to the nearest depot.
  Future<void> _pickDepot({required bool boarding}) async {
    final picked = await showModalBottomSheet<DepotPick>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface100,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => DepotSearch(
        stops: _cat.stops.where((st) => boarding ? st['can_board'] == true : st['can_drop'] == true).toList(),
        near: Here.instance.point.value,
      ),
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (boarding) {
        _fromPick = picked;
        if (_tp == picked.pos) _toPick = null;
      } else {
        _toPick = picked;
        if (_fp == picked.pos) _fromPick = null;
      }
      _useMine = false;
      _route = null;
      _dep = null;
    });
    _depotChanged();
  }

  /// Picks the depot closest to the passenger as the place to get on.
  Future<void> _nearestDepot() async {
    setState(() {
      _finding = true;
      _locError = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      Map<String, dynamic>? best;
      var bestKm = double.infinity;
      for (final s in _cat.stops) {
        if (s['can_board'] != true) continue;
        final d = distanceKm(me, LatLng(toDouble(s['lat']), toDouble(s['lng'])));
        if (d < bestKm) {
          bestKm = d;
          best = s;
        }
      }
      final stop = best;
      if (stop == null) throw Exception('no depot');
      if (mounted) {
        setState(() {
          _fromPick = DepotPick(stop['pos'] as int, '${stop['place_name']}', from: tx('My location'), walkKm: bestKm);
          if (_tp == _fp) _toPick = null;
        });
        await _depotChanged();
      }
    } catch (_) {
      if (mounted) setState(() => _locError = tx('Could not find your location. Choose where you start instead.'));
    }
    if (mounted) setState(() => _finding = false);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
      await _loadSeats();
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadSeats() async {
    try {
      final s = await seatsOn(_day);
      if (mounted) setState(() => _seats = s);
    } catch (_) {}
  }

  /// Finds the depot closest to the passenger and how far it is by road.
  Future<void> _findNearest() async {
    setState(() {
      _finding = true;
      _locError = null;
      _useMine = true;
      _route = null;
      _dep = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      final names = _cat.fromNames;
      final pts = await Future.wait(names.map((n) async {
        final k = knownPlace(n);
        if (k != null) return k.point;
        try {
          final hits = await searchPlaces(n, near: me).timeout(const Duration(seconds: 8));
          return hits.isEmpty ? null : hits.first.point;
        } catch (_) {
          return null;
        }
      }));
      String? best;
      LatLng? bestPoint;
      var bestKm = double.infinity;
      for (var i = 0; i < names.length; i++) {
        final pt = pts[i];
        if (pt == null) continue;
        final d = distanceKm(me, pt);
        if (d < bestKm) {
          bestKm = d;
          best = names[i];
          bestPoint = pt;
        }
      }
      if (best == null || bestPoint == null) throw Exception('no depot found');
      final road = await getRoute(me, bestPoint);
      if (!mounted) return;
      setState(() {
        _me = me;
        _from = best;
        _depotPoint = bestPoint;
        _toDepotKm = road?.km ?? bestKm;
        _toDepotMin = road?.minutes ?? bestKm / 30 * 60;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _useMine = false;
          _locError = tx('Could not find your location. Choose where you start instead.');
        });
      }
    }
    if (mounted) setState(() => _finding = false);
  }

  int _leftFor(RouteFare? r, Departure d) {
    final s = _seats[d.id];
    if (s == null) return d.seats ?? _cat.category(r?.categoryId)?.seats ?? 0;
    return (s.$1 - s.$2).clamp(0, 999);
  }

  int _left(Departure d) => _leftFor(_route, d);

  bool _gone(Departure d) => d.leavingOn(_day).isBefore(DateTime.now().subtract(const Duration(minutes: 5)));

  /// A full departure: offer to tell the passenger when a seat opens.
  Future<void> _waitlist(Departure d) async {
    final ok = await confirmDialog(context, txf('%s is full', ['${d.time}']),
        txf('Join the waiting list for %s? We message you when a seat is free. You still have to book it.',
            [_count == 1 ? tx('1 seat') : txf('%s seats', ['$_count'])]),
        yes: tx('Join waiting list'));
    if (!ok) return;
    try {
      await db.rpc('join_waitlist', params: {'p_departure': d.id, 'p_day': isoDate(_day), 'p_seats': _count});
      if (mounted) toast(context, txf('You are on the waiting list for %s.', ['${d.time}']));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _book() async {
    final dep = _dep;
    if (dep == null || _route == null) {
      setState(() => _error = tx('Choose where to go and the departure time.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc(_depotMode ? 'book_depot' : 'book', params: {
        'p': {
          'kind': 'seat',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'seats': _count,
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
          if (_depotMode) 'from_pos': _fp,
          if (_depotMode) 'to_pos': _tp,
        }
      });
      if (!mounted) return;
      toast(context, tx('Booked. The office will assign a car and send you a message.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
      _loadSeats();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// One ride: time, vehicle, seats left and the fare.
  Widget _rideTile(RouteFare r, Departure d) {
    final left = _leftFor(r, d);
    final full = left <= 0;
    final on = d.id == _dep?.id;
    final cat = _cat.category(r.categoryId);
    final fare = _quotes[r.categoryId]?.fare ?? r.fare;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          if (full) {
            _waitlist(d);
            return;
          }
          setState(() {
            _route = r;
            _dep = d;
            if (_count > left) _count = left;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: on ? AppColors.lime100 : AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 2),
          ),
          child: Row(children: [
            SizedBox(width: 64, child: Text(d.time, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.navy))),
            if (cat != null) ...[VehicleTile(cat.name, width: 44), const SizedBox(width: 10)],
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(cat?.name ?? '', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.navy)),
                Text(full ? tx('Full · tap to join the waiting list') : txf('%s left', ['$left']),
                    style: TextStyle(fontSize: 12, color: full ? AppColors.danger : AppColors.muted)),
              ]),
            ),
            Text(money(fare), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.navy)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasDepots = _cat.throughBookable.isNotEmpty && _cat.stops.isNotEmpty;
    final others = hasDepots ? _otherPlain : _cat.plainBookable;
    final fromNames = {for (final r in others) r.fromName}.toList()..sort();
    final routes = others.where((r) => r.fromName == _from).toList();
    final category = _cat.category(_route?.categoryId);
    final deps = _route == null ? <Departure>[] : _cat.departuresOf(_route!.id, _day);
    final fare = _depotFare ?? (_route?.fare ?? 0);
    final total = fare * _count;
    final fs = _fromPick != null ? _stopAt(_fp) : null;
    final ts = _toPick != null ? _stopAt(_tp) : null;
    final fromPoint = fs != null
        ? LatLng(toDouble(fs['lat']), toDouble(fs['lng']))
        : (_useMine ? _depotPoint : knownPlace(_from ?? '')?.point);
    final toPoint = ts != null
        ? LatLng(toDouble(ts['lat']), toDouble(ts['lng']))
        : ((_route?.toLat != null && _route?.toLng != null) ? LatLng(_route!.toLat!, _route!.toLng!) : null);
    final canNext = _depotFlow ? (_quotes.isNotEmpty && _wayRoutes.isNotEmpty) : _route != null;
    final quote = _quotes[_route?.categoryId];
    final rides = _depotFlow ? _rides : <(RouteFare, Departure)>[];
    final catIds = {for (final r in _wayRoutes) if (r.categoryId != null) r.categoryId!};
    return Scaffold(
      appBar: navyBar('Book a seat'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : MapPanel(
              wide: _step == 0 && _route == null,
              map: RouteMapView(from: fromPoint, fromName: fs != null ? '${fs['place_name']}' : '${_from ?? ''}', to: toPoint, toName: ts != null ? '${ts['place_name']}' : (_route?.toName ?? '')),
              children: [
              if (_cat.bookableRoutes.isEmpty)
                EmptyText(tx('No routes with a timetable yet. Please call the office.'))
              else ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 2),
                  child: Text(
                      (_step == 0 ? tx('Step 1 of 3 · Where to?') : _step == 1 ? tx('Step 2 of 3 · Pick a ride') : tx('Step 3 of 3 · Confirm')).toUpperCase(),
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
                ),
                if (_step == 0) ...[
                if (hasDepots) ...[
                  DepotField(
                    label: 'FROM',
                    verb: 'Board at',
                    pick: _fromPick,
                    onTap: () => _pickDepot(boarding: true),
                    extras: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Wrap(spacing: 8, runSpacing: 8, children: [
                          ChoiceChipButton('📍 ${tx('My location')}', selected: false, onTap: _finding ? () {} : _nearestDepot),
                        ]),
                      ),
                      if (_finding) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(tx('Finding the nearest depot…'))),
                      if (_locError != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(_locError!, style: const TextStyle(color: AppColors.danger))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  DepotField(label: 'TO', verb: 'Get off at', pick: _toPick, onTap: () => _pickDepot(boarding: false)),
                  if (_quoting) const Padding(padding: EdgeInsets.only(top: 10), child: LinearProgressIndicator()),
                  if (_depotFlow && !_quoting && _quotes.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    if (_wayRoutes.isEmpty)
                      AppCard(child: Text(tx('No vehicles go that way yet. Please call the office.')))
                    else
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text('${tx('Estimated fare')} · ${kmText(_quotes.values.first.km)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          ),
                          Text(_cheapest == null ? '' : txf('from %s', [money(_cheapest)]), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                        ]),
                      ),
                  ],
                  if (_depotFlow && _toPick != null && _fromPick != null && _fp == _tp)
                    Padding(padding: const EdgeInsets.only(top: 8), child: Text(tx('Choose two different depots.'), style: const TextStyle(color: AppColors.danger))),
                  if (_otherPlain.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton(
                        onPressed: () => setState(() => _showOther = !_showOther),
                        child: Text(_showOther ? tx('Hide other routes') : tx('Other routes')),
                      ),
                    ),
                  ],
                ],
                if ((!hasDepots || _showOther) && others.isNotEmpty) ...[
                formCard(
                  'FROM',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    if (!hasDepots) ChoiceChipButton('📍 ${tx('My location')}', selected: _useMine, onTap: _finding ? () {} : _findNearest),
                    for (final f in fromNames)
                      ChoiceChipButton(f, selected: !_useMine && f == _from, onTap: () => setState(() {
                            _useMine = false;
                            _from = f;
                            _route = null;
                            _dep = null;
                            _fromPick = _toPick = null;
                            _quotes = {};
                          })),
                  ]),
                ),
                if (!hasDepots && (_finding || _locError != null || (_useMine && _depotPoint != null))) ...[
                  const SizedBox(height: 10),
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      if (_finding)
                        Row(children: [
                          const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                          const SizedBox(width: 10),
                          Expanded(child: Text(tx('Finding the nearest depot…'))),
                        ])
                      else if (_locError != null)
                        Text(_locError!, style: const TextStyle(color: AppColors.danger))
                      else ...[
                        Text(txf('Nearest depot: %s', ['$_from']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        const SizedBox(height: 2),
                        Text(txf('%s from you · about %s by road', [kmText(_toDepotKm), durationText(_toDepotMin ?? 0)]),
                            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ],
                    ]),
                  ),
                ],
                const SizedBox(height: 10),
                formCard(
                  'TO',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final r in routes)
                      ChoiceChipButton(
                        '${r.toName} · ${money(r.fare)}${_cat.category(r.categoryId) != null ? ' · ${_cat.category(r.categoryId)!.name}' : ''}',
                        selected: r.id == _route?.id,
                        onTap: () => setState(() {
                          _route = r;
                          _dep = null;
                          _fromPick = _toPick = null;
                          _quotes = {};
                        }),
                      ),
                  ]),
                ),
                ],
                const SizedBox(height: 12),
                AppButton(tx(_depotFlow ? 'See rides' : 'Next'), onPressed: canNext ? () => setState(() {
                      _step = 1;
                      _rideCat = null;
                    }) : null),
                ],
                if (_step == 1) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(_depotFlow ? '${_fromPick!.name} → ${_toPick!.name}\n${kmText(_quotes.values.isEmpty ? null : _quotes.values.first.km)}' : _routeLabel,
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      const SizedBox(height: 10),
                formCard(
                  'DAY',
                  DayChips(
                    value: _day,
                    onChanged: (d) {
                      setState(() {
                        _day = d;
                        _dep = null;
                        if (_depotFlow) _route = null;
                      });
                      _loadSeats();
                    },
                  ),
                ),
                if (_depotFlow) ...[
                  if (catIds.length > 1) ...[
                    const SizedBox(height: 10),
                    formCard(
                      'VEHICLE',
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        ChoiceChipButton(tx('All'), selected: _rideCat == null, onTap: () => setState(() { _rideCat = null; _dep = null; _route = null; })),
                        for (final id in catIds)
                          ChoiceChipButton(_cat.category(id)?.name ?? '', selected: _rideCat == id, onTap: () => setState(() { _rideCat = id; _dep = null; _route = null; })),
                      ]),
                    ),
                  ],
                  const SizedBox(height: 10),
                  SectionTitle(tx('RIDES')),
                  if (rides.isEmpty) EmptyText(tx('No departure on this day.')),
                  for (final rd in rides) _rideTile(rd.$1, rd.$2),
                ] else if (_route != null) ...[
                  const SizedBox(height: 10),
                  formCard(
                    'LEAVES AT',
                    deps.isEmpty
                        ? Text(tx('No departure on this day.'), style: TextStyle(color: AppColors.muted))
                        : Wrap(spacing: 8, runSpacing: 8, children: [for (final d in deps) _depTile(d)]),
                  ),
                ],
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: _dep == null ? null : () => setState(() => _step = 2)),
                ],
                if (_route != null && _step == 2) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text('$_routeLabel\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}',
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      if (_depotMode && (_fromPick?.from != null || _toPick?.from != null)) ...[
                        const SizedBox(height: 8),
                        if (_fromPick?.from != null)
                          Text(txf('Board at %s · %s from %s', [_fromPick!.name, _fromPick!.walkText, _fromPick!.from!]), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                        if (_toPick?.from != null)
                          Text(txf('Get off at %s · %s from %s', [_toPick!.name, _toPick!.walkText, _toPick!.from!]), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ],
                      const SizedBox(height: 10),
                  Row(children: [
                    if (category != null) ...[VehicleTile(category.name, width: 56), const SizedBox(width: 10)],
                    Expanded(
                      child: Counter(
                        label: tx('SEATS') + (category != null ? ' · ${category.name}' : ''),
                        value: _count,
                        max: _dep == null ? null : (_left(_dep!) < 1 ? 1 : _left(_dep!)),
                        onChanged: (v) => setState(() => _count = v < 1 ? 1 : v),
                      ),
                    ),
                  ]),
                  if (quote != null) ...[
                    const SizedBox(height: 10),
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        FieldLabel(tx('HOW THE FARE IS WORKED OUT')),
                        const SizedBox(height: 4),
                        Text(quote.working, style: const TextStyle(fontSize: 13, height: 1.5)),
                        Text(tx('Walking to and from the depot is free.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      ]),
                    ),
                  ],
                  const SizedBox(height: 10),
                  PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                  TotalBox('TOTAL', money(total), '$_count × ${money(fare)} · ${tx('no fee if you cancel')}'),
                ],
                if (_step == 2) ...[
                  ErrorLine(_error),
                  const SizedBox(height: 8),
                  AppButton(_count == 1 ? tx('Book 1 seat') : txf('Book %s seats', ['${_count}']),
                      loading: _busy, onPressed: _dep == null ? null : _book),
                ],
              ],
            ]),
    );
  }

  Widget _depTile(Departure d) {
    final left = _left(d);
    final gone = _gone(d);
    final full = left <= 0;
    final on = d.id == _dep?.id;
    final disabled = gone || full;
    return Semantics(
      button: true,
      selected: on,
      label: '${d.time}, ${gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['$left'])}',
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: gone ? null : (full ? () => _waitlist(d) : () => setState(() {
              _dep = d;
              if (_count > left) _count = left;
            })),
        child: Container(
          width: 84,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.navy : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 1.5),
          ),
          child: Column(children: [
            Text(d.time,
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: on ? Colors.white : (disabled ? AppColors.muted : AppColors.ink))),
            Text(gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['${left}']),
                style: TextStyle(fontSize: 11, color: on ? AppColors.lime : (disabled ? AppColors.danger : AppColors.muted))),
          ]),
        ),
      ),
    );
  }
}
