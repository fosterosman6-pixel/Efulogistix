import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../location.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../map_panel.dart';
import '../../widgets.dart';
import 'catalog.dart';
import '../../i18n.dart';
import '../../route_preview.dart';

/// Book seats on a route at a set departure time.
class BookSeatScreen extends StatefulWidget {
  const BookSeatScreen({super.key});

  @override
  State<BookSeatScreen> createState() => _BookSeatScreenState();
}

class _BookSeatScreenState extends State<BookSeatScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = where, 1 = when, 2 = seats, payment and confirm
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  Map<String, (int, int)> _seats = {};
  int _count = 1;
  String _pay = 'cash';

  // "My location": the depot nearest to where the passenger is now
  bool _useMine = false;
  bool _finding = false;
  String? _locError;
  LatLng? _me;
  LatLng? _depotPoint;
  double? _toDepotKm;
  double? _toDepotMin;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
      await _loadSeats();
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadSeats() async {
    try {
      final s = await seatsOn(_day);
      if (mounted) setState(() => _seats = s);
    } catch (_) {}
  }

  /// Finds the depot closest to the passenger and how far it is by road.
  Future<void> _findNearest() async {
    setState(() {
      _finding = true;
      _locError = null;
      _useMine = true;
      _route = null;
      _dep = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      final names = _cat.fromNames;
      final pts = await Future.wait(names.map((n) async {
        final k = knownPlace(n);
        if (k != null) return k.point;
        try {
          final hits = await searchPlaces(n, near: me).timeout(const Duration(seconds: 8));
          return hits.isEmpty ? null : hits.first.point;
        } catch (_) {
          return null;
        }
      }));
      String? best;
      LatLng? bestPoint;
      var bestKm = double.infinity;
      for (var i = 0; i < names.length; i++) {
        final pt = pts[i];
        if (pt == null) continue;
        final d = distanceKm(me, pt);
        if (d < bestKm) {
          bestKm = d;
          best = names[i];
          bestPoint = pt;
        }
      }
      if (best == null || bestPoint == null) throw Exception('no depot found');
      final road = await getRoute(me, bestPoint);
      if (!mounted) return;
      setState(() {
        _me = me;
        _from = best;
        _depotPoint = bestPoint;
        _toDepotKm = road?.km ?? bestKm;
        _toDepotMin = road?.minutes ?? bestKm / 30 * 60;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _useMine = false;
          _locError = tx('Could not find your location. Choose where you start instead.');
        });
      }
    }
    if (mounted) setState(() => _finding = false);
  }

  int _left(Departure d) {
    final s = _seats[d.id];
    if (s == null) return d.seats ?? _cat.category(_route?.categoryId)?.seats ?? 0;
    return (s.$1 - s.$2).clamp(0, 999);
  }

  bool _gone(Departure d) => d.leavingOn(_day).isBefore(DateTime.now().subtract(const Duration(minutes: 5)));

  /// A full departure: offer to tell the passenger when a seat opens.
  Future<void> _waitlist(Departure d) async {
    final ok = await confirmDialog(context, txf('%s is full', ['${d.time}']),
        txf('Join the waiting list for %s? We message you when a seat is free. You still have to book it.',
            [_count == 1 ? tx('1 seat') : txf('%s seats', ['$_count'])]),
        yes: tx('Join waiting list'));
    if (!ok) return;
    try {
      await db.rpc('join_waitlist', params: {'p_departure': d.id, 'p_day': isoDate(_day), 'p_seats': _count});
      if (mounted) toast(context, txf('You are on the waiting list for %s.', ['${d.time}']));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _book() async {
    final dep = _dep;
    if (dep == null || _route == null) {
      setState(() => _error = tx('Choose where to go and the departure time.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('book', params: {
        'p': {
          'kind': 'seat',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'seats': _count,
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
        }
      });
      if (!mounted) return;
      toast(context, tx('Booked. The office will assign a car and send you a message.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
      _loadSeats();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final routes = _cat.bookableRoutes.where((r) => r.fromName == _from).toList();
    final category = _cat.category(_route?.categoryId);
    final deps = _route == null ? <Departure>[] : _cat.departuresOf(_route!.id, _day);
    final total = (_route?.fare ?? 0) * _count;
    final fromPoint = _useMine ? _depotPoint : knownPlace(_from ?? '')?.point;
    final toPoint = (_route?.toLat != null && _route?.toLng != null) ? LatLng(_route!.toLat!, _route!.toLng!) : null;
    return Scaffold(
      appBar: navyBar('Book a seat'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : MapPanel(
              wide: _step == 0 && _route == null,
              map: RouteMapView(from: fromPoint, fromName: '${_from ?? ''}', to: toPoint, toName: _route?.toName ?? ''),
              children: [
              if (_cat.bookableRoutes.isEmpty)
                EmptyText(tx('No routes with a timetable yet. Please call the office.'))
              else ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 2),
                  child: Text(
                      (_step == 0 ? tx('Step 1 of 3 · Where to?') : _step == 1 ? tx('Step 2 of 3 · When?') : tx('Step 3 of 3 · Confirm')).toUpperCase(),
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
                ),
                if (_step == 0) ...[
                formCard(
                  'FROM',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    ChoiceChipButton('📍 ${tx('My location')}', selected: _useMine, onTap: _finding ? () {} : _findNearest),
                    for (final f in _cat.fromNames)
                      ChoiceChipButton(f, selected: !_useMine && f == _from, onTap: () => setState(() {
                            _useMine = false;
                            _from = f;
                            _route = null;
                            _dep = null;
                          })),
                  ]),
                ),
                if (_finding || _locError != null || (_useMine && _depotPoint != null)) ...[
                  const SizedBox(height: 10),
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      if (_finding)
                        Row(children: [
                          const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                          const SizedBox(width: 10),
                          Expanded(child: Text(tx('Finding the nearest depot…'))),
                        ])
                      else if (_locError != null)
                        Text(_locError!, style: const TextStyle(color: AppColors.danger))
                      else ...[
                        Text(txf('Nearest depot: %s', ['$_from']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        const SizedBox(height: 2),
                        Text(txf('%s from you · about %s by road', [kmText(_toDepotKm), durationText(_toDepotMin ?? 0)]),
                            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ],
                    ]),
                  ),
                ],
                const SizedBox(height: 10),
                formCard(
                  'TO',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final r in routes)
                      ChoiceChipButton(
                        '${r.toName} · ${money(r.fare)}${_cat.category(r.categoryId) != null ? ' · ${_cat.category(r.categoryId)!.name}' : ''}',
                        selected: r.id == _route?.id,
                        onTap: () => setState(() {
                          _route = r;
                          _dep = null;
                        }),
                      ),
                  ]),
                ),
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: _route == null ? null : () => setState(() => _step = 1)),
                ],
                if (_step == 1) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(_step == 1
                                    ? '${_route?.fromName} → ${_route?.toName}'
                                    : '${_route?.fromName} → ${_route?.toName}\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}',
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      const SizedBox(height: 10),
                formCard(
                  'DAY',
                  DayChips(
                    value: _day,
                    onChanged: (d) {
                      setState(() {
                        _day = d;
                        _dep = null;
                      });
                      _loadSeats();
                    },
                  ),
                ),
                if (_route != null) ...[
                  const SizedBox(height: 10),
                  formCard(
                    'LEAVES AT',
                    deps.isEmpty
                        ? Text(tx('No departure on this day.'), style: TextStyle(color: AppColors.muted))
                        : Wrap(spacing: 8, runSpacing: 8, children: [for (final d in deps) _depTile(d)]),
                  ),
                ],
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: _dep == null ? null : () => setState(() => _step = 2)),
                ],
                if (_route != null && _step == 2) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(_step == 1
                                    ? '${_route?.fromName} → ${_route?.toName}'
                                    : '${_route?.fromName} → ${_route?.toName}\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}',
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      const SizedBox(height: 10),
                  Row(children: [
                    if (category != null) ...[VehicleTile(category.name, width: 56), const SizedBox(width: 10)],
                    Expanded(
                      child: Counter(
                        label: tx('SEATS') + (category != null ? ' · ${category.name}' : ''),
                        value: _count,
                        max: _dep == null ? null : (_left(_dep!) < 1 ? 1 : _left(_dep!)),
                        onChanged: (v) => setState(() => _count = v < 1 ? 1 : v),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                  TotalBox('TOTAL', money(total), '$_count × ${money(_route!.fare)} · ${tx('no fee if you cancel')}'),
                ],
                if (_step == 2) ...[
                  ErrorLine(_error),
                  const SizedBox(height: 8),
                  AppButton(_count == 1 ? tx('Book 1 seat') : txf('Book %s seats', ['${_count}']),
                      loading: _busy, onPressed: _dep == null ? null : _book),
                ],
              ],
            ]),
    );
  }

  Widget _depTile(Departure d) {
    final left = _left(d);
    final gone = _gone(d);
    final full = left <= 0;
    final on = d.id == _dep?.id;
    final disabled = gone || full;
    return Semantics(
      button: true,
      selected: on,
      label: '${d.time}, ${gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['$left'])}',
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: gone ? null : (full ? () => _waitlist(d) : () => setState(() {
              _dep = d;
              if (_count > left) _count = left;
            })),
        child: Container(
          width: 84,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.navy : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 1.5),
          ),
          child: Column(children: [
            Text(d.time,
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: on ? Colors.white : (disabled ? AppColors.muted : AppColors.ink))),
            Text(gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['${left}']),
                style: TextStyle(fontSize: 11, color: on ? AppColors.lime : (disabled ? AppColors.danger : AppColors.muted))),
          ]),
        ),
      ),
    );
  }
}
