import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'catalog.dart';

/// Book seats on a route at a set departure time.
class BookSeatScreen extends StatefulWidget {
  const BookSeatScreen({super.key});

  @override
  State<BookSeatScreen> createState() => _BookSeatScreenState();
}

class _BookSeatScreenState extends State<BookSeatScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  bool _loading = true;
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  Map<String, (int, int)> _seats = {};
  int _count = 1;
  String _pay = 'cash';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
      await _loadSeats();
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadSeats() async {
    try {
      final s = await seatsOn(_day);
      if (mounted) setState(() => _seats = s);
    } catch (_) {}
  }

  int _left(Departure d) {
    final s = _seats[d.id];
    if (s == null) return d.seats ?? _cat.category(_route?.categoryId)?.seats ?? 0;
    return (s.$1 - s.$2).clamp(0, 999);
  }

  bool _gone(Departure d) => d.leavingOn(_day).isBefore(DateTime.now().subtract(const Duration(minutes: 5)));

  /// A full departure: offer to tell the passenger when a seat opens.
  Future<void> _waitlist(Departure d) async {
    final ok = await confirmDialog(context, '${d.time} is full',
        'Join the waiting list for $_count ${_count == 1 ? 'seat' : 'seats'}? We message you when a seat is free. You still have to book it.',
        yes: 'Join waiting list');
    if (!ok) return;
    try {
      await db.rpc('join_waitlist', params: {'p_departure': d.id, 'p_day': isoDate(_day), 'p_seats': _count});
      if (mounted) toast(context, 'You are on the waiting list for ${d.time}.');
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _book() async {
    final dep = _dep;
    if (dep == null || _route == null) {
      setState(() => _error = 'Choose where to go and the departure time.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('book', params: {
        'p': {
          'kind': 'seat',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'seats': _count,
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
        }
      });
      if (!mounted) return;
      toast(context, 'Booked. The office will assign a car and send you a message.');
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
      _loadSeats();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final routes = _cat.bookableRoutes.where((r) => r.fromName == _from).toList();
    final category = _cat.category(_route?.categoryId);
    final deps = _route == null ? <Departure>[] : _cat.departuresOf(_route!.id, _day);
    final total = (_route?.fare ?? 0) * _count;
    return Scaffold(
      appBar: navyBar('Book a seat'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              if (_cat.bookableRoutes.isEmpty)
                const EmptyText('No routes with a timetable yet. Please call the office.')
              else ...[
                formCard(
                  'FROM',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final f in _cat.fromNames)
                      ChoiceChipButton(f, selected: f == _from, onTap: () => setState(() {
                            _from = f;
                            _route = null;
                            _dep = null;
                          })),
                  ]),
                ),
                const SizedBox(height: 10),
                formCard(
                  'TO',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final r in routes)
                      ChoiceChipButton(
                        '${r.toName} · ${money(r.fare)}${_cat.category(r.categoryId) != null ? ' · ${_cat.category(r.categoryId)!.name}' : ''}',
                        selected: r.id == _route?.id,
                        onTap: () => setState(() {
                          _route = r;
                          _dep = null;
                        }),
                      ),
                  ]),
                ),
                const SizedBox(height: 10),
                formCard(
                  'DAY',
                  DayChips(
                    value: _day,
                    onChanged: (d) {
                      setState(() {
                        _day = d;
                        _dep = null;
                      });
                      _loadSeats();
                    },
                  ),
                ),
                if (_route != null) ...[
                  const SizedBox(height: 10),
                  formCard(
                    'LEAVES AT',
                    deps.isEmpty
                        ? const Text('No departure on this day.', style: TextStyle(color: AppColors.muted))
                        : Wrap(spacing: 8, runSpacing: 8, children: [for (final d in deps) _depTile(d)]),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    if (category != null) ...[VehicleTile(category.name, width: 56), const SizedBox(width: 10)],
                    Expanded(
                      child: Counter(
                        label: 'SEATS${category != null ? ' · ${category.name}' : ''}',
                        value: _count,
                        onChanged: (v) => setState(() => _count = v < 1 ? 1 : v),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                  TotalBox('TOTAL', money(total), '$_count × ${money(_route!.fare)} · no fee if you cancel'),
                ],
                ErrorLine(_error),
                const SizedBox(height: 8),
                AppButton(_count == 1 ? 'Book 1 seat' : 'Book $_count seats',
                    loading: _busy, onPressed: _dep == null ? null : _book),
              ],
            ]),
    );
  }

  Widget _depTile(Departure d) {
    final left = _left(d);
    final gone = _gone(d);
    final full = left <= 0;
    final on = d.id == _dep?.id;
    final disabled = gone || full;
    return Semantics(
      button: true,
      selected: on,
      label: '${d.time}, ${gone ? 'left already' : full ? 'full' : '$left seats left'}',
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: gone ? null : (full ? () => _waitlist(d) : () => setState(() => _dep = d)),
        child: Container(
          width: 84,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.navy : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 1.5),
          ),
          child: Column(children: [
            Text(d.time,
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: on ? Colors.white : (disabled ? AppColors.muted : AppColors.ink))),
            Text(gone ? 'Left' : full ? 'Full' : '$left left',
                style: TextStyle(fontSize: 11, color: on ? AppColors.lime : (disabled ? AppColors.danger : AppColors.muted))),
          ]),
        ),
      ),
    );
  }
}
