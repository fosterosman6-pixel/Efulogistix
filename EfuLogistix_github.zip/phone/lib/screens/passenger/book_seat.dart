import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../location.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../map_panel.dart';
import '../../widgets.dart';
import 'catalog.dart';
import '../../i18n.dart';
import '../../route_preview.dart';

/// Book seats on a route at a set departure time.
class BookSeatScreen extends StatefulWidget {
  const BookSeatScreen({super.key});

  @override
  State<BookSeatScreen> createState() => _BookSeatScreenState();
}

class _BookSeatScreenState extends State<BookSeatScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = where, 1 = when, 2 = seats, payment and confirm
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  Map<String, (int, int)> _seats = {};
  int _count = 1;
  String _pay = 'cash';

  // "My location": the depot nearest to where the passenger is now
  bool _useMine = false;
  bool _finding = false;
  String? _locError;
  LatLng? _me;
  LatLng? _depotPoint;
  double? _toDepotKm;
  double? _toDepotMin;

  // depot to depot on a road that has depots
  int? _fp, _tp; // positions of the depot where the passenger gets on and off
  String? _depotCat; // vehicle type chosen
  final Map<String, Map<String, (double, double)>> _depotFares = {}; // category -> 'from-to' -> (km, fare)

  Map<String, dynamic>? _stopAt(int? pos) {
    for (final s in _cat.stops) {
      if (s['pos'] == pos) return s;
    }
    return null;
  }

  bool get _depotMode => _fp != null && _tp != null && _route?.corridorId != null;

  (double, double)? get _depotPair {
    final cat = _depotCat;
    if (!_depotMode || cat == null) return null;
    final byPair = _depotFares[cat];
    if (byPair == null) return null;
    return byPair['${_fp}-${_tp}'];
  }

  double? get _depotFare => _depotPair?.$2;
  double? get _depotKm => _depotPair?.$1;

  String get _routeLabel => _depotMode
      ? '${_stopAt(_fp)?['place_name']} → ${_stopAt(_tp)?['place_name']}'
      : '${_route?.fromName} → ${_route?.toName}';

  /// Finds the through route (right vehicle type and direction) and the fare for the chosen depots.
  Future<void> _depotChanged() async {
    final cat = _depotCat;
    final fp = _fp;
    final tp = _tp;
    _route = null;
    _dep = null;
    if (cat == null || fp == null || tp == null || fp == tp) {
      if (mounted) setState(() {});
      return;
    }
    final firstName = _cat.stops.isEmpty ? null : _cat.stops.first['place_name'];
    final forward = fp < tp;
    RouteFare? r;
    for (final x in _cat.throughBookable) {
      if (x.categoryId == cat && (x.fromName == firstName) == forward) r = x;
    }
    if (r == null) {
      if (mounted) setState(() => _error = tx('No departures for that direction yet.'));
      return;
    }
    if (!_depotFares.containsKey(cat)) {
      try {
        final rows = await db.rpc('corridor_fares', params: {'p_corridor': r.corridorId, 'p_category': cat});
        final m = <String, (double, double)>{};
        if (rows is List) {
          for (final x in rows.whereType<Map>()) {
            m['${x['from_pos']}-${x['to_pos']}'] = (toDouble(x['km']), toDouble(x['fare']));
          }
        }
        _depotFares[cat] = m;
      } catch (e) {
        if (mounted) setState(() => _error = friendlyError(e));
        return;
      }
    }
    if (mounted) {
      setState(() {
        _error = null;
        _route = r;
        _useMine = false;
      });
    }
  }

  Widget _pickerField(String? value, String hint, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          decoration: BoxDecoration(border: Border.all(color: AppColors.line, width: 1.5), borderRadius: BorderRadius.circular(8)),
          child: Row(children: [
            const Icon(Icons.search, color: AppColors.muted),
            const SizedBox(width: 10),
            Expanded(
              child: Text(value ?? hint,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 16, fontWeight: value == null ? FontWeight.w500 : FontWeight.w800, color: value == null ? AppColors.muted : AppColors.ink)),
            ),
          ]),
        ),
      );

  /// Opens a search sheet: type a depot or any place; a place that is not a depot is matched to the nearest depot.
  Future<void> _pickDepot({required bool boarding}) async {
    final picked = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface100,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => DepotSearch(
        stops: _cat.stops.where((st) => boarding ? st['can_board'] == true : (st['can_drop'] == true && st['pos'] != _fp)).toList(),
        near: Here.instance.point.value,
      ),
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (boarding) {
        _fp = picked;
        if (_tp == picked) _tp = null;
      } else {
        _tp = picked;
      }
    });
    _depotChanged();
  }

  /// Picks the depot closest to the passenger as the place to get on.
  Future<void> _nearestDepot() async {
    setState(() {
      _finding = true;
      _locError = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      int? best;
      var bestKm = double.infinity;
      for (final s in _cat.stops) {
        if (s['can_board'] != true) continue;
        final d = distanceKm(me, LatLng(toDouble(s['lat']), toDouble(s['lng'])));
        if (d < bestKm) {
          bestKm = d;
          best = s['pos'] as int;
        }
      }
      if (best == null) throw Exception('no depot');
      if (mounted) {
        setState(() {
          _fp = best;
          if (_tp == best) _tp = null;
        });
        await _depotChanged();
      }
    } catch (_) {
      if (mounted) setState(() => _locError = tx('Could not find your location. Choose where you start instead.'));
    }
    if (mounted) setState(() => _finding = false);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
      await _loadSeats();
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadSeats() async {
    try {
      final s = await seatsOn(_day);
      if (mounted) setState(() => _seats = s);
    } catch (_) {}
  }

  /// Finds the depot closest to the passenger and how far it is by road.
  Future<void> _findNearest() async {
    setState(() {
      _finding = true;
      _locError = null;
      _useMine = true;
      _route = null;
      _dep = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      final names = _cat.fromNames;
      final pts = await Future.wait(names.map((n) async {
        final k = knownPlace(n);
        if (k != null) return k.point;
        try {
          final hits = await searchPlaces(n, near: me).timeout(const Duration(seconds: 8));
          return hits.isEmpty ? null : hits.first.point;
        } catch (_) {
          return null;
        }
      }));
      String? best;
      LatLng? bestPoint;
      var bestKm = double.infinity;
      for (var i = 0; i < names.length; i++) {
        final pt = pts[i];
        if (pt == null) continue;
        final d = distanceKm(me, pt);
        if (d < bestKm) {
          bestKm = d;
          best = names[i];
          bestPoint = pt;
        }
      }
      if (best == null || bestPoint == null) throw Exception('no depot found');
      final road = await getRoute(me, bestPoint);
      if (!mounted) return;
      setState(() {
        _me = me;
        _from = best;
        _depotPoint = bestPoint;
        _toDepotKm = road?.km ?? bestKm;
        _toDepotMin = road?.minutes ?? bestKm / 30 * 60;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _useMine = false;
          _locError = tx('Could not find your location. Choose where you start instead.');
        });
      }
    }
    if (mounted) setState(() => _finding = false);
  }

  int _left(Departure d) {
    final s = _seats[d.id];
    if (s == null) return d.seats ?? _cat.category(_route?.categoryId)?.seats ?? 0;
    return (s.$1 - s.$2).clamp(0, 999);
  }

  bool _gone(Departure d) => d.leavingOn(_day).isBefore(DateTime.now().subtract(const Duration(minutes: 5)));

  /// A full departure: offer to tell the passenger when a seat opens.
  Future<void> _waitlist(Departure d) async {
    final ok = await confirmDialog(context, txf('%s is full', ['${d.time}']),
        txf('Join the waiting list for %s? We message you when a seat is free. You still have to book it.',
            [_count == 1 ? tx('1 seat') : txf('%s seats', ['$_count'])]),
        yes: tx('Join waiting list'));
    if (!ok) return;
    try {
      await db.rpc('join_waitlist', params: {'p_departure': d.id, 'p_day': isoDate(_day), 'p_seats': _count});
      if (mounted) toast(context, txf('You are on the waiting list for %s.', ['${d.time}']));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _book() async {
    final dep = _dep;
    if (dep == null || _route == null) {
      setState(() => _error = tx('Choose where to go and the departure time.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc(_depotMode ? 'book_depot' : 'book', params: {
        'p': {
          'kind': 'seat',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'seats': _count,
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
          if (_depotMode) 'from_pos': _fp,
          if (_depotMode) 'to_pos': _tp,
        }
      });
      if (!mounted) return;
      toast(context, tx('Booked. The office will assign a car and send you a message.'));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
      _loadSeats();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final routes = _cat.plainBookable.where((r) => r.fromName == _from).toList();
    final hasDepots = _cat.throughBookable.isNotEmpty && _cat.stops.isNotEmpty;
    final category = _cat.category(_route?.categoryId);
    final deps = _route == null ? <Departure>[] : _cat.departuresOf(_route!.id, _day);
    final fare = _depotFare ?? (_route?.fare ?? 0);
    final total = fare * _count;
    final fs = _depotMode ? _stopAt(_fp) : null;
    final ts = _depotMode ? _stopAt(_tp) : null;
    final fromPoint = fs != null
        ? LatLng(toDouble(fs['lat']), toDouble(fs['lng']))
        : (_useMine ? _depotPoint : knownPlace(_from ?? '')?.point);
    final toPoint = ts != null
        ? LatLng(toDouble(ts['lat']), toDouble(ts['lng']))
        : ((_route?.toLat != null && _route?.toLng != null) ? LatLng(_route!.toLat!, _route!.toLng!) : null);
    return Scaffold(
      appBar: navyBar('Book a seat'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : MapPanel(
              wide: _step == 0 && _route == null,
              map: RouteMapView(from: fromPoint, fromName: fs != null ? '${fs['place_name']}' : '${_from ?? ''}', to: toPoint, toName: ts != null ? '${ts['place_name']}' : (_route?.toName ?? '')),
              children: [
              if (_cat.bookableRoutes.isEmpty)
                EmptyText(tx('No routes with a timetable yet. Please call the office.'))
              else ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 2),
                  child: Text(
                      (_step == 0 ? tx('Step 1 of 3 · Where to?') : _step == 1 ? tx('Step 2 of 3 · When?') : tx('Step 3 of 3 · Confirm')).toUpperCase(),
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
                ),
                if (_step == 0) ...[
                if (hasDepots) ...[
                  formCard(
                    'VEHICLE',
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      // every passenger vehicle on this road stays in the list; one without a timetable yet says so when tapped
                      for (final id in {for (final r in _cat.routes) if (r.corridorId != null && r.through && r.active && r.categoryId != null) r.categoryId!})
                        ChoiceChipButton(_cat.category(id)?.name ?? '', selected: id == _depotCat, onTap: () {
                          if (!_cat.throughBookable.any((r) => r.categoryId == id)) {
                            toast(context, tx('No times for that vehicle yet. Try another vehicle.'));
                            return;
                          }
                          setState(() => _depotCat = id);
                          _depotChanged();
                        }),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  formCard(
                    'GET ON AT',
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        ChoiceChipButton('📍 ${tx('Nearest depot')}', selected: false, onTap: _finding ? () {} : _nearestDepot),
                      ]),
                      const SizedBox(height: 8),
                      _pickerField(_stopAt(_fp)?['place_name'] as String?, tx('Search a depot or place'), () => _pickDepot(boarding: true)),
                      if (_finding) Padding(padding: const EdgeInsets.only(top: 8), child: Text(tx('Finding the nearest depot…'))),
                      if (_locError != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_locError!, style: const TextStyle(color: AppColors.danger))),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  formCard(
                    'GET OFF AT',
                    _pickerField(_stopAt(_tp)?['place_name'] as String?, tx('Search a depot or place'), () => _pickDepot(boarding: false)),
                  ),
                  if (_depotMode && _depotFare != null) ...[
                    const SizedBox(height: 10),
                    AppCard(
                      child: Row(children: [
                        const Icon(Icons.route_outlined, color: AppColors.lime600),
                        const SizedBox(width: 10),
                        Expanded(child: Text(_routeLabel, style: const TextStyle(fontWeight: FontWeight.w800))),
                        Text('${kmText(_depotKm)} · ${money(_depotFare!)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      ]),
                    ),
                  ],
                  if (_cat.plainBookable.isNotEmpty) const SizedBox(height: 14),
                ],
                if (_cat.plainBookable.isNotEmpty) ...[
                formCard(
                  'FROM',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    ChoiceChipButton('📍 ${tx('My location')}', selected: _useMine, onTap: _finding ? () {} : _findNearest),
                    for (final f in _cat.fromNames)
                      ChoiceChipButton(f, selected: !_useMine && f == _from, onTap: () => setState(() {
                            _useMine = false;
                            _from = f;
                            _route = null;
                            _dep = null;
                            _fp = _tp = null;
                            _depotCat = null;
                          })),
                  ]),
                ),
                if (_finding || _locError != null || (_useMine && _depotPoint != null)) ...[
                  const SizedBox(height: 10),
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      if (_finding)
                        Row(children: [
                          const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                          const SizedBox(width: 10),
                          Expanded(child: Text(tx('Finding the nearest depot…'))),
                        ])
                      else if (_locError != null)
                        Text(_locError!, style: const TextStyle(color: AppColors.danger))
                      else ...[
                        Text(txf('Nearest depot: %s', ['$_from']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        const SizedBox(height: 2),
                        Text(txf('%s from you · about %s by road', [kmText(_toDepotKm), durationText(_toDepotMin ?? 0)]),
                            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ],
                    ]),
                  ),
                ],
                const SizedBox(height: 10),
                formCard(
                  'TO',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final r in routes)
                      ChoiceChipButton(
                        '${r.toName} · ${money(r.fare)}${_cat.category(r.categoryId) != null ? ' · ${_cat.category(r.categoryId)!.name}' : ''}',
                        selected: r.id == _route?.id,
                        onTap: () => setState(() {
                          _route = r;
                          _dep = null;
                          _fp = _tp = null;
                          _depotCat = null;
                        }),
                      ),
                  ]),
                ),
                ],
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: _route == null ? null : () => setState(() => _step = 1)),
                ],
                if (_step == 1) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(_step == 1
                                    ? _routeLabel
                                    : '$_routeLabel\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}',
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      const SizedBox(height: 10),
                formCard(
                  'DAY',
                  DayChips(
                    value: _day,
                    onChanged: (d) {
                      setState(() {
                        _day = d;
                        _dep = null;
                      });
                      _loadSeats();
                    },
                  ),
                ),
                if (_route != null) ...[
                  const SizedBox(height: 10),
                  formCard(
                    'LEAVES AT',
                    deps.isEmpty
                        ? Text(tx('No departure on this day.'), style: TextStyle(color: AppColors.muted))
                        : Wrap(spacing: 8, runSpacing: 8, children: [for (final d in deps) _depTile(d)]),
                  ),
                ],
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: _dep == null ? null : () => setState(() => _step = 2)),
                ],
                if (_route != null && _step == 2) ...[
                      AppCard(
                        child: Row(children: [
                          const Icon(Icons.route_outlined, color: AppColors.lime600),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(_step == 1
                                    ? _routeLabel
                                    : '$_routeLabel\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}',
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                        ]),
                      ),
                      const SizedBox(height: 10),
                  Row(children: [
                    if (category != null) ...[VehicleTile(category.name, width: 56), const SizedBox(width: 10)],
                    Expanded(
                      child: Counter(
                        label: tx('SEATS') + (category != null ? ' · ${category.name}' : ''),
                        value: _count,
                        max: _dep == null ? null : (_left(_dep!) < 1 ? 1 : _left(_dep!)),
                        onChanged: (v) => setState(() => _count = v < 1 ? 1 : v),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                  TotalBox('TOTAL', money(total), '$_count × ${money(fare)} · ${tx('no fee if you cancel')}'),
                ],
                if (_step == 2) ...[
                  ErrorLine(_error),
                  const SizedBox(height: 8),
                  AppButton(_count == 1 ? tx('Book 1 seat') : txf('Book %s seats', ['${_count}']),
                      loading: _busy, onPressed: _dep == null ? null : _book),
                ],
              ],
            ]),
    );
  }

  Widget _depTile(Departure d) {
    final left = _left(d);
    final gone = _gone(d);
    final full = left <= 0;
    final on = d.id == _dep?.id;
    final disabled = gone || full;
    return Semantics(
      button: true,
      selected: on,
      label: '${d.time}, ${gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['$left'])}',
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: gone ? null : (full ? () => _waitlist(d) : () => setState(() {
              _dep = d;
              if (_count > left) _count = left;
            })),
        child: Container(
          width: 84,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.navy : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 1.5),
          ),
          child: Column(children: [
            Text(d.time,
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: on ? Colors.white : (disabled ? AppColors.muted : AppColors.ink))),
            Text(gone ? tx('Left') : full ? tx('Full') : txf('%s left', ['${left}']),
                style: TextStyle(fontSize: 11, color: on ? AppColors.lime : (disabled ? AppColors.danger : AppColors.muted))),
          ]),
        ),
      ),
    );
  }
}

/// Search sheet for depots (and any place, matched to the nearest depot).
class DepotSearch extends StatefulWidget {
  final List<Map<String, dynamic>> stops;
  final LatLng? near;
  const DepotSearch({required this.stops, this.near});

  @override
  State<DepotSearch> createState() => _DepotSearchState();
}

class _DepotSearchState extends State<DepotSearch> {
  final _q = TextEditingController();
  List<Place> _hits = [];
  bool _busy = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Map<String, dynamic>? _nearestTo(LatLng pt) {
    Map<String, dynamic>? best;
    var bestKm = double.infinity;
    for (final st in widget.stops) {
      final d = distanceKm(pt, LatLng(toDouble(st['lat']), toDouble(st['lng'])));
      if (d < bestKm) {
        bestKm = d;
        best = st;
      }
    }
    return best;
  }

  Future<void> _searchMap(String q) async {
    setState(() => _busy = true);
    try {
      final r = await searchPlaces(q, near: widget.near).timeout(const Duration(seconds: 8));
      if (mounted) setState(() => _hits = r.take(5).toList());
    } catch (_) {
      if (mounted) setState(() => _hits = []);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final q = _q.text.trim().toLowerCase();
    final shown = widget.stops.where((st) => q.isEmpty || '${st['place_name']}'.toLowerCase().contains(q)).toList();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: Column(children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 10, bottom: 10), decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(4))),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              controller: _q,
              autofocus: true,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: tx('Search a depot or place'),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { _q.clear(); _hits = []; })),
              ),
              onChanged: (_) => setState(() => _hits = []),
              onSubmitted: (v) { if (v.trim().length >= 2) _searchMap(v); },
            ),
          ),
          Expanded(
            child: ListView(children: [
              for (final st in shown)
                ListTile(
                  leading: const Icon(Icons.place_outlined, color: AppColors.lime600),
                  title: Text('${st['place_name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  onTap: () => Navigator.pop(context, st['pos'] as int),
                ),
              if (q.length >= 2) ...[
                if (shown.isEmpty || _hits.isNotEmpty) const Divider(),
                if (_hits.isEmpty)
                  ListTile(
                    leading: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.travel_explore),
                    title: Text(txf('Find "%s" on the map', [_q.text.trim()])),
                    subtitle: Text(tx('We pick the nearest depot to it')),
                    onTap: _busy ? null : () => _searchMap(_q.text),
                  ),
                for (final h in _hits)
                  Builder(builder: (context) {
                    final st = _nearestTo(h.point);
                    if (st == null) return const SizedBox.shrink();
                    final km = distanceKm(h.point, LatLng(toDouble(st['lat']), toDouble(st['lng'])));
                    return ListTile(
                      leading: const Icon(Icons.near_me_outlined),
                      title: Text(h.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(txf('Nearest depot: %s · %s away', ['${st['place_name']}', kmText(km)])),
                      onTap: () => Navigator.pop(context, st['pos'] as int),
                    );
                  }),
              ],
            ]),
          ),
        ]),
      ),
    );
  }
}
