import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../arrival_card.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../report_pdf.dart';
import '../../route_preview.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import '../tickets.dart';
import 'catalog.dart';
import 'my_things.dart';
import '../../i18n.dart';

/// What a passenger needs to show a booking: the car, its driver and the goods code.
class BookingInfo {
  final Map<String, Truck> trucks = {};
  final Map<String, Profile> people = {};
  final Map<String, String> codes = {};
  final Map<String, VehicleCategory> categories = {};

  Future<void> load(List<Booking> list) async {
    final truckIds = {for (final b in list) if (b.truckId != null) b.truckId!}.toList();
    final driverIds = {for (final b in list) if (b.driverId != null) b.driverId!}.toList();
    final r = await Future.wait<List<Map<String, dynamic>>>([
      truckIds.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('trucks').select().inFilter('id', truckIds),
      driverIds.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('profiles').select().inFilter('id', driverIds),
      db.from('booking_codes').select(),
      db.from('vehicle_categories').select(),
    ]);
    for (final t in r[0].map(Truck.fromMap)) {
      trucks[t.id] = t;
    }
    for (final p in r[1].map(Profile.fromMap)) {
      people[p.id] = p;
    }
    for (final c in r[2]) {
      codes[c['booking_id'].toString()] = (c['code'] ?? '').toString();
    }
    for (final c in r[3].map(VehicleCategory.fromMap)) {
      categories[c.id] = c;
    }
  }
}

class MyBookingsTab extends StatefulWidget {
  const MyBookingsTab({super.key});

  @override
  State<MyBookingsTab> createState() => MyBookingsTabState();
}

class MyBookingsTabState extends State<MyBookingsTab> {
  List<Booking> _list = [];
  BookingInfo _info = BookingInfo();
  final Map<String, int> _rated = {}; // booking id -> stars given
  bool _loading = true;
  String? _error;
  Timer? _timer;
  Set<String> _openIds = {}; // bookings that were still open at the last load
  bool _asking = false;

  @override
  void initState() {
    super.initState();
    load();
    _timer = Timer.periodic(const Duration(seconds: 45), (_) => load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db.from('bookings').select().eq('passenger_id', me.id).order('pickup_at', ascending: false).limit(80);
      final list = rows.map(Booking.fromMap).toList();
      final info = BookingInfo();
      await info.load(list);
      _saveCache(rows, info);
      try {
        final rs = await db.from('ratings').select('booking_id, stars').eq('passenger_id', me.id);
        _rated
          ..clear()
          ..addEntries(rs.map((r) => MapEntry('${r['booking_id']}', (r['stars'] as num).toInt())));
      } catch (_) {}
      if (!mounted) return;
      final finished = [
        for (final b in list)
          if (b.status == 'completed' && b.driverId != null && _openIds.contains(b.id) && !_rated.containsKey(b.id)) b
      ];
      _openIds = {for (final b in list) if (b.open) b.id};
      setState(() {
        _list = list;
        _info = info;
        _error = null;
      });
      // A trip just finished: ask for a rating straight away.
      if (finished.isNotEmpty && !_asking) {
        _asking = true;
        try {
          await _rate(finished.first);
        } finally {
          _asking = false;
        }
      }
    } catch (e) {
      // no signal: show the last bookings that were saved on this phone
      if (_list.isEmpty && await _loadCache()) {
        if (mounted) setState(() => _error = tx('No internet. Showing your saved bookings.'));
      } else if (mounted) {
        setState(() => _error = friendlyError(e));
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _saveCache(List<Map<String, dynamic>> rows, BookingInfo info) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cache_bookings', jsonEncode(rows));
      await prefs.setString('cache_codes', jsonEncode(info.codes));
    } catch (_) {}
  }

  Future<bool> _loadCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('cache_bookings');
      if (raw == null) return false;
      final rows = (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      final info = BookingInfo();
      final codes = prefs.getString('cache_codes');
      if (codes != null) info.codes.addAll(Map<String, String>.from(jsonDecode(codes) as Map));
      if (!mounted) return true;
      setState(() {
        _list = rows.map(Booking.fromMap).toList();
        _info = info;
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _receipt(Booking b, Truck? truck, Profile? driver, String? category) async {
    try {
      final bytes = await buildReportPdf(
        title: 'EfuLogistix receipt',
        period: 'Booking #${b.bookingNo} · ${dayName(b.pickupAt)} ${clock(b.pickupAt)}',
        summary: [
          MapEntry('Total', money(b.amount)),
          MapEntry('Paid by', b.payName),
          MapEntry('Status', b.statusName),
        ],
        tables: [
          PdfTable('Trip', ['Detail', 'Value'], [
            ['Trip', b.title],
            ['From', b.pickupName],
            ['To', b.destName],
            if (b.km != null) ['Distance', kmText(b.km)],
            if (b.kind == 'seat') ['Seats', '${b.seats}'],
            if (truck != null) ['Vehicle', '${truck.plate}${category != null ? ' · $category' : ''}'],
            if (driver != null) ['Driver', driver.displayName],
            ['Fare', money(b.amount)],
          ]),
        ],
      );
      final name = 'efulogistix_receipt_${b.bookingNo}.pdf';
      await Share.shareXFiles([XFile.fromData(bytes, name: name, mimeType: 'application/pdf')], fileNameOverrides: [name]);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  /// "Lost something?": a short note goes to the office as a support ticket about this booking.
  Future<void> _lost(Booking b) async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tx('Lost something?')),
        content: TextField(
          controller: ctl,
          autofocus: true,
          maxLines: 3,
          decoration: InputDecoration(hintText: tx('What did you leave in the vehicle?')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send to the office'))),
        ],
      ),
    );
    final text = ctl.text.trim();
    ctl.dispose();
    if (ok != true || text.isEmpty) return;
    try {
      await db.rpc('report_problem', params: {'p_reason': 'lost_goods', 'p_body': 'Lost item on booking #${b.bookingNo}: $text', 'p_booking': b.id});
      if (mounted) toast(context, tx('The office has been told. They will call you.'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _rate(Booking b) async {
    var stars = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(tx('Rate your driver')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 1; i <= 5; i++)
                IconButton(
                  onPressed: () => setLocal(() => stars = i),
                  icon: Icon(i <= stars ? Icons.star : Icons.star_border, color: AppColors.warning, size: 34),
                ),
            ]),
            TextField(
              controller: comment,
              maxLines: 3,
              maxLength: 300,
              decoration: InputDecoration(hintText: tx('Tell us more (optional)'), border: OutlineInputBorder()),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Not now'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
          ],
        ),
      ),
    );
    final text = comment.text.trim();
    comment.dispose();
    if (ok != true) return;
    try {
      await db.rpc('rate_booking', params: {'p_booking': b.id, 'p_stars': stars, 'p_comment': text.isEmpty ? null : text});
      if (mounted) toast(context, tx('Thank you for rating.'));
      await load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  /// Change a booking until the car has arrived: hire time, fewer seats, a note for the driver.
  Future<void> _change(Booking b) async {
    DateTime? when;
    int? seats;
    final note = TextEditingController(text: b.note ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(txf('Change booking #%s', ['${b.bookingNo}'])),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (b.kind == 'hire')
                OutlinedButton.icon(
                  icon: const Icon(Icons.schedule),
                  label: Text(when == null ? '${tx('Time')}: ${dayName(b.pickupAt)} ${clock(b.pickupAt)}' : '${tx('New time')}: ${dayName(when!)} ${clock(when!)}'),
                  onPressed: () async {
                    final now = DateTime.now();
                    final d = await showDatePicker(context: ctx, initialDate: b.pickupAt.isAfter(now) ? b.pickupAt : now, firstDate: now, lastDate: now.add(const Duration(days: 60)));
                    if (d == null || !ctx.mounted) return;
                    final t = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(b.pickupAt));
                    if (t == null) return;
                    setLocal(() => when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
                  },
                ),
              if (b.kind == 'seat' && b.seats > 1) ...[
                Text(tx('Fewer seats'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                Wrap(spacing: 8, children: [
                  for (var n = 1; n < b.seats; n++)
                    ChoiceChip(label: Text('$n'), selected: seats == n, onSelected: (_) => setLocal(() => seats = seats == n ? null : n)),
                ]),
              ],
              const SizedBox(height: 8),
              TextField(
                controller: note,
                maxLines: 2,
                maxLength: 200,
                decoration: InputDecoration(labelText: tx('Note for the driver'), border: const OutlineInputBorder()),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Close'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Save'))),
          ],
        ),
      ),
    );
    final text = note.text.trim();
    note.dispose();
    if (ok != true) return;
    try {
      await db.rpc('change_booking', params: {
        'p_id': b.id,
        'p_pickup_at': when?.toUtc().toIso8601String(),
        'p_seats': seats,
        'p_note': text == (b.note ?? '') ? null : text,
      });
      if (mounted) toast(context, tx('Saved. The driver is told.'));
      await load();
    } catch (e) {
      if (mounted) {
        final m = e.toString();
        toast(context, m.contains('NOTHING_TO_CHANGE') ? tx('Nothing was changed.') : m.contains('CANNOT_CHANGE') ? tx('This booking can no longer be changed.') : friendlyError(e));
      }
    }
  }

  Future<void> _cancel(Booking b) async {
    if (!await confirmDialog(context, txf('Cancel booking #%s?', ['${b.bookingNo}']), tx('Cancelling is free.'), yes: tx('Cancel booking'))) return;
    try {
      await db.rpc('cancel_booking', params: {'p_id': b.id, 'p_reason': 'Cancelled by passenger'});
      await load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final upcoming = _list.where((b) => b.open).toList()..sort((a, b) {
        final x = (b.status == 'picked_up' ? 1 : 0) - (a.status == 'picked_up' ? 1 : 0);
        return x != 0 ? x : a.pickupAt.compareTo(b.pickupAt);
      });
    final past = _list.where((b) => !b.open).toList();
    return Container(
      color: AppColors.surface100,
      child: Column(children: [
        Container(
          color: AppColors.navy,
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 12, 8, 16),
              child: Row(children: [
                Expanded(child: Text(tx('My bookings'), style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        ),
        if (_loading) const LinearProgressIndicator(),
        Expanded(
          child: RefreshIndicator(
            onRefresh: load,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              ErrorLine(_error),
              if (!_loading && _list.isEmpty) EmptyText(tx('No bookings yet. Book a seat, hire a car or send goods from Home.')),
              if (upcoming.isNotEmpty) SectionTitle(tx('UPCOMING')),
              for (final b in upcoming) ...[_card(b), const SizedBox(height: 10)],
              if (past.isNotEmpty) SectionTitle(tx('PAST')),
              for (final b in past) ...[_card(b), const SizedBox(height: 10)],
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _card(Booking b) {
    final truck = _info.trucks[b.truckId];
    final driver = _info.people[b.driverId];
    final cat = _info.categories[b.categoryId];
    final code = _info.codes[b.id];
    final color = switch (b.status) {
      'assigned' || 'picked_up' => AppColors.lime600,
      'requested' => AppColors.warning,
      'completed' => AppColors.navy,
      _ => AppColors.danger,
    };
    final when = '${dayName(b.pickupAt)} ${clock(b.pickupAt)}';
    final what = switch (b.kind) {
      'seat' => '${b.seats} ${b.seats == 1 ? tx('seat') : tx('seats')}',
      'goods' => txf('to %s', [b.receiverName ?? '']),
      _ => b.km != null ? kmText(b.km) : '',
    };
    return AppCard(
      borderColor: b.status == 'assigned' ? AppColors.lime : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          VehicleTile(cat?.name, width: 52),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text('$when · $what · ${b.kind == 'hire' && b.finalPrice == null ? tx('est.') + ' ' : ''}${money(b.amount)} · ${b.payName}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              Text('#${b.bookingNo}', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
            ]),
          ),
          StatusPill(b.statusName, color: color),
        ]),
        if (b.open) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: RoutePreview(
              from: b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null,
              fromName: b.pickupName,
              to: b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : null,
              toName: b.destName,
              height: 160,
            ),
          ),
        ],
        if (b.status == 'requested')
          Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(tx('We are finding a car and driver for you. You will get a message. If it takes long, the office will help.'),
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ),
        if (b.message != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(txf('Office: %s', ['${b.message}']), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        if (b.cancelReason != null && (b.status == 'declined'))
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(b.cancelReason!, style: const TextStyle(fontSize: 13, color: AppColors.danger)),
          ),
        if (truck != null && b.open) ...[
          const Divider(height: 20),
          Row(children: [
            Avatar(driver, size: 40),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${truck.plate}${cat != null ? ' · ${cat.name}' : ''}${driver != null ? ' · ${driver.firstName}' : ''}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(
                    [
                      if (truck.looks.isNotEmpty) truck.looks,
                      if (b.kind == 'seat') txf('Be at %s by %s', [b.pickupName, clock(b.pickupAt.subtract(const Duration(minutes: 10)))]),
                    ].join(' · '),
                    style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            if (driver?.phone != null)
              IconButton.filled(
                tooltip: tx('Call the driver'),
                style: IconButton.styleFrom(backgroundColor: AppColors.navy),
                onPressed: () => launchUrl(Uri.parse('tel:${driver!.phone}')),
                icon: const Icon(Icons.call, color: Colors.white),
              ),
          ]),
          const SizedBox(height: 8),
          AppButton(tx('Track the car'),
              kind: ButtonKind.outline,
              height: 40,
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => TrackCarScreen(booking: b, truck: truck, driver: driver, category: cat?.name)))),
        ],
        if (b.open) ...[
          const SizedBox(height: 8),
          Row(children: [
            if (b.kind != 'goods')
              Expanded(child: AppButton(tx('Boarding ticket'), kind: ButtonKind.outline, height: 40, onPressed: () => showTicket(context, b.id, b.bookingNo))),
            if (b.status == 'assigned' || b.status == 'picked_up') ...[
              if (b.kind != 'goods') const SizedBox(width: 8),
              Expanded(
                  child: AppButton(b.kind == 'goods' ? tx('Share parcel tracking') : tx('Share my trip'),
                      kind: ButtonKind.outline,
                      height: 40,
                      onPressed: () => shareTrip(context, b.id, b.title, parcelCode: b.kind == 'goods' ? code : null))),
            ],
          ]),
        ],
        if (code != null && code.isNotEmpty && b.open)
          Container(
            margin: const EdgeInsets.only(top: 10),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(10)),
            child: Row(children: [
              Expanded(child: Text(txf('Collection code for %s', [b.receiverName ?? tx('the receiver')]), style: const TextStyle(fontSize: 13))),
              Text(code.split('').join(' '), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 2)),
            ]),
          ),
        if (b.status == 'completed' && b.driverId != null) ...[
          const SizedBox(height: 8),
          if (_rated.containsKey(b.id))
            Row(children: [
              for (var i = 1; i <= 5; i++)
                Icon(i <= _rated[b.id]! ? Icons.star : Icons.star_border, color: AppColors.warning, size: 20),
              const SizedBox(width: 8),
              Text(tx('You rated this trip'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ])
          else
            AppButton(tx('Rate your driver'), kind: ButtonKind.outline, height: 38, onPressed: () => _rate(b)),
        ],
        if (b.status == 'completed') ...[
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: AppButton(tx('Receipt'), kind: ButtonKind.outline, height: 44, onPressed: () => _receipt(b, truck, driver, cat?.name))),
            const SizedBox(width: 8),
            Expanded(child: AppButton(tx('Lost item'), kind: ButtonKind.outline, height: 44, onPressed: () => _lost(b))),
            if (b.driverId != null) _FavouriteHeart(driverId: b.driverId!),
          ]),
        ],
        if (b.canCancel && b.arrivedAt == null && (b.status == 'requested' || b.status == 'assigned')) ...[
          const SizedBox(height: 8),
          AppButton(tx('Change time, seats or note'), kind: ButtonKind.outline, height: 38, onPressed: () => _change(b)),
        ],
        if (b.kind == 'goods' && (b.goodsPhoto != null || b.deliveryPhoto != null)) ...[
          const SizedBox(height: 8),
          Row(children: [
            if (b.goodsPhoto != null) Expanded(child: Column(children: [StoredImage(b.goodsPhoto, height: 80), Text(tx('Your goods'), style: const TextStyle(fontSize: 11, color: AppColors.muted))])),
            if (b.goodsPhoto != null && b.deliveryPhoto != null) const SizedBox(width: 8),
            if (b.deliveryPhoto != null) Expanded(child: Column(children: [StoredImage(b.deliveryPhoto, height: 80), Text('${tx('Delivered')} ✓', style: const TextStyle(fontSize: 11, color: AppColors.lime600, fontWeight: FontWeight.w700))])),
          ]),
        ],
        if (b.canCancel) ...[
          const SizedBox(height: 8),
          AppButton(tx('Cancel · no fee'), kind: ButtonKind.danger, height: 38, onPressed: () => _cancel(b)),
        ],
      ]),
    );
  }
}

/// The assigned car on the map, moving live.
class TrackCarScreen extends StatefulWidget {
  final Booking booking;
  final Truck truck;
  final Profile? driver;
  final String? category;
  const TrackCarScreen({super.key, required this.booking, required this.truck, this.driver, this.category});

  @override
  State<TrackCarScreen> createState() => _TrackCarScreenState();
}

class _TrackCarScreenState extends State<TrackCarScreen> {
  TruckLocation? _loc;
  late Booking _b = widget.booking; // refreshed, so "on board" / "arrived" show without leaving the screen
  List<LatLng>? _routePts;
  double? _routeMin;
  DateTime _lastRoute = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _timer;
  RealtimeChannel? _channel;
  final _sheet = DraggableScrollableController();
  bool _arrivalOpened = false;

  @override
  void initState() {
    super.initState();
    _load();
    Here.instance.startLive();
    // slow poll as a safety net; the live channel below moves the car the moment it reports
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
    _channel = db
        .channel('track-${widget.truck.id}')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'truck_locations',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'truck_id', value: widget.truck.id),
          callback: (payload) {
            final row = payload.newRecord;
            if (row.isEmpty || !mounted) return;
            setState(() => _loc = TruckLocation.fromMap(row));
            _reroute();
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    Here.instance.stopLive();
    final c = _channel;
    if (c != null) db.removeChannel(c);
    _timer?.cancel();
    _sheet.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final row = await db.from('truck_locations').select().eq('truck_id', widget.truck.id).maybeSingle();
      final br = await db.from('bookings').select().eq('id', widget.booking.id).maybeSingle();
      if (mounted) {
        setState(() {
          _loc = row == null ? null : TruckLocation.fromMap(row);
          if (br != null) _b = Booking.fromMap(br);
        });
        // the driver just arrived: lift the sheet so the driver's picture and the vehicle show
        if (_b.arrivedAt != null && _b.status == 'assigned' && !_arrivalOpened) {
          _arrivalOpened = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && _sheet.isAttached) _sheet.animateTo(0.8, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
          });
        }
      }
      _reroute();
    } catch (_) {}
  }

  /// Where the car is heading: the pick-up point first, then the drop-off once the passenger is on board.
  LatLng? get _target {
    final b = _b;
    if (b.status == 'picked_up') return b.destLat != null && b.destLng != null ? LatLng(b.destLat!, b.destLng!) : null;
    return b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null;
  }

  Future<void> _reroute() async {
    final loc = _loc;
    final to = _target;
    if (loc == null || to == null) return;
    if (DateTime.now().difference(_lastRoute) < const Duration(seconds: 30)) return;
    _lastRoute = DateTime.now();
    final r = await getRoute(LatLng(loc.lat, loc.lng), to);
    if (!mounted) return;
    setState(() {
      _routePts = r?.points;
      _routeMin = r?.minutes;
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = _b;
    final pickup = b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null;
    final car = _loc == null ? null : LatLng(_loc!.lat, _loc!.lng);
    final mins = _routeMin != null ? _routeMin!.ceil() : (car != null && pickup != null ? distanceToMin(car, pickup) : null);
    final onBoard = b.status == 'picked_up';
    final finished = !b.open;
    return Scaffold(
      appBar: navyBar(txf('Car #%s', ['${b.bookingNo}'])),
      backgroundColor: AppColors.mapGround,
      body: Stack(children: [
        Positioned.fill(
          child: ValueListenableBuilder<LatLng?>(
            valueListenable: Here.instance.point,
            builder: (context, me, _) => FleetMap(
              me: me,
              trucks: [if (car != null) MapTruck(widget.truck.id, car, widget.truck.plate, kind: vehicleKind(widget.category))],
              route: _routePts,
              end: _target,
              endLabel: onBoard ? b.destName : txf('You · %s', [b.pickupName]),
              bottomPadding: 250,
            ),
          ),
        ),
        if (!finished && mins != null && car != null && b.arrivedAt == null)
          Positioned(
            left: 12,
            top: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(20)),
              child: Text(onBoard ? txf('%s min to your stop', ['$mins']) : txf('Arrives in %s min', ['$mins']),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
            ),
          ),
        DraggableScrollableSheet(
          controller: _sheet,
          initialChildSize: b.arrivedAt != null && b.status == 'assigned' && !finished ? 0.8 : 0.40,
          minChildSize: 0.2,
          maxChildSize: 0.8,
          snap: true,
          snapSizes: const [0.40, 0.8],
          builder: (context, sc) => Container(
            decoration: const BoxDecoration(
              color: AppColors.surface100,
              borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
              boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 12)],
            ),
            child: ListView(
              controller: sc,
              padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(context).viewPadding.bottom + 16),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(4)),
                  ),
                ),
                if (!finished && !onBoard && b.arrivedAt == null && car != null && mins != null && mins <= 2) ...[
                  AppCard(
                    borderColor: AppColors.lime,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('🔔 ${tx('Your driver is 2 minutes away')}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text(tx('Be ready at the pick-up point'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                    ]),
                  ),
                  const SizedBox(height: 10),
                ],
                Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        finished
                    ? tx('This trip is finished')
                    : car == null
                    ? tx('Waiting for the car\'s position')
                    : onBoard
                        ? txf('On the way to %s', ['${b.destName}'])
                        : b.arrivedAt != null
                            ? tx('Your car has arrived')
                            : mins != null
                            ? tx('Car is coming')
                            : txf('Car position · %s', ['${clock(_loc!.updatedAt)}']),
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                      ),
                      Text('${b.kind == 'seat' ? tx('Leaves') : tx('Pick-up')} ${dayName(b.pickupAt)} ${clock(b.pickupAt)} · ${b.destName}',
                          style: const TextStyle(color: AppColors.muted)),
                    ]),
                  ),
                  if (!finished && mins != null && car != null && b.arrivedAt == null)
                    Text(txf('%s min', ['$mins']),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.lime600)),
                ]),
                const SizedBox(height: 12),
                if (b.arrivedAt != null && b.status == 'assigned' && !finished) ...[
                  FullPhotoCard(person: widget.driver, tag: 'Your driver has arrived'),
                  const SizedBox(height: 10),
                ] else
                  AppCard(
                    child: Row(children: [
                      Avatar(widget.driver, size: 48),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(widget.driver?.displayName ?? tx('Driver'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      ),
                      VehicleArt(widget.category, width: 64),
                    ]),
                  ),
                const SizedBox(height: 10),
                VehicleInfo(truck: widget.truck, category: widget.category),
                if (finished && b.status == 'completed') ...[
                  const SizedBox(height: 10),
                  AppCard(
                    borderColor: AppColors.lime,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(tx('TRIP SUMMARY'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.muted)),
                      const SizedBox(height: 6),
                      Row(children: [
                        Expanded(child: Text(tx('You paid'), style: const TextStyle(color: AppColors.muted))),
                        Text(money(b.amount), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                      ]),
                      if (b.km != null && b.km! > 0)
                        Row(children: [
                          Expanded(child: Text(tx('Distance'), style: const TextStyle(color: AppColors.muted))),
                          Text(kmText(b.km), style: const TextStyle(fontWeight: FontWeight.w700)),
                        ]),
                      Row(children: [
                        Expanded(child: Text(tx('Pay'), style: const TextStyle(color: AppColors.muted))),
                        Text(b.payMethod == 'cash' ? tx('Cash to the driver') : b.payName, style: const TextStyle(fontWeight: FontWeight.w700)),
                      ]),
                      const SizedBox(height: 8),
                      Text(tx('Rate your driver and get the receipt in My bookings.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      const SizedBox(height: 8),
                      AppButton(tx('Rate your driver'), height: 44, onPressed: () => Navigator.of(context).pop()),
                    ]),
                  ),
                ],
                const SizedBox(height: 10),
                Row(children: [
                  if (widget.driver?.phone != null) ...[
                    Expanded(
                      child: AppButton(tx('Call'), kind: ButtonKind.outline, height: 46,
                          onPressed: () => launchUrl(Uri.parse('tel:${widget.driver!.phone}'))),
                    ),
                    const SizedBox(width: 8),
                  ],
                  if (b.status == 'assigned' && b.kind != 'goods')
                    Expanded(
                      child: AppButton(tx('Boarding ticket'), kind: ButtonKind.navy, height: 46,
                          onPressed: () => showTicket(context, b.id, b.bookingNo)),
                    ),
                ]),
                const SizedBox(height: 10),
                if (!finished)
                AppButton(tx('Share with family on WhatsApp'), kind: ButtonKind.outline, height: 46, onPressed: () {
                  final text = 'I am travelling with EfuLogistix: ${b.title}, ${dayName(b.pickupAt)} ${clock(b.pickupAt)}. '
                      'Car ${widget.truck.plate}${widget.truck.looks.isNotEmpty ? ' (${widget.truck.looks})' : ''}, '
                      'driver ${widget.driver?.displayName ?? ''} ${widget.driver?.phone ?? ''}. Booking #${b.bookingNo}.';
                  launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}'), mode: LaunchMode.externalApplication);
                }),
                if (!finished) ...[
                  const SizedBox(height: 8),
                  AppButton(tx('Alert my emergency contact'),
                      kind: ButtonKind.outline, height: 46, onPressed: () => alertEmergencyContact(context, b.id, b.title)),
                ],
              ],
            ),
          ),
        ),
      ]),
    );
  }
}

/// Rough minutes for a car to reach a point (40 km/h in town, by straight line × 1.3).
int distanceToMin(LatLng a, LatLng b) {
  final km = distanceKm(a, b) * 1.3;
  return (km / 40 * 60).ceil();
}

/// Heart on a finished booking: add or remove the driver from the favourites.
class _FavouriteHeart extends StatefulWidget {
  final String driverId;
  const _FavouriteHeart({required this.driverId});

  @override
  State<_FavouriteHeart> createState() => _FavouriteHeartState();
}

class _FavouriteHeartState extends State<_FavouriteHeart> {
  bool _on = false;

  @override
  void initState() {
    super.initState();
    FavouriteDriver.isFavourite(widget.driverId).then((v) {
      if (mounted) setState(() => _on = v);
    });
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: tx('Favourite driver'),
        onPressed: () async {
          final next = !_on;
          setState(() => _on = next);
          try {
            await FavouriteDriver.set(widget.driverId, next);
            if (mounted) toast(context, next ? tx('Added to your favourite drivers.') : tx('Removed from your favourite drivers.'));
          } catch (e) {
            if (mounted) {
              setState(() => _on = !next);
              toast(context, friendlyError(e));
            }
          }
        },
        icon: Icon(_on ? Icons.favorite : Icons.favorite_border, color: AppColors.danger),
      );
}
