import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'catalog.dart';

/// What a passenger needs to show a booking: the car, its driver and the goods code.
class BookingInfo {
  final Map<String, Truck> trucks = {};
  final Map<String, Profile> people = {};
  final Map<String, String> codes = {};
  final Map<String, VehicleCategory> categories = {};

  Future<void> load(List<Booking> list) async {
    final truckIds = {for (final b in list) if (b.truckId != null) b.truckId!}.toList();
    final driverIds = {for (final b in list) if (b.driverId != null) b.driverId!}.toList();
    final r = await Future.wait<List<Map<String, dynamic>>>([
      truckIds.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('trucks').select().inFilter('id', truckIds),
      driverIds.isEmpty ? Future.value(<Map<String, dynamic>>[]) : db.from('profiles').select().inFilter('id', driverIds),
      db.from('booking_codes').select(),
      db.from('vehicle_categories').select(),
    ]);
    for (final t in r[0].map(Truck.fromMap)) {
      trucks[t.id] = t;
    }
    for (final p in r[1].map(Profile.fromMap)) {
      people[p.id] = p;
    }
    for (final c in r[2]) {
      codes[c['booking_id'].toString()] = (c['code'] ?? '').toString();
    }
    for (final c in r[3].map(VehicleCategory.fromMap)) {
      categories[c.id] = c;
    }
  }
}

class MyBookingsTab extends StatefulWidget {
  const MyBookingsTab({super.key});

  @override
  State<MyBookingsTab> createState() => MyBookingsTabState();
}

class MyBookingsTabState extends State<MyBookingsTab> {
  List<Booking> _list = [];
  BookingInfo _info = BookingInfo();
  bool _loading = true;
  String? _error;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    load();
    _timer = Timer.periodic(const Duration(seconds: 45), (_) => load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db.from('bookings').select().eq('passenger_id', me.id).order('pickup_at', ascending: false).limit(80);
      final list = rows.map(Booking.fromMap).toList();
      final info = BookingInfo();
      await info.load(list);
      if (!mounted) return;
      setState(() {
        _list = list;
        _info = info;
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _cancel(Booking b) async {
    if (!await confirmDialog(context, 'Cancel booking #${b.bookingNo}?', 'Cancelling is free.', yes: 'Cancel booking')) return;
    try {
      await db.rpc('cancel_booking', params: {'p_id': b.id, 'p_reason': 'Cancelled by passenger'});
      await load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final upcoming = _list.where((b) => b.open).toList()..sort((a, b) => a.pickupAt.compareTo(b.pickupAt));
    final past = _list.where((b) => !b.open).toList();
    return Container(
      color: AppColors.surface100,
      child: Column(children: [
        Container(
          color: AppColors.navy,
          child: const SafeArea(
            bottom: false,
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 12, 8, 16),
              child: Row(children: [
                Expanded(child: Text('My bookings', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        ),
        if (_loading) const LinearProgressIndicator(),
        Expanded(
          child: RefreshIndicator(
            onRefresh: load,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              ErrorLine(_error),
              if (!_loading && _list.isEmpty) const EmptyText('No bookings yet. Book a seat, hire a car or send goods from Home.'),
              if (upcoming.isNotEmpty) const SectionTitle('UPCOMING'),
              for (final b in upcoming) ...[_card(b), const SizedBox(height: 10)],
              if (past.isNotEmpty) const SectionTitle('PAST'),
              for (final b in past) ...[_card(b), const SizedBox(height: 10)],
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _card(Booking b) {
    final truck = _info.trucks[b.truckId];
    final driver = _info.people[b.driverId];
    final cat = _info.categories[b.categoryId];
    final code = _info.codes[b.id];
    final color = switch (b.status) {
      'assigned' || 'picked_up' => AppColors.lime600,
      'requested' => AppColors.warning,
      'completed' => AppColors.navy,
      _ => AppColors.danger,
    };
    final when = '${dayName(b.pickupAt)} ${clock(b.pickupAt)}';
    final what = switch (b.kind) {
      'seat' => '${b.seats} ${b.seats == 1 ? 'seat' : 'seats'}',
      'goods' => 'to ${b.receiverName ?? ''}',
      _ => b.km != null ? kmText(b.km) : '',
    };
    return AppCard(
      borderColor: b.status == 'assigned' ? AppColors.lime : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          VehicleTile(cat?.name, width: 52),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text('$when · $what · ${b.kind == 'hire' && b.finalPrice == null ? 'est. ' : ''}${money(b.amount)} · ${b.payName}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              Text('#${b.bookingNo}', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
            ]),
          ),
          StatusPill(b.statusName, color: color),
        ]),
        if (b.status == 'requested')
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('The office will assign a car and driver. You will get a message.',
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ),
        if (b.message != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('Office: ${b.message}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        if (b.cancelReason != null && (b.status == 'declined'))
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(b.cancelReason!, style: const TextStyle(fontSize: 13, color: AppColors.danger)),
          ),
        if (truck != null && b.open) ...[
          const Divider(height: 20),
          Row(children: [
            Avatar(driver, size: 40),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${truck.plate}${cat != null ? ' · ${cat.name}' : ''}${driver != null ? ' · ${driver.firstName}' : ''}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(
                    [
                      if (truck.looks.isNotEmpty) truck.looks,
                      if (b.kind == 'seat') 'Be at ${b.pickupName} by ${clock(b.pickupAt.subtract(const Duration(minutes: 10)))}',
                    ].join(' · '),
                    style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            if (driver?.phone != null)
              IconButton.filled(
                tooltip: 'Call the driver',
                style: IconButton.styleFrom(backgroundColor: AppColors.navy),
                onPressed: () => launchUrl(Uri.parse('tel:${driver!.phone}')),
                icon: const Icon(Icons.call, color: Colors.white),
              ),
          ]),
          const SizedBox(height: 8),
          AppButton('Track the car',
              kind: ButtonKind.outline,
              height: 40,
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => TrackCarScreen(booking: b, truck: truck, driver: driver, category: cat?.name)))),
        ],
        if (code != null && code.isNotEmpty && b.open)
          Container(
            margin: const EdgeInsets.only(top: 10),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(10)),
            child: Row(children: [
              Expanded(child: Text('Collection code for ${b.receiverName ?? 'the receiver'}', style: const TextStyle(fontSize: 13))),
              Text(code.split('').join(' '), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 2)),
            ]),
          ),
        if (b.canCancel) ...[
          const SizedBox(height: 8),
          AppButton('Cancel · no fee', kind: ButtonKind.danger, height: 38, onPressed: () => _cancel(b)),
        ],
      ]),
    );
  }
}

/// The assigned car on the map, refreshed every 10 seconds.
class TrackCarScreen extends StatefulWidget {
  final Booking booking;
  final Truck truck;
  final Profile? driver;
  final String? category;
  const TrackCarScreen({super.key, required this.booking, required this.truck, this.driver, this.category});

  @override
  State<TrackCarScreen> createState() => _TrackCarScreenState();
}

class _TrackCarScreenState extends State<TrackCarScreen> {
  TruckLocation? _loc;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final row = await db.from('truck_locations').select().eq('truck_id', widget.truck.id).maybeSingle();
      if (mounted) setState(() => _loc = row == null ? null : TruckLocation.fromMap(row));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final pickup = b.pickupLat != null && b.pickupLng != null ? LatLng(b.pickupLat!, b.pickupLng!) : null;
    final car = _loc == null ? null : LatLng(_loc!.lat, _loc!.lng);
    final mins = car != null && pickup != null ? (distanceToMin(car, pickup)) : null;
    return Scaffold(
      appBar: navyBar('Car #${b.bookingNo}'),
      body: Column(children: [
        Expanded(
          child: FleetMap(
            trucks: [if (car != null) MapTruck(widget.truck.id, car, widget.truck.plate)],
            end: pickup,
            endLabel: 'You · ${b.pickupName}',
            bottomPadding: 20,
          ),
        ),
        Container(
          color: AppColors.surface100,
          padding: const EdgeInsets.all(16),
          child: SafeArea(
            top: false,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(
                car == null
                    ? 'Waiting for the car\'s position'
                    : b.status == 'picked_up'
                        ? 'On the way to ${b.destName}'
                        : mins != null
                            ? 'Car is coming · about $mins min'
                            : 'Car position · ${clock(_loc!.updatedAt)}',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              Text('${b.kind == 'seat' ? 'Leaves' : 'Pick-up'} ${dayName(b.pickupAt)} ${clock(b.pickupAt)} · ${b.destName}',
                  style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              AppCard(
                child: Row(children: [
                  Avatar(widget.driver, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(widget.driver?.displayName ?? 'Driver', style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text([widget.truck.plate, if (widget.truck.looks.isNotEmpty) widget.truck.looks, if (widget.category != null) widget.category!].join(' · '),
                          style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                    ]),
                  ),
                  VehicleArt(widget.category, width: 64),
                  if (widget.driver?.phone != null)
                    IconButton.filled(
                      tooltip: 'Call the driver',
                      style: IconButton.styleFrom(backgroundColor: AppColors.navy),
                      onPressed: () => launchUrl(Uri.parse('tel:${widget.driver!.phone}')),
                      icon: const Icon(Icons.call, color: Colors.white),
                    ),
                ]),
              ),
              const SizedBox(height: 10),
              AppButton('Share with family on WhatsApp', kind: ButtonKind.outline, height: 46, onPressed: () {
                final text = 'I am travelling with EfuLogistix: ${b.title}, ${dayName(b.pickupAt)} ${clock(b.pickupAt)}. '
                    'Car ${widget.truck.plate}${widget.truck.looks.isNotEmpty ? ' (${widget.truck.looks})' : ''}, '
                    'driver ${widget.driver?.displayName ?? ''} ${widget.driver?.phone ?? ''}. Booking #${b.bookingNo}.';
                launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}'), mode: LaunchMode.externalApplication);
              }),
            ]),
          ),
        ),
      ]),
    );
  }
}

/// Rough minutes for a car to reach a point (40 km/h in town, by straight line × 1.3).
int distanceToMin(LatLng a, LatLng b) {
  final km = distanceKm(a, b) * 1.3;
  return (km / 40 * 60).ceil();
}
