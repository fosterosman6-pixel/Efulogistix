import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../geo.dart';
import '../../map_panel.dart';
import '../../widgets.dart';
import 'catalog.dart';
import 'hire_car.dart';
import '../../i18n.dart';
import '../../route_preview.dart';

/// Send bags, parcels or animals on a route departure. The receiver collects with a 4-digit code.
class SendGoodsScreen extends StatefulWidget {
  const SendGoodsScreen({super.key});

  @override
  State<SendGoodsScreen> createState() => _SendGoodsScreenState();
}

class _SendGoodsScreenState extends State<SendGoodsScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = where and when, 1 = what, 2 = receiver, payment and confirm
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  final Map<String, int> _qty = {}; // goods label -> how many
  String _pay = 'cash';
  String _size = 'medium';
  bool _fragile = false;
  final _declared = TextEditingController();
  Photo? _goodsPhoto;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    _receiver.dispose();
    _receiverPhone.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double get _total {
    var sum = 0.0;
    for (final g in _cat.goods) {
      sum += g.price * (_qty[g.label] ?? 0);
    }
    return sum;
  }

  Future<void> _book() async {
    final dep = _dep;
    final items = [
      for (final e in _qty.entries)
        if (e.value > 0) {'label': e.key, 'qty': e.value},
    ];
    if (dep == null) {
      setState(() => _error = tx('Choose where it goes and the departure.'));
      return;
    }
    if (items.isEmpty) {
      setState(() => _error = tx('Add what you are sending.'));
      return;
    }
    if (_receiver.text.trim().isEmpty || _receiverPhone.text.trim().isEmpty) {
      setState(() => _error = tx('Type the receiver\'s name and phone.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final id = await db.rpc('book', params: {
        'p': {
          'kind': 'goods',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'goods': items,
          'receiver_name': _receiver.text.trim(),
          'receiver_phone': _receiverPhone.text.trim(),
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
        }
      });
      try {
        await db.rpc('set_goods_extras', params: {
          'p_booking': id,
          'p_size': _size,
          'p_fragile': _fragile,
          'p_declared': double.tryParse(_declared.text.trim().replaceAll(',', '')),
          'p_photo': _goodsPhoto?.path,
        });
      } catch (_) {} // the booking is made; the details can be told to the driver by phone
      if (!mounted) return;
      toast(context, txf('Booked. Send the collection code (in My bookings) to %s.', ['${_receiver.text.trim()}']));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final routes = _cat.bookableRoutes.where((r) => r.fromName == _from).toList();
    final deps = _route == null
        ? <Departure>[]
        : _cat
            .departuresOf(_route!.id, _day)
            .where((d) => d.leavingOn(_day).isAfter(DateTime.now().subtract(const Duration(minutes: 5))))
            .toList();
    final count = _qty.values.fold<int>(0, (s, v) => s + v);
    final fromPoint = knownPlace(_route?.fromName ?? _from ?? '')?.point;
    final toPoint = (_route?.toLat != null && _route?.toLng != null) ? LatLng(_route!.toLat!, _route!.toLng!) : null;
    return Scaffold(
      appBar: navyBar('Send goods'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : MapPanel(
              wide: _step == 0 && _route == null,
              map: RouteMapView(from: fromPoint, fromName: _route?.fromName ?? '${_from ?? ''}', to: toPoint, toName: _route?.toName ?? ''),
              children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 8, left: 2),
                child: Text(
                    (_step == 0 ? tx('Step 1 of 3 · Where and when?') : _step == 1 ? tx('Step 2 of 3 · What are you sending?') : tx('Step 3 of 3 · Receiver and pay')).toUpperCase(),
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
              ),
              if (_step == 0) ...[
              formCard(
                'FROM',
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final f in _cat.fromNames)
                    ChoiceChipButton(f, selected: f == _from, onTap: () => setState(() {
                          _from = f;
                          _route = null;
                          _dep = null;
                        })),
                ]),
              ),
              const SizedBox(height: 10),
              formCard(
                'TO',
                routes.isEmpty
                    ? Text(tx('No routes yet.'), style: TextStyle(color: AppColors.muted))
                    : Wrap(spacing: 8, runSpacing: 8, children: [
                        for (final r in routes)
                          ChoiceChipButton(r.toName, selected: r.id == _route?.id, onTap: () => setState(() {
                                _route = r;
                                _dep = null;
                              })),
                      ]),
              ),
              const SizedBox(height: 10),
              formCard('DAY', DayChips(value: _day, onChanged: (d) => setState(() {
                    _day = d;
                    _dep = null;
                  }))),
              if (_route != null) ...[
                const SizedBox(height: 10),
                formCard(
                  'LEAVES AT',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final d in deps)
                      ChoiceChipButton('${d.time} ${_cat.category(_route!.categoryId)?.name.toLowerCase() ?? ''}',
                          selected: d.id == _dep?.id, onTap: () => setState(() => _dep = d)),
                    ChoiceChipButton(tx('Lorry (whole load, per km)'), selected: false, onTap: () async {
                      final nav = Navigator.of(context);
                      final done = await nav.push<bool>(
                          MaterialPageRoute(builder: (_) => const HireCarScreen(categoryName: 'Lorry', goods: true)));
                      if (done == true && mounted) nav.pop(true);
                    }),
                  ]),
                ),
              ],
              const SizedBox(height: 12),
              AppButton(tx('Next'), onPressed: _dep == null ? null : () => setState(() => _step = 1)),
              ],
              if (_step == 1) ...[
              AppCard(
                child: Row(children: [
                  const Icon(Icons.inventory_2_outlined, color: AppColors.lime600),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text('${_route?.fromName} → ${_route?.toName}\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}${_step == 2 ? ' · $count ${count == 1 ? 'item' : 'items'}' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                ]),
              ),
              const SizedBox(height: 10),
              SectionTitle(tx('WHAT')),
              if (_cat.goods.isEmpty) EmptyText(tx('No goods prices yet. Please call the office.')),
              for (final g in _cat.goods) ...[
                AppCard(
                  borderColor: (_qty[g.label] ?? 0) > 0 ? AppColors.lime : null,
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(g.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        Text(txf('%s each', ['${money(g.price)}']), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ]),
                    ),
                    IconButton(
                      tooltip: tx('Less'),
                      onPressed: () => setState(() => _qty[g.label] = ((_qty[g.label] ?? 0) - 1).clamp(0, 999)),
                      icon: const Icon(Icons.remove_circle_outline, color: AppColors.navy),
                    ),
                    Text('${_qty[g.label] ?? 0}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    IconButton(
                      tooltip: tx('More'),
                      onPressed: () => setState(() => _qty[g.label] = (_qty[g.label] ?? 0) + 1),
                      icon: const Icon(Icons.add_circle, color: AppColors.lime600),
                    ),
                  ]),
                ),
                const SizedBox(height: 6),
              ],
              const SizedBox(height: 12),
              AppButton(tx('Next'), onPressed: count == 0 ? null : () => setState(() => _step = 2)),
              ],
              if (_step == 2) ...[
              AppCard(
                child: Row(children: [
                  const Icon(Icons.inventory_2_outlined, color: AppColors.lime600),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text('${_route?.fromName} → ${_route?.toName}\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}${_step == 2 ? ' · $count ${count == 1 ? 'item' : 'items'}' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                ]),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: inputCard('RECEIVER', _receiver, hint: 'Name')),
                const SizedBox(width: 8),
                Expanded(child: inputCard('PHONE', _receiverPhone, hint: '0884 …', type: TextInputType.phone)),
              ]),
              const SizedBox(height: 10),
              formCard('SIZE', Row(children: [
                for (final e in [('small', 'Small', 'envelope'), ('medium', 'Medium', 'box / bag'), ('large', 'Large', 'sack / furniture')]) ...[
                  Expanded(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => _size = e.$1),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        margin: const EdgeInsets.only(right: 6),
                        decoration: BoxDecoration(
                          color: _size == e.$1 ? AppColors.navy : AppColors.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.navy, width: 1.5),
                        ),
                        child: Column(children: [
                          Text(tx(e.$2), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: _size == e.$1 ? Colors.white : AppColors.navy)),
                          Text(tx(e.$3), style: TextStyle(fontSize: 10, color: _size == e.$1 ? AppColors.onNavyMuted : AppColors.muted)),
                        ]),
                      ),
                    ),
                  ),
                ],
              ])),
              const SizedBox(height: 10),
              AppCard(
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(
                    width: 110,
                    child: PhotoSlot(
                      label: tx('Photo of the goods'),
                      fileLabel: 'goods',
                      photo: _goodsPhoto,
                      hint: tx('Helps the driver say yes'),
                      allowGallery: true,
                      height: 80,
                      onTaken: (p) => setState(() => _goodsPhoto = p),
                      onRemove: () => setState(() => _goodsPhoto = null),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(children: [
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        title: Text(tx('Fragile'), style: const TextStyle(fontWeight: FontWeight.w700)),
                        value: _fragile,
                        onChanged: (v) => setState(() => _fragile = v),
                      ),
                      TextField(
                        controller: _declared,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(labelText: tx('Value of the goods (K, optional)'), isDense: true, border: const OutlineInputBorder()),
                      ),
                    ]),
                  ),
                ]),
              ),
              TotalBox('TOTAL', money(_total), txf('%s items · receiver gets a code to collect', ['$count'])),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(tx('You can cancel until the driver has collected the goods.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ),
              PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
              const SizedBox(height: 10),
              ErrorLine(_error),
              const SizedBox(height: 8),
              AppButton(tx('Book goods'), loading: _busy, onPressed: _book),
              ],
            ]),
    );
  }
}
