import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../photos.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../geo.dart';
import '../../map_panel.dart';
import '../../widgets.dart';
import '../../here.dart';
import '../../ride_find.dart';
import 'catalog.dart';
import 'hire_car.dart';
import '../../i18n.dart';
import '../../route_preview.dart';

/// Send bags, parcels or animals on a route departure. The receiver collects with a 4-digit code.
class SendGoodsScreen extends StatefulWidget {
  const SendGoodsScreen({super.key});

  @override
  State<SendGoodsScreen> createState() => _SendGoodsScreenState();
}

class _SendGoodsScreenState extends State<SendGoodsScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = where and day, 1 = when, 2 = what, 3 = receiver, payment and confirm
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DepotPick? _fromPick, _toPick; // depots where the goods go on and come off
  int? _fp, _tp; // positions on the road the goods travel on (set when both depots are chosen)
  String? _road; // that road
  Map<String, FareQuote> _quotes = {}; // vehicle type id -> fare between the two depots (gives the distance)
  bool _quoting = false;
  bool _showOther = false;
  String? _time; // the departure time the sender chose, e.g. 10:00
  String? _to; // the place the goods go to; every vehicle type that goes there is offered below
  DateTime _day = DateTime.now();
  Departure? _dep;
  final Map<String, int> _qty = {}; // goods label -> how many
  String _pay = 'cash';
  String _size = 'medium';
  bool _fragile = false;
  final _declared = TextEditingController();
  Photo? _goodsPhoto;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    _receiver.dispose();
    _receiverPhone.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.allFromNames;
      _from = froms.isEmpty ? null : froms.first;
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  FareQuote? get _anyQuote => _quotes.values.isEmpty ? null : _quotes.values.first;

  /// The share of the whole road this parcel travels (1 on a plain route).
  double get _share {
    final q = _anyQuote;
    if (!_depotFlow || q == null || q.totalKm <= 0) return 1;
    return (q.km / q.totalKm).clamp(0.0, 1.0);
  }

  /// An item's list price is the price for the whole road; a shorter trip pays its share, rounded to K500, never below K500.
  double _unit(GoodsPrice g) {
    final whole = _cat.roadGoods[_road]?[g.label] ?? g.price; // a price set for this road in SQL, else the normal list
    if (_share >= 1) return whole;
    final v = (whole * _share / 500).round() * 500.0;
    return v < 500 ? 500 : v;
  }

  double get _total {
    var sum = 0.0;
    for (final g in _cat.goods) {
      sum += _unit(g) * (_qty[g.label] ?? 0);
    }
    return sum;
  }

  Future<void> _book() async {
    final dep = _dep;
    final items = [
      for (final e in _qty.entries)
        if (e.value > 0) {'label': e.key, 'qty': e.value},
    ];
    if (dep == null) {
      setState(() => _error = tx('Choose where it goes and the departure.'));
      return;
    }
    if (items.isEmpty) {
      setState(() => _error = tx('Add what you are sending.'));
      return;
    }
    if (_receiver.text.trim().isEmpty || _receiverPhone.text.trim().isEmpty) {
      setState(() => _error = tx('Type the receiver\'s name and phone.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final id = await db.rpc(_depotMode ? 'book_depot' : 'book', params: {
        'p': {
          if (_depotMode) 'from_pos': _fp,
          if (_depotMode) 'to_pos': _tp,
          'kind': 'goods',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'goods': items,
          'receiver_name': _receiver.text.trim(),
          'receiver_phone': _receiverPhone.text.trim(),
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
        }
      });
      try {
        await db.rpc('set_goods_extras', params: {
          'p_booking': id,
          'p_size': _size,
          'p_fragile': _fragile,
          'p_declared': double.tryParse(_declared.text.trim().replaceAll(',', '')),
          'p_photo': _goodsPhoto?.path,
        });
      } catch (_) {} // the booking is made; the details can be told to the driver by phone
      if (!mounted) return;
      toast(context, txf('Booked. Send the collection code (in My bookings) to %s.', ['${_receiver.text.trim()}']));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Map<String, dynamic>? _stopNamed(String? name) {
    for (final s in _cat.allStops) {
      if (s['place_name'] == name) return s;
    }
    return null;
  }

  bool get _depotFlow => _fromPick != null && _toPick != null && _fromPick!.name != _toPick!.name && _fp != null && _tp != null;
  bool get _depotMode => _fp != null && _tp != null && _route?.corridorId != null;

  /// Vehicles' through routes of the chosen road that go the right way for the chosen depots.
  List<RouteFare> get _wayRoutes {
    final road = _road;
    if (!_depotFlow || road == null) return [];
    final onRoad = _cat.stopsOf(road);
    if (onRoad.isEmpty) return [];
    final firstName = onRoad.first['place_name'];
    final fwd = _fp! < _tp!;
    return _cat.throughBookable.where((r) => r.corridorId == road && (r.fromName == firstName) == fwd).toList();
  }

  String get _routeLabel => _depotFlow
      ? '${_fromPick!.name} → ${_toPick!.name}'
      : '${_route?.fromName} → ${_route?.toName}';

  String _key(String n) => n.toLowerCase().replaceAll('depot', '').replaceAll(RegExp(r'\s+'), ' ').trim();

  /// Ordinary routes that are not already covered by the depot road.
  List<RouteFare> get _otherPlain {
    final keys = {for (final s in _cat.allStops) _key('${s['place_name']}')};
    return _cat.plainBookable.where((r) => !(keys.contains(_key(r.fromName)) && keys.contains(_key(r.toName)))).toList();
  }

  /// Finds the road that has both depots and gets the distance between them (the fare quote carries it).
  Future<void> _depotChanged() async {
    _route = null;
    _dep = null;
    _time = null;
    _quotes = {};
    _fp = null;
    _tp = null;
    _road = null;
    final from = _fromPick, to = _toPick;
    if (from == null || to == null || from.name == to.name || _cat.corridorIds.isEmpty) {
      if (mounted) setState(() {});
      return;
    }
    String? road; // the shorter road when two roads have both depots
    for (final id in _cat.corridorIds.reversed) {
      if (_cat.posIn(id, from.name) != null && _cat.posIn(id, to.name) != null) {
        road = id;
        break;
      }
    }
    final fp = road == null ? null : _cat.posIn(road, from.name);
    final tp = road == null ? null : _cat.posIn(road, to.name);
    if (road == null || fp == null || tp == null) {
      if (mounted) {
        setState(() => _error = tx('Goods cannot go between those two depots on one vehicle. Choose other depots or call the office.'));
      }
      return;
    }
    setState(() {
      _quoting = true;
      _error = null;
    });
    try {
      final q = await loadQuotes(road, fp, tp);
      if (mounted && from == _fromPick && to == _toPick) {
        setState(() {
          _road = road;
          _fp = fp;
          _tp = tp;
          _quotes = q;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
    if (mounted) setState(() => _quoting = false);
  }

  /// Search sheet: any place, My location or a pin, matched to the nearest depot.
  Future<void> _pickDepot({required bool boarding}) async {
    final picked = await showModalBottomSheet<DepotPick>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface100,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => DepotSearch(
        stops: _cat.pickerStops(boarding),
        near: Here.instance.point.value,
      ),
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (boarding) {
        _fromPick = picked;
        if (_toPick?.name == picked.name) _toPick = null;
      } else {
        _toPick = picked;
        if (_fromPick?.name == picked.name) _fromPick = null;
      }
      _to = null; // a depot choice replaces a place choice
    });
    _depotChanged();
  }

  @override
  Widget build(BuildContext context) {
    final others = (_cat.throughBookable.isNotEmpty && _cat.allStops.isNotEmpty) ? _otherPlain : _cat.plainBookable;
    final routes = others.where((r) => r.fromName == _from).toList();
    final hasDepots = _cat.throughBookable.isNotEmpty && _cat.allStops.isNotEmpty;
    final fromNames = {for (final r in others) r.fromName}.toList()..sort();
    final toNames = {for (final r in routes) r.toName}.toList()..sort();
    final matching = routes.where((r) => r.toName == _to).toList();
    final cutoff = DateTime.now().subtract(const Duration(minutes: 5));
    final deps = <(RouteFare, Departure)>[
      for (final r in matching)
        for (final d in _cat.departuresOf(r.id, _day))
          if (d.leavingOn(_day).isAfter(cutoff)) (r, d),
    ]..sort((a, b) => a.$2.leavesAt.compareTo(b.$2.leavesAt));
    final depotDeps = <(RouteFare, Departure)>[
      for (final r in _wayRoutes)
        for (final d in _cat.departuresOf(r.id, _day))
          if (d.leavingOn(_day).isAfter(cutoff)) (r, d),
    ]..sort((a, b) => a.$2.leavesAt.compareTo(b.$2.leavesAt));
    final rideList = _depotFlow ? depotDeps : (_to != null ? deps : <(RouteFare, Departure)>[]);
    final times = <String>[];
    for (final rd in rideList) {
      if (!times.contains(rd.$2.time)) times.add(rd.$2.time);
    }
    final atTime = rideList.where((rd) => rd.$2.time == _time).toList();
    final fs = _fromPick != null ? _stopNamed(_fromPick!.name) : null;
    final ts = _toPick != null ? _stopNamed(_toPick!.name) : null;
    final shown = _route ?? matching.firstOrNull;
    final count = _qty.values.fold<int>(0, (s, v) => s + v);
    final fromPoint = fs != null ? LatLng(toDouble(fs['lat']), toDouble(fs['lng'])) : knownPlace(shown?.fromName ?? _from ?? '')?.point;
    final toPoint = ts != null
        ? LatLng(toDouble(ts['lat']), toDouble(ts['lng']))
        : ((shown?.toLat != null && shown?.toLng != null) ? LatLng(shown!.toLat!, shown.toLng!) : null);
    final canNext = _depotFlow ? _quotes.isNotEmpty : _to != null;
    final q = _anyQuote;
    return Scaffold(
      appBar: navyBar('Send goods'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : MapPanel(
              wide: _step == 0 && shown == null && fs == null,
              map: RouteMapView(from: fromPoint, fromName: fs != null ? '${fs['place_name']}' : (shown?.fromName ?? '${_from ?? ''}'), to: toPoint, toName: ts != null ? '${ts['place_name']}' : (shown?.toName ?? '')),
              children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 8, left: 2),
                child: Text(
                    (_step == 0 ? tx('Step 1 of 4 · Where to?') : _step == 1 ? tx('Step 2 of 4 · When does it go?') : _step == 2 ? tx('Step 3 of 4 · What are you sending?') : tx('Step 4 of 4 · Receiver and pay')).toUpperCase(),
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: AppColors.muted)),
              ),
              if (_step == 0) ...[
              if (hasDepots) ...[
                DepotField(label: 'FROM', verb: 'Hand it in at', pick: _fromPick, onTap: () => _pickDepot(boarding: true)),
                const SizedBox(height: 10),
                DepotField(label: 'TO', verb: 'Collected at', pick: _toPick, onTap: () => _pickDepot(boarding: false)),
                if (_quoting) const Padding(padding: EdgeInsets.only(top: 10), child: LinearProgressIndicator()),
                if (_fromPick != null && _toPick != null && _fromPick!.name == _toPick!.name)
                  Padding(padding: const EdgeInsets.only(top: 8), child: Text(tx('Choose two different depots.'), style: const TextStyle(color: AppColors.danger))),
                if (_otherPlain.isNotEmpty)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () => setState(() => _showOther = !_showOther),
                      child: Text(_showOther ? tx('Hide other routes') : tx('Other routes')),
                    ),
                  ),
              ],
              if ((!hasDepots || _showOther) && others.isNotEmpty) ...[
              const SizedBox(height: 10),
              formCard(
                'FROM',
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final f in fromNames)
                    ChoiceChipButton(f, selected: f == _from, onTap: () => setState(() {
                          _from = f;
                          _to = null;
                          _fromPick = _toPick = null;
                          _quotes = {};
                          _route = null;
                          _dep = null;
                          _time = null;
                        })),
                ]),
              ),
              const SizedBox(height: 10),
              formCard(
                'TO',
                routes.isEmpty
                    ? Text(tx('No routes yet.'), style: TextStyle(color: AppColors.muted))
                    : Wrap(spacing: 8, runSpacing: 8, children: [
                        for (final n in toNames)
                          ChoiceChipButton(n, selected: n == _to, onTap: () => setState(() {
                                _to = n;
                                _fromPick = _toPick = null;
                                _quotes = {};
                                _route = null;
                                _dep = null;
                                _time = null;
                              })),
                      ]),
              ),
              ],
              const SizedBox(height: 10),
              formCard('DAY', DayChips(value: _day, onChanged: (d) => setState(() {
                    _day = d;
                    _dep = null;
                    _route = null;
                    _time = null;
                  }))),
              const SizedBox(height: 12),
              AppButton(tx('Next'), onPressed: canNext ? () => setState(() => _step = 1) : null),
              ],
              if (_step == 1) ...[
              AppCard(
                child: Row(children: [
                  const Icon(Icons.inventory_2_outlined, color: AppColors.lime600),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text('${_depotFlow ? '${_fromPick!.name} → ${_toPick!.name}' : '${_from ?? ''} → ${_to ?? ''}'}\n${dayName(_day)}${q != null ? ' · ${kmText(q.km)}' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  TextButton(onPressed: () => setState(() => _step = 0), child: Text(tx('Back'))),
                ]),
              ),
              const SizedBox(height: 10),
              formCard(
                'LEAVES AT',
                times.isEmpty
                    ? Text(tx('No departure on this day.'), style: TextStyle(color: AppColors.muted))
                    : Wrap(spacing: 8, runSpacing: 8, children: [
                        // one chip per time, not one per vehicle
                        for (final t in times)
                          ChoiceChipButton(t, selected: t == _time, onTap: () => setState(() {
                                _time = t;
                                final first = rideList.firstWhere((rd) => rd.$2.time == t);
                                _route = first.$1;
                                _dep = first.$2;
                              })),
                      ]),
              ),
              if (_time != null && atTime.isNotEmpty) ...[
                const SizedBox(height: 10),
                formCard(
                  'CARRIED BY',
                  Column(children: [
                    for (final rd in atTime)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () => setState(() {
                            _route = rd.$1;
                            _dep = rd.$2;
                          }),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: rd.$2.id == _dep?.id ? AppColors.lime100 : AppColors.surface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: rd.$2.id == _dep?.id ? AppColors.navy : AppColors.line, width: 2),
                            ),
                            child: Row(children: [
                              VehicleTile(_cat.category(rd.$1.categoryId)?.name ?? '', width: 44),
                              const SizedBox(width: 10),
                              Expanded(child: Text(_cat.category(rd.$1.categoryId)?.name ?? '', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy))),
                              if (rd.$2.id == _dep?.id) const Icon(Icons.check_circle, color: AppColors.lime600),
                            ]),
                          ),
                        ),
                      ),
                    Text(tx('Goods are priced by the items, not by the vehicle.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
              ],
              const SizedBox(height: 10),
              ChoiceChipButton(tx('Lorry (whole load, per km)'), selected: false, onTap: () async {
                final nav = Navigator.of(context);
                final done = await nav.push<bool>(MaterialPageRoute(builder: (_) => const HireCarScreen(categoryName: 'Lorry', goods: true)));
                if (done == true && mounted) nav.pop(true);
              }),
              const SizedBox(height: 12),
              AppButton(tx('Next'), onPressed: _dep == null ? null : () => setState(() => _step = 2)),
              ],
              if (_step == 2) ...[
              AppCard(
                child: Row(children: [
                  const Icon(Icons.inventory_2_outlined, color: AppColors.lime600),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text('$_routeLabel\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}${_step == 3 ? ' · $count ${count == 1 ? 'item' : 'items'}' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                ]),
              ),
              const SizedBox(height: 10),
              SectionTitle(tx('WHAT')),
              if (_cat.goods.isEmpty) EmptyText(tx('No goods prices yet. Please call the office.')),
              for (final g in _cat.goods) ...[
                AppCard(
                  borderColor: (_qty[g.label] ?? 0) > 0 ? AppColors.lime : null,
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(g.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        Text(txf('%s each', ['${money(_unit(g))}']), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ]),
                    ),
                    IconButton(
                      tooltip: tx('Less'),
                      onPressed: () => setState(() => _qty[g.label] = ((_qty[g.label] ?? 0) - 1).clamp(0, 999)),
                      icon: const Icon(Icons.remove_circle_outline, color: AppColors.navy),
                    ),
                    Text('${_qty[g.label] ?? 0}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    IconButton(
                      tooltip: tx('More'),
                      onPressed: () => setState(() => _qty[g.label] = (_qty[g.label] ?? 0) + 1),
                      icon: const Icon(Icons.add_circle, color: AppColors.lime600),
                    ),
                  ]),
                ),
                const SizedBox(height: 6),
              ],
              if (_share < 1 && q != null) ...[
                const SizedBox(height: 4),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    FieldLabel(tx('HOW THE PRICE IS WORKED OUT')),
                    const SizedBox(height: 4),
                    Text(txf('%s of the %s road = %s%', [kmText(q.km), kmText(q.totalKm), (_share * 100).round().toString()]), style: const TextStyle(fontSize: 13, height: 1.5)),
                    Text(tx('Each price in the list is for the whole road. You pay this share, rounded to K500, never less than K500 per item.'),
                        style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
              ],
              const SizedBox(height: 12),
              AppButton(tx('Next'), onPressed: count == 0 ? null : () => setState(() => _step = 3)),
              ],
              if (_step == 3) ...[
              AppCard(
                child: Row(children: [
                  const Icon(Icons.inventory_2_outlined, color: AppColors.lime600),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text('$_routeLabel\n${dayName(_day)}${_dep != null ? ' · ${_dep!.time}' : ''}${_step == 3 ? ' · $count ${count == 1 ? 'item' : 'items'}' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                ]),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: inputCard('RECEIVER', _receiver, hint: 'Name')),
                const SizedBox(width: 8),
                Expanded(child: inputCard('PHONE', _receiverPhone, hint: '0884 …', type: TextInputType.phone)),
              ]),
              const SizedBox(height: 10),
              formCard('SIZE', Row(children: [
                for (final e in [('small', 'Small', 'envelope'), ('medium', 'Medium', 'box / bag'), ('large', 'Large', 'sack / furniture')]) ...[
                  Expanded(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => _size = e.$1),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        margin: const EdgeInsets.only(right: 6),
                        decoration: BoxDecoration(
                          color: _size == e.$1 ? AppColors.navy : AppColors.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.navy, width: 1.5),
                        ),
                        child: Column(children: [
                          Text(tx(e.$2), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: _size == e.$1 ? Colors.white : AppColors.navy)),
                          Text(tx(e.$3), style: TextStyle(fontSize: 10, color: _size == e.$1 ? AppColors.onNavyMuted : AppColors.muted)),
                        ]),
                      ),
                    ),
                  ),
                ],
              ])),
              const SizedBox(height: 10),
              AppCard(
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(
                    width: 110,
                    child: PhotoSlot(
                      label: tx('Photo of the goods'),
                      fileLabel: 'goods',
                      photo: _goodsPhoto,
                      hint: tx('Helps the driver say yes'),
                      allowGallery: true,
                      height: 80,
                      onTaken: (p) => setState(() => _goodsPhoto = p),
                      onRemove: () => setState(() => _goodsPhoto = null),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(children: [
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        title: Text(tx('Fragile'), style: const TextStyle(fontWeight: FontWeight.w700)),
                        value: _fragile,
                        onChanged: (v) => setState(() => _fragile = v),
                      ),
                      TextField(
                        controller: _declared,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(labelText: tx('Value of the goods (K, optional)'), isDense: true, border: const OutlineInputBorder()),
                      ),
                    ]),
                  ),
                ]),
              ),
              TotalBox('TOTAL', money(_total), txf('%s items · receiver gets a code to collect', ['$count'])),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(tx('You can cancel until the driver has collected the goods.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ),
              PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
              const SizedBox(height: 10),
              ErrorLine(_error),
              const SizedBox(height: 8),
              AppButton(tx('Book goods'), loading: _busy, onPressed: _book),
              ],
            ]),
    );
  }
}
