import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import 'catalog.dart';
import 'hire_car.dart';
import '../../i18n.dart';

/// Send bags, parcels or animals on a route departure. The receiver collects with a 4-digit code.
class SendGoodsScreen extends StatefulWidget {
  const SendGoodsScreen({super.key});

  @override
  State<SendGoodsScreen> createState() => _SendGoodsScreenState();
}

class _SendGoodsScreenState extends State<SendGoodsScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  bool _loading = true;
  bool _busy = false;
  String? _error;
  String? _from;
  RouteFare? _route;
  DateTime _day = DateTime.now();
  Departure? _dep;
  final Map<String, int> _qty = {}; // goods label -> how many
  String _pay = 'cash';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    _receiver.dispose();
    _receiverPhone.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await _cat.load();
      final froms = _cat.fromNames;
      _from = froms.isEmpty ? null : froms.first;
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double get _total {
    var sum = 0.0;
    for (final g in _cat.goods) {
      sum += g.price * (_qty[g.label] ?? 0);
    }
    return sum;
  }

  Future<void> _book() async {
    final dep = _dep;
    final items = [
      for (final e in _qty.entries)
        if (e.value > 0) {'label': e.key, 'qty': e.value},
    ];
    if (dep == null) {
      setState(() => _error = 'Choose where it goes and the departure.');
      return;
    }
    if (items.isEmpty) {
      setState(() => _error = 'Add what you are sending.');
      return;
    }
    if (_receiver.text.trim().isEmpty || _receiverPhone.text.trim().isEmpty) {
      setState(() => _error = 'Type the receiver\'s name and phone.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('book', params: {
        'p': {
          'kind': 'goods',
          'departure_id': dep.id,
          'travel_on': isoDate(_day),
          'goods': items,
          'receiver_name': _receiver.text.trim(),
          'receiver_phone': _receiverPhone.text.trim(),
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
        }
      });
      if (!mounted) return;
      toast(context, txf('Booked. Send the collection code (in My bookings) to %s.', ['${_receiver.text.trim()}']));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final routes = _cat.bookableRoutes.where((r) => r.fromName == _from).toList();
    final deps = _route == null
        ? <Departure>[]
        : _cat
            .departuresOf(_route!.id, _day)
            .where((d) => d.leavingOn(_day).isAfter(DateTime.now().subtract(const Duration(minutes: 5))))
            .toList();
    final count = _qty.values.fold<int>(0, (s, v) => s + v);
    return Scaffold(
      appBar: navyBar('Send goods'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              formCard(
                'FROM',
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final f in _cat.fromNames)
                    ChoiceChipButton(f, selected: f == _from, onTap: () => setState(() {
                          _from = f;
                          _route = null;
                          _dep = null;
                        })),
                ]),
              ),
              const SizedBox(height: 10),
              formCard(
                'TO',
                routes.isEmpty
                    ? Text(tx('No routes yet.'), style: TextStyle(color: AppColors.muted))
                    : Wrap(spacing: 8, runSpacing: 8, children: [
                        for (final r in routes)
                          ChoiceChipButton(r.toName, selected: r.id == _route?.id, onTap: () => setState(() {
                                _route = r;
                                _dep = null;
                              })),
                      ]),
              ),
              const SizedBox(height: 10),
              formCard('DAY', DayChips(value: _day, onChanged: (d) => setState(() {
                    _day = d;
                    _dep = null;
                  }))),
              if (_route != null) ...[
                const SizedBox(height: 10),
                formCard(
                  'ON THE',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final d in deps)
                      ChoiceChipButton('${d.time} ${_cat.category(_route!.categoryId)?.name.toLowerCase() ?? ''}',
                          selected: d.id == _dep?.id, onTap: () => setState(() => _dep = d)),
                    ChoiceChipButton(tx('Lorry (whole load, per km)'), selected: false, onTap: () async {
                      final nav = Navigator.of(context);
                      final done = await nav.push<bool>(
                          MaterialPageRoute(builder: (_) => const HireCarScreen(categoryName: 'Lorry', goods: true)));
                      if (done == true && mounted) nav.pop(true);
                    }),
                  ]),
                ),
              ],
              const SizedBox(height: 10),
              SectionTitle(tx('WHAT')),
              if (_cat.goods.isEmpty) EmptyText(tx('No goods prices yet. Please call the office.')),
              for (final g in _cat.goods) ...[
                AppCard(
                  borderColor: (_qty[g.label] ?? 0) > 0 ? AppColors.lime : null,
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(g.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        Text(txf('%s each', ['${money(g.price)}']), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ]),
                    ),
                    IconButton(
                      tooltip: tx('Less'),
                      onPressed: () => setState(() => _qty[g.label] = ((_qty[g.label] ?? 0) - 1).clamp(0, 999)),
                      icon: const Icon(Icons.remove_circle_outline, color: AppColors.navy),
                    ),
                    Text('${_qty[g.label] ?? 0}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    IconButton(
                      tooltip: tx('More'),
                      onPressed: () => setState(() => _qty[g.label] = (_qty[g.label] ?? 0) + 1),
                      icon: const Icon(Icons.add_circle, color: AppColors.lime600),
                    ),
                  ]),
                ),
                const SizedBox(height: 6),
              ],
              const SizedBox(height: 6),
              Row(children: [
                Expanded(child: inputCard('RECEIVER', _receiver, hint: 'Name')),
                const SizedBox(width: 8),
                Expanded(child: inputCard('PHONE', _receiverPhone, hint: '0884 …', type: TextInputType.phone)),
              ]),
              TotalBox('TOTAL', money(_total), '$count items · receiver gets a code to collect'),
              PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
              const SizedBox(height: 10),
              ErrorLine(_error),
              const SizedBox(height: 8),
              AppButton(tx('Book goods'), loading: _busy, onPressed: _book),
            ]),
    );
  }
}
