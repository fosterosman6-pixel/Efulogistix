import 'package:flutter/material.dart';
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';
import '../../i18n.dart';

/// Routes, timetable, vehicle types and goods prices that passengers book from.
class Catalog {
  List<VehicleCategory> categories = [];
  List<RouteFare> routes = [];
  List<Departure> departures = [];
  List<GoodsPrice> goods = [];
  List<Map<String, dynamic>> stops = []; // depots of the longest road, in order (goods use this)
  List<Map<String, dynamic>> allStops = []; // depots of every road
  List<String> corridorIds = []; // roads, the one with most depots first

  List<Map<String, dynamic>> stopsOf(String corridor) => allStops.where((s) => s['corridor_id'] == corridor).toList();

  int? posIn(String corridor, String name) {
    for (final s in allStops) {
      if (s['corridor_id'] == corridor && s['place_name'] == name) return s['pos'] as int;
    }
    return null;
  }

  /// Every depot once (a depot on two roads is listed once), for the search box.
  List<Map<String, dynamic>> pickerStops(bool boarding) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final id in corridorIds) {
      for (final s in stopsOf(id)) {
        if (s[boarding ? 'can_board' : 'can_drop'] != true) continue;
        if (seen.add('${s['place_name']}')) out.add(s);
      }
    }
    return out;
  }
  String officePhone = '';

  /// Loads the timetable. With no signal the last copy saved on this phone is used.
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('vehicle_categories').select().eq('active', true).order('name'),
        db.from('routes').select().eq('active', true).order('to_name'),
        db.from('departures').select().eq('active', true).order('leaves_at'),
        db.from('goods_prices').select().eq('active', true).order('label'),
        db.from('app_settings').select(),
        db.from('corridor_stops').select().order('pos'),
        db.from('transfer_points').select(),
      ]);
      try {
        await prefs.setString('cache_catalog', jsonEncode(r));
      } catch (_) {}
      _apply(r);
    } catch (e) {
      final raw = prefs.getString('cache_catalog');
      if (raw == null) rethrow;
      _apply((jsonDecode(raw) as List)
          .map((l) => (l as List).map((x) => Map<String, dynamic>.from(x as Map)).toList())
          .toList());
      offline = true;
    }
  }

  bool offline = false;

  void _apply(List<List<Map<String, dynamic>>> r) {
    categories = r[0].map(VehicleCategory.fromMap).toList();
    routes = r[1].map(RouteFare.fromMap).toList();
    departures = r[2].map(Departure.fromMap).toList();
    goods = r[3].map(GoodsPrice.fromMap).toList();
    allStops = r.length > 5 ? r[5] : [];
    final count = <String, int>{};
    for (final s in allStops) {
      count['${s['corridor_id']}'] = (count['${s['corridor_id']}'] ?? 0) + 1;
    }
    corridorIds = count.keys.toList()..sort((a, b) => count[b]!.compareTo(count[a]!));
    // the long road is the one named in the change points (set in the database); with none set, the road with most depots
    final long = r.length > 6 && r[6].isNotEmpty ? '${r[6].first['corridor_a']}' : null;
    if (long != null && corridorIds.remove(long)) corridorIds.insert(0, long);
    stops = corridorIds.isEmpty ? [] : stopsOf(corridorIds.first);
    officePhone = r[4].isEmpty ? '' : (r[4].first['office_phone'] ?? '').toString();
  }

  VehicleCategory? category(String? id) {
    for (final c in categories) {
      if (c.id == id) return c;
    }
    return null;
  }

  RouteFare? route(String? id) {
    for (final r in routes) {
      if (r.id == id) return r;
    }
    return null;
  }

  /// Routes that have at least one departure in the timetable.
  List<RouteFare> get bookableRoutes {
    final withDep = departures.map((d) => d.routeId).toSet();
    return routes.where((r) => withDep.contains(r.id)).toList();
  }

  /// Ordinary routes (not the whole road with depots).
  List<RouteFare> get plainBookable => bookableRoutes.where((r) => r.corridorId == null).toList();

  /// The whole road with depots, one per vehicle type and direction, that has departures.
  List<RouteFare> get throughBookable => bookableRoutes.where((r) => r.corridorId != null && r.through).toList();

  List<String> get allFromNames => {for (final r in bookableRoutes) r.fromName}.toList()..sort();

  List<String> get fromNames => {for (final r in plainBookable) r.fromName}.toList()..sort();

  List<Departure> departuresOf(String routeId, DateTime day) =>
      departures.where((d) => d.routeId == routeId && d.runsOn(day)).toList()..sort((a, b) => a.leavesAt.compareTo(b.leavesAt));

  List<VehicleCategory> get forHire => categories.where((c) => c.forHire).toList()..sort((a, b) => a.hirePerKm.compareTo(b.hirePerKm));
}

/// Free seats per departure for one day: { departure id: (seats, booked) }.
Future<Map<String, (int, int)>> seatsOn(DateTime day) async {
  final rows = await db.rpc('departure_seats', params: {'p_day': _iso(day)});
  final out = <String, (int, int)>{};
  if (rows is List) {
    for (final r in rows.whereType<Map>()) {
      out[r['departure_id'].toString()] = (toInt(r['seats']), toInt(r['booked']));
    }
  }
  return out;
}

String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String isoDate(DateTime d) => _iso(d);

/// "Today", "Tomorrow", "Wed 28 Oct"
String dayName(DateTime d) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final x = DateTime(d.year, d.month, d.day);
  final diff = x.difference(today).inDays;
  if (diff == 0) return tx('Today');
  if (diff == 1) return tx('Tomorrow');
  return '${weekdayShort(d.weekday)} ${shortDate(d)}';
}

/// How the passenger pays, with the mobile money reference when needed.
class PayPicker extends StatelessWidget {
  final String method;
  final ValueChanged<String> onChanged;
  final TextEditingController reference;
  const PayPicker({super.key, required this.method, required this.onChanged, required this.reference});

  @override
  Widget build(BuildContext context) {
    final hasAccount = appState.profile?.accountId != null;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SectionTitle(tx('PAY')),
      const SizedBox(height: 4),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final e in payNames.entries)
          if (e.key != 'account' || hasAccount)
            ChoiceChipButton(e.value, selected: method == e.key, onTap: () => onChanged(e.key)),
      ]),
      if (method == 'airtel_money' || method == 'tnm_mpamba') ...[
        const SizedBox(height: 8),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            FieldLabel(method == 'airtel_money' ? tx('AIRTEL MONEY REFERENCE (FROM THE SMS)') : tx('MPAMBA REFERENCE (FROM THE SMS)')),
            TextField(
              controller: reference,
              textCapitalization: TextCapitalization.characters,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.\-]'))],
              decoration: const InputDecoration(hintText: 'e.g. CI261026.1544.K73022', border: InputBorder.none, isDense: true),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            Text(tx('Send the money to the EfuLogistix number first, then type the reference.'),
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
      ],
      if (method == 'account')
        Padding(
          padding: EdgeInsets.only(top: 6),
          child: Text(tx('Charged to your company. You pay nothing to the driver.'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
        ),
    ]);
  }
}

/// Big total box at the bottom of a booking form.
class TotalBox extends StatelessWidget {
  final String label;
  final String amount;
  final String note;
  const TotalBox(this.label, this.amount, this.note, {super.key});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tx(label), style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12, fontWeight: FontWeight.w700)),
              Text(tx(note), style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
            ]),
          ),
          Text(amount, style: const TextStyle(color: AppColors.lime, fontSize: 26, fontWeight: FontWeight.w800)),
        ]),
      );
}

/// A row of day chips: today and the next days, plus a calendar.
class DayChips extends StatelessWidget {
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  const DayChips({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final days = [for (var i = 0; i < 3; i++) today.add(Duration(days: i))];
    final picked = DateTime(value.year, value.month, value.day);
    return Wrap(spacing: 8, runSpacing: 8, children: [
      for (final d in days) ChoiceChipButton(dayName(d), selected: d == picked, onTap: () => onChanged(d)),
      ChoiceChipButton(
        days.contains(picked) ? tx('Other day') : dayName(picked),
        selected: !days.contains(picked),
        onTap: () async {
          final d = await showDatePicker(
            context: context,
            initialDate: picked,
            firstDate: today,
            lastDate: today.add(const Duration(days: 60)),
          );
          if (d != null) onChanged(d);
        },
      ),
    ]);
  }
}

Widget formCard(String label, Widget child) => AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        FieldLabel(label),
        const SizedBox(height: 6),
        child,
      ]),
    );

/// Plain input inside a card.
Widget inputCard(String label, TextEditingController c, {String? hint, TextInputType? type}) => AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        FieldLabel(label),
        TextField(
          controller: c,
          keyboardType: type,
          decoration: InputDecoration(hintText: hint == null ? null : tx(hint), border: InputBorder.none, isDense: true),
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ]),
    );

PreferredSizeWidget navyBar(String title) => AppBar(
      title: Text(tx(title), style: const TextStyle(fontWeight: FontWeight.w800)),
      backgroundColor: AppColors.navy,
      foregroundColor: Colors.white,
    );
