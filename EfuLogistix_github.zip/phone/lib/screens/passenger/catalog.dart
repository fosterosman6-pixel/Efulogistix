import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app_state.dart';
import '../../format.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../widgets.dart';

/// Routes, timetable, vehicle types and goods prices that passengers book from.
class Catalog {
  List<VehicleCategory> categories = [];
  List<RouteFare> routes = [];
  List<Departure> departures = [];
  List<GoodsPrice> goods = [];
  String officePhone = '';

  Future<void> load() async {
    final r = await Future.wait<List<Map<String, dynamic>>>([
      db.from('vehicle_categories').select().eq('active', true).order('name'),
      db.from('routes').select().eq('active', true).order('to_name'),
      db.from('departures').select().eq('active', true).order('leaves_at'),
      db.from('goods_prices').select().eq('active', true).order('label'),
      db.from('app_settings').select(),
    ]);
    categories = r[0].map(VehicleCategory.fromMap).toList();
    routes = r[1].map(RouteFare.fromMap).toList();
    departures = r[2].map(Departure.fromMap).toList();
    goods = r[3].map(GoodsPrice.fromMap).toList();
    officePhone = r[4].isEmpty ? '' : (r[4].first['office_phone'] ?? '').toString();
  }

  VehicleCategory? category(String? id) {
    for (final c in categories) {
      if (c.id == id) return c;
    }
    return null;
  }

  RouteFare? route(String? id) {
    for (final r in routes) {
      if (r.id == id) return r;
    }
    return null;
  }

  /// Routes that have at least one departure in the timetable.
  List<RouteFare> get bookableRoutes {
    final withDep = departures.map((d) => d.routeId).toSet();
    return routes.where((r) => withDep.contains(r.id)).toList();
  }

  List<String> get fromNames => {for (final r in bookableRoutes) r.fromName}.toList()..sort();

  List<Departure> departuresOf(String routeId, DateTime day) =>
      departures.where((d) => d.routeId == routeId && d.runsOn(day)).toList()..sort((a, b) => a.leavesAt.compareTo(b.leavesAt));

  List<VehicleCategory> get forHire => categories.where((c) => c.forHire).toList()..sort((a, b) => a.hirePerKm.compareTo(b.hirePerKm));
}

/// Free seats per departure for one day: { departure id: (seats, booked) }.
Future<Map<String, (int, int)>> seatsOn(DateTime day) async {
  final rows = await db.rpc('departure_seats', params: {'p_day': _iso(day)});
  final out = <String, (int, int)>{};
  if (rows is List) {
    for (final r in rows.whereType<Map>()) {
      out[r['departure_id'].toString()] = (toInt(r['seats']), toInt(r['booked']));
    }
  }
  return out;
}

String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String isoDate(DateTime d) => _iso(d);

/// "Today", "Tomorrow", "Wed 28 Oct"
String dayName(DateTime d) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final x = DateTime(d.year, d.month, d.day);
  final diff = x.difference(today).inDays;
  if (diff == 0) return 'Today';
  if (diff == 1) return 'Tomorrow';
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return '${days[d.weekday - 1]} ${shortDate(d)}';
}

/// How the passenger pays, with the mobile money reference when needed.
class PayPicker extends StatelessWidget {
  final String method;
  final ValueChanged<String> onChanged;
  final TextEditingController reference;
  const PayPicker({super.key, required this.method, required this.onChanged, required this.reference});

  @override
  Widget build(BuildContext context) {
    final hasAccount = appState.profile?.accountId != null;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SectionTitle('PAY'),
      const SizedBox(height: 4),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final e in payNames.entries)
          if (e.key != 'account' || hasAccount)
            ChoiceChipButton(e.value, selected: method == e.key, onTap: () => onChanged(e.key)),
      ]),
      if (method == 'airtel_money' || method == 'tnm_mpamba') ...[
        const SizedBox(height: 8),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            FieldLabel(method == 'airtel_money' ? 'AIRTEL MONEY REFERENCE (FROM THE SMS)' : 'MPAMBA REFERENCE (FROM THE SMS)'),
            TextField(
              controller: reference,
              textCapitalization: TextCapitalization.characters,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.\-]'))],
              decoration: const InputDecoration(hintText: 'e.g. CI261026.1544.K73022', border: InputBorder.none, isDense: true),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const Text('Send the money to the EfuLogistix number first, then type the reference.',
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
      ],
      if (method == 'account')
        const Padding(
          padding: EdgeInsets.only(top: 6),
          child: Text('Charged to your company. You pay nothing to the driver.', style: TextStyle(fontSize: 12, color: AppColors.muted)),
        ),
    ]);
  }
}

/// Big total box at the bottom of a booking form.
class TotalBox extends StatelessWidget {
  final String label;
  final String amount;
  final String note;
  const TotalBox(this.label, this.amount, this.note, {super.key});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12, fontWeight: FontWeight.w700)),
              Text(note, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
            ]),
          ),
          Text(amount, style: const TextStyle(color: AppColors.lime, fontSize: 26, fontWeight: FontWeight.w800)),
        ]),
      );
}

/// A row of day chips: today and the next days, plus a calendar.
class DayChips extends StatelessWidget {
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  const DayChips({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final days = [for (var i = 0; i < 3; i++) today.add(Duration(days: i))];
    final picked = DateTime(value.year, value.month, value.day);
    return Wrap(spacing: 8, runSpacing: 8, children: [
      for (final d in days) ChoiceChipButton(dayName(d), selected: d == picked, onTap: () => onChanged(d)),
      ChoiceChipButton(
        days.contains(picked) ? 'Other day' : dayName(picked),
        selected: !days.contains(picked),
        onTap: () async {
          final d = await showDatePicker(
            context: context,
            initialDate: picked,
            firstDate: today,
            lastDate: today.add(const Duration(days: 60)),
          );
          if (d != null) onChanged(d);
        },
      ),
    ]);
  }
}

Widget formCard(String label, Widget child) => AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        FieldLabel(label),
        const SizedBox(height: 6),
        child,
      ]),
    );

/// Plain input inside a card.
Widget inputCard(String label, TextEditingController c, {String? hint, TextInputType? type}) => AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        FieldLabel(label),
        TextField(
          controller: c,
          keyboardType: type,
          decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true),
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ]),
    );

PreferredSizeWidget navyBar(String title) => AppBar(
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      backgroundColor: AppColors.navy,
      foregroundColor: Colors.white,
    );
