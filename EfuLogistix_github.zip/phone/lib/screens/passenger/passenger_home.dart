import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'book_seat.dart';
import 'catalog.dart';
import 'hire_car.dart';
import 'my_bookings.dart';
import 'send_goods.dart';

/// Passenger app: Home (book), My bookings, Account.
class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});

  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  int _tab = 0;
  final _bookingsKey = GlobalKey<MyBookingsTabState>();

  Future<void> _open(Widget screen) async {
    final booked = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => screen));
    if (booked == true && mounted) {
      setState(() => _tab = 1);
      _bookingsKey.currentState?.load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final body = switch (_tab) {
      0 => _HomeTab(open: _open, showBookings: () => setState(() => _tab = 1)),
      1 => MyBookingsTab(key: _bookingsKey),
      _ => const _AccountTab(),
    };
    return Scaffold(
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), selectedIcon: Icon(Icons.confirmation_number), label: 'My bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatefulWidget {
  final Future<void> Function(Widget) open;
  final VoidCallback showBookings;
  const _HomeTab({required this.open, required this.showBookings});

  @override
  State<_HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<_HomeTab> {
  Booking? _next;
  String? _nextLine;
  String? _nextCategory;
  String _officePhone = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('passenger_id', me.id)
          .inFilter('status', ['requested', 'assigned', 'picked_up'])
          .order('pickup_at')
          .limit(1);
      final settings = await db.from('app_settings').select();
      final next = rows.isEmpty ? null : Booking.fromMap(rows.first);
      String? line;
      String? cat;
      if (next != null) {
        final info = BookingInfo();
        await info.load([next]);
        final truck = info.trucks[next.truckId];
        final driver = info.people[next.driverId];
        cat = info.categories[next.categoryId]?.name;
        line = [
          '${dayName(next.pickupAt)} ${clock(next.pickupAt)}',
          if (next.kind == 'seat') '${next.seats} ${next.seats == 1 ? 'seat' : 'seats'}',
          if (truck != null) truck.plate,
          if (driver != null) driver.firstName,
        ].join(' · ');
      }
      if (!mounted) return;
      setState(() {
        _next = next;
        _nextLine = line;
        _nextCategory = cat;
        _officePhone = settings.isEmpty ? '' : (settings.first['office_phone'] ?? '').toString();
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    final next = _next;
    return Container(
      color: AppColors.surface100,
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Container(
            color: AppColors.navy,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 8, 22),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const ProfileHeader(),
                  const SizedBox(height: 14),
                  Text('Muli bwanji, ${me?.firstName ?? ''}', style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
                  const Text('Where are you going?', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (next != null) ...[
                InkWell(
                  onTap: widget.showBookings,
                  borderRadius: BorderRadius.circular(12),
                  child: AppCard(
                    borderColor: next.status == 'assigned' ? AppColors.lime : AppColors.line,
                    child: Row(children: [
                      VehicleTile(_nextCategory, width: 48),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const FieldLabel('NEXT BOOKING'),
                          Text(next.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          if (_nextLine != null) Text(_nextLine!, style: const TextStyle(fontSize: 13)),
                        ]),
                      ),
                      StatusPill(next.statusName, color: next.status == 'requested' ? AppColors.warning : AppColors.lime600),
                    ]),
                  ),
                ),
                const SizedBox(height: 14),
              ],
              _bigOption('minibus', 'Book a seat', 'Matola or minibus on a route, at a set time',
                  () => widget.open(const BookSeatScreen()).then((_) => _load())),
              _bigOption('taxi', 'Hire a car', 'Taxi, kabaza, matola or lorry · priced per km',
                  () => widget.open(const HireCarScreen()).then((_) => _load())),
              _bigOption('lorry', 'Send goods', 'Bags, parcels or a load to someone',
                  () => widget.open(const SendGoodsScreen()).then((_) => _load())),
              if (_officePhone.isNotEmpty)
                TextButton(
                  onPressed: () => launchUrl(Uri.parse('tel:$_officePhone')),
                  child: Text('Prefer to call? $_officePhone · the office books it for you',
                      textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _bigOption(String kind, String title, String subtitle, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Material(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(children: [
                VehicleTile(kind, width: 76),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    Text(subtitle, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                  ]),
                ),
                const Icon(Icons.chevron_right, color: AppColors.muted),
              ]),
            ),
          ),
        ),
      );
}

class _AccountTab extends StatefulWidget {
  const _AccountTab();

  @override
  State<_AccountTab> createState() => _AccountTabState();
}

class _AccountTabState extends State<_AccountTab> {
  final _name = TextEditingController(text: appState.profile?.fullName ?? '');
  final _phone = TextEditingController(text: appState.profile?.phone ?? '');
  String? _company;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final acc = appState.profile?.accountId;
    if (acc != null) {
      db.from('company_accounts').select().eq('id', acc).maybeSingle().then((row) {
        if (mounted && row != null) setState(() => _company = (row['name'] ?? '').toString());
      }).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final me = appState.profile;
    if (me == null) return;
    setState(() => _busy = true);
    try {
      await db.from('profiles').update({'full_name': _name.text.trim(), 'phone': _phone.text.trim()}).eq('id', me.id);
      await appState.refresh();
      if (mounted) toast(context, 'Saved');
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    return Container(
      color: AppColors.surface100,
      child: ListView(padding: EdgeInsets.zero, children: [
        Container(
          color: AppColors.navy,
          child: const SafeArea(bottom: false, child: Padding(padding: EdgeInsets.fromLTRB(20, 10, 8, 18), child: ProfileHeader())),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            inputCard('FULL NAME', _name),
            const SizedBox(height: 10),
            inputCard('PHONE', _phone, type: TextInputType.phone),
            const SizedBox(height: 10),
            AppButton('Save', loading: _busy, onPressed: _save, height: 46),
            const SizedBox(height: 16),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const FieldLabel('COMPANY ACCOUNT'),
                Text(_company ?? (me?.accountId == null ? 'None · ask the office to link your company' : '…'),
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                const FieldLabel('MISSED BOOKINGS'),
                Text('${me?.noShows ?? 0}',
                    style: TextStyle(fontWeight: FontWeight.w800, color: (me?.noShows ?? 0) > 2 ? AppColors.danger : AppColors.ink)),
                const Text('Cancel in the app if you cannot travel. Cancelling is free.',
                    style: TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            const SizedBox(height: 10),
            const AppCard(child: LanguageSwitch()),
            const SizedBox(height: 16),
            AppButton('Sign out', kind: ButtonKind.danger, onPressed: () => appState.signOut()),
          ]),
        ),
      ]),
    );
  }
}
