import 'dart:async';

import 'package:flutter/material.dart';
import '../../icon_art.dart';
import 'package:latlong2/latlong.dart' hide Path;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app_state.dart';
import '../../capture.dart';
import '../../format.dart';
import '../../home_ui.dart';
import '../../models.dart';
import '../../profile_header.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import '../../menu_ui.dart';
import '../profile_screen.dart';
import '../../notices.dart';
import 'book_seat.dart';
import 'catalog.dart';
import 'hire_car.dart';
import 'my_bookings.dart';
import 'send_goods.dart';
import '../tickets.dart';
import 'my_things.dart';
import '../chat_screen.dart';
import '../support/support_screens.dart';
import '../../i18n.dart';

/// Passenger app: Home (book), My bookings, Account.
class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});

  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  int _tab = 0;
  final _bookingsKey = GlobalKey<MyBookingsTabState>();

  Future<void> _open(Widget screen) async {
    final booked = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => screen));
    if (booked == true && mounted) {
      setState(() => _tab = 1);
      _bookingsKey.currentState?.load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final body = switch (_tab) {
      0 => _HomeTab(open: _open, showBookings: () => setState(() => _tab = 1)),
      1 => MyBookingsTab(key: _bookingsKey),
      _ => const _AccountTab(),
    };
    return Scaffold(
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          NavigationDestination(icon: const NavArt('home', Icons.home), selectedIcon: const NavArt('home', Icons.home, selected: true), label: tx('Home')),
          NavigationDestination(icon: const NavArt('ticket', Icons.confirmation_number), selectedIcon: const NavArt('ticket', Icons.confirmation_number, selected: true), label: tx('My bookings')),
          NavigationDestination(icon: const NavArt('person', Icons.person), selectedIcon: const NavArt('person', Icons.person, selected: true), label: tx('Account')),
        ],
      ),
    );
  }
}

class _HomeTab extends StatefulWidget {
  final Future<void> Function(Widget) open;
  final VoidCallback showBookings;
  const _HomeTab({required this.open, required this.showBookings});

  @override
  State<_HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<_HomeTab> {
  Booking? _next;
  Booking? _last; // the most recent finished booking, offered as "Book again"
  String? _nextLine;
  String? _nextCategory;
  String _officePhone = '';
  MapTruck? _car;
  Truck? _nextTruck;
  Profile? _nextDriver;
  RealtimeChannel? _carChannel;
  String? _carTruckId;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  Future<void> _load() async {
    final me = appState.profile;
    if (me == null) return;
    try {
      final rows = await db
          .from('bookings')
          .select()
          .eq('passenger_id', me.id)
          .inFilter('status', ['requested', 'assigned', 'picked_up'])
          .order('pickup_at')
          .limit(10);
      rows.sort((a, b) => (b['status'] == 'picked_up' ? 1 : 0) - (a['status'] == 'picked_up' ? 1 : 0));
      Booking? last;
      if (rows.isEmpty) {
        final done = await db.from('bookings').select().eq('passenger_id', me.id).eq('status', 'completed').order('completed_at', ascending: false).limit(1);
        if (done.isNotEmpty) last = Booking.fromMap(done.first);
      }
      final settings = await db.from('app_settings').select();
      final next = rows.isEmpty ? null : Booking.fromMap(rows.first);
      String? line;
      String? cat;
      String? plate;
      Truck? nextTruck;
      Profile? nextDriver;
      if (next != null) {
        final info = BookingInfo();
        await info.load([next]);
        final truck = info.trucks[next.truckId];
        nextTruck = truck;
        nextDriver = info.people[next.driverId];
        plate = truck?.plate;
        final driver = info.people[next.driverId];
        cat = info.categories[next.categoryId]?.name;
        line = [
          '${dayName(next.pickupAt)} ${clock(next.pickupAt)}',
          if (next.kind == 'seat') '${next.seats} ${next.seats == 1 ? 'seat' : 'seats'}',
          if (truck != null) truck.plate,
          if (driver != null) driver.firstName,
        ].join(' · ');
      }
      MapTruck? car;
      if (next != null && next.truckId != null && (next.status == 'assigned' || next.status == 'picked_up')) {
        final loc = await db.from('truck_locations').select().eq('truck_id', next.truckId!).maybeSingle();
        if (loc != null) {
          final l = TruckLocation.fromMap(loc);
          car = MapTruck(l.truckId, LatLng(l.lat, l.lng), plate ?? '', kind: vehicleKind(cat));
        }
      }
      if (!mounted) return;
      _followCar(next?.truckId, plate ?? '', vehicleKind(cat));
      setState(() {
        _car = car;
        _next = next;
        _last = last;
        _nextTruck = nextTruck;
        _nextDriver = nextDriver;
        _nextLine = line;
        _nextCategory = cat;
        _officePhone = settings.isEmpty ? '' : (settings.first['office_phone'] ?? '').toString();
      });
    } catch (_) {}
  }

  /// Moves the car on the map the moment its position changes.
  void _followCar(String? truckId, String plate, String kind) {
    if (truckId == _carTruckId) return;
    final old = _carChannel;
    if (old != null) db.removeChannel(old);
    _carChannel = null;
    _carTruckId = truckId;
    if (truckId == null) return;
    _carChannel = db
        .channel('car-$truckId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'truck_locations',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'truck_id', value: truckId),
          callback: (payload) {
            final row = payload.newRecord;
            if (row.isEmpty || !mounted) return;
            final l = TruckLocation.fromMap(row);
            setState(() => _car = MapTruck(l.truckId, LatLng(l.lat, l.lng), plate, kind: kind));
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    _timer?.cancel();
    final c = _carChannel;
    if (c != null) db.removeChannel(c);
    super.dispose();
  }

  /// No trip booked: say so, and offer the last trip again.
  Widget _emptyCard() {
    final l = _last;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            const Icon(Icons.event_available_outlined, color: AppColors.lime600),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tx('No trip booked'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text(tx('Book a seat, hire a car or send goods below.'), style: const TextStyle(fontSize: 13, color: AppColors.muted)),
              ]),
            ),
          ]),
          if (l != null) ...[
            const SizedBox(height: 10),
            AppButton(txf('Book again: %s', [l.title]),
                kind: ButtonKind.outline,
                height: 44,
                onPressed: () => widget
                    .open(l.kind == 'hire' ? const HireCarScreen() : l.kind == 'goods' ? const SendGoodsScreen() : const BookSeatScreen())
                    .then((_) => _load())),
          ],
        ]),
      ),
    );
  }

  /// Requested → Car assigned → On board: where the booking is now.
  Widget _progress(Booking b) {
    final step = switch (b.status) { 'requested' => 0, 'assigned' => 1, 'picked_up' => 2, _ => 0 };
    final labels = [tx('Requested'), tx('Car assigned'), b.kind == 'goods' ? tx('On its way') : tx('On board')];
    return Row(children: [
      for (var i = 0; i < 3; i++) ...[
        if (i > 0)
          Expanded(child: Container(height: 3, color: i <= step ? AppColors.lime : AppColors.line)),
        Column(children: [
          Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: i <= step ? AppColors.lime : AppColors.surface,
              border: Border.all(color: i <= step ? AppColors.lime : AppColors.line, width: 2),
            ),
            child: i < step ? const Icon(Icons.check, size: 12, color: AppColors.navy) : null,
          ),
          const SizedBox(height: 3),
          Text(labels[i],
              style: TextStyle(fontSize: 11, fontWeight: i == step ? FontWeight.w800 : FontWeight.w500, color: i <= step ? AppColors.ink : AppColors.muted)),
        ]),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    final next = _next;
    return Container(
      color: AppColors.surface100,
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          HomeHero(
            headline: tx('Where are you going?'),
          ),
          HomeBody(children: [
            if (next != null) ...[
              HomeLabel(tx('Your next trip')),
              InkWell(
                onTap: () {
                  final t = _nextTruck;
                  if (t != null && (next.status == 'assigned' || next.status == 'picked_up')) {
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => TrackCarScreen(booking: next, truck: t, driver: _nextDriver, category: _nextCategory)))
                        .then((_) => _load());
                  } else {
                    widget.showBookings();
                  }
                },
                borderRadius: BorderRadius.circular(16),
                child: AppCard(
                  borderColor: next.status != 'requested' ? AppColors.lime : null,
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    VehicleTile(_nextCategory, width: 48),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(next.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        if (_nextLine != null) Text(_nextLine!, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                      ]),
                    ),
                    StatusPill(next.statusName, color: next.status == 'requested' ? AppColors.warning : AppColors.lime600),
                  ]),
                ),
              ),
              const SizedBox(height: 8),
              _progress(next),
              if (next.status == 'assigned' || next.status == 'picked_up')
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(children: [
                    if (next.kind != 'goods') ...[
                      Expanded(
                        child: AppButton(tx('Show ticket'),
                            kind: ButtonKind.outline, height: 44, onPressed: () => showTicket(context, next.id, next.bookingNo)),
                      ),
                      const SizedBox(width: 8),
                    ],
                    Expanded(
                      child: AppButton(tx('Message'),
                          kind: ButtonKind.outline,
                          height: 44,
                          onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => ChatScreen(bookingId: next.id, title: _nextDriver?.firstName ?? tx('Driver'))))),
                    ),
                    if (_nextDriver?.phone != null) ...[
                      const SizedBox(width: 8),
                      Expanded(
                        child: AppButton(tx('Call driver'),
                            kind: ButtonKind.outline, height: 44, onPressed: () => launchUrl(Uri.parse('tel:${_nextDriver!.phone}'))),
                      ),
                    ],
                  ]),
                ),
              const SizedBox(height: 10),
            ],
            if (next == null) _emptyCard(),
            HomeMap(car: _car),
            ActionTile(
              primary: true,
              art: 'seat',
              icon: Icons.airline_seat_recline_normal,
              title: tx('Book a seat'),
              subtitle: tx('Matola or minibus on a route, at a set time'),
              onTap: () => widget.open(const BookSeatScreen()).then((_) => _load()),
            ),
            TileRow([
              QuickTile(
                art: 'taxi',
                icon: Icons.local_taxi_outlined,
                title: tx('Hire a car'),
                subtitle: tx('Taxi, kabaza, matola or lorry · priced per km'),
                onTap: () => widget.open(const HireCarScreen()).then((_) => _load()),
              ),
              QuickTile(
                art: 'parcel',
                icon: Icons.inventory_2_outlined,
                title: tx('Send goods'),
                subtitle: tx('Bags, parcels or a load to someone'),
                onTap: () => widget.open(const SendGoodsScreen()).then((_) => _load()),
              ),
            ]),
            HomeLabel(tx('Need a hand?')),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(children: [
                if (_officePhone.isNotEmpty)
                  ListTile(
                    leading: const IconArt('call', size: 34, fallback: Icons.call_outlined),
                    title: Text(tx('Call the office')),
                    subtitle: Text(_officePhone),
                    onTap: () => launchUrl(Uri.parse('tel:$_officePhone')),
                  ),
                if (_officePhone.isNotEmpty) const Divider(height: 1),
                ListTile(
                  leading: const IconArt('headset', size: 34, fallback: Icons.support_agent_outlined),
                  title: Text(tx('Help & support · report a problem')),
                  onTap: () => widget.open(const SupportHomeScreen()),
                ),
              ]),
            ),
          ]),
        ]),
      ),
    );
  }
}

class _AccountTab extends StatefulWidget {
  const _AccountTab();

  @override
  State<_AccountTab> createState() => _AccountTabState();
}

class _AccountTabState extends State<_AccountTab> {
  final _name = TextEditingController(text: appState.profile?.fullName ?? '');
  final _phone = TextEditingController(text: appState.profile?.phone ?? '');
  String? _company;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final acc = appState.profile?.accountId;
    if (acc != null) {
      db.from('company_accounts').select().eq('id', acc).maybeSingle().then((row) {
        if (mounted && row != null) setState(() => _company = (row['name'] ?? '').toString());
      }).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final me = appState.profile;
    if (me == null) return;
    setState(() => _busy = true);
    try {
      await db.from('profiles').update({'full_name': _name.text.trim(), 'phone': _phone.text.trim()}).eq('id', me.id);
      await appState.refresh();
      if (mounted) toast(context, tx('Saved'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    void open(Widget s) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => s));
    return Container(
      color: AppColors.surface,
      child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
        Container(
          color: AppColors.navy,
          child: const SafeArea(bottom: false, child: Padding(padding: EdgeInsets.fromLTRB(20, 10, 8, 18), child: ProfileHeader())),
        ),
        MenuHeading(tx('General')),
        MenuRow(art: 'person', icon: Icons.person_outline, title: tx('My profile'), subtitle: tx('Name, phone and picture'), onTap: () => open(const MyProfileScreen())),
        MenuRow(art: 'bell', icon: Icons.notifications_none, title: tx('Messages'), onTap: () => open(const NoticesScreen())),
        MenuRow(icon: Icons.place_outlined, title: tx('Saved places'), subtitle: tx('Home, Work and other places'), onTap: () => open(const SavedPlacesScreen())),
        MenuRow(icon: Icons.favorite_border, title: tx('Favourite drivers'), subtitle: tx('Ask for a driver you like'), onTap: () => open(const FavouriteDriversScreen())),
        MenuRow(icon: Icons.health_and_safety_outlined, title: tx('Emergency contact'), subtitle: tx('Someone to alert on a trip'), onTap: () => open(const EmergencyContactScreen())),
        MenuRow(icon: Icons.card_giftcard_outlined, title: tx('Invite friends'), subtitle: tx('Share your code'), onTap: () => open(const InviteFriendsScreen())),
        MenuRow(icon: Icons.notifications_active_outlined, title: tx('Notification settings'), subtitle: tx('Choose what buzzes your phone'), onTap: () => open(const NotificationSettingsScreen())),
        if (me?.accountId != null || (me?.noShows ?? 0) > 0)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            child: AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (me?.accountId != null) ...[
                  FieldLabel(tx('COMPANY ACCOUNT')),
                  Text(_company ?? '…', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                ],
                FieldLabel(tx('MISSED BOOKINGS')),
                Text('${me?.noShows ?? 0}',
                    style: TextStyle(fontWeight: FontWeight.w800, color: (me?.noShows ?? 0) > 2 ? AppColors.danger : AppColors.ink)),
                Text(tx('Cancel in the app if you cannot travel. Cancelling is free.'), style: TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
          ),
        menuDivider,
        const SupportGroup(),
        menuDivider,
        const LogoutRow(),
      ]),
    );
  }
}
