import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../models.dart';
import '../../icon_art.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'catalog.dart';
import 'my_things.dart';
import '../../i18n.dart';
import '../../route_preview.dart';
import '../../pin_place.dart';

/// Hire a whole car (taxi, kabaza, matola, lorry ...), priced per km.
/// With [goods] the lorry carries a load for someone (receiver gets a code).
class HireCarScreen extends StatefulWidget {
  final String? categoryName; // preselect, e.g. 'Lorry'
  final bool goods;
  final Place? dest; // chosen on the home screen (Home / Work)
  final bool pickDest; // open the map to drop a pin straight away
  const HireCarScreen({super.key, this.categoryName, this.goods = false, this.dest, this.pickDest = false});

  @override
  State<HireCarScreen> createState() => _HireCarScreenState();
}

class _HireCarScreenState extends State<HireCarScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  final _note = TextEditingController();
  List<FavouriteDriver> _favourites = [];
  FavouriteDriver? _askFor;
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  final _load = TextEditingController();
  bool _loading = true;
  int _step = 0; // 0 = vehicle and places, 1 = when and details, 2 = price and confirm
  bool _busy = false;
  String? _error;
  VehicleCategory? _category;
  Place? _pickup;
  Place? _dest;
  String _tripType = 'one_way';
  DateTime? _when; // null = now
  double? _roadKm;
  bool _roughKm = false; // true when the road route could not be fetched and the distance is a straight-line estimate
  bool _measuring = false;
  String _pay = 'cash';

  @override
  void initState() {
    super.initState();
    _start();
    SavedPlace.load().then((l) {
      if (mounted) setState(() => _saved = l);
    });
    FavouriteDriver.load().then((l) {
      if (mounted) setState(() => _favourites = l);
    });
  }

  @override
  void dispose() {
    _reference.dispose();
    _note.dispose();
    _receiver.dispose();
    _receiverPhone.dispose();
    _load.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      await _cat.load();
      final list = _cat.forHire;
      _category = list.where((c) => c.name.toLowerCase() == (widget.categoryName ?? '').toLowerCase()).firstOrNull ??
          list.where((c) => c.name.toLowerCase() == 'taxi').firstOrNull ??
          list.firstOrNull;
      await Here.instance.refresh();
      final here = Here.instance.point.value;
      // a phone position outside Malawi is a bad fix: leave the pick-up empty so the passenger chooses it
      if (here != null && inMalawi(here)) _pickup = Place(Here.instance.name.value ?? 'Here', 'Where you are now', here);
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
    if (widget.dest != null && mounted) {
      setState(() => _dest = widget.dest);
      _measure();
    } else if (widget.pickDest && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _pickOnMap());
    }
  }

  /// Road distance for the trip (there and back for a return), or straight line × 1.3 offline.
  Future<void> _measure() async {
    final a = _pickup, b = _dest;
    if (a == null || b == null) return;
    setState(() => _measuring = true);
    final r = await getRoute(a.point, b.point);
    final oneWay = r?.km ?? distanceKm(a.point, b.point) * 1.3;
    if (mounted) {
      setState(() {
        _roughKm = r == null;
        _routePts = r?.points;
        _routeMin = r?.minutes;
        _roadKm = oneWay;
        _measuring = false;
      });
    }
  }

  double get _km {
    final one = _roadKm ?? 0;
    return switch (_tripType) {
      'return' => one * 2,
      'whole_day' => one * 2 < 100 ? 100 : one * 2,
      _ => one,
    };
  }

  Future<void> _pickPlace(bool pickup) async {
    final p = await showSearch<Place?>(context: context, delegate: PlaceSearch(near: Here.instance.point.value));
    if (p == null) return;
    if (!inMalawi(p.point)) {
      setState(() => _error = tx('That place is outside Malawi. If it says "Where I am now", your phone location is wrong: turn location off and on, or choose the place by name.'));
      return;
    }
    setState(() {
      if (pickup) {
        _pickup = p;
      } else {
        _dest = p;
      }
      _roadKm = null;
    });
    _measure();
  }

  Future<void> _pickTime() async {
    final now = DateTime.now();
    final d = await showDatePicker(
        context: context, initialDate: _when ?? now, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 60)));
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_when ?? now.add(const Duration(hours: 1))));
    if (t == null) return;
    setState(() => _when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<void> _request() async {
    final c = _category, a = _pickup, b = _dest;
    if (c == null || a == null || b == null) {
      setState(() => _error = tx('Choose the vehicle, where to pick you up and where to go.'));
      return;
    }
    if (widget.goods && (_receiver.text.trim().isEmpty || _receiverPhone.text.trim().isEmpty)) {
      setState(() => _error = tx('Type the receiver\'s name and phone.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    if (!inMalawi(a.point) || !inMalawi(b.point)) {
      setState(() {
        _busy = false;
        _error = tx('Pick-up and drop-off must both be in Malawi. Check the places.');
      });
      return;
    }
    try {
      await db.rpc('book', params: {
        'p': {
          'kind': 'hire',
          'category_id': c.id,
          'pickup_name': a.name,
          'pickup_lat': a.point.latitude,
          'pickup_lng': a.point.longitude,
          'dest_name': b.name,
          'dest_lat': b.point.latitude,
          'dest_lng': b.point.longitude,
          'trip_type': _tripType,
          'km': double.parse(_km.toStringAsFixed(1)),
          'pickup_at': (_when ?? DateTime.now()).toUtc().toIso8601String(),
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
          'note': [if (_askFor != null) 'Please send driver ${_askFor!.name} if possible.', _note.text.trim()].where((x) => x.isNotEmpty).join(' '),
          if (widget.goods) ...{
            'goods': [
              {'label': _load.text.trim().isEmpty ? 'Load' : _load.text.trim(), 'qty': 1}
            ],
            'receiver_name': _receiver.text.trim(),
            'receiver_phone': _receiverPhone.text.trim(),
          },
        }
      });
      if (!mounted) return;
      toast(context, txf('Request sent. We are finding a %s for you and will send you a message.', ['${c.name.toLowerCase()}']));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  List<LatLng>? _routePts;
  double? _routeMin;
  List<MapTruck> _near = [];
  List<SavedPlace> _saved = [];
  DateTime _nearAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// Free drivers around the pick-up point (type and position only), shown on the map.
  Future<void> _loadNear() async {
    final at = _pickup?.point ?? Here.instance.point.value;
    if (at == null || DateTime.now().difference(_nearAt) < const Duration(seconds: 15)) return;
    _nearAt = DateTime.now();
    try {
      final rows = await db.rpc('nearby_drivers', params: {'p_lat': at.latitude, 'p_lng': at.longitude, 'p_km': 15}) as List;
      if (!mounted) return;
      setState(() => _near = [
            for (final r in rows)
              MapTruck(r['truck_id'].toString(), LatLng((r['lat'] as num).toDouble(), (r['lng'] as num).toDouble()), '',
                  kind: vehicleKind((r['category'] ?? '').toString())),
          ]);
    } catch (_) {} // before schema_v42, or no signal: no cars on the map
  }

  Widget _chip(Widget child) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x260A2253), blurRadius: 8, offset: Offset(0, 2))],
        ),
        child: child,
      );

  Future<void> _useSaved(String label) async {
    final hit = _saved.where((x) => x.label.toLowerCase() == label.toLowerCase()).firstOrNull;
    if (hit == null) {
      toast(context, txf('Save your %s in Account → Saved places.', [label.toLowerCase()]));
      return;
    }
    setState(() {
      _dest = hit.place;
      _roadKm = null;
    });
    _measure();
  }

  Future<void> _pickOnMap() async {
    final p = await Navigator.of(context).push<Place>(MaterialPageRoute(builder: (_) => PinPlaceScreen(start: _pickup?.point ?? Here.instance.point.value)));
    if (p == null) return;
    setState(() {
      _dest = p;
      _roadKm = null;
    });
    _measure();
  }

  /// One vehicle as a row, with the price for this trip once the places are chosen.
  Widget _vehicleRow(VehicleCategory x) {
    final on = x.id == _category?.id;
    final price = _roadKm == null ? null : x.hirePrice(_roadKm!);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _category = x),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.lime100 : AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 2),
          ),
          child: Row(children: [
            VehicleArt(x.name, width: 64),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(x.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.navy)),
                Text('${money(x.hirePerKm)} / km', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              ]),
            ),
            if (price != null)
              Text(money(price), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.navy))
            else if (_measuring && _dest != null)
              const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = _category;
    final est = c == null || _roadKm == null ? null : c.hirePrice(_km);
    final now = DateTime.now();
    final soon = DateTime(now.year, now.month, now.day, now.hour + 2);
    const top = 0.0; // the title bar already clears the status bar
    final planning = _step == 0 && _dest == null; // the map gets more room until a place is chosen
    final nearKind = c == null ? null : vehicleKind(c.name);
    final shown = _near.where((t) => nearKind == null || t.kind == nearKind).toList();
    if (!_loading) _loadNear();
    return Scaffold(
      appBar: navyBar(widget.goods ? 'Hire a lorry for a load' : 'Hire a car'),
      backgroundColor: AppColors.mapGround,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              // ------------------------------------------------ map
              Expanded(
                flex: planning ? 5 : 4,
                child: Stack(children: [
                  Positioned.fill(
                    child: FleetMap(
                      me: Here.instance.point.value,
                      trucks: shown,
                      route: _dest == null ? null : _routePts,
                      end: _dest?.point,
                      endLabel: _dest?.name,
                      stops: [if (_pickup != null && _dest != null) MapStop(_pickup!.point, _pickup!.name, 0)],
                      topPadding: top + 70,
                      bottomPadding: 40,
                    ),
                  ),
                  if (_dest != null && _roadKm != null)
                    Positioned(
                      top: top + 16,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
                          child: Text('${kmText(_roadKm)}${_routeMin == null ? '' : ' · ${durationText(_routeMin!)}'}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        ),
                      ),
                    ),
                  if (_dest == null && shown.isNotEmpty)
                    Positioned(
                      right: 12,
                      top: top + 14,
                      child: _chip(Text(
                          '${shown.length} ${shown.length == 1 ? tx('car') : tx('cars')} ${tx('near you')}',
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
                    ),
                ]),
              ),
              // ------------------------------------------------ panel
              Expanded(
                flex: planning ? 5 : 6,
                child: Container(
                  decoration: const BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                    boxShadow: [BoxShadow(color: Color(0x140A2253), blurRadius: 14, offset: Offset(0, -4))],
                  ),
                  child: ListView(padding: EdgeInsets.fromLTRB(16, 10, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
                    Center(
                      child: Container(
                          width: 40,
                          height: 4,
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2))),
                    ),
                    if (_cat.forHire.isEmpty)
                      EmptyText(tx('No vehicles for hire yet. Please call the office.'))
                    else ...[
                      if (_step == 0) ...[
                        InkWell(
                          onTap: () => _pickPlace(true),
                          child: Row(children: [
                            const Icon(Icons.my_location, size: 16, color: AppColors.lime600),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(_pickup?.name ?? tx('Choose where to pick you up'),
                                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                            ),
                            const Icon(Icons.expand_more, size: 18, color: AppColors.muted),
                          ]),
                        ),
                        const SizedBox(height: 10),
                        InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _pickPlace(false),
                          child: AppCard(
                            child: Row(children: [
                              const IconArt('place_search', size: 34, fallback: Icons.search),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(_dest?.name ?? (widget.goods ? tx('Where should the load go?') : tx('Where to?')),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _dest == null ? AppColors.ink : AppColors.navy)),
                              ),
                            ]),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Wrap(spacing: 8, runSpacing: 8, children: [
                          ActionChip(avatar: const IconArt('place_home', size: 26, fallback: Icons.home_outlined), label: Text(tx('Home')), onPressed: () => _useSaved('Home')),
                          ActionChip(avatar: const IconArt('place_work', size: 26, fallback: Icons.work_outline), label: Text(tx('Work')), onPressed: () => _useSaved('Work')),
                          ActionChip(avatar: const IconArt('place_map', size: 26, fallback: Icons.map_outlined), label: Text(tx('Map')), onPressed: _pickOnMap),
                        ]),
                        const SizedBox(height: 12),
                        if (_dest == null)
                          SizedBox(
                            height: 104,
                            child: ListView(scrollDirection: Axis.horizontal, children: [
                              for (final x in _cat.forHire) ...[_vehicleOption(x), const SizedBox(width: 8)],
                            ]),
                          )
                        else ...[
                          for (final x in _cat.forHire) _vehicleRow(x),
                          const SizedBox(height: 4),
                        ],
                        ErrorLine(_error),
                        const SizedBox(height: 6),
                        AppButton(tx('Next'),
                            onPressed: (_pickup != null && _dest != null && _category != null) ? () => setState(() => _step = 1) : null),
                      ],
                if (_step == 1) ...[
                AppCard(
                  child: Row(children: [
                    const Icon(Icons.route_outlined, color: AppColors.lime600),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                          '${c?.name ?? ''} · ${_pickup?.name} → ${_dest?.name}\n${_when == null ? tx('Now') : '${dayName(_when!)} ${clock(_when)}'}${Booking.tripTypeNames[_tripType] != null ? ' · ${Booking.tripTypeNames[_tripType]}' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                    TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                  ]),
                ),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final e in Booking.tripTypeNames.entries)
                    ChoiceChipButton(e.value, selected: _tripType == e.key, onTap: () => setState(() => _tripType = e.key)),
                ]),
                const SizedBox(height: 10),
                formCard(
                  'WHEN',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    ChoiceChipButton(tx('Now'), selected: _when == null, onTap: () => setState(() => _when = null)),
                    ChoiceChipButton('${dayName(soon)} ${clock(soon)}',
                        selected: _when == soon, onTap: () => setState(() => _when = soon)),
                    ChoiceChipButton(_when == null || _when == soon ? tx('Other time') : '${dayName(_when!)} ${clock(_when)}',
                        selected: _when != null && _when != soon, onTap: _pickTime),
                  ]),
                ),
                if (widget.goods) ...[
                  const SizedBox(height: 10),
                  inputCard('WHAT IS THE LOAD', _load, hint: 'e.g. 20 bags of cement'),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: inputCard('RECEIVER', _receiver, hint: 'Name')),
                    const SizedBox(width: 8),
                    Expanded(child: inputCard('PHONE', _receiverPhone, hint: '0884 …', type: TextInputType.phone)),
                  ]),
                ],
                const SizedBox(height: 12),
                AppButton(tx('Next'), onPressed: () => setState(() => _step = 2)),
                ],
                if (_step == 2) ...[
                AppCard(
                  child: Row(children: [
                    const Icon(Icons.route_outlined, color: AppColors.lime600),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                          '${c?.name ?? ''} · ${_pickup?.name} → ${_dest?.name}\n${_when == null ? tx('Now') : '${dayName(_when!)} ${clock(_when)}'}${Booking.tripTypeNames[_tripType] != null ? ' · ${Booking.tripTypeNames[_tripType]}' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                    TextButton(onPressed: () => setState(() => _step = _step - 1), child: Text(tx('Back'))),
                  ]),
                ),
                const SizedBox(height: 10),
                if (_measuring)
                  const LinearProgressIndicator()
                else if (_roadKm != null && c != null)
                  AppCard(
                    child: Column(children: [
                      _line(
                          _tripType == 'return'
                              ? 'Distance by road (there and back)'
                              : _tripType == 'whole_day'
                                  ? 'Whole day (at least 100 km)'
                                  : 'Distance by road',
                          _roughKm ? '≈ ${kmText(_km)}' : kmText(_km)),
                      if (_roughKm)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(tx('Estimated: no road route was available. The final price uses the km on the odometer.'),
                              style: const TextStyle(fontSize: 12, color: AppColors.warning)),
                        ),
                      const SizedBox(height: 4),
                      _line(txf('%s rate', [c.name]), '${money(c.hirePerKm)} / km'),
                      if (c.hireMin > 0) ...[const SizedBox(height: 4), _line('Smallest price', money(c.hireMin))],
                    ]),
                  ),
                if (est != null) TotalBox('ESTIMATE', money(est), txf('Final price = km on the odometer × %s', [money(c!.hirePerKm)])),
                PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                const SizedBox(height: 10),
                if (_favourites.isNotEmpty) ...[
                  FieldLabel(tx('ASK FOR A FAVOURITE DRIVER (OPTIONAL)')),
                  Wrap(spacing: 8, children: [
                    for (final f in _favourites)
                      ChoiceChip(
                        label: Text(f.name),
                        selected: _askFor?.id == f.id,
                        onSelected: (on) => setState(() => _askFor = on ? f : null),
                      ),
                  ]),
                  const SizedBox(height: 10),
                ],
                inputCard('NOTE FOR THE DRIVER (OPTIONAL)', _note, hint: 'e.g. I have 2 suitcases'),
                const SizedBox(height: 10),
                ErrorLine(_error),
                const SizedBox(height: 8),
                AppButton(txf('Request %s', [c?.name.toLowerCase() ?? tx('car')]), loading: _busy, onPressed: est == null ? null : _request),
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(tx('You can change the time or cancel until the car arrives.'),
                      textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ),
                ],
                    ],
                  ]),
                ),
              ),
            ]),
    );
  }

  Widget _line(String a, String b) => Row(children: [
        Expanded(child: Text(a, style: const TextStyle(color: AppColors.muted, fontSize: 13))),
        Text(b, style: const TextStyle(fontWeight: FontWeight.w800)),
      ]);

  Widget _vehicleOption(VehicleCategory x) {
    final on = x.id == _category?.id;
    return Semantics(
      button: true,
      selected: on,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => _category = x),
        child: Container(
          width: 92,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.lime100 : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 2),
          ),
          child: Column(children: [
            VehicleArt(x.name, width: 72),
            Text(x.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.navy)),
            Text('${money(x.hirePerKm)}/km',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: on ? AppColors.lime600 : AppColors.muted)),
          ]),
        ),
      ),
    );
  }

  Widget _placeCard(String label, Place? p, IconData icon, VoidCallback onTap) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(children: [
              Icon(icon, color: AppColors.navy),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FieldLabel(label),
                  Text(p?.name ?? tx('Tap to choose'),
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: p == null ? AppColors.muted : AppColors.ink)),
                  if (p != null && p.detail.isNotEmpty)
                    Text(p.detail, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
              const IconArt('place_search', size: 26, fallback: Icons.search),
            ]),
          ),
        ),
      );
}

/// Search box for places (known Mangochi places work without internet).
class PlaceSearch extends SearchDelegate<Place?> {
  final LatLng? near;
  PlaceSearch({this.near}) : super(searchFieldLabel: tx('Search a place')) {
    loadSharedPlaces(force: false);
  }

  final Map<String, Future<List<Place>>> _cache = {};
  Future<List<SavedPlace>>? _saved;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [if (query.isNotEmpty) IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];

  @override
  Widget buildLeading(BuildContext context) =>
      IconButton(onPressed: () => close(context, null), icon: const Icon(Icons.arrow_back));

  @override
  Widget buildResults(BuildContext context) => _results();

  @override
  Widget buildSuggestions(BuildContext context) {
    if (query.trim().length < 2) {
      final here = near;
      return ListView(children: [
        FutureBuilder<List<SavedPlace>>(
          future: _saved ??= SavedPlace.load(),
          builder: (context, snap) => Column(children: [
            for (final sp in snap.data ?? const <SavedPlace>[])
              ListTile(
                leading: sp.label == 'Home' ? const IconArt('place_home', size: 30, fallback: Icons.home_outlined) : sp.label == 'Work' ? const IconArt('place_work', size: 30, fallback: Icons.work_outline) : const Icon(Icons.star_outline, color: AppColors.navy),
                title: Text(sp.label, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(sp.place.name),
                onTap: () => close(context, Place(sp.place.name, sp.label, sp.place.point)),
              ),
          ]),
        ),
        _pinTile(context),
        if (here != null)
          ListTile(
            leading: const Icon(Icons.my_location),
            title: Text(tx('Where I am now')),
            onTap: () => close(context, Place(Here.instance.name.value ?? 'Here', 'Where you are now', here)),
          ),
        for (final p in knownPlaces)
          ListTile(leading: const Icon(Icons.place_outlined), title: Text(p.name), subtitle: Text(p.detail), onTap: () => close(context, p)),
      ]);
    }
    return _results();
  }

  /// One online search per text; waits a moment so it is not sent for every letter.
  Future<List<Place>> _search(String q) {
    final hit = _cache[q];
    if (hit != null) return hit;
    final f = () async {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      if (q != query.trim()) {
        _cache.remove(q); // the person kept typing: skip this one
        return quickMatches(q);
      }
      await loadSharedPlaces(force: false); // places the office added a moment ago
      return searchPlaces(q, near: near);
    }();
    return _cache[q] = f;
  }

  Widget _pinTile(BuildContext context) => ListTile(
        leading: const Icon(Icons.pin_drop_outlined, color: AppColors.navy),
        title: Text(tx('Choose on the map'), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(tx('Drop a pin on the exact spot')),
        onTap: () async {
          final p = await Navigator.of(context).push<Place>(MaterialPageRoute(builder: (_) => PinPlaceScreen(start: near)));
          if (p != null) suggestPinnedPlace(p); // a named pin goes to the office so everyone can use it
          if (p != null && context.mounted) close(context, p);
        },
      );

  Widget _tile(BuildContext context, Place p) => ListTile(
        leading: const Icon(Icons.place_outlined),
        title: Text(p.name),
        subtitle: p.detail.isEmpty ? null : Text(p.detail),
        onTap: () => close(context, p),
      );

  Widget _results() {
    final q = query.trim();
    final quick = quickMatches(q);
    return FutureBuilder<List<Place>>(
      future: _search(q),
      builder: (context, snap) {
        final waiting = snap.connectionState != ConnectionState.done;
        final list = snap.hasData ? snap.data! : quick; // known places show at once
        return ListView(children: [
          if (waiting) const LinearProgressIndicator(minHeight: 2),
          for (final p in list) _tile(context, p),
          _pinTile(context),
          if (!waiting && lastSearchOffline)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(tx('Could not search online (check your data). Showing known places only.'),
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ),
          if (!waiting && list.isEmpty && !lastSearchOffline) EmptyText(tx('No place found. Try another spelling.')),
          if (waiting && list.isEmpty)
            Padding(padding: const EdgeInsets.all(16), child: Text(tx('Searching…'), style: const TextStyle(color: AppColors.muted))),
        ]);
      },
    );
  }
}
