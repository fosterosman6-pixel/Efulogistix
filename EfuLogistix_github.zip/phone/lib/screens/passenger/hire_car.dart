import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../../app_state.dart';
import '../../format.dart';
import '../../geo.dart';
import '../../here.dart';
import '../../models.dart';
import '../../theme.dart';
import '../../vehicle_art.dart';
import '../../widgets.dart';
import 'catalog.dart';
import '../../i18n.dart';
import '../../route_preview.dart';

/// Hire a whole car (taxi, kabaza, matola, lorry ...), priced per km.
/// With [goods] the lorry carries a load for someone (receiver gets a code).
class HireCarScreen extends StatefulWidget {
  final String? categoryName; // preselect, e.g. 'Lorry'
  final bool goods;
  const HireCarScreen({super.key, this.categoryName, this.goods = false});

  @override
  State<HireCarScreen> createState() => _HireCarScreenState();
}

class _HireCarScreenState extends State<HireCarScreen> {
  final _cat = Catalog();
  final _reference = TextEditingController();
  final _note = TextEditingController();
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  final _load = TextEditingController();
  bool _loading = true;
  bool _busy = false;
  String? _error;
  VehicleCategory? _category;
  Place? _pickup;
  Place? _dest;
  String _tripType = 'one_way';
  DateTime? _when; // null = now
  double? _roadKm;
  bool _measuring = false;
  String _pay = 'cash';

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    _reference.dispose();
    _note.dispose();
    _receiver.dispose();
    _receiverPhone.dispose();
    _load.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      await _cat.load();
      final list = _cat.forHire;
      _category = list.where((c) => c.name.toLowerCase() == (widget.categoryName ?? '').toLowerCase()).firstOrNull ??
          list.where((c) => c.name.toLowerCase() == 'taxi').firstOrNull ??
          list.firstOrNull;
      await Here.instance.refresh();
      final here = Here.instance.point.value;
      if (here != null) _pickup = Place(Here.instance.name.value ?? 'Here', 'Where you are now', here);
    } catch (e) {
      _error = friendlyError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  /// Road distance for the trip (there and back for a return), or straight line × 1.3 offline.
  Future<void> _measure() async {
    final a = _pickup, b = _dest;
    if (a == null || b == null) return;
    setState(() => _measuring = true);
    final r = await getRoute(a.point, b.point);
    final oneWay = r?.km ?? distanceKm(a.point, b.point) * 1.3;
    if (mounted) {
      setState(() {
        _roadKm = oneWay;
        _measuring = false;
      });
    }
  }

  double get _km {
    final one = _roadKm ?? 0;
    return switch (_tripType) {
      'return' => one * 2,
      'whole_day' => one * 2 < 100 ? 100 : one * 2,
      _ => one,
    };
  }

  Future<void> _pickPlace(bool pickup) async {
    final p = await showSearch<Place?>(context: context, delegate: _PlaceSearch(near: Here.instance.point.value));
    if (p == null) return;
    setState(() {
      if (pickup) {
        _pickup = p;
      } else {
        _dest = p;
      }
      _roadKm = null;
    });
    _measure();
  }

  Future<void> _pickTime() async {
    final now = DateTime.now();
    final d = await showDatePicker(
        context: context, initialDate: _when ?? now, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 60)));
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_when ?? now.add(const Duration(hours: 1))));
    if (t == null) return;
    setState(() => _when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<void> _request() async {
    final c = _category, a = _pickup, b = _dest;
    if (c == null || a == null || b == null) {
      setState(() => _error = tx('Choose the vehicle, where to pick you up and where to go.'));
      return;
    }
    if (widget.goods && (_receiver.text.trim().isEmpty || _receiverPhone.text.trim().isEmpty)) {
      setState(() => _error = tx('Type the receiver\'s name and phone.'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.rpc('book', params: {
        'p': {
          'kind': 'hire',
          'category_id': c.id,
          'pickup_name': a.name,
          'pickup_lat': a.point.latitude,
          'pickup_lng': a.point.longitude,
          'dest_name': b.name,
          'dest_lat': b.point.latitude,
          'dest_lng': b.point.longitude,
          'trip_type': _tripType,
          'km': double.parse(_km.toStringAsFixed(1)),
          'pickup_at': (_when ?? DateTime.now()).toUtc().toIso8601String(),
          'pay_method': _pay,
          'pay_reference': _reference.text.trim(),
          'note': _note.text.trim(),
          if (widget.goods) ...{
            'goods': [
              {'label': _load.text.trim().isEmpty ? 'Load' : _load.text.trim(), 'qty': 1}
            ],
            'receiver_name': _receiver.text.trim(),
            'receiver_phone': _receiverPhone.text.trim(),
          },
        }
      });
      if (!mounted) return;
      toast(context, txf('Request sent. The office will assign a %s and send you a message.', ['${c.name.toLowerCase()}']));
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _category;
    final est = c == null || _roadKm == null ? null : c.hirePrice(_km);
    final now = DateTime.now();
    final soon = DateTime(now.year, now.month, now.day, now.hour + 2);
    return Scaffold(
      appBar: navyBar(widget.goods ? 'Hire a lorry for a load' : 'Hire a car'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
              if (_cat.forHire.isEmpty)
                EmptyText(tx('No vehicles for hire yet. Please call the office.'))
              else ...[
                SectionTitle(tx('VEHICLE')),
                const SizedBox(height: 4),
                SizedBox(
                  height: 104,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final x in _cat.forHire) ...[_vehicleOption(x), const SizedBox(width: 8)],
                  ]),
                ),
                const SizedBox(height: 10),
                _placeCard('PICK ME UP', _pickup, Icons.my_location, () => _pickPlace(true)),
                const SizedBox(height: 10),
                _placeCard('GO TO', _dest, Icons.flag_outlined, () => _pickPlace(false)),
                const SizedBox(height: 10),
                if (_pickup != null && _dest != null) ...[
                  RoutePreview(from: _pickup!.point, fromName: _pickup!.name, to: _dest!.point, toName: _dest!.name),
                  const SizedBox(height: 10),
                ],
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final e in Booking.tripTypeNames.entries)
                    ChoiceChipButton(e.value, selected: _tripType == e.key, onTap: () => setState(() => _tripType = e.key)),
                ]),
                const SizedBox(height: 10),
                formCard(
                  'WHEN',
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    ChoiceChipButton(tx('Now'), selected: _when == null, onTap: () => setState(() => _when = null)),
                    ChoiceChipButton(txf('Today %s', ['${clock(soon)}']),
                        selected: _when == soon, onTap: () => setState(() => _when = soon)),
                    ChoiceChipButton(_when == null || _when == soon ? tx('Other time') : '${dayName(_when!)} ${clock(_when)}',
                        selected: _when != null && _when != soon, onTap: _pickTime),
                  ]),
                ),
                if (widget.goods) ...[
                  const SizedBox(height: 10),
                  inputCard('WHAT IS THE LOAD', _load, hint: 'e.g. 20 bags of cement'),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: inputCard('RECEIVER', _receiver, hint: 'Name')),
                    const SizedBox(width: 8),
                    Expanded(child: inputCard('PHONE', _receiverPhone, hint: '0884 …', type: TextInputType.phone)),
                  ]),
                ],
                const SizedBox(height: 10),
                if (_measuring)
                  const LinearProgressIndicator()
                else if (_roadKm != null && c != null)
                  AppCard(
                    child: Column(children: [
                      _line(
                          _tripType == 'return'
                              ? 'Distance by road (there and back)'
                              : _tripType == 'whole_day'
                                  ? 'Whole day (at least 100 km)'
                                  : 'Distance by road',
                          kmText(_km)),
                      const SizedBox(height: 4),
                      _line(txf('%s rate', [c.name]), '${money(c.hirePerKm)} / km'),
                      if (c.hireMin > 0) ...[const SizedBox(height: 4), _line('Smallest price', money(c.hireMin))],
                    ]),
                  ),
                if (est != null) TotalBox('ESTIMATE', money(est), txf('Final price = km on the odometer × %s', [money(c!.hirePerKm)])),
                PayPicker(method: _pay, onChanged: (m) => setState(() => _pay = m), reference: _reference),
                const SizedBox(height: 10),
                inputCard('NOTE FOR THE DRIVER (OPTIONAL)', _note, hint: 'e.g. I have 2 suitcases'),
                const SizedBox(height: 10),
                ErrorLine(_error),
                const SizedBox(height: 8),
                AppButton(txf('Request %s', [c?.name.toLowerCase() ?? tx('car')]), loading: _busy, onPressed: est == null ? null : _request),
              ],
            ]),
    );
  }

  Widget _line(String a, String b) => Row(children: [
        Expanded(child: Text(a, style: const TextStyle(color: AppColors.muted, fontSize: 13))),
        Text(b, style: const TextStyle(fontWeight: FontWeight.w800)),
      ]);

  Widget _vehicleOption(VehicleCategory x) {
    final on = x.id == _category?.id;
    return Semantics(
      button: true,
      selected: on,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => _category = x),
        child: Container(
          width: 92,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: on ? AppColors.lime100 : AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: on ? AppColors.navy : AppColors.line, width: 2),
          ),
          child: Column(children: [
            VehicleArt(x.name, width: 72),
            Text(x.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.navy)),
            Text('${money(x.hirePerKm)}/km',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: on ? AppColors.lime600 : AppColors.muted)),
          ]),
        ),
      ),
    );
  }

  Widget _placeCard(String label, Place? p, IconData icon, VoidCallback onTap) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(children: [
              Icon(icon, color: AppColors.navy),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FieldLabel(label),
                  Text(p?.name ?? tx('Tap to choose'),
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: p == null ? AppColors.muted : AppColors.ink)),
                  if (p != null && p.detail.isNotEmpty)
                    Text(p.detail, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
              const Icon(Icons.search, color: AppColors.muted),
            ]),
          ),
        ),
      );
}

/// Search box for places (known Mangochi places work without internet).
class _PlaceSearch extends SearchDelegate<Place?> {
  final LatLng? near;
  _PlaceSearch({this.near}) : super(searchFieldLabel: 'Search a place');

  Timer? _debounce;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [if (query.isNotEmpty) IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];

  @override
  Widget buildLeading(BuildContext context) =>
      IconButton(onPressed: () => close(context, null), icon: const Icon(Icons.arrow_back));

  @override
  Widget buildResults(BuildContext context) => _results();

  @override
  Widget buildSuggestions(BuildContext context) {
    if (query.trim().length < 2) {
      final here = near;
      return ListView(children: [
        if (here != null)
          ListTile(
            leading: const Icon(Icons.my_location),
            title: Text(tx('Where I am now')),
            onTap: () => close(context, Place(Here.instance.name.value ?? 'Here', 'Where you are now', here)),
          ),
        for (final p in knownPlaces)
          ListTile(leading: const Icon(Icons.place_outlined), title: Text(p.name), subtitle: Text(p.detail), onTap: () => close(context, p)),
      ]);
    }
    return _results();
  }

  Widget _results() => FutureBuilder<List<Place>>(
        future: _search(query),
        builder: (context, snap) {
          if (!snap.hasData) return const LinearProgressIndicator();
          final list = snap.data!;
          if (list.isEmpty) return EmptyText(tx('No place found. Try another spelling.'));
          return ListView(children: [
            for (final p in list)
              ListTile(
                leading: const Icon(Icons.place_outlined),
                title: Text(p.name),
                subtitle: Text(p.detail),
                onTap: () => close(context, p),
              ),
          ]);
        },
      );

  Future<List<Place>> _search(String q) {
    _debounce?.cancel();
    final c = Completer<List<Place>>();
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      c.complete(await searchPlaces(q, near: near));
    });
    return c.future;
  }
}
