import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' hide Path;

/// Asks for location permission. Returns an error message, or null when GPS can be used.
Future<String?> ensureLocation() async {
  if (!await Geolocator.isLocationServiceEnabled()) return 'Turn on GPS (location) on your phone.';
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
  if (perm == LocationPermission.denied) return 'Allow location so the owner can see your truck.';
  if (perm == LocationPermission.deniedForever) {
    return 'Location is blocked. Allow it for EfuLogistix in your phone settings.';
  }
  return null;
}

Future<LatLng?> currentPoint() async {
  try {
    final p = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium),
    ).timeout(const Duration(seconds: 10));
    return LatLng(p.latitude, p.longitude);
  } catch (_) {
    // GPS slow (indoors): use the last position the phone knew
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) return LatLng(last.latitude, last.longitude);
    } catch (_) {}
    return null;
  }
}
