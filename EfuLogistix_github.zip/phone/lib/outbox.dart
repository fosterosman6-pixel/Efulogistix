import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_state.dart';

/// Saves writes on the phone when there is no signal and sends them later.
/// Used for stops, positions, GPS distance and expenses. Steps with photos need signal.
class Outbox {
  Outbox._();
  static final instance = Outbox._();

  static const _key = 'outbox_v1';
  final pending = ValueNotifier<int>(0);
  Timer? _timer;
  bool _flushing = false;

  Future<void> start() async {
    final prefs = await SharedPreferences.getInstance();
    pending.value = (prefs.getStringList(_key) ?? []).length;
    _timer ??= Timer.periodic(const Duration(seconds: 30), (_) => flush());
    unawaited(flush());
  }

  /// Insert a row, or keep it for later when offline.
  Future<void> insert(String table, Map<String, dynamic> row) => _send({'op': 'insert', 'table': table, 'row': row});

  /// Insert-or-update a row, or keep it for later when offline.
  Future<void> upsert(String table, Map<String, dynamic> row) => _send({'op': 'upsert', 'table': table, 'row': row});

  /// Call a database function, or keep the call for later when offline.
  Future<void> rpc(String fn, Map<String, dynamic> params) => _send({'op': 'rpc', 'fn': fn, 'params': params});

  Future<void> _send(Map<String, dynamic> job) async {
    try {
      await _run(job);
    } catch (e) {
      if (_isOffline(e)) {
        await _save(job);
      } else {
        rethrow;
      }
    }
  }

  Future<void> _run(Map<String, dynamic> job) async {
    switch (job['op']) {
      case 'insert':
        await db.from(job['table'] as String).insert(Map<String, dynamic>.from(job['row'] as Map));
      case 'upsert':
        await db.from(job['table'] as String).upsert(Map<String, dynamic>.from(job['row'] as Map));
      case 'rpc':
        await db.rpc(job['fn'] as String, params: Map<String, dynamic>.from(job['params'] as Map));
    }
  }

  bool _isOffline(Object e) {
    final m = e.toString().toLowerCase();
    return m.contains('socket') ||
        m.contains('failed host lookup') ||
        m.contains('network') ||
        m.contains('clientexception') ||
        m.contains('timeout') ||
        m.contains('connection');
  }

  Future<void> _save(Map<String, dynamic> job) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    list.add(jsonEncode(job));
    // keep at most 500 waiting jobs (positions are the most frequent; old ones matter least)
    while (list.length > 500) {
      list.removeAt(0);
    }
    await prefs.setStringList(_key, list);
    pending.value = list.length;
  }

  /// Sends everything that was saved while offline, oldest first.
  Future<void> flush() async {
    if (_flushing || db.auth.currentUser == null) return;
    _flushing = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList(_key) ?? [];
      while (list.isNotEmpty) {
        final job = jsonDecode(list.first) as Map<String, dynamic>;
        try {
          await _run(job);
        } catch (e) {
          if (_isOffline(e)) break; // still offline: try again later
          debugPrint('outbox dropped a job: $e'); // rejected by the server: drop it
        }
        list.removeAt(0);
        await prefs.setStringList(_key, list);
        pending.value = list.length;
      }
    } finally {
      _flushing = false;
    }
  }
}
