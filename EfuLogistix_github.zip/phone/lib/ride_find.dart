import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'app_state.dart';
import 'format.dart';
import 'geo.dart';
import 'here.dart';
import 'i18n.dart';
import 'location.dart';
import 'models.dart';
import 'pin_place.dart';
import 'screens/passenger/catalog.dart' show formCard;
import 'theme.dart';
import 'widgets.dart';

/// A depot where the passenger gets on or off. When they asked for a place that is not a depot
/// (a school, a shop, their house, "My location", a pin), `from` is that place and `walkKm` how far the depot is from it.
class DepotPick {
  final int pos;
  final String name;
  final String? from;
  final double? walkKm;
  const DepotPick(this.pos, this.name, {this.from, this.walkKm});

  int get walkMinutes => ((walkKm ?? 0) * 12).round().clamp(1, 999);
  String get walkText => walkKm == null ? '' : '${kmText(walkKm)} · ${walkMinutes} min walk';
  bool get far => (walkKm ?? 0) > 6;
}

/// The fare between two depots for one vehicle type, with the working.
class FareQuote {
  final String categoryId;
  final double km;
  final double fare;
  final double perKm;
  final double minFare;
  final double roundTo;
  final double totalKm;
  final double? fullFare;
  final bool overridden;
  const FareQuote(this.categoryId, this.km, this.fare, this.perKm, this.minFare, this.roundTo, this.totalKm, this.fullFare, this.overridden);

  factory FareQuote.fromMap(Map m) => FareQuote(
        '${m['category_id']}',
        toDouble(m['km']),
        toDouble(m['fare']),
        toDouble(m['per_km']),
        toDouble(m['min_fare']),
        toDouble(m['round_to']),
        toDouble(m['total_km']),
        m['full_fare'] == null ? null : toDouble(m['full_fare']),
        m['overridden'] == true,
      );

  /// What the whole-road price (or the rate) gives before rounding.
  double get raw => fullFare != null && totalKm > 0 ? fullFare! * km / totalKm : perKm * km;

  /// How the fare was worked out, in words.
  String get working {
    if (overridden) return tx('A fixed fare for these two depots.');
    final base = fullFare != null && totalKm > 0
        ? txf('%s for the whole road × %s of %s = %s', [money(fullFare), kmText(km), kmText(totalKm), money(raw)])
        : txf('%s × %s per km = %s', [kmText(km), money(perKm), money(raw)]);
    final rounded = txf('Rounded to the nearest %s → %s', [money(roundTo), money(fare)]);
    return '$base\n$rounded\n${txf('Never less than %s', [money(minFare)])}';
  }
}

/// The fares between two depots for every vehicle type at once, keyed by vehicle type id.
Future<Map<String, FareQuote>> loadQuotes(String corridorId, int fromPos, int toPos) async {
  final rows = await db.rpc('corridor_quote', params: {'p_corridor': corridorId, 'p_from': fromPos, 'p_to': toPos});
  final out = <String, FareQuote>{};
  if (rows is List) {
    for (final r in rows.whereType<Map>()) {
      final q = FareQuote.fromMap(r);
      out[q.categoryId] = q;
    }
  }
  return out;
}

/// A tappable search box.
class PickerField extends StatelessWidget {
  final String? value;
  final String hint;
  final VoidCallback onTap;
  const PickerField({super.key, required this.value, required this.hint, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          decoration: BoxDecoration(border: Border.all(color: AppColors.line, width: 1.5), borderRadius: BorderRadius.circular(8)),
          child: Row(children: [
            const Icon(Icons.search, color: AppColors.muted),
            const SizedBox(width: 10),
            Expanded(
              child: Text(value ?? hint,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 16, fontWeight: value == null ? FontWeight.w500 : FontWeight.w800, color: value == null ? AppColors.muted : AppColors.ink)),
            ),
          ]),
        ),
      );
}

/// FROM or TO: search any place, and see the nearest depot it was matched to.
class DepotField extends StatelessWidget {
  final String label;
  final String verb; // "Board at" / "Get off at"
  final DepotPick? pick;
  final VoidCallback onTap;
  final List<Widget> extras;
  const DepotField({super.key, required this.label, required this.verb, required this.pick, required this.onTap, this.extras = const []});

  @override
  Widget build(BuildContext context) {
    final p = pick;
    return formCard(
      label,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ...extras,
        PickerField(value: p?.from ?? p?.name, hint: tx('Search any place or depot'), onTap: onTap),
        if (p != null) ...[
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: AppColors.lime100, borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.directions_bus_outlined, color: AppColors.navy),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${tx(verb)} ${p.name}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy, fontSize: 15)),
                  if (p.from != null)
                    Text(txf('%s from %s', [p.walkText, p.from!]), style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                  if (p.far)
                    Text(tx('That is a long way to the nearest depot. A hire may suit you better.'),
                        style: const TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ),
              TextButton(onPressed: onTap, child: Text(tx('Other depot'))),
            ]),
          ),
        ],
      ]),
    );
  }
}

/// Search sheet: type any place (a school, a shop, a church ...), use "My location" or drop a pin; it is matched to the nearest depot.
/// A depot name can be picked directly. Returns a [DepotPick].
class DepotSearch extends StatefulWidget {
  final List<Map<String, dynamic>> stops;
  final LatLng? near;
  const DepotSearch({super.key, required this.stops, this.near});

  @override
  State<DepotSearch> createState() => _DepotSearchState();
}

class _DepotSearchState extends State<DepotSearch> {
  final _q = TextEditingController();
  List<Place> _hits = [];
  bool _busy = false;
  String? _err;
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  DepotPick? _pickFor(Place pl) {
    Map<String, dynamic>? best;
    var bestKm = double.infinity;
    for (final st in widget.stops) {
      final d = distanceKm(pl.point, LatLng(toDouble(st['lat']), toDouble(st['lng'])));
      if (d < bestKm) {
        bestKm = d;
        best = st;
      }
    }
    if (best == null) return null;
    return DepotPick(best['pos'] as int, '${best['place_name']}', from: pl.name, walkKm: bestKm);
  }

  void _use(Place pl) {
    final pick = _pickFor(pl);
    if (pick != null) Navigator.pop(context, pick);
  }

  Future<void> _searchMap(String q) async {
    if (q.trim().length < 2) return;
    setState(() => _busy = true);
    try {
      final r = await searchPlaces(q, near: widget.near).timeout(const Duration(seconds: 8));
      if (mounted) setState(() => _hits = r.take(6).toList());
    } catch (_) {
      if (mounted) setState(() => _hits = []);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _mine() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      final problem = await ensureLocation();
      if (problem != null) throw Exception(problem);
      final me = Here.instance.point.value ?? await currentPoint();
      if (me == null) throw Exception('no position');
      if (!mounted) return;
      _use(Place(tx('My location'), '', me));
    } catch (_) {
      if (mounted) setState(() => _err = tx('Could not find your location. Search a place instead.'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _pin() async {
    final p = await Navigator.of(context).push<Place>(MaterialPageRoute(builder: (_) => PinPlaceScreen(start: widget.near)));
    if (p != null && mounted) _use(p);
  }

  Widget _placeTile(Place h) {
    final pick = _pickFor(h);
    if (pick == null) return const SizedBox.shrink();
    return ListTile(
      leading: const Icon(Icons.near_me_outlined),
      title: Text(h.name, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(txf('Nearest depot: %s · %s away', [pick.name, kmText(pick.walkKm)])),
      onTap: () => Navigator.pop(context, pick),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = _q.text.trim();
    final q = text.toLowerCase();
    final depots = widget.stops.where((st) => q.isEmpty || '${st['place_name']}'.toLowerCase().contains(q)).toList();
    final stopNames = {for (final st in widget.stops) '${st['place_name']}'.toLowerCase()};
    final known = q.length < 2 ? <Place>[] : quickMatches(text).where((p) => !stopNames.contains(p.name.toLowerCase())).take(8).toList();
    final knownNames = {for (final p in known) p.name.toLowerCase()};
    final online = _hits.where((p) => !knownNames.contains(p.name.toLowerCase()) && !stopNames.contains(p.name.toLowerCase())).toList();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.82,
        child: Column(children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 10, bottom: 10), decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(4))),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              controller: _q,
              autofocus: true,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: tx('Search any place or depot'),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { _q.clear(); _hits = []; })),
              ),
              onChanged: (v) {
                setState(() => _hits = []);
                _debounce?.cancel();
                if (v.trim().length >= 3) _debounce = Timer(const Duration(milliseconds: 700), () => _searchMap(v));
              },
              onSubmitted: _searchMap,
            ),
          ),
          if (_err != null) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 6), child: Text(_err!, style: const TextStyle(color: AppColors.danger))),
          Expanded(
            child: ListView(children: [
              if (q.isEmpty) ...[
                ListTile(
                  leading: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location, color: AppColors.navy),
                  title: Text(tx('My location'), style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(tx('We find the nearest depot to you')),
                  onTap: _busy ? null : _mine,
                ),
                ListTile(
                  leading: const Icon(Icons.push_pin_outlined, color: AppColors.navy),
                  title: Text(tx('Choose on the map'), style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(tx('Drop a pin on any spot')),
                  onTap: _pin,
                ),
                const Divider(),
              ],
              for (final st in depots)
                ListTile(
                  leading: const Icon(Icons.directions_bus_outlined, color: AppColors.lime600),
                  title: Text('${st['place_name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(tx('Depot')),
                  onTap: () => Navigator.pop(context, DepotPick(st['pos'] as int, '${st['place_name']}')),
                ),
              if (known.isNotEmpty) ...[
                if (depots.isNotEmpty) const Divider(),
                for (final p in known) _placeTile(p),
              ],
              if (online.isNotEmpty) ...[
                const Divider(),
                for (final h in online) _placeTile(h),
              ],
              if (q.length >= 2 && online.isEmpty)
                ListTile(
                  leading: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.travel_explore),
                  title: Text(txf('Find "%s" on the map', [text])),
                  subtitle: Text(tx('We pick the nearest depot to it')),
                  onTap: _busy ? null : () => _searchMap(text),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}
