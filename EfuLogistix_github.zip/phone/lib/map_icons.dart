import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:vector_graphics/vector_graphics.dart' show vg;

import 'theme.dart';
import 'vehicle_art.dart';

/// Map markers drawn in code: a round car badge with the plate underneath,
/// numbered pickup circles and a destination flag. Cached, so each one is drawn once.
class MapIcons {
  MapIcons._();
  static final _cache = <String, g.BitmapDescriptor>{};
  static const _scale = 3.0; // draw at 3x so they stay sharp

  static Future<g.BitmapDescriptor> _draw(String key, double w, double h, void Function(Canvas c) paint) async {
    final hit = _cache[key];
    if (hit != null) return hit;
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec)..scale(_scale);
    paint(canvas);
    final img = await rec.endRecording().toImage((w * _scale).ceil(), (h * _scale).ceil());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    final icon = g.BitmapDescriptor.bytes(data!.buffer.asUint8List(), width: w, height: h);
    _cache[key] = icon;
    return icon;
  }

  static TextPainter _text(String t, double size, Color color, {FontWeight weight = FontWeight.w800}) =>
      TextPainter(text: TextSpan(text: t, style: TextStyle(fontSize: size, color: color, fontWeight: weight, fontFamily: 'Inter')), textDirection: TextDirection.ltr, maxLines: 1)
        ..layout();

  static TextPainter _glyph(IconData i, double size, Color color) => TextPainter(
        text: TextSpan(
            text: String.fromCharCode(i.codePoint),
            style: TextStyle(fontSize: size, color: color, fontFamily: i.fontFamily, package: i.fontPackage)),
        textDirection: TextDirection.ltr,
      )..layout();

  /// The vehicle picture on a white card with its plate underneath (real photo where we have one,
  /// the drawing otherwise). Parked vehicles are faded with a grey plate.
  static Future<g.BitmapDescriptor> car({required String label, bool idle = false, String kind = 'matola'}) async {
    final key = 'veh2|$label|$idle|$kind';
    final hit = _cache[key];
    if (hit != null) return hit;
    ui.Image? photo;
    if (photoKinds.contains(kind)) {
      try {
        final bytes = (await rootBundle.load('assets/vehicles/$kind.jpg')).buffer.asUint8List();
        final codec = await ui.instantiateImageCodec(bytes, targetWidth: 360);
        photo = (await codec.getNextFrame()).image;
      } catch (_) {}
    }
    final art = photo == null ? await vg.loadPicture(SvgStringLoader(vehicleSvg(kind)), null) : null;
    final tp = _text(label, 11, idle ? AppColors.muted : AppColors.navy);
    const cw = 92.0, ch = 54.0; // the card
    final w = (tp.width + 24).clamp(cw + 8, 170.0).toDouble();
    final h = ch + 6 + 20;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec)..scale(_scale);
    final cx = w / 2;
    final card = RRect.fromRectAndRadius(Rect.fromLTWH(cx - cw / 2, 3, cw, ch), const Radius.circular(12));
    if (idle) c.saveLayer(null, Paint()..color = const Color(0xB3FFFFFF));
    c.drawShadow(Path()..addRRect(card), const Color(0xFF0A2253), 4, false);
    c.drawRRect(card, Paint()..color = Colors.white);
    c.drawRRect(
        card,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = idle ? AppColors.line : AppColors.navy);
    final inner = Rect.fromLTWH(cx - cw / 2 + 5, 3 + 4, cw - 10, ch - 8);
    if (photo != null) {
      final fit = applyBoxFit(BoxFit.contain, Size(photo.width.toDouble(), photo.height.toDouble()), inner.size);
      final dst = Alignment.center.inscribe(fit.destination, inner);
      c.drawImageRect(photo, Offset.zero & Size(photo.width.toDouble(), photo.height.toDouble()), dst, Paint()..filterQuality = FilterQuality.high);
    } else if (art != null) {
      c.save();
      c.translate(inner.left, inner.top + (inner.height - inner.width / 2) / 2);
      c.scale(inner.width / art.size.width, (inner.width / 2) / art.size.height);
      c.drawPicture(art.picture);
      c.restore();
      art.picture.dispose();
    }
    if (idle) c.restore();
    final pill = RRect.fromRectAndRadius(Rect.fromLTWH(cx - tp.width / 2 - 8, ch + 6, tp.width + 16, 18), const Radius.circular(9));
    c.drawRRect(pill, Paint()..color = idle ? const Color(0xFFE6E9EF) : AppColors.navy);
    tp
      ..text = TextSpan(text: label, style: TextStyle(fontSize: 11, color: idle ? AppColors.muted : Colors.white, fontWeight: FontWeight.w800, fontFamily: 'Inter'))
      ..layout();
    tp.paint(c, Offset(cx - tp.width / 2, ch + 6 + (18 - tp.height) / 2));
    final img = await rec.endRecording().toImage((w * _scale).ceil(), (h * _scale).ceil());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    final icon = g.BitmapDescriptor.bytes(data!.buffer.asUint8List(), width: w, height: h);
    _cache[key] = icon;
    return icon;
  }


  /// The car seen from above (assets/car_top.png). Use with `flat: true` and `rotation: bearing`
  /// so it turns the way the vehicle drives. Parked vehicles are faded.
  static Future<g.BitmapDescriptor> topCar({bool idle = false, String kind = 'taxi'}) async {
    final key = 'top2|$kind|$idle';
    final hit = _cache[key];
    if (hit != null) return hit;
    final w = kind == 'kabaza' ? 14.0 : 30.0;
    ui.Image img;
    try {
      final bytes = (await rootBundle.load('assets/topview/$kind.png')).buffer.asUint8List();
      img = (await (await ui.instantiateImageCodec(bytes, targetWidth: (w * _scale).ceil())).getNextFrame()).image;
    } catch (_) {
      final bytes = (await rootBundle.load('assets/car_top.png')).buffer.asUint8List();
      img = (await (await ui.instantiateImageCodec(bytes, targetWidth: (w * _scale).ceil())).getNextFrame()).image;
    }
    final h = w * img.height / img.width;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    c.drawImageRect(img, Offset.zero & Size(img.width.toDouble(), img.height.toDouble()),
        Rect.fromLTWH(0, 0, w * _scale, h * _scale), Paint()..filterQuality = FilterQuality.high..color = Color.fromRGBO(255, 255, 255, idle ? 0.55 : 1));
    final out = await rec.endRecording().toImage((w * _scale).ceil(), (h * _scale).ceil());
    final data = await out.toByteData(format: ui.ImageByteFormat.png);
    final icon = g.BitmapDescriptor.bytes(data!.buffer.asUint8List(), width: w, height: h);
    _cache[key] = icon;
    return icon;
  }

  /// The plate in a small pill. Transparent space on top, so with anchor (0.5, 0) it hangs
  /// just under a car marker placed at the same point.
  static Future<g.BitmapDescriptor> plate(String label, {bool idle = false}) {
    final tp = _text(label, 11, idle ? AppColors.muted : Colors.white);
    final w = tp.width + 18;
    const top = 26.0, ph = 18.0;
    return _draw('plate|$label|$idle', w, top + ph, (c) {
      final pill = RRect.fromRectAndRadius(Rect.fromLTWH(0, top, w, ph), const Radius.circular(9));
      c.drawRRect(pill, Paint()..color = idle ? const Color(0xFFE6E9EF) : AppColors.navy);
      tp.paint(c, Offset((w - tp.width) / 2, top + (ph - tp.height) / 2));
    });
  }

  /// Direction of travel from [a] to [b] in degrees (0 = north), or null when they are under ~4 m apart.
  static double? bearing(double aLat, double aLng, double bLat, double bLng) {
    final dy = (bLat - aLat) * 111320;
    final dx = (bLng - aLng) * 111320 * math.cos(aLat * math.pi / 180);
    if (dx * dx + dy * dy < 16) return null;
    return (math.atan2(dx, dy) * 180 / math.pi + 360) % 360;
  }

  /// Numbered pickup circle ("?" when the place was only guessed).
  static Future<g.BitmapDescriptor> number(int n, {bool auto = false}) {
    const d = 32.0;
    final label = auto ? '?' : (n == 0 ? '' : '$n');
    return _draw('num|$label|$auto', d, d, (c) {
      c.drawCircle(const Offset(d / 2, d / 2), d / 2 - 1, Paint()..color = auto ? AppColors.warning : AppColors.navy);
      c.drawCircle(
          const Offset(d / 2, d / 2),
          d / 2 - 2,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3
            ..color = Colors.white);
      if (label.isEmpty) {
        c.drawCircle(const Offset(d / 2, d / 2), 5, Paint()..color = Colors.white);
      } else {
        final tp = _text(label, 15, Colors.white);
        tp.paint(c, Offset(d / 2 - tp.width / 2, d / 2 - tp.height / 2));
      }
    });
  }

  /// Destination / "you are here to be picked up" flag.
  static Future<g.BitmapDescriptor> flag() {
    const w = 40.0, h = 48.0;
    return _draw('flag', w, h, (c) {
      c.drawCircle(const Offset(w / 2, 18), 17, Paint()..color = AppColors.lime);
      c.drawCircle(
          const Offset(w / 2, 18),
          17,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3
            ..color = AppColors.navy);
      final f = _glyph(Icons.flag, 22, AppColors.navy);
      f.paint(c, Offset(w / 2 - f.width / 2, 18 - f.height / 2));
      c.drawPath(
          Path()
            ..moveTo(w / 2 - 6, 33)
            ..lineTo(w / 2 + 6, 33)
            ..lineTo(w / 2, 47)
            ..close(),
          Paint()..color = AppColors.navy);
    });
  }
}
