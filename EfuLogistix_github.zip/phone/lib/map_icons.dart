import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as g;
import 'package:vector_graphics/vector_graphics.dart' show vg;

import 'theme.dart';
import 'vehicle_art.dart';

/// Map markers drawn in code: a round car badge with the plate underneath,
/// numbered pickup circles and a destination flag. Cached, so each one is drawn once.
class MapIcons {
  MapIcons._();
  static final _cache = <String, g.BitmapDescriptor>{};
  static const _scale = 3.0; // draw at 3x so they stay sharp

  static Future<g.BitmapDescriptor> _draw(String key, double w, double h, void Function(Canvas c) paint) async {
    final hit = _cache[key];
    if (hit != null) return hit;
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec)..scale(_scale);
    paint(canvas);
    final img = await rec.endRecording().toImage((w * _scale).ceil(), (h * _scale).ceil());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    final icon = g.BitmapDescriptor.bytes(data!.buffer.asUint8List(), width: w, height: h);
    _cache[key] = icon;
    return icon;
  }

  static TextPainter _text(String t, double size, Color color, {FontWeight weight = FontWeight.w800}) =>
      TextPainter(text: TextSpan(text: t, style: TextStyle(fontSize: size, color: color, fontWeight: weight)), textDirection: TextDirection.ltr, maxLines: 1)
        ..layout();

  static TextPainter _glyph(IconData i, double size, Color color) => TextPainter(
        text: TextSpan(
            text: String.fromCharCode(i.codePoint),
            style: TextStyle(fontSize: size, color: color, fontFamily: i.fontFamily, package: i.fontPackage)),
        textDirection: TextDirection.ltr,
      )..layout();

  /// The vehicle illustration (kabaza, taxi, matola, minibus or lorry) with its plate underneath.
  /// Parked vehicles are drawn faded with a grey plate.
  static Future<g.BitmapDescriptor> car({required String label, bool idle = false, String kind = 'matola'}) async {
    final key = 'veh|$label|$idle|$kind';
    final hit = _cache[key];
    if (hit != null) return hit;
    final info = await vg.loadPicture(SvgStringLoader(vehicleSvg(kind)), null);
    final tp = _text(label, 11, idle ? AppColors.muted : AppColors.navy);
    const vw = 96.0, vh = 48.0;
    final w = (tp.width + 16).clamp(vw, 160.0).toDouble();
    final h = vh + 2 + 18;
    final rec = ui.PictureRecorder();
    final c = Canvas(rec)..scale(_scale);
    final cx = w / 2;
    c.save();
    c.translate(cx - vw / 2, 0);
    c.scale(vw / info.size.width, vh / info.size.height);
    if (idle) c.saveLayer(null, Paint()..color = const Color(0xB3FFFFFF));
    c.drawPicture(info.picture);
    if (idle) c.restore();
    c.restore();
    info.picture.dispose();
    final pill = RRect.fromRectAndRadius(Rect.fromLTWH(cx - tp.width / 2 - 7, vh + 2, tp.width + 14, 16), const Radius.circular(8));
    c.drawRRect(pill, Paint()..color = idle ? const Color(0xFFE6E9EF) : Colors.white);
    c.drawRRect(
        pill,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = idle ? AppColors.muted : AppColors.lime600);
    tp.paint(c, Offset(cx - tp.width / 2, vh + 2 + (16 - tp.height) / 2));
    final img = await rec.endRecording().toImage((w * _scale).ceil(), (h * _scale).ceil());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    final icon = g.BitmapDescriptor.bytes(data!.buffer.asUint8List(), width: w, height: h);
    _cache[key] = icon;
    return icon;
  }

  /// Numbered pickup circle ("?" when the place was only guessed).
  static Future<g.BitmapDescriptor> number(int n, {bool auto = false}) {
    const d = 32.0;
    final label = auto ? '?' : (n == 0 ? '' : '$n');
    return _draw('num|$label|$auto', d, d, (c) {
      c.drawCircle(const Offset(d / 2, d / 2), d / 2 - 1, Paint()..color = auto ? AppColors.warning : AppColors.navy);
      c.drawCircle(
          const Offset(d / 2, d / 2),
          d / 2 - 2,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3
            ..color = Colors.white);
      if (label.isEmpty) {
        c.drawCircle(const Offset(d / 2, d / 2), 5, Paint()..color = Colors.white);
      } else {
        final tp = _text(label, 15, Colors.white);
        tp.paint(c, Offset(d / 2 - tp.width / 2, d / 2 - tp.height / 2));
      }
    });
  }

  /// Destination / "you are here to be picked up" flag.
  static Future<g.BitmapDescriptor> flag() {
    const w = 40.0, h = 48.0;
    return _draw('flag', w, h, (c) {
      c.drawCircle(const Offset(w / 2, 18), 17, Paint()..color = AppColors.lime);
      c.drawCircle(
          const Offset(w / 2, 18),
          17,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3
            ..color = AppColors.navy);
      final f = _glyph(Icons.flag, 22, AppColors.navy);
      f.paint(c, Offset(w / 2 - f.width / 2, 18 - f.height / 2));
      c.drawPath(
          Path()
            ..moveTo(w / 2 - 6, 33)
            ..lineTo(w / 2 + 6, 33)
            ..lineTo(w / 2, 47)
            ..close(),
          Paint()..color = AppColors.navy);
    });
  }
}
