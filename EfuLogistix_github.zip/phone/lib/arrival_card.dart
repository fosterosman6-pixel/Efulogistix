import 'package:flutter/material.dart';

import 'capture.dart';
import 'i18n.dart';
import 'models.dart';
import 'theme.dart';

/// The person's profile picture, large, with their name on it. Shown to the passenger when the driver
/// has arrived, and to the driver when they reach the passenger, so each can recognise the other.
class FullPhotoCard extends StatelessWidget {
  final Profile? person;
  final String tag; // e.g. "Your driver has arrived"
  final double height;
  const FullPhotoCard({super.key, required this.person, required this.tag, this.height = 300});

  void _open(BuildContext context) {
    final p = person;
    if (p?.avatarPath == null) return;
    showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        backgroundColor: Colors.black,
        child: InteractiveViewer(child: StoredImage(p!.avatarPath, height: 520, fit: BoxFit.contain)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = person;
    final name = p?.displayName ?? '';
    final letter = (p?.firstName ?? '').isEmpty ? '?' : p!.firstName.substring(0, 1).toUpperCase();
    return GestureDetector(
      onTap: () => _open(context),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: SizedBox(
          height: height,
          width: double.infinity,
          child: Stack(fit: StackFit.expand, children: [
            if (p?.avatarPath == null)
              Container(
                color: AppColors.lime,
                alignment: Alignment.center,
                child: Text(letter, style: const TextStyle(fontSize: 110, fontWeight: FontWeight.w800, color: AppColors.navy)),
              )
            else
              IgnorePointer(child: StoredImage(p!.avatarPath, height: height, width: double.infinity)),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x00000000), Color(0x00000000), Color(0xCC0A2253)],
                  stops: [0, 0.55, 1],
                ),
              ),
            ),
            Positioned(
              left: 12,
              top: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(20)),
                child: Text(tx(tag), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: AppColors.navy)),
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 12,
              child: Text(name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
            ),
          ]),
        ),
      ),
    );
  }
}

/// Plate, colour, make and model of the vehicle, so the passenger can spot it.
class VehicleInfo extends StatelessWidget {
  final Truck truck;
  final String? category;
  const VehicleInfo({super.key, required this.truck, this.category});

  @override
  Widget build(BuildContext context) {
    final rows = <MapEntry<String, String>>[
      if ((truck.colour ?? '').trim().isNotEmpty) MapEntry(tx('Colour'), truck.colour!.trim()),
      if ((truck.make ?? '').trim().isNotEmpty) MapEntry(tx('Make'), truck.make!.trim()),
      if ((truck.model ?? '').trim().isNotEmpty) MapEntry(tx('Model'), truck.model!.trim()),
      if (category != null) MapEntry(tx('Type'), category!),
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.line)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(10)),
          child: Text(truck.plate.toUpperCase(),
              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            for (final r in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 1),
                child: Row(children: [
                  SizedBox(
                    width: 58,
                    child: Text(r.key, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ),
                  Expanded(child: Text(r.value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700))),
                ]),
              ),
          ]),
        ),
      ]),
    );
  }
}
