import 'package:flutter/material.dart';
import 'icon_art.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';
import 'demo/demo.dart';
import 'i18n.dart';
import 'photos.dart';
import 'profile_header.dart';
import 'theme.dart';
import 'widgets.dart';

/// Holds a mileage photo and the typed km.
class OdoController {
  Photo? photo;
  final km = TextEditingController();
  int? get value => int.tryParse(km.text.replaceAll(RegExp(r'[^0-9]'), ''));
  bool get ready => photo != null && value != null;
  void dispose() => km.dispose();
}

/// "1 · Photo of mileage" + "2 · Type the mileage" block used at every mileage step.
class OdometerCapture extends StatefulWidget {
  final OdoController controller;
  final String photoLabel; // file name prefix, e.g. 'shift_start'
  final String? hint; // e.g. "Last recorded: 45,218 km"
  final VoidCallback? onChanged;
  const OdometerCapture({super.key, required this.controller, required this.photoLabel, this.hint, this.onChanged});

  @override
  State<OdometerCapture> createState() => _OdometerCaptureState();
}

class _OdometerCaptureState extends State<OdometerCapture> {
  bool _busy = false;

  Future<void> _take() async {
    setState(() => _busy = true);
    try {
      final p = await takePhoto(widget.photoLabel);
      if (p != null) {
        widget.controller.photo = p;
        widget.onChanged?.call();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final photo = widget.controller.photo;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FieldLabel('1 · ${tr('mileage_photo')}'),
              const SizedBox(height: 8),
              InkWell(
                onTap: _busy ? null : _take,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  height: 150,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(color: const Color(0xFF111827), borderRadius: BorderRadius.circular(10)),
                  child: Stack(fit: StackFit.expand, children: [
                    if (photo != null) Image.memory(photo.bytes, fit: BoxFit.cover),
                    if (photo == null)
                      Center(
                        child: _busy
                            ? const CircularProgressIndicator(color: Colors.white)
                            : Column(mainAxisSize: MainAxisSize.min, children: [
                                const Icon(Icons.photo_camera, color: Colors.white, size: 36),
                                const SizedBox(height: 6),
                                Text(tr('take_photo'),
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                              ]),
                      ),
                    if (photo != null)
                      Positioned(
                        right: 8,
                        top: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(999)),
                          child: Text(tr('retake'),
                              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                        ),
                      ),
                    if (photo != null)
                      Positioned(
                        left: 8,
                        bottom: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(999)),
                          child: Text(tx('Live photo saved'),
                              style: TextStyle(color: AppColors.navy, fontSize: 12, fontWeight: FontWeight.w700)),
                        ),
                      ),
                  ]),
                ),
              ),
              const SizedBox(height: 6),
              Text(tr('camera_only'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        AppCard(
          borderColor: AppColors.lime,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FieldLabel('2 · ${tr('type_mileage')}'),
              TextField(
                controller: widget.controller.km,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => widget.onChanged?.call(),
                decoration: const InputDecoration(hintText: '0', border: InputBorder.none),
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              if (widget.hint != null)
                Text(widget.hint!,
                    style: const TextStyle(fontSize: 12, color: AppColors.lime600, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ],
    );
  }
}

/// One square photo slot (truck sides, documents). Shows the picture once taken.
class PhotoSlot extends StatefulWidget {
  final String label;
  final String fileLabel;
  final Photo? photo;
  final ValueChanged<Photo> onTaken;
  final bool allowGallery;
  final bool front;
  final double height;
  final String? existing; // a photo already stored (shown until a new one is taken)
  final String? hint; // what to shoot, shown in the empty box
  final VoidCallback? onRemove;
  const PhotoSlot({
    super.key,
    required this.label,
    required this.fileLabel,
    required this.photo,
    required this.onTaken,
    this.allowGallery = false,
    this.front = false,
    this.height = 80,
    this.existing,
    this.hint,
    this.onRemove,
  });

  @override
  State<PhotoSlot> createState() => _PhotoSlotState();
}

class _PhotoSlotState extends State<PhotoSlot> {
  bool _busy = false;

  Future<void> _take({bool gallery = false}) async {
    setState(() => _busy = true);
    try {
      final p = await takePhoto(widget.fileLabel, allowGallery: gallery, front: widget.front);
      if (p != null) widget.onTaken(p);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _choose() async {
    if (!widget.allowGallery) return _take();
    final p = widget.photo;
    final has = p != null || widget.existing != null;
    final pick = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_camera_outlined), title: Text(tx('Take a photo')), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.photo_library_outlined), title: Text(tx('Choose from the gallery')), onTap: () => Navigator.pop(ctx, 'gallery')),
          if (has)
            ListTile(leading: const Icon(Icons.zoom_in), title: Text(tx('View large')), onTap: () => Navigator.pop(ctx, 'view')),
          if (widget.onRemove != null && p != null)
            ListTile(leading: const Icon(Icons.delete_outline, color: AppColors.danger), title: Text(tx('Remove')), onTap: () => Navigator.pop(ctx, 'remove')),
        ]),
      ),
    );
    if (!mounted || pick == null) return;
    if (pick == 'camera') return _take();
    if (pick == 'gallery') return _take(gallery: true);
    if (pick == 'remove') return widget.onRemove?.call();
    if (pick == 'view') {
      await showDialog<void>(
        context: context,
        builder: (_) => Dialog(
          insetPadding: const EdgeInsets.all(12),
          backgroundColor: Colors.black,
          child: InteractiveViewer(
            child: p != null ? Image.memory(p.bytes, fit: BoxFit.contain) : StoredImage(widget.existing, height: 520, fit: BoxFit.contain),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.photo;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InkWell(
          onTap: _busy ? null : _choose,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            height: widget.height,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: p == null ? AppColors.surface100 : null,
              borderRadius: BorderRadius.circular(8),
              border: p == null ? Border.all(color: AppColors.muted) : null,
            ),
            child: p != null
                ? Image.memory(p.bytes, fit: BoxFit.cover)
                : widget.existing != null
                    ? IgnorePointer(child: StoredImage(widget.existing, height: widget.height, width: double.infinity))
                    : Center(
                        child: _busy
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const IconArt('camera', size: 38, fallback: Icons.add_a_photo_outlined),
                                if (widget.hint != null && widget.height >= 80)
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(6, 2, 6, 0),
                                    child: Text(widget.hint!,
                                        textAlign: TextAlign.center,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                                  ),
                              ]),
                      ),
          ),
        ),
        const SizedBox(height: 4),
        Text('${widget.label}${p != null || widget.existing != null ? ' ✓' : ''}',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: p != null || widget.existing != null ? AppColors.navy : AppColors.muted)),
        if (widget.allowGallery && !_busy)
          Text(tx(p != null || widget.existing != null ? 'Tap to change' : 'Tap to add'),
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: AppColors.muted)),
      ],
    );
  }
}

/// Shows a stored photo (signed link), with a tap to see it full screen.
class StoredImage extends StatelessWidget {
  final String? path;
  final double height;
  final double? width;
  final BoxFit fit;
  const StoredImage(this.path, {super.key, this.height = 80, this.width, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    // photos taken in demo mode are kept on the phone
    final local = path == null ? null : Demo.photos[path];
    if (local != null) {
      return InkWell(
        onTap: () => showDialog<void>(
          context: context,
          builder: (_) => Dialog(
            insetPadding: const EdgeInsets.all(12),
            child: InteractiveViewer(child: Image.memory(local, fit: BoxFit.contain)),
          ),
        ),
        child: Container(
          height: height,
          width: width,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: const Color(0xFF111827), borderRadius: BorderRadius.circular(8)),
          child: Image.memory(local, fit: fit),
        ),
      );
    }
    return FutureBuilder<String?>(
        future: photoUrl(path),
        builder: (context, snap) {
          final url = snap.data;
          final box = Container(
            height: height,
            width: width,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(color: const Color(0xFF111827), borderRadius: BorderRadius.circular(8)),
            child: url == null
                ? Center(
                    child: snap.connectionState == ConnectionState.waiting
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.image_not_supported_outlined, color: Colors.white54))
                : Image.network(url, fit: fit),
          );
          if (url == null) return box;
          return InkWell(
            onTap: () => showDialog<void>(
              context: context,
              builder: (_) => Dialog(
                insetPadding: const EdgeInsets.all(12),
                child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain)),
              ),
            ),
            child: box,
          );
        },
      );
  }
}

/// Small coloured label (Approved, Pending, Short K4,870 ...).
class StatusPill extends StatelessWidget {
  final String text;
  final Color color;
  final Color? background;
  const StatusPill(this.text, {super.key, this.color = AppColors.navy, this.background});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: background ?? color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
      );
}

/// English / Chichewa switch for driver screens.
class LanguageSwitch extends StatelessWidget {
  const LanguageSwitch({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: language,
        builder: (context, lang, _) => Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(color: AppColors.navy700, borderRadius: BorderRadius.circular(999)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            for (final (code, name) in const [('en', 'English'), ('ny', 'Chichewa')])
              GestureDetector(
                onTap: () => appState.setLanguage(code),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: lang == code ? AppColors.lime : Colors.transparent,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(name,
                      style: TextStyle(
                          fontSize: 11, fontWeight: FontWeight.w700, color: lang == code ? AppColors.navy : Colors.white)),
                ),
              ),
          ]),
        ),
      );
}

/// − 12 + counter.
class Counter extends StatelessWidget {
  final String label;
  final int value;
  final ValueChanged<int> onChanged;
  final bool highlight;
  final int? max; // cannot go above this (e.g. seats left)
  const Counter({super.key, required this.label, required this.value, required this.onChanged, this.highlight = false, this.max});

  @override
  Widget build(BuildContext context) => AppCard(
        borderColor: highlight ? AppColors.lime : null,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FieldLabel(label),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _round(Icons.remove, 'Less', AppColors.surface100, () => onChanged(value > 0 ? value - 1 : 0)),
              Text('$value', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              _round(Icons.add, 'More', AppColors.lime, () => onChanged(max != null && value >= max! ? value : value + 1)),
            ]),
          ],
        ),
      );

  Widget _round(IconData icon, String tip, Color color, VoidCallback onTap) => Semantics(
        button: true,
        label: '$tip $label',
        child: Material(
          color: color,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(width: 44, height: 44, child: Icon(icon, color: AppColors.navy)),
          ),
        ),
      );
}

/// "ON DUTY · MZ 4521 · MATOLA · since 07:31" -> "On duty · MZ 4521" (short, one line).
String _statusLine(String raw) {
  final parts = raw.split(' · ').where((e) => e.trim().isNotEmpty).toList();
  if (parts.isEmpty) return '';
  final head = parts.first.trim();
  final nice = head.isEmpty ? head : head[0].toUpperCase() + head.substring(1).toLowerCase();
  return parts.length > 1 ? '$nice · ${parts[1].trim()}' : nice;
}

/// Round top-bar button that flips English / Chichewa.
class LanguageButton extends StatelessWidget {
  const LanguageButton({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: language,
        builder: (context, lang, _) => Tooltip(
          message: lang == 'ny' ? 'English' : 'Chichewa',
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => appState.setLanguage(lang == 'ny' ? 'en' : 'ny'),
            child: Container(
              width: 36,
              height: 36,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.navy700, shape: BoxShape.circle),
              child: Text(lang == 'ny' ? 'NY' : 'EN', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
            ),
          ),
        ),
      );
}

/// Navy page header used on driver screens.
class NavyHeader extends StatelessWidget {
  final String top;
  final String title;
  final String? subtitle;
  final List<Widget> actions;
  const NavyHeader({super.key, required this.top, required this.title, this.subtitle, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    final lang = actions.whereType<LanguageSwitch>().toList();
    final rest = actions.where((a) => a is! LanguageSwitch).toList();
    final me = appState.profile;
    return Container(
      color: AppColors.navy,
      padding: const EdgeInsets.fromLTRB(16, 8, 4, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
            const ProfileAvatarButton(size: 48),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(greetingFor(me),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Row(children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: (top.toUpperCase().startsWith('ON DUTY') || top.toUpperCase().startsWith('MUKUGWIRA')) ? AppColors.lime : const Color(0xFF9AA3B8),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(_statusLine(top),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                ]),
              ]),
            ),
            if (lang.isNotEmpty) const LanguageButton(),
            ...rest,
          ]),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              Expanded(
                child: Text(title,
                    style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, height: 1.1)),
              ),
            ]),
          ),
          if (subtitle != null)
            Padding(
              padding: const EdgeInsets.only(right: 12, top: 4),
              child: Text(subtitle!, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 14)),
            ),
        ],
      ),
    );
  }
}
