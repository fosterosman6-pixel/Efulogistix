import 'package:flutter/material.dart';

import 'app_state.dart';
import 'format.dart';
import 'i18n.dart';
import 'models.dart';
import 'theme.dart';
import 'widgets.dart';
import 'screens/passenger/catalog.dart' show navyBar;

String _groupName(String g) => switch (g) {
      'walkin' => tx('Walk-ins'),
      'parcel' => tx('Parcels'),
      'hire' => tx('Hire'),
      _ => tx('Booked passengers'),
    };

/// Every rand of one trip: cash to hand in, and what was already paid. Read from the booking records,
/// for the driver at the end of a trip and for the owner on the trip page.
class TripMoneyCard extends StatefulWidget {
  final String tripId;
  const TripMoneyCard({super.key, required this.tripId});

  @override
  State<TripMoneyCard> createState() => _TripMoneyCardState();
}

class _TripMoneyCardState extends State<TripMoneyCard> {
  Map<String, dynamic>? _m;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await db.rpc('trip_money', params: {'p_trip': widget.tripId});
      if (mounted && r is Map) setState(() => _m = Map<String, dynamic>.from(r));
    } catch (_) {} // the older summary above still shows the cash total
  }

  List<Map<String, dynamic>> _list(String key) => [for (final e in (_m?[key] as List? ?? [])) Map<String, dynamic>.from(e as Map)];

  Widget _row(String label, double amount, {VoidCallback? onTap, bool bold = false}) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Expanded(child: Text(label, style: TextStyle(fontSize: 14, fontWeight: bold ? FontWeight.w800 : FontWeight.w500))),
            Text(money(amount), style: TextStyle(fontSize: bold ? 17 : 14, fontWeight: FontWeight.w800, color: AppColors.navy)),
            if (onTap != null) const Icon(Icons.chevron_right, size: 18, color: AppColors.muted),
          ]),
        ),
      );

  void _open(String group, bool cash) => Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => TripMoneyLinesScreen(tripId: widget.tripId, group: group, cash: cash, title: _groupName(group))));

  @override
  Widget build(BuildContext context) {
    final m = _m;
    if (m == null) return const SizedBox.shrink();
    final cash = _list('cash');
    final paid = _list('paid');
    final other = toDouble(m['cash_other_stops']);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 12),
      AppCard(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          FieldLabel(tx('CASH COLLECTED')),
          if (cash.isEmpty && other <= 0) Text(tx('No cash this trip.'), style: const TextStyle(color: AppColors.muted)),
          for (final c in cash) _row('${_groupName('${c['group']}')} (${toInt(c['count'])})', toDouble(c['amount']), onTap: () => _open('${c['group']}', true)),
          if (other > 0) _row(tx('Other stops on the way'), other),
          const Divider(color: AppColors.line, height: 16),
          _row(tx('Hand in'), toDouble(m['hand_in']), bold: true),
        ]),
      ),
      if (paid.isNotEmpty) ...[
        const SizedBox(height: 12),
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            FieldLabel(tx('ALREADY PAID · NOT FOR YOU TO HAND IN')),
            for (final p in paid)
              _row('${payNames['${p['method']}'] ?? '${p['method']}'} · ${_groupName('${p['group']}')} (${toInt(p['count'])})', toDouble(p['amount']),
                  onTap: () => _open('${p['group']}', false)),
            const Divider(color: AppColors.line, height: 16),
            _row(tx('Paid to EfuLogistix'), toDouble(m['paid_total']), bold: true),
          ]),
        ),
      ],
      const SizedBox(height: 12),
      AppCard(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _row(tx('All fares this trip'), toDouble(m['all_total']), bold: true),
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(txf('%s of %s seats used (passengers, walk-ins and large parcels)', ['${toInt(m['seats_used'])}', '${toInt(m['seats_cap'])}']),
                style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          ),
          const Divider(color: AppColors.line, height: 12),
          _row(txf('Wallet share (%s%% of cash)', ['${toDouble(m['wallet_pct']).round()}']), toDouble(m['wallet_share'])),
        ]),
      ),
    ]);
  }
}

/// The people behind one line of the summary.
class TripMoneyLinesScreen extends StatefulWidget {
  final String tripId, group, title;
  final bool cash;
  const TripMoneyLinesScreen({super.key, required this.tripId, required this.group, required this.cash, required this.title});

  @override
  State<TripMoneyLinesScreen> createState() => _TripMoneyLinesScreenState();
}

class _TripMoneyLinesScreenState extends State<TripMoneyLinesScreen> {
  List<Map<String, dynamic>>? _rows;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await db.rpc('trip_money_lines', params: {'p_trip': widget.tripId, 'p_group': widget.group, 'p_cash': widget.cash});
      if (mounted) setState(() => _rows = [for (final e in (r as List)) Map<String, dynamic>.from(e as Map)]);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = _rows;
    final total = rows == null ? 0.0 : rows.fold<double>(0, (s, r) => s + toDouble(r['amount']));
    return Scaffold(
      appBar: navyBar(widget.title),
      backgroundColor: AppColors.surface100,
      body: rows == null
          ? Center(child: _error == null ? const CircularProgressIndicator() : ErrorLine(_error))
          : ListView(padding: const EdgeInsets.all(16), children: [
              for (final r in rows) ...[
                AppCard(
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${r['who']} · #${r['booking_no']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text('${r['pickup_name']} → ${r['dest_name']}', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                        Text('${toInt(r['seats'])} ${toInt(r['seats']) == 1 ? tx('seat') : tx('seats')} · ${payNames['${r['method']}'] ?? '${r['method']}'}',
                            style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      ]),
                    ),
                    Text(money(toDouble(r['amount'])), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AppColors.navy)),
                  ]),
                ),
                const SizedBox(height: 8),
              ],
              if (rows.isEmpty) EmptyText(tx('Nothing here.')),
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(children: [
                  Expanded(child: Text(tx('Total'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                  Text(money(total), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.navy)),
                ]),
              ),
            ]),
    );
  }
}
