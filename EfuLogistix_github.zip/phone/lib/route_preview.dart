import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'app_state.dart';
import 'format.dart';
import 'geo.dart';
import 'here.dart';
import 'i18n.dart';
import 'theme.dart';
import 'tracking.dart';
import 'vehicle_art.dart';
import 'widgets.dart';

/// The road line from where you start to where you go, shown while booking.
/// [from] may be missing: then the place called [fromName] is looked up on the map.
class RoutePreview extends StatefulWidget {
  final LatLng? from;
  final String fromName;
  final LatLng? to;
  final String toName;
  final double height;

  /// true = trip in progress: the map is big and stays zoomed on the vehicle's current position.
  final bool live;
  const RoutePreview({super.key, this.from, required this.fromName, required this.to, required this.toName, this.height = 190, this.live = false});

  @override
  State<RoutePreview> createState() => _RoutePreviewState();
}

class _RoutePreviewState extends State<RoutePreview> {
  static final Map<String, LatLng> _found = {}; // place names already looked up
  RouteInfo? _route;
  LatLng? _start;
  LatLng? _end;
  bool _loading = false;
  bool _failed = false;
  String _key = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RoutePreview old) {
    super.didUpdateWidget(old);
    final k = _makeKey();
    if (k != _key) _load();
  }

  String _makeKey() => '${widget.from?.latitude},${widget.from?.longitude}|${widget.fromName}|${widget.to?.latitude},${widget.to?.longitude}|${widget.toName}';

  Future<void> _load() async {
    final key = _key = _makeKey();
    if (widget.to == null && widget.toName.isEmpty) {
      setState(() {
        _route = null;
        _start = null;
        _end = null;
      });
      return;
    }
    setState(() {
      _loading = true;
      _failed = false;
    });
    LatLng? start = widget.from ?? _found[widget.fromName];
    if (start == null && widget.fromName.isNotEmpty) {
      try {
        final hits = await searchPlaces(widget.fromName, near: Here.instance.point.value);
        if (hits.isNotEmpty) {
          start = hits.first.point;
          _found[widget.fromName] = start;
        }
      } catch (_) {}
    }
    LatLng? to = widget.to ?? _found[widget.toName];
    if (to == null && widget.toName.isNotEmpty) {
      try {
        final hits = await searchPlaces(widget.toName, near: Here.instance.point.value);
        if (hits.isNotEmpty) {
          to = hits.first.point;
          _found[widget.toName] = to;
        }
      } catch (_) {}
    }
    RouteInfo? r;
    if (start != null && to != null) r = await getRoute(start, to);
    if (!mounted || key != _key) return;
    setState(() {
      _end = to;
      _start = start;
      _route = r;
      _failed = r == null;
      _loading = false;
    });
  }

  Widget _map({required bool interactive, VoidCallback? onTap, double top = 40, double bottom = 40}) {
    Widget build(LatLng? pos) => FleetMap(
          route: _route?.points,
          end: _end ?? widget.to,
          endLabel: widget.toName,
          stops: [if (_start != null) MapStop(_start!, widget.fromName, 0)],
          trucks: widget.live && pos != null
              ? [MapTruck('me', pos, appState.truck?.plate ?? '', kind: vehicleKind(appState.category?.name))]
              : const [],
          follow: widget.live,
          me: Here.instance.point.value,
          topPadding: top,
          bottomPadding: bottom,
          interactive: interactive,
          onTap: onTap,
        );
    if (!widget.live) return build(null);
    return ValueListenableBuilder<LatLng?>(
      valueListenable: Tracking.instance.position,
      builder: (_, p, __) => build(p ?? Here.instance.point.value),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.to == null && widget.toName.isEmpty) return const SizedBox.shrink();
    final r = _route;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          height: widget.height,
          child: Stack(children: [
            Positioned.fill(
              child: _map(
                interactive: false,
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => Scaffold(
                    appBar: AppBar(
                      title: Text('${widget.fromName} → ${widget.toName}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      backgroundColor: AppColors.navy,
                      foregroundColor: Colors.white,
                    ),
                    body: _map(interactive: true, top: 60, bottom: 60),
                  ),
                )),
              ),
            ),
            if (_loading) const Positioned(left: 0, right: 0, top: 0, child: LinearProgressIndicator()),
          ]),
        ),
      ),
      if (r != null)
        Padding(
          padding: const EdgeInsets.only(top: 6, left: 4),
          child: Text(txf('%s by road · about %s', [kmText(r.km), durationText(r.minutes)]),
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.navy)),
        )
      else if (_failed && !_loading)
        Padding(
          padding: const EdgeInsets.only(top: 6, left: 4),
          child: Text(tx('The road line could not be loaded. Check your data.'), style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ),
    ]);
  }
}
