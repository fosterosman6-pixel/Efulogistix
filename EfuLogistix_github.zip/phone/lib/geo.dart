// Free OpenStreetMap services: place search (Nominatim) and road routes (OSRM).
// Fine for a small fleet; for heavy use, host your own or use a paid plan.
import 'dart:convert';
import 'dart:math' as math;

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' hide Path;

import 'config.dart';

/// Mangochi town, used to rank nearby search results first.
final mangochi = LatLng(-14.4783, 35.2645);

class Place {
  final String name;
  final String detail;
  final LatLng point;
  Place(this.name, this.detail, this.point);
}

class RouteInfo {
  final List<LatLng> points;
  final double km;
  final double minutes;
  RouteInfo(this.points, this.km, this.minutes);
}

const _headers = {'User-Agent': '${Config.userAgent} (fleet app, Mangochi Malawi)', 'Accept-Language': 'en'};

/// Common places around Mangochi, so trips can be made without internet (approximate centres).
final knownPlaces = <Place>[
  Place('Mangochi Main Rank', 'Mangochi', LatLng(-14.4782, 35.2645)),
  Place('Mangochi Boma', 'Mangochi', LatLng(-14.4780, 35.2640)),
  Place('Monkey Bay', 'Mangochi District', LatLng(-14.0833, 34.9167)),
  Place('Cape Maclear', 'Mangochi District', LatLng(-14.0167, 34.8333)),
  Place('Namwera', 'Mangochi District', LatLng(-14.3667, 35.4833)),
  Place('Makanjira', 'Mangochi District', LatLng(-13.7000, 35.5000)),
  Place('Mpondasi', 'Mangochi District', LatLng(-14.2500, 35.1000)),
  Place('Nkopola', 'Mangochi District', LatLng(-14.3600, 35.1700)),
  Place('Liwonde', 'Machinga District', LatLng(-15.0667, 35.2333)),
  Place('Balaka', 'Balaka District', LatLng(-14.9793, 34.9558)),
  Place('Zomba', 'Zomba District', LatLng(-15.3860, 35.3188)),
  Place('Ntcheu', 'Ntcheu District', LatLng(-14.8167, 34.6333)),
  Place('Dedza', 'Dedza District', LatLng(-14.3779, 34.3332)),
  Place('Salima', 'Salima District', LatLng(-13.7804, 34.4587)),
  Place('Blantyre', 'Blantyre', LatLng(-15.7861, 35.0058)),
  Place('Lilongwe', 'Lilongwe', LatLng(-13.9626, 33.7741)),
  Place('Malindi', 'Mangochi District', LatLng(-14.2833, 35.2000)),
  Place('Chiponde', 'Mangochi District', LatLng(-14.5167, 35.3833)),
  Place('Lungwena', 'Mangochi District', LatLng(-14.1667, 35.1500)),
  Place('Katuli', 'Mangochi District', LatLng(-14.4000, 35.3000)),
  Place('Mtakataka', 'Dedza District', LatLng(-14.2167, 34.5833)),
  Place('Golomoti', 'Dedza District', LatLng(-14.4167, 34.6167)),
  Place('Chilumba', 'Karonga District', LatLng(-10.5333, 34.2333)),
  Place('Nkhotakota', 'Nkhotakota District', LatLng(-12.9167, 34.3000)),
  Place('Kasungu', 'Kasungu District', LatLng(-13.0333, 33.4833)),
  Place('Mzuzu', 'Mzimba District', LatLng(-11.4500, 34.0167)),
  Place('Karonga', 'Karonga District', LatLng(-9.9333, 33.9333)),
  Place('Mulanje', 'Mulanje District', LatLng(-16.0333, 35.5000)),
  Place('Thyolo', 'Thyolo District', LatLng(-16.0667, 35.1333)),
  Place('Chikwawa', 'Chikwawa District', LatLng(-16.0333, 34.8000)),
  Place('Nsanje', 'Nsanje District', LatLng(-16.9167, 35.2667)),
  Place('Mangochi Hospital', 'Mangochi', LatLng(-14.4770, 35.2610)),
  Place('Mangochi Market', 'Mangochi', LatLng(-14.4790, 35.2650)),
  Place('Chitsulo', 'Mangochi District', LatLng(-14.3000, 35.1000)),
  // Schools (approximate positions: near the town or trading centre they serve)
  Place('Mangochi Secondary School', 'School · Mangochi', LatLng(-14.4735, 35.2590)),
  Place('Mangochi Primary School', 'School · Mangochi', LatLng(-14.4770, 35.2625)),
  Place('Mangochi Islamic Secondary School', 'School · Mangochi', LatLng(-14.4800, 35.2680)),
  Place('Mangochi Technical College', 'College · Mangochi', LatLng(-14.4700, 35.2560)),
  Place('Mangochi Teachers College', 'College · Mangochi', LatLng(-14.4690, 35.2700)),
  Place('Chilipa Secondary School', 'School · Mangochi District', LatLng(-14.5500, 35.2400)),
  Place('Katuli Secondary School', 'School · Mangochi District', LatLng(-14.4020, 35.3010)),
  Place('Namwera Secondary School', 'School · Mangochi District', LatLng(-14.3680, 35.4800)),
  Place('Monkey Bay Secondary School', 'School · Mangochi District', LatLng(-14.0800, 34.9150)),
  Place('Cape Maclear Primary School', 'School · Mangochi District', LatLng(-14.0180, 34.8350)),
  Place('Lungwena Secondary School', 'School · Mangochi District', LatLng(-14.1680, 35.1480)),
  Place('Makanjira Secondary School', 'School · Mangochi District', LatLng(-13.7020, 35.4980)),
  Place('Nkopola Primary School', 'School · Mangochi District', LatLng(-14.3610, 35.1690)),
  Place('Malindi Secondary School', 'School · Mangochi District', LatLng(-14.2840, 35.1990)),
  Place('Chiponde Primary School', 'School · Mangochi District', LatLng(-14.5160, 35.3820)),
  Place('Nankumba Secondary School', 'School · Mangochi District', LatLng(-14.0300, 34.8500)),
];

/// Known places that match what was typed: every typed word must start a word of the name or the district.
/// Instant and works offline.
List<Place> quickMatches(String q) {
  final words = q.toLowerCase().split(RegExp(r'[\s,]+')).where((w) => w.isNotEmpty).toList();
  if (words.isEmpty) return [];
  bool hit(Place p) {
    final hay = '${p.name} ${p.detail}'.toLowerCase().split(RegExp(r'[\s,]+'));
    return words.every((w) => hay.any((h) => h.startsWith(w)));
  }

  final list = knownPlaces.where(hit).toList();
  // names that start with the text first
  final s = q.trim().toLowerCase();
  list.sort((a, b) => (a.name.toLowerCase().startsWith(s) ? 0 : 1).compareTo(b.name.toLowerCase().startsWith(s) ? 0 : 1));
  return list;
}

/// true when the last online search failed (no internet or the service is busy).
bool lastSearchOffline = false;

/// A known place with exactly this name (any case), or null.
Place? knownPlace(String name) {
  final s = name.trim().toLowerCase();
  for (final p in knownPlaces) {
    if (p.name.toLowerCase() == s) return p;
  }
  return null;
}

/// Known places first, then results from two free OpenStreetMap services at the same time
/// (Nominatim and Photon), so one being slow or down does not stop the search.
/// Never waits longer than about 7 seconds. Works offline with the known places only.
Future<List<Place>> searchPlaces(String query, {LatLng? near}) async {
  final q = query.trim();
  if (q.length < 2) return [];
  final known = quickMatches(q);
  final results = await Future.wait<List<Place>?>([
    _searchNominatim(q, near: near).then<List<Place>?>((v) => v).catchError((_) => null),
    _searchPhoton(q, near: near).then<List<Place>?>((v) => v).catchError((_) => null),
  ]);
  lastSearchOffline = results.every((r) => r == null);
  final seen = <String>{for (final p in known) _placeKey(p)};
  final out = [...known];
  for (final list in results) {
    for (final p in list ?? <Place>[]) {
      if (seen.add(_placeKey(p))) out.add(p);
    }
  }
  // closest to the person first among the online ones
  final c = near ?? mangochi;
  final online = out.sublist(known.length)..sort((a, b) => distanceKm(c, a.point).compareTo(distanceKm(c, b.point)));
  return [...known, ...online].take(12).toList();
}

String _placeKey(Place p) => '${p.name.toLowerCase()}|${p.point.latitude.toStringAsFixed(2)}|${p.point.longitude.toStringAsFixed(2)}';

Future<List<Place>> _searchNominatim(String q, {LatLng? near}) async {
  final c = near ?? mangochi;
  final box = [c.longitude - 2, c.latitude + 2, c.longitude + 2, c.latitude - 2].join(',');
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'format': 'jsonv2',
    'limit': '8',
    'countrycodes': 'mw',
    'viewbox': box,
    'q': q,
  });
  final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 7));
  if (res.statusCode != 200) throw Exception('search failed');
  final rows = jsonDecode(res.body) as List<dynamic>;
  return rows.whereType<Map>().map((r) {
    final display = (r['display_name'] ?? '').toString();
    final parts = display.split(',').map((s) => s.trim()).toList();
    final name = (r['name'] as String?)?.isNotEmpty == true ? r['name'] as String : (parts.isNotEmpty ? parts.first : display);
    final detail = parts.length > 1 ? parts.sublist(1, math.min(3, parts.length)).join(', ') : '';
    return Place(name, detail, LatLng(double.parse(r['lat'].toString()), double.parse(r['lon'].toString())));
  }).toList();
}

/// Photon (photon.komoot.io): fast, forgiving search-as-you-type on the same OpenStreetMap data.
Future<List<Place>> _searchPhoton(String q, {LatLng? near}) async {
  final c = near ?? mangochi;
  final uri = Uri.https('photon.komoot.io', '/api/', {
    'q': q,
    'limit': '10',
    'lang': 'en',
    'lat': '${c.latitude}',
    'lon': '${c.longitude}',
    // Malawi: west, south, east, north
    'bbox': '32.6,-17.2,36.0,-9.3',
  });
  final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 7));
  if (res.statusCode != 200) throw Exception('search failed');
  final data = jsonDecode(res.body) as Map<String, dynamic>;
  final out = <Place>[];
  for (final f in (data['features'] as List<dynamic>? ?? [])) {
    final p = (f['properties'] as Map?) ?? {};
    final coords = (f['geometry']?['coordinates'] as List?) ?? [];
    final name = (p['name'] ?? p['street'] ?? '').toString();
    if (name.isEmpty || coords.length < 2) continue;
    if ((p['countrycode'] ?? 'MW').toString().toUpperCase() != 'MW') continue;
    final detail = [p['city'] ?? p['locality'] ?? p['district'], p['county'] ?? p['state']]
        .where((e) => e != null && e.toString().isNotEmpty && e.toString() != name)
        .map((e) => e.toString())
        .toSet()
        .join(', ');
    out.add(Place(name, detail, LatLng((coords[1] as num).toDouble(), (coords[0] as num).toDouble())));
  }
  return out;
}

/// Village or place name for a point (e.g. "Nkope"), or null.
Future<String?> reverseName(LatLng p) async {
  try {
    final uri = Uri.https('nominatim.openstreetmap.org', '/reverse', {
      'format': 'jsonv2',
      'zoom': '14',
      'lat': '${p.latitude}',
      'lon': '${p.longitude}',
    });
    final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 8));
    if (res.statusCode != 200) return null;
    final row = jsonDecode(res.body) as Map<String, dynamic>;
    final address = row['address'] as Map<String, dynamic>?;
    final name = (address?['village'] ?? address?['town'] ?? address?['suburb'] ?? address?['hamlet'] ??
            row['name'] ?? (row['display_name'] as String?)?.split(',').first)
        ?.toString();
    return (name == null || name.isEmpty) ? null : name;
  } catch (_) {
    return null;
  }
}

Future<RouteInfo?> getRoute(LatLng from, LatLng to) async {
  try {
    final uri = Uri.parse('https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}?overview=full&geometries=geojson');
    final res = await http.get(uri);
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final routes = data['routes'] as List<dynamic>?;
    if (routes == null || routes.isEmpty) return null;
    final r = routes.first as Map<String, dynamic>;
    final coords = (r['geometry']['coordinates'] as List<dynamic>)
        .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
        .toList();
    return RouteInfo(coords, (r['distance'] as num).toDouble() / 1000, (r['duration'] as num).toDouble() / 60);
  } catch (_) {
    return null;
  }
}

/// Straight-line distance in km.
double distanceKm(LatLng a, LatLng b) {
  const r = 6371.0;
  double rad(double d) => d * math.pi / 180;
  final dLat = rad(b.latitude - a.latitude);
  final dLng = rad(b.longitude - a.longitude);
  final h = math.pow(math.sin(dLat / 2), 2) +
      math.cos(rad(a.latitude)) * math.cos(rad(b.latitude)) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h));
}
