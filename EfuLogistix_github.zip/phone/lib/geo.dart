// Free OpenStreetMap services: place search (Nominatim) and road routes (OSRM).
// Fine for a small fleet; for heavy use, host your own or use a paid plan.
import 'dart:convert';
import 'dart:math' as math;

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' hide Path;

import 'config.dart';

/// Mangochi town, used to rank nearby search results first.
final mangochi = LatLng(-14.4783, 35.2645);

class Place {
  final String name;
  final String detail;
  final LatLng point;
  Place(this.name, this.detail, this.point);
}

class RouteInfo {
  final List<LatLng> points;
  final double km;
  final double minutes;
  RouteInfo(this.points, this.km, this.minutes);
}

const _headers = {'User-Agent': '${Config.userAgent} (fleet app, Mangochi Malawi)', 'Accept-Language': 'en'};

/// Common places around Mangochi, so trips can be made without internet (approximate centres).
final knownPlaces = <Place>[
  Place('Mangochi Main Rank', 'Mangochi', LatLng(-14.4782, 35.2645)),
  Place('Mangochi Boma', 'Mangochi', LatLng(-14.4780, 35.2640)),
  Place('Monkey Bay', 'Mangochi District', LatLng(-14.0833, 34.9167)),
  Place('Cape Maclear', 'Mangochi District', LatLng(-14.0167, 34.8333)),
  Place('Namwera', 'Mangochi District', LatLng(-14.3667, 35.4833)),
  Place('Makanjira', 'Mangochi District', LatLng(-13.7000, 35.5000)),
  Place('Mpondasi', 'Mangochi District', LatLng(-14.2500, 35.1000)),
  Place('Nkopola', 'Mangochi District', LatLng(-14.3600, 35.1700)),
  Place('Liwonde', 'Machinga District', LatLng(-15.0667, 35.2333)),
  Place('Balaka', 'Balaka District', LatLng(-14.9793, 34.9558)),
  Place('Zomba', 'Zomba District', LatLng(-15.3860, 35.3188)),
  Place('Ntcheu', 'Ntcheu District', LatLng(-14.8167, 34.6333)),
  Place('Dedza', 'Dedza District', LatLng(-14.3779, 34.3332)),
  Place('Salima', 'Salima District', LatLng(-13.7804, 34.4587)),
  Place('Blantyre', 'Blantyre', LatLng(-15.7861, 35.0058)),
  Place('Lilongwe', 'Lilongwe', LatLng(-13.9626, 33.7741)),
];

List<Place> _knownMatches(String q) {
  final s = q.toLowerCase();
  return knownPlaces.where((p) => p.name.toLowerCase().contains(s)).toList();
}

/// A known place with exactly this name (any case), or null.
Place? knownPlace(String name) {
  final s = name.trim().toLowerCase();
  for (final p in knownPlaces) {
    if (p.name.toLowerCase() == s) return p;
  }
  return null;
}

/// Known places first, then OpenStreetMap results. Works offline with the known places only.
Future<List<Place>> searchPlaces(String query, {LatLng? near}) async {
  final q = query.trim();
  if (q.length < 2) return [];
  final known = _knownMatches(q);
  try {
    final online = await _searchOnline(q, near: near);
    final names = known.map((p) => p.name.toLowerCase()).toSet();
    return [...known, ...online.where((p) => !names.contains(p.name.toLowerCase()))];
  } catch (_) {
    return known;
  }
}

Future<List<Place>> _searchOnline(String q, {LatLng? near}) async {
  final c = near ?? mangochi;
  final box = [c.longitude - 1.5, c.latitude + 1.5, c.longitude + 1.5, c.latitude - 1.5].join(',');
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'format': 'jsonv2',
    'limit': '8',
    'countrycodes': 'mw',
    'viewbox': box,
    'q': q,
  });
  final res = await http.get(uri, headers: _headers);
  if (res.statusCode != 200) throw Exception('search failed');
  final rows = jsonDecode(res.body) as List<dynamic>;
  return rows.whereType<Map>().map((r) {
    final display = (r['display_name'] ?? '').toString();
    final parts = display.split(',').map((s) => s.trim()).toList();
    final name = (r['name'] as String?)?.isNotEmpty == true ? r['name'] as String : (parts.isNotEmpty ? parts.first : display);
    final detail = parts.length > 1 ? parts.sublist(1, math.min(3, parts.length)).join(', ') : '';
    return Place(
      name,
      detail,
      LatLng(double.parse(r['lat'].toString()), double.parse(r['lon'].toString())),
    );
  }).toList();
}

/// Village or place name for a point (e.g. "Nkope"), or null.
Future<String?> reverseName(LatLng p) async {
  try {
    final uri = Uri.https('nominatim.openstreetmap.org', '/reverse', {
      'format': 'jsonv2',
      'zoom': '14',
      'lat': '${p.latitude}',
      'lon': '${p.longitude}',
    });
    final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 8));
    if (res.statusCode != 200) return null;
    final row = jsonDecode(res.body) as Map<String, dynamic>;
    final address = row['address'] as Map<String, dynamic>?;
    final name = (address?['village'] ?? address?['town'] ?? address?['suburb'] ?? address?['hamlet'] ??
            row['name'] ?? (row['display_name'] as String?)?.split(',').first)
        ?.toString();
    return (name == null || name.isEmpty) ? null : name;
  } catch (_) {
    return null;
  }
}

Future<RouteInfo?> getRoute(LatLng from, LatLng to) async {
  try {
    final uri = Uri.parse('https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}?overview=full&geometries=geojson');
    final res = await http.get(uri);
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final routes = data['routes'] as List<dynamic>?;
    if (routes == null || routes.isEmpty) return null;
    final r = routes.first as Map<String, dynamic>;
    final coords = (r['geometry']['coordinates'] as List<dynamic>)
        .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
        .toList();
    return RouteInfo(coords, (r['distance'] as num).toDouble() / 1000, (r['duration'] as num).toDouble() / 60);
  } catch (_) {
    return null;
  }
}

/// Straight-line distance in km.
double distanceKm(LatLng a, LatLng b) {
  const r = 6371.0;
  double rad(double d) => d * math.pi / 180;
  final dLat = rad(b.latitude - a.latitude);
  final dLng = rad(b.longitude - a.longitude);
  final h = math.pow(math.sin(dLat / 2), 2) +
      math.cos(rad(a.latitude)) * math.cos(rad(b.latitude)) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h));
}
