import 'package:flutter/material.dart';
import 'icon_art.dart';

import 'app_state.dart';
import 'capture.dart';
import 'here.dart';
import 'i18n.dart';
import 'models.dart';
import 'notices.dart';
import 'photos.dart';
import 'theme.dart';

/// Round profile picture; shows the first letter when there is no picture.
class Avatar extends StatelessWidget {
  final Profile? person;
  final double size;
  const Avatar(this.person, {super.key, this.size = 48});

  @override
  Widget build(BuildContext context) {
    final p = person;
    final letter = Text(
      (p?.firstName ?? '?').isEmpty ? '?' : (p?.firstName ?? '?').substring(0, 1).toUpperCase(),
      style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy, fontSize: size * 0.42),
    );
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: AppColors.lime,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      alignment: Alignment.center,
      child: p?.avatarPath == null ? letter : IgnorePointer(child: StoredImage(p!.avatarPath, height: size, width: size)),
    );
  }
}

/// After login: name, picture and where the person is now. Tap the picture to change it.
class ProfileHeader extends StatefulWidget {
  final List<Widget> actions;
  final String? line; // replaces the location line, e.g. "ON DUTY · MZ 4521"
  const ProfileHeader({super.key, this.actions = const [], this.line});

  @override
  State<ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends State<ProfileHeader> {
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Here.instance.refresh();
    NoticeCenter.instance.start();
  }

  Future<void> _changePicture() async {
    final me = appState.profile;
    if (me == null || _busy) return;
    final gallery = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tx('Take a photo')),
              onTap: () => Navigator.pop(ctx, false)),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(tx('Choose from gallery')),
              onTap: () => Navigator.pop(ctx, true)),
        ]),
      ),
    );
    if (gallery == null) return;
    setState(() => _busy = true);
    try {
      final photo = await takePhoto('avatar', allowGallery: gallery, front: true);
      if (photo != null) {
        await db.from('profiles').update({'avatar_path': photo.path}).eq('id', me.id);
        await appState.refresh();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    return Row(children: [
      Semantics(
        button: true,
        label: tx('Change profile picture'),
        child: GestureDetector(
          onTap: _changePicture,
          child: Stack(children: [
            Avatar(me),
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(color: AppColors.navy, shape: BoxShape.circle),
                child: _busy
                    ? const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.camera_alt, size: 12, color: Colors.white),
              ),
            ),
          ]),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(me?.displayName ?? '',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
          if (widget.line != null)
            Text(widget.line!, style: const TextStyle(color: AppColors.lime, fontSize: 13, fontWeight: FontWeight.w700))
          else
            InkWell(
              onTap: () => Here.instance.refresh(force: true),
              child: ValueListenableBuilder<String?>(
                valueListenable: Here.instance.name,
                builder: (context, place, _) => Row(children: [
                  const IconArt('pin', size: 18, fallback: Icons.place),
                  const SizedBox(width: 2),
                  Flexible(
                    child: Text(place == null ? tx('Finding your location…') : txf('%s · now', ['${place}']),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13)),
                  ),
                ]),
              ),
            ),
        ]),
      ),
      ...widget.actions,
      const NoticeBell(),
    ]);
  }
}


/// Small tappable profile picture for the driver screens' headers. Tap to change the picture.
class ProfileAvatarButton extends StatefulWidget {
  final double size;
  const ProfileAvatarButton({super.key, this.size = 42});

  @override
  State<ProfileAvatarButton> createState() => _ProfileAvatarButtonState();
}

class _ProfileAvatarButtonState extends State<ProfileAvatarButton> {
  bool _busy = false;

  Future<void> _change() async {
    final me = appState.profile;
    if (me == null || _busy) return;
    final gallery = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tx('Take a photo')),
              onTap: () => Navigator.pop(ctx, false)),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(tx('Choose from gallery')),
              onTap: () => Navigator.pop(ctx, true)),
        ]),
      ),
    );
    if (gallery == null) return;
    setState(() => _busy = true);
    try {
      final photo = await takePhoto('avatar', allowGallery: gallery, front: true);
      if (photo != null) {
        await db.from('profiles').update({'avatar_path': photo.path}).eq('id', me.id);
        await appState.refresh();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => GestureDetector(
          onTap: _change,
          child: Stack(children: [
            Avatar(appState.profile, size: widget.size),
            if (_busy)
              const Positioned.fill(child: Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))),
          ]),
        ),
      );
}
