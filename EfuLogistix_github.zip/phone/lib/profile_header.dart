import 'package:flutter/material.dart';

import 'app_state.dart';
import 'capture.dart';
import 'here.dart';
import 'i18n.dart';
import 'models.dart';
import 'notices.dart';
import 'photos.dart';
import 'theme.dart';
import 'screens/chats_screen.dart';
import 'screens/profile_screen.dart';

/// "Good morning, Osman": the same greeting in every top bar. Without a full name it just says Welcome.
String greetingFor(Profile? me) {
  if (me == null || !me.hasName) return tx('Welcome');
  final h = DateTime.now().hour;
  return txf(h < 12 ? 'Good morning, %s' : h < 17 ? 'Good afternoon, %s' : 'Good evening, %s', [me.firstName]);
}

/// "Good morning, Hastings": the greeting small, the name large and scaled to fit, so neither is ever cut off.
class GreetingText extends StatelessWidget {
  final Profile? me;
  const GreetingText(this.me, {super.key});

  @override
  Widget build(BuildContext context) {
    final g = greetingFor(me);
    final i = g.indexOf(', ');
    if (i <= 0) {
      return FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Text(g, maxLines: 1, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
      );
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(g.substring(0, i),
          maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13, fontWeight: FontWeight.w500)),
      FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Text(g.substring(i + 2),
            maxLines: 1, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 0.1)),
      ),
    ]);
  }
}

/// Round profile picture; shows the first letter when there is no picture.
class Avatar extends StatelessWidget {
  final Profile? person;
  final double size;
  const Avatar(this.person, {super.key, this.size = 48});

  @override
  Widget build(BuildContext context) {
    final p = person;
    final letter = Text(
      (p?.firstName ?? '?').isEmpty ? '?' : (p?.firstName ?? '?').substring(0, 1).toUpperCase(),
      style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy, fontSize: size * 0.42),
    );
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: AppColors.lime,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      alignment: Alignment.center,
      child: p?.avatarPath == null ? letter : IgnorePointer(child: StoredImage(p!.avatarPath, height: size, width: size)),
    );
  }
}

/// After login: name, picture and where the person is now. Tap the picture to change it.
class ProfileHeader extends StatefulWidget {
  final List<Widget> actions;
  final String? line; // replaces the location line, e.g. "ON DUTY · MZ 4521"
  const ProfileHeader({super.key, this.actions = const [], this.line});

  @override
  State<ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends State<ProfileHeader> {
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Here.instance.refresh();
    NoticeCenter.instance.start();
  }

  Future<void> _changePicture() async {
    final me = appState.profile;
    if (me == null || _busy) return;
    final gallery = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tx('Take a photo')),
              onTap: () => Navigator.pop(ctx, false)),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(tx('Choose from gallery')),
              onTap: () => Navigator.pop(ctx, true)),
        ]),
      ),
    );
    if (gallery == null) return;
    setState(() => _busy = true);
    try {
      final photo = await takePhoto('avatar', allowGallery: gallery, front: true);
      if (photo != null) {
        await db.from('profiles').update({'avatar_path': photo.path}).eq('id', me.id);
        await appState.refresh();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = appState.profile;
    return Row(children: [
      Semantics(
        button: true,
        label: tx('Change profile picture'),
        child: GestureDetector(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyProfileScreen())),
          child: Avatar(me, size: 48),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          GreetingText(me),
          const SizedBox(height: 2),
          if (widget.line != null)
            Text(widget.line!, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13, fontWeight: FontWeight.w600))
          else
            InkWell(
              onTap: () => Here.instance.refresh(force: true),
              child: ValueListenableBuilder<String?>(
                valueListenable: Here.instance.name,
                builder: (context, place, _) => Row(children: [
                  const Icon(Icons.place_outlined, size: 15, color: AppColors.lime),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(place == null ? tx('Finding your location…') : (place == 'Location unknown' || place == 'Location off') ? tx('Tap to find your location') : place,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 13, fontWeight: FontWeight.w500)),
                  ),
                ]),
              ),
            ),
        ]),
      ),
      ...widget.actions,
      const ChatsButton(),
      const NoticeBell(),
    ]);
  }
}


/// Small tappable profile picture for the driver screens' headers. Tap to change the picture.
class ProfileAvatarButton extends StatefulWidget {
  final double size;
  const ProfileAvatarButton({super.key, this.size = 42});

  @override
  State<ProfileAvatarButton> createState() => _ProfileAvatarButtonState();
}

class _ProfileAvatarButtonState extends State<ProfileAvatarButton> {
  bool _busy = false;

  Future<void> _change() async {
    final me = appState.profile;
    if (me == null || _busy) return;
    final gallery = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tx('Take a photo')),
              onTap: () => Navigator.pop(ctx, false)),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(tx('Choose from gallery')),
              onTap: () => Navigator.pop(ctx, true)),
        ]),
      ),
    );
    if (gallery == null) return;
    setState(() => _busy = true);
    try {
      final photo = await takePhoto('avatar', allowGallery: gallery, front: true);
      if (photo != null) {
        await db.from('profiles').update({'avatar_path': photo.path}).eq('id', me.id);
        await appState.refresh();
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => GestureDetector(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyProfileScreen())),
          child: Stack(children: [
            Avatar(appState.profile, size: widget.size),
            if (_busy)
              const Positioned.fill(child: Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))),
          ]),
        ),
      );
}
