import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:latlong2/latlong.dart' hide Path;
import 'package:shared_preferences/shared_preferences.dart';

import 'app_state.dart';
import 'geo.dart';
import 'i18n.dart';
import 'theme.dart';
import 'tracking.dart';
import 'widgets.dart';

/// Settled areas (from the building map) that have no name on our map yet: [lat, lng, buildings].
List<List<double>>? _gaps;
Future<List<List<double>>> _loadGaps() async {
  if (_gaps != null) return _gaps!;
  try {
    final raw = jsonDecode(await rootBundle.loadString('assets/place_gaps.json')) as List<dynamic>;
    _gaps = [for (final r in raw) [for (final x in (r as List)) (x as num).toDouble()]];
  } catch (_) {
    _gaps = [];
  }
  return _gaps!;
}

/// Shown on the driver home when the driver is standing in an area nobody has named yet:
/// "What do people call this place?" One name, one tap, and it goes to the office to add for everyone.
class NameThisAreaCard extends StatefulWidget {
  const NameThisAreaCard({super.key});

  @override
  State<NameThisAreaCard> createState() => _NameThisAreaCardState();
}

class _NameThisAreaCardState extends State<NameThisAreaCard> {
  String? _hereKey; // the area the driver is in, when it still needs a name
  LatLng? _at;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Tracking.instance.position.addListener(_check);
    _check();
  }

  @override
  void dispose() {
    Tracking.instance.position.removeListener(_check);
    super.dispose();
  }

  Future<void> _check() async {
    final p = Tracking.instance.position.value;
    if (p == null || _busy) return;
    final gaps = await _loadGaps();
    // not when a known place is already close (the office may have added it since)
    if (knownPlaces.any((k) => distanceKm(p, k.point) < 0.7)) {
      if (_hereKey != null && mounted) setState(() => _hereKey = null);
      return;
    }
    String? key;
    for (final g in gaps) {
      if (distanceKm(p, LatLng(g[0], g[1])) < 0.5) {
        key = '${g[0]},${g[1]}';
        break;
      }
    }
    if (key != null) {
      final prefs = await SharedPreferences.getInstance();
      final until = prefs.getInt('area_snooze_$key') ?? 0;
      if (until > DateTime.now().millisecondsSinceEpoch) key = null;
    }
    if (mounted && (key != _hereKey)) {
      setState(() {
        _hereKey = key;
        _at = p;
      });
    }
  }

  Future<void> _snooze(int days) async {
    final key = _hereKey;
    if (key == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('area_snooze_$key', DateTime.now().add(Duration(days: days)).millisecondsSinceEpoch);
    if (mounted) setState(() => _hereKey = null);
  }

  Future<void> _name() async {
    final me = appState.profile;
    final at = _at ?? Tracking.instance.position.value;
    if (me == null || at == null) return;
    final name = TextEditingController();
    var type = 'Village';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(tx('What do people call this place?')),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: name, autofocus: true, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: tx('Place name'))),
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final t in const ['Village', 'Market', 'School', 'Clinic', 'Church', 'Mosque', 'Other'])
                ChoiceChip(label: Text(t), selected: type == t, onSelected: (_) => setLocal(() => type = t)),
            ]),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tx('Cancel'))),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tx('Send'))),
          ],
        ),
      ),
    );
    final n = name.text.trim();
    name.dispose();
    if (ok != true || n.length < 2 || !mounted) return;
    setState(() => _busy = true);
    try {
      await db.from('place_suggestions').insert({
        'name': n,
        'detail': '$type · Suggested by a driver',
        'lat': at.latitude,
        'lng': at.longitude,
        'suggested_by': me.id,
      });
      await _snooze(3650);
      if (mounted) toast(context, tx('Sent to the office. Thank you.'));
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_hereKey == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        borderColor: AppColors.lime,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tx('This place has no name on our map'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 2),
          Text(tx('You are in a settled area nobody has named yet. Tell us what people call it, so passengers can find it.'),
              style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: AppButton(tx('Name this place'), height: 44, onPressed: _busy ? null : _name)),
            const SizedBox(width: 8),
            TextButton(onPressed: () => _snooze(3), child: Text(tx('Not now'))),
          ]),
        ]),
      ),
    );
  }
}
