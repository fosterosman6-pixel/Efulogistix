import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'location.dart';
import 'tracking.dart';

/// Where the person is now, as a place name ("Chitundu, Mangochi"), for the header after login.
class Here {
  Here._();
  static final instance = Here._();

  final name = ValueNotifier<String?>(null);
  final point = ValueNotifier<LatLng?>(null);
  DateTime _at = DateTime.fromMillisecondsSinceEpoch(0);
  bool _busy = false;

  /// Looks up the place again when the last look is older than 3 minutes (or when [force]).
  Future<void> refresh({bool force = false}) async {
    if (_busy) return;
    if (!force && DateTime.now().difference(_at) < const Duration(minutes: 3) && name.value != null) return;
    _busy = true;
    try {
      LatLng? p = Tracking.instance.position.value;
      if (p == null) {
        final problem = await ensureLocation();
        if (problem != null) {
          name.value = 'Location off';
          return;
        }
        p = await currentPoint();
      }
      if (p == null) {
        name.value = 'Location unknown';
        return;
      }
      point.value = p;
      _at = DateTime.now();
      name.value = nearestKnown(p) ?? 'Near ${p.latitude.toStringAsFixed(3)}, ${p.longitude.toStringAsFixed(3)}';
      final online = await reverseName(p);
      if (online != null) {
        final known = nearestKnown(p, withinKm: 25);
        name.value = known != null && !online.toLowerCase().contains(known.toLowerCase().split(' ').first)
            ? '$online, ${known.split(' ').first}'
            : online;
      }
    } catch (_) {
      name.value ??= 'Location unknown';
    } finally {
      _busy = false;
    }
  }
}

/// The closest known place (works without internet), within [withinKm].
String? nearestKnown(LatLng p, {double withinKm = 5}) {
  Place? best;
  var bestKm = withinKm;
  for (final k in knownPlaces) {
    final d = distanceKm(p, k.point);
    if (d <= bestKm) {
      best = k;
      bestKm = d;
    }
  }
  return best?.name;
}
