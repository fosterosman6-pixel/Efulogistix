import 'dart:async';

import 'package:geolocator/geolocator.dart';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'location.dart';
import 'tracking.dart';

/// Where the person is now, as a place name ("Chitundu, Mangochi"), for the header after login.
class Here {
  Here._();
  static final instance = Here._();

  final name = ValueNotifier<String?>(null);
  final point = ValueNotifier<LatLng?>(null);
  /// The last position the phone gave that is outside Malawi (a wrong fix), so the screen can say so.
  final badFix = ValueNotifier<LatLng?>(null);
  DateTime _at = DateTime.fromMillisecondsSinceEpoch(0);
  bool _busy = false;
  DateTime _busySince = DateTime.fromMillisecondsSinceEpoch(0);

  StreamSubscription<Position>? _live;
  int _liveUsers = 0;
  LatLng? _lastNamed;

  /// Follows the phone's GPS in real time (a new point with every fix, about once a second).
  /// Call [stopLive] when the screen closes. Safe to call from several screens.
  bool _starting = false;

  Future<void> startLive() async {
    _liveUsers++;
    if (_live != null || _starting) return;
    _starting = true;
    final problem = await ensureLocation();
    _starting = false;
    if (problem != null || _liveUsers == 0 || _live != null) return;
    _live = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, distanceFilter: 0),
    ).listen((pos) {
      final p = LatLng(pos.latitude, pos.longitude);
      if (!inMalawi(p)) {
        badFix.value = p; // wrong fix: ignore it, but remember it so the screen can explain
        return;
      }
      badFix.value = null;
      point.value = p;
      // look the place name up again only after moving about 300 m
      if (name.value == null || name.value == 'Location unknown' || name.value == 'Location off' ||
          _lastNamed == null || distanceKm(p, _lastNamed!) > 0.3) {
        _lastNamed = p;
        refresh(force: true);
      }
    }, onError: (_) {});
  }

  void stopLive() {
    if (_liveUsers > 0) _liveUsers--;
    if (_liveUsers == 0) {
      _live?.cancel();
      _live = null;
    }
  }

  /// Looks up the place again when the last look is older than 3 minutes (or when [force]).
  Future<void> refresh({bool force = false}) async {
    // a lookup stuck for over 20 s is abandoned so a new one can start
    if (_busy && DateTime.now().difference(_busySince) < const Duration(seconds: 20)) return;
    if (!force && DateTime.now().difference(_at) < const Duration(minutes: 3) && name.value != null) return;
    _busy = true;
    _busySince = DateTime.now();
    try {
      LatLng? p = (_live != null ? point.value : null) ?? Tracking.instance.position.value;
      if (p == null) {
        final problem = await ensureLocation();
        if (problem != null) {
          name.value = 'Location off';
          return;
        }
        p = await currentPoint();
      }
      if (p == null) {
        name.value = 'Location unknown';
        return;
      }
      if (!inMalawi(p)) {
        badFix.value = p;
        name.value = 'Location unknown';
        return;
      }
      badFix.value = null;
      point.value = p;
      _at = DateTime.now();
      name.value = nearestKnown(p) ?? 'Near ${p.latitude.toStringAsFixed(3)}, ${p.longitude.toStringAsFixed(3)}';
      final online = await reverseName(p).timeout(const Duration(seconds: 8), onTimeout: () => null);
      if (online != null) {
        final known = nearestKnown(p, withinKm: 25);
        name.value = known != null && !online.toLowerCase().contains(known.toLowerCase().split(' ').first)
            ? '$online, ${known.split(' ').first}'
            : online;
      }
    } catch (_) {
      name.value ??= 'Location unknown';
    } finally {
      _busy = false;
    }
  }
}

/// The closest known place (works without internet), within [withinKm].
String? nearestKnown(LatLng p, {double withinKm = 5}) {
  Place? best;
  var bestKm = withinKm;
  for (final k in knownPlaces) {
    final d = distanceKm(p, k.point);
    if (d <= bestKm) {
      best = k;
      bestKm = d;
    }
  }
  return best?.name;
}
