import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:latlong2/latlong.dart' hide Path;

import 'geo.dart';
import 'theme.dart';

/// Speaks the turn instructions (English).
class TurnVoice {
  static final _tts = FlutterTts();
  static bool _ready = false;

  static Future<void> speak(String text) async {
    try {
      if (!_ready) {
        _ready = true;
        await _tts.setLanguage('en-GB');
        await _tts.setSpeechRate(0.45);
      }
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}

/// The big green banner: next turn, how far to it, and the time and distance left.
class NavBanner extends StatelessWidget {
  final NavStep? step;
  final LatLng? me;
  final double? leftKm;
  final double? leftMinutes;
  final String? toLabel;
  const NavBanner({super.key, required this.step, required this.me, this.leftKm, this.leftMinutes, this.toLabel});

  IconData _icon(NavStep s) {
    final m = s.modifier;
    switch (s.type) {
      case 'arrive':
        return Icons.flag;
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
        return m.contains('left') ? Icons.roundabout_left : Icons.roundabout_right;
      case 'merge':
        return Icons.merge;
      case 'fork':
        return m.contains('left') ? Icons.fork_left : Icons.fork_right;
    }
    return switch (m) {
      'left' => Icons.turn_left,
      'right' => Icons.turn_right,
      'slight left' => Icons.turn_slight_left,
      'slight right' => Icons.turn_slight_right,
      'sharp left' => Icons.turn_sharp_left,
      'sharp right' => Icons.turn_sharp_right,
      'uturn' => Icons.u_turn_left,
      _ => Icons.straight,
    };
  }

  String _fmt(double m) => m >= 1000 ? '${(m / 1000).toStringAsFixed(1)} km' : '${(m / 10).round() * 10} m';

  @override
  Widget build(BuildContext context) {
    final s = step;
    final d = (s == null || me == null) ? null : distanceKm(me!, s.at) * 1000;
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: AppColors.navy,
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 10, offset: Offset(0, 3))],
        ),
        child: Row(children: [
          Icon(s == null ? Icons.navigation : _icon(s), color: AppColors.lime, size: 44),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d == null ? 'Finding the route…' : _fmt(d), style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
              Text(s?.text ?? 'Hold on',
                  maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
      ),
      if (leftKm != null && leftMinutes != null)
        Container(
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 6)]),
          child: Text('${leftMinutes!.round()} min · ${leftKm!.toStringAsFixed(1)} km${toLabel == null ? '' : ' · $toLabel'}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy)),
        ),
    ]);
  }
}
