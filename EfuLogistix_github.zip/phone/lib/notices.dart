import 'dart:async';

import 'package:flutter/material.dart';

import 'app_state.dart';
import 'format.dart';
import 'models.dart';
import 'theme.dart';
import 'widgets.dart';

/// Messages for the signed-in person (booking assigned, vehicle approved, meeting at the office ...).
/// Checked every minute while the app is open.
class NoticeCenter {
  NoticeCenter._();
  static final instance = NoticeCenter._();

  final unread = ValueNotifier<int>(0);
  final items = ValueNotifier<List<Notice>>([]);
  Timer? _timer;
  String? _user;

  void start() {
    final me = appState.profile?.id;
    if (me == null) return;
    if (_user != me) {
      _user = me;
      items.value = [];
      unread.value = 0;
    }
    _timer ??= Timer.periodic(const Duration(seconds: 60), (_) => load());
    load();
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    _user = null;
    items.value = [];
    unread.value = 0;
  }

  Future<void> load() async {
    final me = appState.profile?.id;
    if (me == null) return;
    try {
      final rows = await db.from('notices').select().eq('user_id', me).order('created_at', ascending: false).limit(60);
      final list = rows.map(Notice.fromMap).toList();
      final before = items.value.isEmpty ? null : items.value.first.id;
      items.value = list;
      unread.value = list.where((n) => !n.read).length;
      // a new message while the app is open: show it at the bottom of the screen
      if (before != null && list.isNotEmpty && list.first.id != before && !list.first.read) {
        final ctx = navigatorKey.currentContext;
        if (ctx != null && ctx.mounted) toast(ctx, list.first.title);
      }
    } catch (_) {}
  }

  Future<void> markAllRead() async {
    final me = appState.profile?.id;
    if (me == null || unread.value == 0) return;
    try {
      await db.from('notices').update({'read': true}).eq('user_id', me).eq('read', false);
    } catch (_) {}
    await load();
  }
}

/// The bell with a red number.
class NoticeBell extends StatelessWidget {
  final Color color;
  const NoticeBell({super.key, this.color = Colors.white});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: NoticeCenter.instance.unread,
        builder: (context, n, _) => IconButton(
          tooltip: n == 0 ? 'Messages' : '$n new messages',
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NoticesScreen())),
          icon: Badge(
            isLabelVisible: n > 0,
            label: Text('$n'),
            child: Icon(Icons.notifications_outlined, color: color),
          ),
        ),
      );
}

class NoticesScreen extends StatefulWidget {
  const NoticesScreen({super.key});

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  @override
  void initState() {
    super.initState();
    NoticeCenter.instance.load().then((_) => NoticeCenter.instance.markAllRead());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Messages', style: TextStyle(fontWeight: FontWeight.w800)),
          backgroundColor: AppColors.navy,
          foregroundColor: Colors.white,
        ),
        body: ValueListenableBuilder<List<Notice>>(
          valueListenable: NoticeCenter.instance.items,
          builder: (context, list, _) => RefreshIndicator(
            onRefresh: NoticeCenter.instance.load,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              if (list.isEmpty) const EmptyText('No messages yet.'),
              for (final n in list) ...[
                AppCard(
                  borderColor: n.read ? null : AppColors.lime,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Icon(_icon(n.kind), color: AppColors.navy),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(n.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        if (n.body != null) Text(n.body!, style: const TextStyle(fontSize: 14)),
                        const SizedBox(height: 2),
                        Text('${shortDate(n.createdAt)} · ${clock(n.createdAt)}',
                            style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      ]),
                    ),
                  ]),
                ),
                const SizedBox(height: 8),
              ],
            ]),
          ),
        ),
      );

  IconData _icon(String? kind) => switch (kind) {
        'booking' => Icons.event_seat_outlined,
        'truck' => Icons.local_shipping_outlined,
        'match' => Icons.handshake_outlined,
        'wallet' => Icons.account_balance_wallet_outlined,
        'fee' => Icons.receipt_long_outlined,
        _ => Icons.notifications_outlined,
      };
}
