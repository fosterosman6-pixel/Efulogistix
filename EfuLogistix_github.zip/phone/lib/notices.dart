import 'dart:async';

import 'package:flutter/material.dart';
import 'icon_art.dart';

import 'app_state.dart';
import 'format.dart';
import 'models.dart';
import 'theme.dart';
import 'widgets.dart';
import 'i18n.dart';
import 'notice_text.dart';
import 'push.dart';
import 'screens/chat_screen.dart';
import 'screens/driver/pickups.dart';
import 'screens/driver/wallet.dart';
import 'screens/driver/documents.dart';
import 'screens/passenger/my_bookings.dart';
import 'screens/support/support_screens.dart';
import 'screens/owner/add_vehicle.dart';
import 'screens/owner/statement_screen.dart';
import 'screens/owner/service_screen.dart';

/// Messages for the signed-in person (booking assigned, vehicle approved, meeting at the office ...).
/// Checked every 15 seconds while the app is running; a new message also pops up and rings.
class NoticeCenter {
  NoticeCenter._();
  static final instance = NoticeCenter._();

  final unread = ValueNotifier<int>(0);
  final items = ValueNotifier<List<Notice>>([]);
  Timer? _timer;
  String? _user;

  void start() {
    final me = appState.profile?.id;
    if (me == null) return;
    if (_user != me) {
      _user = me;
      items.value = [];
      unread.value = 0;
    }
    _timer ??= Timer.periodic(const Duration(seconds: 15), (_) => load());
    load();
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    _user = null;
    items.value = [];
    unread.value = 0;
  }

  Future<void> load() async {
    final me = appState.profile?.id;
    if (me == null) return;
    try {
      final rows = await db.from('notices').select().eq('user_id', me).order('created_at', ascending: false).limit(60);
      final list = rows.map(Notice.fromMap).toList();
      final before = items.value.isEmpty ? null : items.value.first.id;
      items.value = list;
      unread.value = list.where((n) => !n.read).length;
      // a new message while the app is open: show it at the bottom of the screen
      if (before != null && list.isNotEmpty && list.first.id != before && !list.first.read) {
        final ctx = navigatorKey.currentContext;
        if (ctx != null && ctx.mounted) toast(ctx, noticeText(list.first.title));
      }
      // ring and pop up for every new unread message (up to 3), even when push is not set up
      if (before != null) {
        var rung = 0;
        for (final n in list) {
          if (n.id == before || rung >= 3) break;
          if (!n.read) {
            rung++;
            unawaited(Push.ringNow(n.id, noticeText(n.title), n.body));
          }
        }
      }
    } catch (_) {}
  }

  Future<void> markAllRead() async {
    final me = appState.profile?.id;
    if (me == null || unread.value == 0) return;
    try {
      await db.from('notices').update({'read': true}).eq('user_id', me).eq('read', false);
    } catch (_) {}
    await load();
  }
}

/// The bell with a red number.
class NoticeBell extends StatelessWidget {
  final Color color;
  const NoticeBell({super.key, this.color = Colors.white});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: NoticeCenter.instance.unread,
        builder: (context, n, _) => IconButton(
          tooltip: n == 0 ? tx('Messages') : txf('%s new messages', ['$n']),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NoticesScreen())),
          icon: Badge(
            isLabelVisible: n > 0,
            label: Text('$n'),
            child: const IconArt('bell', size: 28, fallback: Icons.notifications_outlined),
          ),
        ),
      );
}

class NoticesScreen extends StatefulWidget {
  const NoticesScreen({super.key});

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  @override
  void initState() {
    super.initState();
    NoticeCenter.instance.load().then((_) => NoticeCenter.instance.markAllRead());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(tx('Messages'), style: TextStyle(fontWeight: FontWeight.w800)),
          backgroundColor: AppColors.navy,
          foregroundColor: Colors.white,
        ),
        body: ValueListenableBuilder<List<Notice>>(
          valueListenable: NoticeCenter.instance.items,
          builder: (context, list, _) => RefreshIndicator(
            onRefresh: NoticeCenter.instance.load,
            child: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewPadding.bottom), children: [
              if (list.isEmpty) EmptyText(tx('No messages yet.')),
              for (final n in list) ...[
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => _open(context, n),
                  child: AppCard(
                  borderColor: n.read ? null : AppColors.lime,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    IconArt(_icon(n.kind), size: 38, fallback: Icons.notifications_outlined),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(noticeText(n.title), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        if (n.body != null) Text(noticeText(n.body), style: const TextStyle(fontSize: 14)),
                        const SizedBox(height: 2),
                        Text('${shortDate(n.createdAt)} · ${clock(n.createdAt)}',
                            style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                      ]),
                    ),
                    if (_opens(n)) const Icon(Icons.chevron_right, color: AppColors.muted),
                  ]),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ]),
          ),
        ),
      );

  /// Where tapping this message goes for the signed-in role (null: nowhere to go).
  Widget? _target(Notice n) {
    final role = appState.profile?.role;
    final driver = role == 'driver';
    final passenger = role == 'passenger';
    switch (n.kind) {
      case 'chat':
        if (n.refId == null) return null; // older owner/driver chat notices: found in _open
        return ChatScreen(bookingId: n.refId, title: _who(n));
      case 'chat_peer':
        if (n.refId == null) return null;
        return ChatScreen(peerId: n.refId, title: _who(n));
      case 'booking':
        if (driver) return const PickupsScreen();
        if (passenger) return const Scaffold(body: MyBookingsTab());
        return null;
      case 'support':
        return n.refId == null ? null : TicketScreen(ticketId: n.refId!);
      case 'wallet':
        return driver ? const WalletScreen() : null;
      case 'fee':
        return (!driver && !passenger) ? const StatementScreen() : null;
      case 'reminder':
        if (driver) return const DocumentsScreen();
        if (!passenger && n.title.startsWith('Service due')) return const ServiceScreen();
        return null;
      default:
        return null;
    }
  }

  String _who(Notice n) => n.title.startsWith('Message from ') ? n.title.substring('Message from '.length) : tx('Chat');

  /// Does tapping this message go somewhere?
  bool _opens(Notice n) => _target(n) != null || (n.kind == 'chat' && n.refId == null) || (n.kind == 'truck' && n.refId != null && appState.profile?.role != 'driver');

  Future<void> _open(BuildContext context, Notice n) async {
    final nav = Navigator.of(context);
    if (n.kind == 'truck' && n.refId != null && appState.profile?.role != 'driver') {
      try {
        final row = await db.from('trucks').select().eq('id', n.refId!).maybeSingle();
        if (row != null) nav.push(MaterialPageRoute(builder: (_) => VehicleDetailScreen(truck: Truck.fromMap(row))));
      } catch (_) {}
      return;
    }
    if (n.kind == 'chat' && n.refId == null) {
      // sent before messages carried the sender: the last person-to-person message to me before this notice
      try {
        final me = appState.profile?.id;
        final rows = await db
            .from('chat_messages')
            .select('sender_id')
            .eq('recipient_id', me!)
            .isFilter('booking_id', null)
            .lte('created_at', n.createdAt.add(const Duration(minutes: 2)).toUtc().toIso8601String())
            .order('created_at', ascending: false)
            .limit(1);
        if (rows.isNotEmpty) {
          nav.push(MaterialPageRoute(builder: (_) => ChatScreen(peerId: rows.first['sender_id'] as String, title: _who(n))));
        }
      } catch (_) {}
      return;
    }
    final screen = _target(n);
    if (screen != null) nav.push(MaterialPageRoute(builder: (_) => screen));
  }

  String _icon(String? kind) => switch (kind) {
        'booking' => 'ticket',
        'truck' => 'truck',
        'match' => 'match',
        'wallet' => 'wallet',
        'fee' => 'fee',
        'support' || 'report' || 'chat' || 'chat_peer' => 'headset',
        _ => 'bell',
      };
}
