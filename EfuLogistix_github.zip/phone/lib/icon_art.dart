import 'package:flutter/material.dart';

import 'theme.dart';

/// Picture icons by name (assets/icons/<name>.png). If a picture is missing, a plain icon is shown instead.
class IconArt extends StatelessWidget {
  final String name;
  final double size;
  final IconData fallback;
  const IconArt(this.name, {super.key, this.size = 32, this.fallback = Icons.circle_outlined});

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/icons/$name.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => Icon(fallback, size: size * 0.78, color: AppColors.navy),
      );
}

/// Bottom navigation picture; faded when not selected.
class NavArt extends StatelessWidget {
  final String name;
  final IconData fallback;
  final bool selected;
  const NavArt(this.name, this.fallback, {super.key, this.selected = false});

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: selected ? 1 : 0.55,
        child: IconArt(name, size: 32, fallback: fallback),
      );
}
