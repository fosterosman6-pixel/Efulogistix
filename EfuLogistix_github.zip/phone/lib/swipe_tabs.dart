import 'package:flutter/material.dart';

/// Lets the person swipe left or right anywhere on a tab to move to the next or previous bottom-menu tab.
/// Maps and sideways lists keep their own swipes, because they take the gesture first.
class SwipeTabs extends StatelessWidget {
  final int index;
  final int count;
  final ValueChanged<int> onChanged;
  final Widget child;
  const SwipeTabs({super.key, required this.index, required this.count, required this.onChanged, required this.child});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragEnd: (d) {
        final v = d.primaryVelocity ?? 0;
        if (v < -350 && index < count - 1) {
          onChanged(index + 1);
        } else if (v > 350 && index > 0) {
          onChanged(index - 1);
        }
      },
      child: child,
    );
  }
}
