import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_state.dart';
import 'format.dart';
import 'i18n.dart';
import 'theme.dart';

/// Where the passenger is on a trip with a change of car, for the second driver ([forDriver] true)
/// or for the passenger (false). Asks the database, so it follows whatever the first driver does.
/// Times are estimates from distance and speed, not live tracking.
class LegStatusBox extends StatefulWidget {
  final String bookingId;
  final int leg; // 1 or 2 (this booking's part of the trip)
  final bool forDriver;
  const LegStatusBox({super.key, required this.bookingId, required this.leg, this.forDriver = true});

  @override
  State<LegStatusBox> createState() => _LegStatusBoxState();
}

class _LegStatusBoxState extends State<LegStatusBox> {
  Map<String, dynamic>? _s;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await db.rpc('leg_status', params: {'p_booking': widget.bookingId});
      if (mounted && r is Map) setState(() => _s = Map<String, dynamic>.from(r));
    } catch (_) {} // keep what is shown; the transfer note above still tells the story
  }

  DateTime? _t(String key) {
    final v = _s?[key];
    return v == null ? null : DateTime.tryParse('$v')?.toLocal();
  }

  Widget _call(String label, String? phone) {
    if (phone == null || phone.trim().isEmpty) return const SizedBox.shrink();
    return TextButton(
      style: TextButton.styleFrom(visualDensity: VisualDensity.compact, padding: const EdgeInsets.symmetric(horizontal: 6)),
      onPressed: () => launchUrl(Uri.parse('tel:${phone.trim()}')),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) return const SizedBox.shrink();
    final state = '${s['state']}';
    final to = '${s['leg1_to'] ?? ''}';
    final from = '${s['leg1_from'] ?? ''}';
    final plate = s['leg1_plate'] == null ? '' : ' · ${s['leg1_plate']}';
    final boarded = _t('boarded_at');
    final arrives = _t('arrives_at');
    final dropped = _t('dropped_at');
    final walk = s['walk_min'];
    String text;
    Color bg = AppColors.surface100, edge = AppColors.line, fg = AppColors.navy;
    List<Widget> actions = [];
    if (widget.forDriver) {
      // the second driver's view
      switch (state) {
        case 'on_car':
          text = txf('On the first car%s. Boarded at %s %s. Arrives %s about %s.', [plate, from, clock(boarded), to, clock(arrives)]);
          bg = const Color(0xFFFFF6DD);
          edge = const Color(0xFFF0C24A);
          fg = const Color(0xFF5A4300);
          actions = [_call(tx('Call first driver'), s['leg1_driver_phone'] as String?), _call(tx('Call passenger'), s['passenger_phone'] as String?)];
        case 'at_change':
          text = txf('Dropped at %s %s. Walking to the pick-up, about %s min.', [to, clock(dropped), '$walk']);
          bg = const Color(0xFFE9F7C8);
          edge = AppColors.lime600;
          fg = const Color(0xFF2F4A00);
          actions = [_call(tx('Call passenger'), s['passenger_phone'] as String?)];
        case 'missed':
          text = tx('Missed the first car. You can leave on time. The office is arranging another car.');
          bg = const Color(0xFFFDE8E8);
          edge = AppColors.danger;
          fg = AppColors.danger;
        case 'cancelled':
          text = tx('The first part of the trip was cancelled.');
          bg = const Color(0xFFFDE8E8);
          edge = AppColors.danger;
          fg = AppColors.danger;
        default:
          text = txf('Not on the first car yet. Coming from %s%s.', [from, plate]);
          actions = [_call(tx('Call first driver'), s['leg1_driver_phone'] as String?)];
      }
    } else if (widget.leg == 2) {
      // the passenger's view of part 2
      final d = s['leg2_driver'] == null ? tx('The driver') : '${s['leg2_driver']}';
      text = s['leg2_driver_told'] == true
          ? txf('%s knows where you are and will wait for you at the pick-up.', [d])
          : tx('The second driver is told when you get on the first car.');
      if (state == 'missed' || state == 'cancelled') text = tx('The first part of the trip did not happen. The office will help.');
      actions = [_call(tx('Call second driver'), s['leg2_driver_phone'] as String?)];
    } else {
      return const SizedBox.shrink();
    }
    return Container(
      margin: const EdgeInsets.only(top: 6),
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: edge, width: 1.5)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: fg)),
        if (actions.isNotEmpty) Wrap(children: actions),
      ]),
    );
  }
}
