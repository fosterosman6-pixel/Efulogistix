import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_state.dart';
import 'theme.dart';
import 'widgets.dart';

/// A 4-digit PIN kept on this phone only (a salted hash, never the PIN itself).
/// When it is on, the app asks for it on opening and after 30 seconds in the background.
class AppLockService extends ChangeNotifier {
  AppLockService._();
  static final instance = AppLockService._();

  static const _kHash = 'app_lock_hash';
  static const _kSalt = 'app_lock_salt';
  static const graceSeconds = 30;

  String? _hash;
  String? _salt;
  bool locked = false;
  bool _ready = false;
  DateTime? _leftAt;

  bool get hasPin => _hash != null;

  Future<void> load() async {
    if (_ready) return;
    try {
      final p = await SharedPreferences.getInstance();
      _hash = p.getString(_kHash);
      _salt = p.getString(_kSalt);
    } catch (_) {}
    _ready = true;
    if (hasPin) {
      locked = true;
      notifyListeners();
    }
  }

  String _digest(String pin, String salt) => sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final rnd = Random.secure();
    final salt = base64Url.encode(List<int>.generate(12, (_) => rnd.nextInt(256)));
    _salt = salt;
    _hash = _digest(pin, salt);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_kSalt, salt);
      await p.setString(_kHash, _hash!);
    } catch (_) {}
    locked = false;
    notifyListeners();
  }

  bool verify(String pin) => _hash != null && _salt != null && _digest(pin, _salt!) == _hash;

  Future<void> clear() async {
    _hash = null;
    _salt = null;
    locked = false;
    try {
      final p = await SharedPreferences.getInstance();
      await p.remove(_kHash);
      await p.remove(_kSalt);
    } catch (_) {}
    notifyListeners();
  }

  void unlock() {
    locked = false;
    notifyListeners();
  }

  void appPaused() => _leftAt = DateTime.now();

  void appResumed() {
    final at = _leftAt;
    _leftAt = null;
    if (hasPin && at != null && DateTime.now().difference(at).inSeconds >= graceSeconds && !locked) {
      locked = true;
      notifyListeners();
    }
  }
}

/// Wraps the whole app: shows the PIN screen over it while locked (the screens underneath keep their place).
class AppLockGate extends StatefulWidget {
  final Widget child;
  const AppLockGate({super.key, required this.child});

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppLockService.instance.load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) AppLockService.instance.appPaused();
    if (state == AppLifecycleState.resumed) AppLockService.instance.appResumed();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([AppLockService.instance, appState]),
        builder: (context, _) {
          final show = AppLockService.instance.locked && appState.session != null;
          return Stack(children: [
            widget.child,
            // its own Overlay: this sits above the app's Navigator, and text fields need one
            if (show) Positioned.fill(child: Overlay(initialEntries: [OverlayEntry(builder: (_) => const _LockScreen())])),
          ]);
        },
      );
}

class _LockScreen extends StatefulWidget {
  const _LockScreen();

  @override
  State<_LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<_LockScreen> {
  final _ctl = TextEditingController();
  final _focus = FocusNode();
  int _wrong = 0;
  String? _error;

  @override
  void dispose() {
    _ctl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _check(String v) {
    if (v.length < 4) return;
    if (AppLockService.instance.verify(v)) {
      AppLockService.instance.unlock();
      return;
    }
    _wrong++;
    _ctl.clear();
    setState(() => _error = _wrong >= 5 ? 'Too many tries. Use "Forgot PIN" to sign in again.' : 'Wrong PIN. Try again.');
  }

  Future<void> _forgot() async {
    await AppLockService.instance.clear();
    await appState.signOut();
  }

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.navy,
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.lock_outline, color: AppColors.lime, size: 48),
                const SizedBox(height: 12),
                const Text('Enter your PIN',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 20),
                SizedBox(
                  width: 180,
                  child: TextField(
                    controller: _ctl,
                    focusNode: _focus,
                    autofocus: true,
                    obscureText: true,
                    textAlign: TextAlign.center,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                    onChanged: _check,
                    enabled: _wrong < 5,
                    style: const TextStyle(color: Colors.white, fontSize: 28, letterSpacing: 12),
                    decoration: const InputDecoration(
                      counterText: '',
                      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.onNavyMuted)),
                      focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.lime)),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                if (_error != null)
                  Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFFB4AB), fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: _forgot,
                  child: const Text('Forgot PIN · sign out', style: TextStyle(color: AppColors.onNavyMuted)),
                ),
              ]),
            ),
          ),
        ),
      );
}

/// Turn the PIN on, change it, or turn it off.
class AppLockSettingsScreen extends StatefulWidget {
  const AppLockSettingsScreen({super.key});

  @override
  State<AppLockSettingsScreen> createState() => _AppLockSettingsScreenState();
}

class _AppLockSettingsScreenState extends State<AppLockSettingsScreen> {
  final _current = TextEditingController();
  final _pin = TextEditingController();
  final _again = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _current.dispose();
    _pin.dispose();
    _again.dispose();
    super.dispose();
  }

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), counterText: ''),
        ),
      );

  Future<void> _save() async {
    final svc = AppLockService.instance;
    if (svc.hasPin && !svc.verify(_current.text)) {
      setState(() => _error = 'Your current PIN is wrong.');
      return;
    }
    if (_pin.text.length != 4) {
      setState(() => _error = 'The PIN must be 4 digits.');
      return;
    }
    if (_pin.text != _again.text) {
      setState(() => _error = 'The two PINs are not the same.');
      return;
    }
    await svc.setPin(_pin.text);
    if (!mounted) return;
    toast(context, 'PIN saved. The app will ask for it when you come back.');
    Navigator.of(context).pop();
  }

  Future<void> _off() async {
    final svc = AppLockService.instance;
    if (!svc.verify(_current.text)) {
      setState(() => _error = 'Type your current PIN to turn it off.');
      return;
    }
    await svc.clear();
    if (!mounted) return;
    toast(context, 'PIN turned off.');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final has = AppLockService.instance.hasPin;
    return Scaffold(
      backgroundColor: AppColors.surface100,
      appBar: AppBar(title: const Text('App lock (PIN)')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(
            has
                ? 'A PIN is on. The app asks for it when you open it and after 30 seconds away.'
                : 'Protect money and records on this phone with a 4-digit PIN. It stays on this phone only.',
            style: const TextStyle(color: AppColors.muted)),
        const SizedBox(height: 16),
        if (has) _field(_current, 'Current PIN'),
        _field(_pin, has ? 'New PIN (4 digits)' : 'PIN (4 digits)'),
        _field(_again, 'Type it again'),
        ErrorLine(_error),
        const SizedBox(height: 8),
        AppButton(has ? 'Change PIN' : 'Turn on PIN', onPressed: _save),
        if (has) ...[
          const SizedBox(height: 10),
          AppButton('Turn PIN off', kind: ButtonKind.danger, onPressed: _off),
        ],
      ]),
    );
  }
}
