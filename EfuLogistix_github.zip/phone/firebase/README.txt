Put google-services.json (from the Firebase console) in this folder.
