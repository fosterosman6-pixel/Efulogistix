# EfuLogistix app (Flutter) · version 3

The phone app for **passengers, drivers and vehicle owners**. It works for every vehicle category:
Matola, Minibus, Lorry, Taxi, Kabaza and any category the admin adds.

**Managers and the admin use the web panel** in the `efulogistix_admin` folder (a manager who signs in on the phone
is told to use the panel).

| Role | Uses | Can do |
| --- | --- | --- |
| **Passenger** | Phone app, *Passenger* button | Book a seat on a route at a set time, hire a whole car (per km), send goods with a receiver code, track the car, cancel free |
| **Driver** | Phone app, *Driver* button | Upload documents, wait for a vehicle (office meeting), shifts and trips, booked pickups, hand in 100% to the owner, wallet (10%) |
| **Vehicle owner** | Phone app, *Vehicle owner* button | Add vehicles with photos and papers (admin checks), see own vehicles and drivers only, confirm hand-ins, pay driver wallets on Monday, EfuLogistix fee |
| **Manager** | Web panel | Bookings, drivers & matching, shifts, cash, route history, fees, service, reports |
| **Admin** | Web panel | Everything, plus people, documents, vehicle approval, categories, fares, timetable & rates, settings |

---

## 1. Database (Supabase)

Your project: `https://zqrjzruhvrpmdtbhlxsn.supabase.co`. The URL and publishable key are already in `lib/config.dart`.
**Never put the `sb_secret_…` / service_role key in the app.**

1. Supabase → **SQL Editor → New query** → paste all of `supabase/schema.sql` → **Run**.
2. New query → paste all of `supabase/schema_v2.sql` → **Run**.
3. New query → paste all of `supabase/schema_v3.sql` → **Run**. (Each file is safe to run again; it only adds what is missing.)
4. **Authentication → Sign In / Providers → Email**: turn **off "Confirm email"** (easier for drivers).

## 2. Make yourself the admin

1. Install the app (step 3) or open the web panel, and create an account with your email
   (in the phone app: *New here? Create an account*).
2. In the SQL Editor run, with your email:

```sql
update public.profiles set role = 'admin', active = true where email = 'you@example.com';
```

3. Open the **admin web panel** (see `efulogistix_admin/README.md`) and sign in.

## 3. Build the phone app (Windows, VS Code)

Open the `efulogistix_fleet_flutter` folder in VS Code. In the terminal:

```bash
flutter create --org mw.efulogistix --project-name efulogistix_fleet --platforms android,ios .
del test\widget_test.dart
flutter pub get
dart run tool/add_permissions.dart
flutter run                          # on a connected Android phone
flutter build apk --split-per-abi    # APKs for drivers: build/app/outputs/flutter-apk/
```

- `flutter create .` only adds the android/ios folders; it keeps `lib/`.
- `add_permissions.dart` adds internet, GPS (also while the phone is locked during a shift), the tracking
  notification and the camera. Safe to run again.
- If `flutter pub get` complains about versions: `flutter pub upgrade --major-versions`.
- Send drivers the `app-armeabi-v7a-release.apk` (most cheap phones) or `app-arm64-v8a-release.apk`.

## 4. Set up the business (in the admin panel)

1. **Categories**: check Matola, Minibus, Lorry, Taxi, Kabaza (seats, licence classes). Add others.
2. **People → Invite**: vehicle owners first, then managers, then drivers (email + role). They create their
   account in the app with that same email and are linked straight away. Walk-in sign-ups wait for your *Approve*.
3. **Vehicles → Add vehicle**: plate, category, owner, oil interval. Add insurance / COF papers with expiry dates.
4. **Fares**: route fares per category ("Mangochi Main Rank → Monkey Bay, Matola, K5,000"), and goods prices.
   *Copy to category* gives a quick start for another category; *Raise all* adds a percentage after a fuel rise.
5. Give drivers a vehicle in **Drivers & matching** (office meeting, then *Agreed*), or directly in **People → Edit**.
6. **Documents**: approve each driver's National ID, licence (class + expiry) and face photo.
   A driver cannot start a shift until these are approved and their licence class fits the vehicle.

## 5. A driver's day

| Step | Driver does | Checked by |
| --- | --- | --- |
| Documents (once) | National ID, licence, face photo, next of kin (+ PrDP if switched on) | Admin approves |
| Start shift | Real time shown, live photo of the odometer, types the km | Photo + GPS |
| New trip | Picks the route: fare is fixed by the admin. Passengers (up to the seats), goods; lorries: load price + kg | Server works out the total |
| Start route | Odometer photo + km | Compared with GPS |
| On the way | **Stop**: drop-offs and pickups, saved with the GPS point | Shown on the map; stops the driver did not save show as "?" |
| Offload | Odometer photo + km | Compared with GPS |
| Change truck | Photos of both odometers + 4 photos of the new vehicle | Manager approves (admin panel), owner sees it |
| End of day | 4 vehicle photos, odometer photo + km, cash / Airtel Money / TNM Mpamba + reference | The vehicle owner confirms the money (the office for company vehicles); 10% goes to the driver's wallet |

Expected cash = trips − driver-paid expenses (worked out by the database, not the phone).

**Alerts** (admin panel and vehicle owner): overspeed, long stop, stop not saved, mileage difference, cash short,
truck change, no signal, oil change due, papers and licence expiring. Limits are in the admin panel → *Settings*.

**Offline**: stops, expenses and GPS points are kept on the phone and sent when signal returns
(a counter shows how many are waiting). Steps with a photo need signal.

**Chichewa**: drivers can switch English / Chichewa on their screens.

## Version 3 · what is new and how to start it

After running `schema_v3.sql`, in the **admin panel**:

1. **Timetable & rates**: add departure times to your routes (passengers book seats on them), set the hire price per km
   and the EfuLogistix fees (weekly, monthly, per trip) for each category. Example prices are filled in; change them.
2. **Settings**: office phone (shown to passengers), office meeting place, driver wallet % (10), stop detection.
3. **Vehicles**: vehicles sent by owners wait at the top. *Approve* puts them on the road (their papers too);
   *Send back* tells the owner what to fix. New papers for a running vehicle are checked there too.
4. **Drivers & matching**: approved drivers without a vehicle. *Match* → choose the vehicle, day and time:
   driver and owner get a message. After the meeting press *Agreed* (the driver gets the vehicle) or *Not agreed*.
5. **Bookings**: new bookings from passengers. Click one → choose a vehicle with a driver → *Assign*.
   *Same vehicle for all waiting bookings of this departure* fills a matola in one click. *Booking for a caller* is for phone bookings.
6. **EfuLogistix fees**: *Bill last week* / *Bill last month*, then *Received* when the owner has paid.
7. **Route history**: choose a vehicle and a day: the route, every stop of 2 minutes or more with arrival and departure
   times (also when the driver did not press Stop), and a replay.

In the **phone app**:

- **Passenger**: Home → *Book a seat*, *Hire a car*, *Send goods*. My bookings shows the car, the driver, the goods code
  for the receiver, *Track the car* and *Cancel · no fee*. Missed bookings are counted on the profile.
- **Driver**: after login the header shows name, picture and location. Waiting screen until matched.
  On duty: the seat icon opens **Booked pickups** (Picked up, No-show, Delivered with the receiver's code).
  Cash bookings are added to the running trip. End of day: hand in 100% to the owner; *My wallet* shows the 10%.
- **Owner**: *Add vehicle* (details, photos, papers, fee plan). Tap a vehicle for papers and fee plan.
  **Cash**: confirm each hand-in (this adds the driver's 10% to the wallet), *Driver pay* (every Monday,
  can take a shortfall off first), *EfuLogistix fee*.
- **GPS**: every point is saved on the phone and uploaded when there is signal (up to about 3 days without signal).
  If GPS is switched off during a shift, the office gets a *Tracking stopped* alert.

New package: `flutter_svg` (vehicle pictures). Run `flutter pub get` after copying the files.

## Demo mode (no account, no internet)

On the sign-in screen, pick **Passenger**, **Driver** or **Vehicle owner** and tap **Try demo**. The app opens with sample data
from a small Mangochi fleet: six vehicles (Matola, Minibus, Lorry, Taxi), drivers, two weeks of trips, today's shifts,
cash hand-ins, alerts and a truck change waiting for approval.

- Everything works as normal (start shift, trips, stops, offload, end of day, receive cash, approve changes), but it
  is kept on the phone only and is reset when the app is closed. Nothing touches the real Supabase database.
- You can sign out and try another role in the same session: the driver's trips show up for the owner.
- A green **DEMO** label shows in the corner. **Sign out** leaves demo mode.
- Map tiles still need internet; without it the map is blank but everything else works.

## Files

- `lib/screens/driver/` driver screens · `lib/screens/owner/` vehicle-owner screens · `lib/screens/passenger/` passenger screens
- `lib/tracking.dart` GPS for the whole shift · `lib/outbox.dart` offline queue · `lib/i18n.dart` English/Chichewa
- `supabase/schema.sql` + `supabase/schema_v2.sql` the database, rules, checks and alerts

## Good to know

- The app does **not read the numbers in photos**. The typed km is compared with GPS distance; the photo is the proof
  the manager can open.
- Mobile money is **recorded** (method + reference), not collected through Airtel/TNM. Connecting their payment
  systems needs a merchant account with them.
- OpenStreetMap maps, search and routes are free for light use. If the fleet grows large, move to a paid or self-hosted service.
- The Chichewa words should be checked by a native speaker before going live.
- Please confirm the PrDP rule and the licence classes per category with DRTSS.
