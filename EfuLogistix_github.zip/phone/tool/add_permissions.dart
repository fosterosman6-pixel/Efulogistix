// Adds the permissions the app needs after `flutter create .` has made the android/ and ios/ folders:
// internet, GPS (also while the phone is locked during a shift), the tracking notification, and the camera.
// Run from the project folder:  dart run tool/add_permissions.dart   (safe to run again)
import 'dart:io';

void main() {
  _android();
  _ios();
}

void _android() {
  final file = File('android/app/src/main/AndroidManifest.xml');
  if (!file.existsSync()) {
    stdout.writeln('Android: no AndroidManifest.xml yet. Run "flutter create ." first.');
    return;
  }
  var xml = file.readAsStringSync();
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.FOREGROUND_SERVICE', // keeps GPS running with the phone locked during a shift
    'android.permission.FOREGROUND_SERVICE_LOCATION', // needed on Android 14+
    'android.permission.POST_NOTIFICATIONS', // the "EfuLogistix is recording your shift" notice, Android 13+
    'android.permission.WAKE_LOCK',
  ];
  final missing = perms.where((p) => !xml.contains('"$p"')).toList();
  if (missing.isEmpty) {
    stdout.writeln('Android: permissions already there.');
  } else {
    final lines = missing.map((p) => '    <uses-permission android:name="$p"/>').join('\n');
    final at = xml.indexOf('<application');
    if (at < 0) {
      stdout.writeln('Android: could not find <application> in the manifest. Add these lines by hand:\n$lines');
      return;
    }
    xml = '${xml.substring(0, at)}${lines.trimLeft()}\n    ${xml.substring(at)}';
    stdout.writeln('Android: added ${missing.length} permission(s).');
  }
  // the camera app opened by image_picker must be found on Android 11+
  if (!xml.contains('android.media.action.IMAGE_CAPTURE')) {
    const query = '''
    <queries>
        <intent>
            <action android:name="android.media.action.IMAGE_CAPTURE"/>
        </intent>
    </queries>
''';
    final end = xml.lastIndexOf('</manifest>');
    if (end > 0) {
      xml = xml.substring(0, end) + query + xml.substring(end);
      stdout.writeln('Android: added the camera query.');
    }
  }
  file.writeAsStringSync(xml);
}

void _ios() {
  final file = File('ios/Runner/Info.plist');
  if (!file.existsSync()) {
    stdout.writeln('iPhone: no ios/ folder (fine if you only build for Android).');
    return;
  }
  var plist = file.readAsStringSync();
  const texts = {
    'NSLocationWhenInUseUsageDescription': 'EfuLogistix shows your vehicle on the map and records the trip route.',
    'NSLocationAlwaysAndWhenInUseUsageDescription':
        'EfuLogistix keeps recording the route while you are on duty, also with the phone locked.',
    'NSCameraUsageDescription': 'EfuLogistix takes photos of the mileage, the vehicle and your documents.',
    'NSPhotoLibraryUsageDescription': 'EfuLogistix lets you choose a photo of a document or a receipt.',
  };
  var added = 0;
  final buffer = StringBuffer();
  texts.forEach((key, text) {
    if (!plist.contains('<key>$key</key>')) {
      buffer.write('\t<key>$key</key>\n\t<string>$text</string>\n');
      added++;
    }
  });
  if (!plist.contains('<key>UIBackgroundModes</key>')) {
    buffer.write('\t<key>UIBackgroundModes</key>\n\t<array>\n\t\t<string>location</string>\n\t</array>\n');
    added++;
  }
  if (added == 0) {
    stdout.writeln('iPhone: permission texts already there.');
    return;
  }
  final at = plist.lastIndexOf('</dict>');
  if (at < 0) {
    stdout.writeln('iPhone: could not update Info.plist. Add these by hand:\n$buffer');
    return;
  }
  plist = plist.substring(0, at) + buffer.toString() + plist.substring(at);
  file.writeAsStringSync(plist);
  stdout.writeln('iPhone: added $added permission entr${added == 1 ? 'y' : 'ies'}.');
}
