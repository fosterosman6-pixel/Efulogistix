// Adds the permissions the app needs after `flutter create .` has made the android/ and ios/ folders:
// internet, GPS (also while the phone is locked during a shift), the tracking notification, and the camera.
// Run from the project folder:  dart run tool/add_permissions.dart   (safe to run again)
import 'dart:io';

void main() {
  _android();
  _noShrink();
  _firebase();
  _launcherIcon();
  _ios();
}

/// EfuLogistix logo as the phone's app icon, and "EfuLogistix" as the name under it.
void _launcherIcon() {
  final res = Directory('android/app/src/main/res');
  final src = Directory('tool/launcher');
  if (!res.existsSync() || !src.existsSync()) {
    stdout.writeln('Icon: skipped (no android/ folder or no tool/launcher icons).');
    return;
  }
  // 1st choice: the standard icon generator (flutter_launcher_icons, settings in pubspec.yaml)
  final gen = Process.runSync('dart', ['run', 'flutter_launcher_icons'], runInShell: true);
  stdout.write(gen.stdout);
  stderr.write(gen.stderr);
  if (gen.exitCode == 0) {
    _appName();
    _iconReport(res);
    return;
  }
  stdout.writeln('Icon: generator failed (exit ${gen.exitCode}), copying the ready-made icons instead.');
  var copied = 0;
  for (final dir in src.listSync().whereType<Directory>()) {
    final name = dir.uri.pathSegments.where((s) => s.isNotEmpty).last; // e.g. mipmap-hdpi
    final out = Directory('${res.path}/$name')..createSync(recursive: true);
    for (final f in dir.listSync().whereType<File>()) {
      f.copySync('${out.path}/${f.uri.pathSegments.last}');
      copied++;
    }
  }
  // Android 8+ round / shaped icons: white background + the logo in the middle
  final anydpi = Directory('${res.path}/mipmap-anydpi-v26')..createSync(recursive: true);
  File('${anydpi.path}/ic_launcher.xml').writeAsStringSync('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/efu_icon_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
''');
  final values = Directory('${res.path}/values')..createSync(recursive: true);
  File('${values.path}/efu_icon_colors.xml').writeAsStringSync('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="efu_icon_background">#FFFFFF</color>
</resources>
''');
  // point the app at ic_launcher
  final m = File('android/app/src/main/AndroidManifest.xml');
  if (m.existsSync()) {
    m.writeAsStringSync(m.readAsStringSync().replaceFirst(RegExp(r'android:icon="[^"]*"'), 'android:icon="@mipmap/ic_launcher"'));
  }
  _appName();
  _iconReport(res);
  stdout.writeln('Icon: copied $copied logo file(s).');
}

/// "EfuLogistix" as the name under the icon.
void _appName() {
  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (manifest.existsSync()) {
    final xml = manifest.readAsStringSync();
    final fixed = xml.replaceFirst(RegExp(r'android:label="[^"]*"'), 'android:label="EfuLogistix"');
    if (fixed != xml) manifest.writeAsStringSync(fixed);
  }
  stdout.writeln('Icon: app name set to EfuLogistix.');
}

/// Prints what the build will use, so the log shows the icon really changed.
void _iconReport(Directory res) {
  final xml = File('android/app/src/main/AndroidManifest.xml').readAsStringSync();
  stdout.writeln('Icon: manifest uses ${RegExp(r'android:icon="[^"]*"').firstMatch(xml)?.group(0)}');
  for (final d in res.listSync().whereType<Directory>().where((d) => d.path.contains('mipmap'))) {
    final files = d.listSync().whereType<File>().map((f) => '${f.uri.pathSegments.last} ${f.lengthSync()}B');
    stdout.writeln('Icon: ${d.uri.pathSegments.where((s) => s.isNotEmpty).last}: ${files.join(', ')}');
  }
}

void _android() {
  final file = File('android/app/src/main/AndroidManifest.xml');
  if (!file.existsSync()) {
    stdout.writeln('Android: no AndroidManifest.xml yet. Run "flutter create ." first.');
    return;
  }
  var xml = file.readAsStringSync();
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.FOREGROUND_SERVICE', // keeps GPS running with the phone locked during a shift
    'android.permission.FOREGROUND_SERVICE_LOCATION', // needed on Android 14+
    'android.permission.POST_NOTIFICATIONS', // the "EfuLogistix is recording your shift" notice, Android 13+
    'android.permission.WAKE_LOCK',
    'android.permission.CAMERA', // scanning tickets and taking photos
    'android.permission.RECORD_AUDIO', // voice notes in the chat
    'android.permission.VIBRATE', // ringing alerts
    'android.permission.USE_FULL_SCREEN_INTENT', // ringing alerts on the lock screen
  ];
  final missing = perms.where((p) => !xml.contains('"$p"')).toList();
  if (missing.isEmpty) {
    stdout.writeln('Android: permissions already there.');
  } else {
    final lines = missing.map((p) => '    <uses-permission android:name="$p"/>').join('\n');
    final at = xml.indexOf('<application');
    if (at < 0) {
      stdout.writeln('Android: could not find <application> in the manifest. Add these lines by hand:\n$lines');
      return;
    }
    xml = '${xml.substring(0, at)}${lines.trimLeft()}\n    ${xml.substring(at)}';
    stdout.writeln('Android: added ${missing.length} permission(s).');
  }
  // the camera app opened by image_picker must be found on Android 11+
  if (!xml.contains('android.media.action.IMAGE_CAPTURE')) {
    const query = '''
    <queries>
        <intent>
            <action android:name="android.media.action.IMAGE_CAPTURE"/>
        </intent>
    </queries>
''';
    final end = xml.lastIndexOf('</manifest>');
    if (end > 0) {
      xml = xml.substring(0, end) + query + xml.substring(end);
      stdout.writeln('Android: added the camera query.');
    }
  }
  // Google Maps key (kept out of the code: set MAPS_API_KEY as a GitHub secret, or in the shell)
  var mapsKey = Platform.environment['MAPS_API_KEY'] ?? '';
  if (mapsKey.isEmpty && File('maps_key.txt').existsSync()) mapsKey = File('maps_key.txt').readAsStringSync().trim();
  if (mapsKey.isEmpty) {
    stdout.writeln('Android: MAPS_API_KEY not set, the Google map will be blank.');
  } else if (!xml.contains('com.google.android.geo.API_KEY')) {
    final close = xml.indexOf('</application>');
    if (close > 0) {
      xml = '${xml.substring(0, close)}    <meta-data android:name="com.google.android.geo.API_KEY" android:value="$mapsKey"/>\n    ${xml.substring(close)}';
      stdout.writeln('Android: added the Google Maps key.');
    }
  }
  file.writeAsStringSync(xml);
}

void _ios() {
  final file = File('ios/Runner/Info.plist');
  if (!file.existsSync()) {
    stdout.writeln('iPhone: no ios/ folder (fine if you only build for Android).');
    return;
  }
  var plist = file.readAsStringSync();
  const texts = {
    'NSLocationWhenInUseUsageDescription': 'EfuLogistix shows your vehicle on the map and records the trip route.',
    'NSLocationAlwaysAndWhenInUseUsageDescription':
        'EfuLogistix keeps recording the route while you are on duty, also with the phone locked.',
    'NSCameraUsageDescription': 'EfuLogistix takes photos of the mileage, the vehicle and your documents.',
    'NSPhotoLibraryUsageDescription': 'EfuLogistix lets you choose a photo of a document or a receipt.',
    'NSMicrophoneUsageDescription': 'EfuLogistix records voice notes for the chat with your driver or passenger.',
  };
  var added = 0;
  final buffer = StringBuffer();
  texts.forEach((key, text) {
    if (!plist.contains('<key>$key</key>')) {
      buffer.write('\t<key>$key</key>\n\t<string>$text</string>\n');
      added++;
    }
  });
  if (!plist.contains('<key>UIBackgroundModes</key>')) {
    buffer.write('\t<key>UIBackgroundModes</key>\n\t<array>\n\t\t<string>location</string>\n\t</array>\n');
    added++;
  }
  if (added == 0) {
    stdout.writeln('iPhone: permission texts already there.');
    return;
  }
  final at = plist.lastIndexOf('</dict>');
  if (at < 0) {
    stdout.writeln('iPhone: could not update Info.plist. Add these by hand:\n$buffer');
    return;
  }
  plist = plist.substring(0, at) + buffer.toString() + plist.substring(at);
  file.writeAsStringSync(plist);
  stdout.writeln('iPhone: added $added permission entr${added == 1 ? 'y' : 'ies'}.');
}


/// Push notifications: only when the file firebase/google-services.json has been added to the project
/// (downloaded from the Firebase console). Without it the app still builds, just without push.
void _firebase() {
  final src = File('firebase/google-services.json');
  if (!src.existsSync()) {
    stdout.writeln('Firebase: firebase/google-services.json not found, building WITHOUT push notifications.');
    return;
  }
  if (!Directory('android/app').existsSync()) {
    stdout.writeln('Firebase: no android/ folder yet.');
    return;
  }
  src.copySync('android/app/google-services.json');
  const id = 'com.google.gms.google-services';
  const ver = '4.4.2';
  File? find(List<String> names) {
    for (final n in names) {
      final f = File(n);
      if (f.existsSync()) return f;
    }
    return null;
  }

  final app = find(['android/app/build.gradle.kts', 'android/app/build.gradle']);
  if (app == null) {
    stdout.writeln('Firebase: could not find android/app/build.gradle.');
    return;
  }
  final kts = app.path.endsWith('.kts');
  final plugin = kts ? 'id("$id")' : "id '$id'";
  final settings = find(['android/settings.gradle.kts', 'android/settings.gradle']);
  final top = find(['android/build.gradle.kts', 'android/build.gradle']);

  // 1) make the plugin known
  var done = false;
  if (settings != null) {
    var t = settings.readAsStringSync();
    if (t.contains(id)) {
      done = true;
    } else {
      final re = RegExp(r'(\n[ \t]*)id\s*\(?\s*[\x22\x27]com\.android\.application[\x22\x27]\s*\)?\s*version[^\n]*');
      final m = re.firstMatch(t);
      if (m != null) {
        final line = settings.path.endsWith('.kts')
            ? '${m.group(1)}id("$id") version "$ver" apply false'
            : "${m.group(1)}id '$id' version '$ver' apply false";
        t = t.replaceRange(m.end, m.end, line);
        settings.writeAsStringSync(t);
        done = true;
      }
    }
  }
  if (!done && top != null) {
    var t = top.readAsStringSync();
    if (!t.contains(id)) {
      final dep = top.path.endsWith('.kts') ? 'classpath("com.google.gms:google-services:$ver")' : "classpath 'com.google.gms:google-services:$ver'";
      final re = RegExp(r'buildscript\s*\{[\s\S]*?dependencies\s*\{');
      final m = re.firstMatch(t);
      if (m != null) {
        t = t.replaceRange(m.end, m.end, '\n        $dep');
      } else {
        t = 'buildscript {\n    repositories { google(); mavenCentral() }\n    dependencies {\n        $dep\n    }\n}\n$t';
      }
      top.writeAsStringSync(t);
    }
    done = true;
  }
  if (!done) {
    stdout.writeln('Firebase: could not register the Google services plugin.');
    return;
  }

  // 2) apply it in the app module
  var a = app.readAsStringSync();
  if (a.contains(id)) {
    stdout.writeln('Firebase: already set up.');
    return;
  }
  final re = RegExp(r'plugins\s*\{');
  final m = re.firstMatch(a);
  if (m != null) {
    a = a.replaceRange(m.end, m.end, '\n    $plugin');
  } else {
    a = "$a\napply plugin: 'com.google.gms.google-services'\n";
  }
  app.writeAsStringSync(a);
  stdout.writeln('Firebase: push notifications switched on.');
}

/// The code shrinker (R8) breaks the camera's barcode reader in release builds
/// ("Attempt to invoke virtual method ... on a null object reference"), so it is switched off.
void _noShrink() {
  for (final n in ['android/app/build.gradle.kts', 'android/app/build.gradle']) {
    final f = File(n);
    if (!f.existsSync()) continue;
    var t = f.readAsStringSync();
    if (t.contains('EFU_NO_SHRINK')) return;
    final kts = n.endsWith('.kts');
    final m = RegExp(r'release\s*\{').firstMatch(t);
    if (m == null) {
      stdout.writeln('Shrink: no release block found.');
      return;
    }
    final add = kts
        ? '\n            // EFU_NO_SHRINK\n            isMinifyEnabled = false\n            isShrinkResources = false'
        : '\n            // EFU_NO_SHRINK\n            minifyEnabled false\n            shrinkResources false';
    t = t.replaceRange(m.end, m.end, add);
    f.writeAsStringSync(t);
    stdout.writeln('Shrink: code shrinker switched off for release builds.');
    return;
  }
}
