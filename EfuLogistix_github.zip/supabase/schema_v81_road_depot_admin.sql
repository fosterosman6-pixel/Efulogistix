-- v81: the admin adds, moves, renames and deletes depots on a road (Admin web, Roads page). Admin only.
-- Special fares stay with their depots, distances and fares are worked out again, and drivers and passengers see the
-- change on their next refresh. Safe to run twice.
begin;

-- one place that rewrites a road's depot order from a list of names (keeps special fares by depot name)
create or replace function public._road_apply(p_corridor uuid, p_names text[])
returns void language plpgsql security definer set search_path = public as $$
declare ov record; n int; i int; nm text; pl places%rowtype;
begin
  drop table if exists _ov;
  create temp table _ov on commit drop as
    select o.category_id, a.place_name as a_name, b.place_name as b_name, o.fare
      from corridor_overrides o
      join corridor_stops a on a.corridor_id = o.corridor_id and a.pos = o.from_pos
      join corridor_stops b on b.corridor_id = o.corridor_id and b.pos = o.to_pos
     where o.corridor_id = p_corridor;
  delete from corridor_overrides where corridor_id = p_corridor;

  delete from corridor_stops where corridor_id = p_corridor and place_name <> all (p_names);
  update corridor_stops set pos = pos + 1000 where corridor_id = p_corridor;
  n := coalesce(array_length(p_names, 1), 0);
  for i in 1..n loop
    nm := p_names[i];
    if exists (select 1 from corridor_stops where corridor_id = p_corridor and place_name = nm) then
      update corridor_stops set pos = i - 1 where corridor_id = p_corridor and place_name = nm;
    else
      select * into pl from places where name = nm;
      if pl.name is null then raise exception 'No place called "%"', nm; end if;
      insert into corridor_stops (corridor_id, pos, place_name, lat, lng) values (p_corridor, i - 1, pl.name, pl.lat, pl.lng);
    end if;
  end loop;

  for ov in select v.category_id, v.fare, least(pa.pos, pb.pos) as p1, greatest(pa.pos, pb.pos) as p2
              from _ov v
              join corridor_stops pa on pa.corridor_id = p_corridor and pa.place_name = v.a_name
              join corridor_stops pb on pb.corridor_id = p_corridor and pb.place_name = v.b_name
             where pa.pos <> pb.pos loop
    insert into corridor_overrides (corridor_id, category_id, from_pos, to_pos, fare)
    values (p_corridor, ov.category_id, ov.p1, ov.p2, ov.fare)
    on conflict do nothing;
  end loop;

  perform corridor_recalc_km(p_corridor);
  perform corridor_rebuild(p_corridor);
end $$;

create or replace function public._road_names(p_corridor uuid) returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(place_name order by pos), '{}') from corridor_stops where corridor_id = p_corridor;
$$;

-- add a depot (a place from the places list) after the depot at p_after_pos (-1 = at the very start)
create or replace function public.road_depot_add(p_corridor uuid, p_place text, p_after_pos int, p_board boolean default true, p_drop boolean default true)
returns void language plpgsql security definer set search_path = public as $$
declare names text[]; out_ text[] := '{}'; i int; cur text;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if not exists (select 1 from places where name = p_place) then raise exception 'No place called "%". Add it to Places first.', p_place; end if;
  if exists (select 1 from corridor_stops where corridor_id = p_corridor and place_name = p_place) then raise exception 'ALREADY_ON_ROAD'; end if;
  names := _road_names(p_corridor);
  if p_after_pos < 0 then out_ := array[p_place];
  end if;
  for i in 1..coalesce(array_length(names, 1), 0) loop
    cur := names[i];
    out_ := out_ || cur;
    if i - 1 = p_after_pos then out_ := out_ || p_place; end if;
  end loop;
  perform _road_apply(p_corridor, out_);
  update corridor_stops set can_board = p_board, can_drop = p_drop where corridor_id = p_corridor and place_name = p_place;
end $$;

create or replace function public.road_depot_delete(p_corridor uuid, p_pos int)
returns void language plpgsql security definer set search_path = public as $$
declare names text[]; nm text;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select place_name into nm from corridor_stops where corridor_id = p_corridor and pos = p_pos;
  if nm is null then return; end if;
  names := _road_names(p_corridor);
  if coalesce(array_length(names, 1), 0) <= 2 then raise exception 'A road needs at least two depots'; end if;
  perform _road_apply(p_corridor, array_remove(names, nm));
end $$;

-- move one depot a place up (p_dir = -1) or down (p_dir = 1)
create or replace function public.road_depot_move(p_corridor uuid, p_pos int, p_dir int)
returns void language plpgsql security definer set search_path = public as $$
declare names text[]; i int := p_pos + 1; j int := p_pos + 1 + p_dir; tmp text;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  names := _road_names(p_corridor);
  if p_dir not in (-1, 1) or j < 1 or j > coalesce(array_length(names, 1), 0) or i > coalesce(array_length(names, 1), 0) then return; end if;
  tmp := names[i]; names[i] := names[j]; names[j] := tmp;
  perform _road_apply(p_corridor, names);
end $$;

-- rename a depot everywhere it is written (places, every road, routes, change-of-car points)
create or replace function public.road_depot_rename(p_corridor uuid, p_pos int, p_new text)
returns void language plpgsql security definer set search_path = public as $$
declare old text := (select place_name from corridor_stops where corridor_id = p_corridor and pos = p_pos); nw text := trim(p_new); k record;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if old is null or nw = '' or nw = old then return; end if;
  if exists (select 1 from places where name = nw) then raise exception 'A place called "%" already exists', nw; end if;
  update places set name = nw where name = old;
  update corridor_stops set place_name = nw where place_name = old;
  update routes set from_name = nw where from_name = old;
  update routes set to_name = nw where to_name = old;
  update transfer_points set hub_a = nw where hub_a = old;
  update transfer_points set hub_b = nw where hub_b = old;
  for k in select distinct corridor_id from corridor_stops where place_name = nw loop
    perform corridor_rebuild(k.corridor_id);
  end loop;
end $$;

revoke all on function public._road_apply(uuid, text[]), public._road_names(uuid) from public, anon, authenticated;
revoke all on function public.road_depot_add(uuid, text, int, boolean, boolean), public.road_depot_delete(uuid, int),
                       public.road_depot_move(uuid, int, int), public.road_depot_rename(uuid, int, text) from public, anon;
grant execute on function public.road_depot_add(uuid, text, int, boolean, boolean), public.road_depot_delete(uuid, int),
                          public.road_depot_move(uuid, int, int), public.road_depot_rename(uuid, int, text) to authenticated;
commit;
