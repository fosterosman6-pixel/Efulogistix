-- EfuLogistix: database update v11  (run AFTER schema_v10.sql)
-- Shifts that were never ended: the office sees them, can close them, and the driver + owner get a reminder.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

-- Office: close a shift the driver forgot to end (it is marked "flagged" so it gets a look)
create or replace function public.admin_close_shift(p_shift uuid, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare s shifts%rowtype;
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  select * into s from shifts where id = p_shift for update;
  if s.id is null or s.status <> 'on_duty' then raise exception 'NOT_ON_DUTY'; end if;
  if exists (select 1 from trips where shift_id = s.id and status = 'in_progress') then raise exception 'TRIP_RUNNING'; end if;
  update shifts set status = 'off_duty', ended_at = now(), end_reason = 'admin_closed',
         review = 'flagged', review_note = coalesce(nullif(trim(p_note), ''), 'Closed by the office: the driver did not end the shift.'),
         reviewed_by = auth.uid()
   where id = s.id;
  perform notify(s.driver_id, 'Your shift was closed by the office',
                 'The shift from ' || to_char(s.started_at at time zone 'Africa/Blantyre', 'DD Mon HH24:MI')
                 || ' was still open. Please end your shift each day.', 'shift', s.id);
end $$;

-- Reminder: a shift open for more than 16 hours. Once per shift per day.
create or replace function public.send_stale_shift_notices()
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; k text; who uuid;
begin
  for r in
    select s.id, s.driver_id, s.started_at, t.plate, t.owner_id, p.full_name
    from shifts s join trucks t on t.id = s.truck_id join profiles p on p.id = s.driver_id
    where s.status = 'on_duty' and s.started_at < now() - interval '16 hours'
  loop
    k := 'stale:' || r.id || ':' || (now() at time zone 'Africa/Blantyre')::date;
    if exists (select 1 from reminder_log where key = k) then continue; end if;
    insert into reminder_log (key) values (k);
    for who in select r.driver_id union select r.owner_id where r.owner_id is not null loop
      perform notify(who, 'Shift still open · ' || r.plate,
        coalesce(r.full_name, 'Driver') || ' started on ' || to_char(r.started_at at time zone 'Africa/Blantyre', 'DD Mon HH24:MI')
        || ' and has not ended the shift. End it with the mileage photos.', 'shift', r.id);
      n := n + 1;
    end loop;
  end loop;
  return n;
end $$;

do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule('efu-stale-shifts') where exists (select 1 from cron.job where jobname = 'efu-stale-shifts');
  perform cron.schedule('efu-stale-shifts', '15 * * * *', 'select public.send_stale_shift_notices()');
exception when others then
  raise notice 'pg_cron not available: enable it under Database > Extensions, then run this file again. (%)', sqlerrm;
end $$;

revoke execute on function public.send_stale_shift_notices() from public, anon, authenticated;
grant execute on function public.admin_close_shift(uuid, text) to authenticated;
