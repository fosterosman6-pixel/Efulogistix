-- v63: trips with a change of car.
-- Example: Makawa -> DMI. The Monkey Bay car stops at Soko Taxi Rank; a local car runs Mankhwala Depot -> DMI.
-- The passenger books ONCE; the app books both cars (two linked bookings, same day, a connecting time is picked for car 2).
--   cashless: the passenger pays once (same reference on both parts); each driver is credited their own part.
--   cash:     the passenger pays each driver for their own part (the app shows both amounts).
-- Safe to run twice. Run after v60 (Mankhwala - Mangochi Turn Off) and v61/v62.
begin;

-- the local road also passes DMI, Changamile, Mtavu and Mpima (they are on both roads)
do $$
declare b uuid; n int;
begin
  select id into b from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off';
  if b is null then raise exception 'Run v60 (Mankhwala - Mangochi Turn Off) first'; end if;
  select count(*) into n from public.corridor_stops where corridor_id = b;
  if n <= 2 then
    delete from public.corridor_overrides where corridor_id = b;
    delete from public.corridor_stops where corridor_id = b;
    insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
    select b, v.pos, p.name, p.lat, p.lng
      from (values (0, 'Mankhwala Depot'), (1, 'Mpima Depot'), (2, 'Mtavu Depot'), (3, 'Changamile Depot'),
                   (4, 'DMI Depot'), (5, 'Mangochi Turn Off Depot')) as v(pos, name)
      join public.places p on p.name = v.name;
    perform public.corridor_recalc_km(b);
    perform public.corridor_rebuild(b);
  end if;
end $$;

alter table public.bookings add column if not exists parent_id uuid references public.bookings (id) on delete set null;
alter table public.bookings add column if not exists leg int not null default 0;          -- 0 = normal, 1 / 2 = part of a trip with a change
alter table public.bookings add column if not exists transfer_note text;

create table if not exists public.transfer_points (
  id uuid primary key default gen_random_uuid(),
  corridor_a uuid not null references public.route_corridors (id) on delete cascade,   -- the long road
  hub_a text not null,                                                                   -- where its cars stop
  corridor_b uuid not null references public.route_corridors (id) on delete cascade,   -- the local road
  hub_b text not null,                                                                   -- where its cars start
  walk_km numeric not null default 1.5,
  speed_kmh numeric not null default 45,
  unique (corridor_a, corridor_b)
);
alter table public.transfer_points enable row level security;
drop policy if exists transfer_points_read on public.transfer_points;
create policy transfer_points_read on public.transfer_points for select to authenticated using (true);
drop policy if exists transfer_points_admin on public.transfer_points;
create policy transfer_points_admin on public.transfer_points for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.transfer_points (corridor_a, hub_a, corridor_b, hub_b)
select a.id, 'Soko Taxi Rank', b.id, 'Mankhwala Depot'
  from public.route_corridors a, public.route_corridors b
 where a.name = 'Mangochi - Monkey Bay' and b.name = 'Mankhwala - Mangochi Turn Off'
on conflict (corridor_a, corridor_b) do nothing;

-- does this trip need a change? returns null (no) or the plan with both parts and their fares
create or replace function public.plan_transfer(p_corridor uuid, p_from int, p_to int, p_category uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  t transfer_points%rowtype; ha int; hb int; fa corridor_stops%rowtype; ta corridor_stops%rowtype;
  fb int; tb int; k text; qa record; qb record; la jsonb; lb jsonb; na text; nb text;
begin
  select * into t from transfer_points where corridor_a = p_corridor limit 1;
  if t.id is null then return null; end if;
  select pos into ha from corridor_stops where corridor_id = t.corridor_a and place_name = t.hub_a;
  select pos into hb from corridor_stops where corridor_id = t.corridor_b and place_name = t.hub_b;
  select * into fa from corridor_stops where corridor_id = p_corridor and pos = p_from;
  select * into ta from corridor_stops where corridor_id = p_corridor and pos = p_to;
  if ha is null or hb is null or fa.pos is null or ta.pos is null then return null; end if;

  if p_from > ha and p_to < ha then
    select pos into tb from corridor_stops where corridor_id = t.corridor_b and place_name = ta.place_name and pos > hb;
    if tb is null then return null; end if;
    k := 'out';
    select f.km, f.fare into qa from corridor_fares(t.corridor_a, p_category) f where f.from_pos = p_from and f.to_pos = ha;
    select f.km, f.fare into qb from corridor_fares(t.corridor_b, p_category) f where f.from_pos = hb and f.to_pos = tb;
    if qa.fare is null or qb.fare is null then return null; end if;
    la := jsonb_build_object('from_name', fa.place_name, 'to_name', t.hub_a, 'km', qa.km, 'fare', qa.fare);
    lb := jsonb_build_object('from_name', t.hub_b, 'to_name', ta.place_name, 'km', qb.km, 'fare', qb.fare);
    return jsonb_build_object('kind', k, 'hub_a', t.hub_a, 'hub_b', t.hub_b, 'walk_km', t.walk_km,
                              'legs', jsonb_build_array(la, lb), 'total', qa.fare + qb.fare);
  elsif p_to > ha and p_from < ha then
    select pos into fb from corridor_stops where corridor_id = t.corridor_b and place_name = fa.place_name and pos > hb;
    if fb is null then return null; end if;
    k := 'in';
    select f.km, f.fare into qb from corridor_fares(t.corridor_b, p_category) f where f.from_pos = fb and f.to_pos = hb;
    select f.km, f.fare into qa from corridor_fares(t.corridor_a, p_category) f where f.from_pos = ha and f.to_pos = p_to;
    if qa.fare is null or qb.fare is null then return null; end if;
    lb := jsonb_build_object('from_name', fa.place_name, 'to_name', t.hub_b, 'km', qb.km, 'fare', qb.fare);
    la := jsonb_build_object('from_name', t.hub_a, 'to_name', ta.place_name, 'km', qa.km, 'fare', qa.fare);
    return jsonb_build_object('kind', k, 'hub_a', t.hub_a, 'hub_b', t.hub_b, 'walk_km', t.walk_km,
                              'legs', jsonb_build_array(lb, la), 'total', qa.fare + qb.fare);
  end if;
  return null;
end $$;
revoke all on function public.plan_transfer(uuid, int, int, uuid) from public, anon;
grant execute on function public.plan_transfer(uuid, int, int, uuid) to authenticated;

-- km along a road between two positions
create or replace function public._km_between_pos(p_corridor uuid, p1 int, p2 int)
returns numeric language sql stable as $$
  select coalesce(sum(km_from_prev), 0) from corridor_stops
   where corridor_id = p_corridor and pos > least(p1, p2) and pos <= greatest(p1, p2);
$$;

-- book both parts at once. p = the same keys as book_depot (departure_id is the long-road car chosen by the passenger).
create or replace function public.book_transfer(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; t transfer_points%rowtype; plan jsonb; k text;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  ha int; hb int; sp int; a_id uuid; b_id uuid; ba bookings%rowtype; bb bookings%rowtype; one uuid; two uuid;
  pass_a time; need time; c record; dn departures%rowtype; found boolean := false; spb int; walk_min numeric;
  fb int; tb int;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into t from transfer_points where corridor_a = r.corridor_id limit 1;
  plan := public.plan_transfer(r.corridor_id, fp, tp, r.category_id);
  if plan is null then raise exception 'NO_TRANSFER'; end if;
  k := plan ->> 'kind';
  select pos into ha from corridor_stops where corridor_id = t.corridor_a and place_name = t.hub_a;
  select pos into hb from corridor_stops where corridor_id = t.corridor_b and place_name = t.hub_b;
  walk_min := t.walk_km / 5 * 60 + 10;      -- walking at 5 km/h plus 10 minutes to spare

  -- the long-road part first (this also sets the right direction for the chosen time)
  a_id := public.book_depot((p - 'corridor_id') || jsonb_build_object(
            'from_pos', case when k = 'out' then fp else ha end, 'to_pos', case when k = 'out' then ha else tp end));
  select * into ba from bookings where id = a_id;
  select * into d from departures where id = ba.departure_id;
  select * into r from routes where id = d.route_id;
  select min(pos) into sp from corridor_stops where corridor_id = r.corridor_id and place_name = r.from_name;
  pass_a := (d.leaves_at + (public._km_between_pos(r.corridor_id, sp, ha) / t.speed_kmh * 60) * interval '1 minute')::time;

  if k = 'out' then
    -- local car: first one that leaves Mankhwala after the passenger has arrived at Soko and walked
    need := (pass_a + walk_min * interval '1 minute')::time;
    select pos into tb from corridor_stops where corridor_id = t.corridor_b and place_name = plan -> 'legs' -> 1 ->> 'to_name';
    select x.* into dn from departures x join routes r2 on r2.id = x.route_id
     where r2.corridor_id = t.corridor_b and r2.through and r2.active and r2.category_id = r.category_id and x.active
       and (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r2.from_name)
         < (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r2.to_name)
       and x.leaves_at >= need and extract(isodow from ba.travel_on)::int = any (x.days)
     order by x.leaves_at limit 1;
    if dn.id is null then raise exception 'NO_CONNECTION'; end if;
    b_id := public.book_depot((p - 'corridor_id') || jsonb_build_object('departure_id', dn.id, 'from_pos', hb, 'to_pos', tb));
    one := a_id; two := b_id;
  else
    -- local car first: the last one that gets to Mankhwala (and the walk) before the long-road car reaches Soko
    select pos into fb from corridor_stops where corridor_id = t.corridor_b and place_name = plan -> 'legs' -> 0 ->> 'from_name';
    for c in select d3.id as id, d3.leaves_at, r3.from_name from departures d3 join routes r3 on r3.id = d3.route_id
              where r3.corridor_id = t.corridor_b and r3.through and r3.active and r3.category_id = r.category_id and d3.active
                and (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r3.from_name)
                  > (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r3.to_name)
                and extract(isodow from ba.travel_on)::int = any (d3.days)
              order by d3.leaves_at desc loop
      select pos into spb from corridor_stops where corridor_id = t.corridor_b and place_name = c.from_name;
      if (c.leaves_at + (public._km_between_pos(t.corridor_b, spb, hb) / t.speed_kmh * 60 + walk_min) * interval '1 minute')::time <= pass_a
         and c.leaves_at + (public._km_between_pos(t.corridor_b, spb, hb) / t.speed_kmh * 60) * interval '1 minute' >= c.leaves_at then
        select * into dn from departures where id = c.id; found := true; exit;
      end if;
    end loop;
    if not found then raise exception 'NO_CONNECTION'; end if;
    b_id := public.book_depot((p - 'corridor_id') || jsonb_build_object('departure_id', dn.id, 'from_pos', fb, 'to_pos', hb));
    one := b_id; two := a_id;
  end if;

  select * into ba from bookings where id = one;
  select * into bb from bookings where id = two;
  update bookings set leg = 1,
         transfer_note = 'Change of car at ' || ba.dest_name || '. Then ' || bb.pickup_name || ' → ' || bb.dest_name || ' with another driver.'
   where id = one;
  update bookings set leg = 2, parent_id = one,
         transfer_note = 'Change of car: comes from ' || ba.dest_name || ' (booked together with #' || ba.booking_no || ').'
   where id = two;
  return one;
end $$;
revoke all on function public.book_transfer(jsonb) from public, anon;
grant execute on function public.book_transfer(jsonb) to authenticated;

-- cancelling part 1 cancels part 2
create or replace function public.cancel_linked_leg() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'cancelled' and old.status <> 'cancelled' and new.leg = 1 then
    update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = 'The first part of the trip was cancelled'
     where parent_id = new.id and status in ('requested', 'assigned');
  end if;
  return new;
end $$;
drop trigger if exists bookings_cancel_linked on public.bookings;
create trigger bookings_cancel_linked after update of status on public.bookings
  for each row execute function public.cancel_linked_leg();

commit;

select jsonb_pretty(public.plan_transfer(
  (select id from route_corridors where name = 'Mangochi - Monkey Bay'),
  (select pos from corridor_stops where corridor_id = (select id from route_corridors where name = 'Mangochi - Monkey Bay') and place_name = 'Makawa Trading Centre Depot'),
  (select pos from corridor_stops where corridor_id = (select id from route_corridors where name = 'Mangochi - Monkey Bay') and place_name = 'DMI Depot'),
  (select id from vehicle_categories where name = '7 Seater'))) as plan_makawa_to_dmi;
