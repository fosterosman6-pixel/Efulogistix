-- EfuLogistix v12: overdue fees. Owners with unpaid bills get a reminder, the office sees an alert,
-- and no new driver can be matched to their vehicles until the bills are paid (or waived).
-- Safe to run more than once. Run after schema_v11.sql.

alter table public.app_settings add column if not exists fee_grace_days int not null default 14;

alter table public.alerts drop constraint if exists alerts_kind_check;
alter table public.alerts add constraint alerts_kind_check check (kind in (
  'overspeed', 'long_stop', 'mileage', 'cash_short', 'truck_change', 'no_signal', 'service_due', 'paper_expiry',
  'document_expiry', 'unrecorded_stop', 'tracking_off', 'fee_overdue'));

-- number of bills this owner has not paid within the grace days after the period ended
create or replace function public.overdue_fee_count(p_owner uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from fee_bills b
  where b.owner_id = p_owner and b.status = 'due'
    and b.period_end + coalesce((select fee_grace_days from app_settings where id = 1), 14) < (now() at time zone 'Africa/Blantyre')::date;
$$;
grant execute on function public.overdue_fee_count(uuid) to authenticated;

-- same as before, plus: no new driver for an owner who has overdue fees
create or replace function public.match_driver(p_driver uuid, p_truck uuid, p_meet_at timestamptz, p_place text, p_note text)
returns uuid language plpgsql security definer set search_path = public as $$
declare d profiles%rowtype; t trucks%rowtype; mid uuid; when_txt text;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into d from profiles where id = p_driver;
  select * into t from trucks where id = p_truck;
  if d.id is null or d.role <> 'driver' or not d.active then raise exception 'NOT_A_DRIVER'; end if;
  if t.id is null or t.status <> 'approved' then raise exception 'TRUCK_NOT_APPROVED'; end if;
  if t.owner_id is not null and overdue_fee_count(t.owner_id) > 0 then raise exception 'FEES_OVERDUE'; end if;
  if exists (select 1 from driver_matches where driver_id = p_driver and status = 'invited') then
    raise exception 'ALREADY_INVITED';
  end if;
  insert into driver_matches (driver_id, truck_id, meet_at, place, note)
  values (p_driver, p_truck, p_meet_at,
          coalesce(nullif(p_place, ''), (select office_place from app_settings where id = 1)), nullif(p_note, ''))
  returning id into mid;
  when_txt := to_char(p_meet_at at time zone 'Africa/Blantyre', 'Dy DD Mon, HH24:MI');
  perform notify(p_driver, 'Meet the owner of ' || t.plate,
    when_txt || ' at ' || coalesce(nullif(p_place, ''), 'the office') || '. Bring your licence and ID.', 'match', mid);
  perform notify(t.owner_id, 'Meet a driver for ' || t.plate,
    coalesce(d.full_name, d.email) || ' · ' || when_txt || ' at ' || coalesce(nullif(p_place, ''), 'the office') || '.', 'match', mid);
  return mid;
end;
$$;

-- Daily: tell the owner (once a week per bill) and raise one alert per bill for the office.
create or replace function public.send_overdue_fee_notices()
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; k text; wk text := to_char(now() at time zone 'Africa/Blantyre', 'IYYY-IW');
begin
  for r in
    select b.id, b.owner_id, b.truck_id, b.amount, b.period_start, b.period_end, t.plate
    from fee_bills b join trucks t on t.id = b.truck_id
    where b.status = 'due' and b.owner_id is not null
      and b.period_end + coalesce((select fee_grace_days from app_settings where id = 1), 14) < (now() at time zone 'Africa/Blantyre')::date
  loop
    k := 'feeoverdue:' || r.id || ':' || wk;
    if exists (select 1 from reminder_log where key = k) then continue; end if;
    insert into reminder_log (key) values (k);
    perform notify(r.owner_id, 'Fee overdue · ' || r.plate,
      'K' || to_char(r.amount, 'FM999,999,990') || ' for ' || to_char(r.period_start, 'DD Mon') || ' – ' || to_char(r.period_end, 'DD Mon')
      || ' is not paid. Pay it to match new drivers to your vehicles.', 'fee', r.id);
    if not exists (select 1 from alerts where kind = 'fee_overdue' and ref_id = r.id) then
      insert into alerts (kind, truck_id, ref_id, title, detail)
      values ('fee_overdue', r.truck_id, r.id, 'Fee overdue · ' || r.plate,
              'K' || to_char(r.amount, 'FM999,999,990') || ' · ' || to_char(r.period_start, 'DD Mon') || ' – ' || to_char(r.period_end, 'DD Mon'));
    end if;
    n := n + 1;
  end loop;
  -- bills that are now paid or waived: close their alerts
  update alerts a set resolved = true
  where a.kind = 'fee_overdue' and not a.resolved
    and exists (select 1 from fee_bills b where b.id = a.ref_id and b.status <> 'due');
  return n;
end $$;
revoke execute on function public.send_overdue_fee_notices() from public, anon, authenticated;

do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule('efu-fee-overdue') where exists (select 1 from cron.job where jobname = 'efu-fee-overdue');
  perform cron.schedule('efu-fee-overdue', '30 5 * * *', 'select public.send_overdue_fee_notices()');
exception when others then
  raise notice 'pg_cron not available: enable it under Database > Extensions, then run this file again. (%)', sqlerrm;
end $$;
