-- EfuLogistix: database update v6  (run AFTER schema_v5.sql)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice: it only adds.
--
-- v6 adds
--   * waiting list: when a departure is full, a passenger can wait; when a seat opens they are told
--   * referral codes: each person has a code; a new passenger can enter a friend's code once

-- ====================================================================================
-- WAITING LIST
-- ====================================================================================
create table if not exists public.waitlist (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles (id) on delete cascade default auth.uid(),
  departure_id uuid not null references public.departures (id) on delete cascade,
  travel_on date not null,
  seats int not null check (seats between 1 and 20),
  status text not null default 'waiting' check (status in ('waiting', 'told', 'cancelled')),
  created_at timestamptz not null default now(),
  told_at timestamptz
);
create unique index if not exists waitlist_one_active on public.waitlist (passenger_id, departure_id, travel_on) where status = 'waiting';
create index if not exists waitlist_lookup on public.waitlist (departure_id, travel_on, status, created_at);

create or replace function public.join_waitlist(p_departure uuid, p_day date, p_seats int)
returns uuid language plpgsql security definer set search_path = public as $$
declare me profiles%rowtype; free int; wid uuid; d departures%rowtype;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.role <> 'passenger' or not me.active then raise exception 'NOT_ALLOWED'; end if;
  if p_seats is null or p_seats < 1 then raise exception 'SEATS_REQUIRED'; end if;
  select * into d from departures where id = p_departure and active;
  if d.id is null or p_day is null or p_day < current_date then raise exception 'NO_DEPARTURE'; end if;
  select (s.seats - s.booked) into free from public.departure_seats(p_day) s where s.departure_id = p_departure;
  if coalesce(free, 0) >= p_seats then raise exception 'SEATS_AVAILABLE'; end if;   -- just book it
  if exists (select 1 from waitlist where passenger_id = me.id and departure_id = p_departure and travel_on = p_day and status = 'waiting') then
    raise exception 'ALREADY_WAITING';
  end if;
  insert into waitlist (passenger_id, departure_id, travel_on, seats) values (me.id, p_departure, p_day, p_seats) returning id into wid;
  return wid;
end $$;

create or replace function public.leave_waitlist(p_id uuid)
returns void language sql security definer set search_path = public as $$
  update waitlist set status = 'cancelled' where id = p_id and passenger_id = auth.uid() and status = 'waiting';
$$;

-- When a seat booking is cancelled, declined or a no-show, tell the people waiting (first come, first told)
create or replace function public.tell_waitlist() returns trigger
language plpgsql security definer set search_path = public as $$
declare free int; w record; dname text;
begin
  if new.kind <> 'seat' or new.departure_id is null or new.travel_on is null then return new; end if;
  if new.status not in ('cancelled', 'declined', 'no_show') or old.status in ('cancelled', 'declined', 'no_show') then return new; end if;
  select (s.seats - s.booked) into free from public.departure_seats(new.travel_on) s where s.departure_id = new.departure_id;
  select r.from_name || ' to ' || r.to_name into dname from departures d join routes r on r.id = d.route_id where d.id = new.departure_id;
  for w in select * from waitlist where departure_id = new.departure_id and travel_on = new.travel_on and status = 'waiting'
           order by created_at loop
    exit when coalesce(free, 0) <= 0;
    if w.seats <= free then
      update waitlist set status = 'told', told_at = now() where id = w.id;
      perform public.notify(w.passenger_id, 'A seat is free',
        w.seats || ' seat' || case when w.seats = 1 then '' else 's' end || ' now free on ' || coalesce(dname, 'your route')
        || ' (' || to_char(new.travel_on, 'DD Mon') || '). Open Book a seat before someone else does.', 'waitlist', w.id);
      free := free - w.seats;
    end if;
  end loop;
  return new;
end $$;
drop trigger if exists bookings_tell_waitlist on public.bookings;
create trigger bookings_tell_waitlist after update of status on public.bookings
  for each row execute function public.tell_waitlist();

-- ====================================================================================
-- REFERRAL CODES
-- ====================================================================================
alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by uuid references public.profiles (id) on delete set null;
create unique index if not exists profiles_referral_code_idx on public.profiles (referral_code);

create or replace function public.make_referral_code() returns text
language plpgsql volatile as $$
declare c text; i int := 0;
begin
  loop
    c := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));
    exit when not exists (select 1 from public.profiles where referral_code = c);
    i := i + 1; if i > 20 then raise exception 'NO_CODE'; end if;
  end loop;
  return c;
end $$;

-- every person gets a code (new sign-ups and everyone already there)
create or replace function public.give_referral_code() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.referral_code is null then new.referral_code := public.make_referral_code(); end if;
  return new;
end $$;
drop trigger if exists profiles_referral_code on public.profiles;
create trigger profiles_referral_code before insert on public.profiles
  for each row execute function public.give_referral_code();
update public.profiles set referral_code = public.make_referral_code() where referral_code is null;

-- My code and how many people used it
create or replace function public.my_referral()
returns table (code text, people bigint)
language sql stable security definer set search_path = public as $$
  select p.referral_code, (select count(*) from profiles x where x.referred_by = p.id) from profiles p where p.id = auth.uid();
$$;

-- Use a friend's code, once, and not your own
create or replace function public.use_referral(p_code text)
returns void language plpgsql security definer set search_path = public as $$
declare me profiles%rowtype; friend uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'NOT_SIGNED_IN'; end if;
  if me.referred_by is not null then raise exception 'ALREADY_USED'; end if;
  select id into friend from profiles where referral_code = upper(btrim(p_code));
  if friend is null then raise exception 'BAD_CODE'; end if;
  if friend = me.id then raise exception 'OWN_CODE'; end if;
  perform set_config('efu.system', 'on', true);
  update profiles set referred_by = friend where id = me.id;
  perform public.notify(friend, 'Your invite worked', coalesce(nullif(me.full_name, ''), 'Someone') || ' joined with your code.', 'referral', me.id);
end $$;

-- ====================================================================================
-- SECURITY AND ACCESS
-- ====================================================================================
alter table public.waitlist enable row level security;
drop policy if exists waitlist_read on public.waitlist;
create policy waitlist_read on public.waitlist for select to authenticated
  using (passenger_id = auth.uid() or public.is_manager());
revoke insert, update, delete on public.waitlist from authenticated;
grant select on public.waitlist to authenticated;
grant all on public.waitlist to service_role;
grant execute on function public.join_waitlist(uuid, date, int) to authenticated;
grant execute on function public.leave_waitlist(uuid) to authenticated;
grant execute on function public.my_referral() to authenticated;
grant execute on function public.use_referral(text) to authenticated;
revoke execute on function public.tell_waitlist() from public, anon, authenticated;
revoke execute on function public.give_referral_code() from public, anon, authenticated;
revoke execute on function public.make_referral_code() from public, anon, authenticated;
