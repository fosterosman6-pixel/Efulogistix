-- v61: remove the Sienta vehicle type. A Sienta is a 7 Seater, so everything moves to 7 Seater:
-- vehicles, fares, whole-road prices, timetable times and past bookings' vehicle type.
-- Safe to run twice. If 7 Seater already has its own price on a road, that price is kept.
begin;

do $$
declare s uuid; v uuid; c record;
begin
  select id into s from public.vehicle_categories where name = 'Sienta';
  select id into v from public.vehicle_categories where name = '7 Seater';
  if s is null then raise notice 'No Sienta type (already removed)'; return; end if;
  if v is null then raise exception 'There is no 7 Seater vehicle type to move Sienta to'; end if;

  update public.trucks   set category_id = v where category_id = s;
  update public.bookings set category_id = v where category_id = s;

  -- every road keeps a 7 Seater price (the Sienta one, when 7 Seater has none)
  insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
  select corridor_id, v, per_km, min_fare, round_to, full_fare from public.corridor_rates where category_id = s
  on conflict (corridor_id, category_id) do nothing;
  insert into public.corridor_overrides (corridor_id, category_id, from_pos, to_pos, fare)
  select corridor_id, v, from_pos, to_pos, fare from public.corridor_overrides where category_id = s
  on conflict do nothing;

  -- 7 Seater routes must exist before the times can move to them
  for c in select distinct corridor_id from public.corridor_rates where category_id = v loop
    perform public.corridor_rebuild(c.corridor_id);
  end loop;

  -- times: move each Sienta time to the matching 7 Seater route; a time 7 Seater already has is just switched off on Sienta
  update public.departures d set route_id = n.id
    from public.routes o
    join public.routes n on n.corridor_id = o.corridor_id and n.from_name = o.from_name and n.to_name = o.to_name
                        and n.category_id = v and n.active
   where d.route_id = o.id and o.category_id = s and o.corridor_id is not null
     and not exists (select 1 from public.departures x where x.route_id = n.id and x.leaves_at = d.leaves_at);
  update public.departures d set active = false
    from public.routes o where d.route_id = o.id and o.category_id = s;

  delete from public.corridor_overrides where category_id = s;
  delete from public.corridor_rates where category_id = s;
  for c in select id from public.route_corridors loop
    perform public.corridor_rebuild(c.id);   -- the Sienta routes are switched off
  end loop;
  update public.routes set active = false where category_id = s;

  begin
    delete from public.vehicle_categories where id = s;
  exception when foreign_key_violation then
    update public.vehicle_categories set active = false where id = s;   -- still used by old records: hidden instead
  end;
end $$;

commit;

select vc.name as vehicle, count(*) filter (where r.active) as active_routes
  from public.vehicle_categories vc left join public.routes r on r.category_id = vc.id and r.through
 where vc.name in ('Sienta', '7 Seater') group by vc.name;
select r.from_name, r.to_name, count(d.id) filter (where d.active) as times
  from public.routes r left join public.departures d on d.route_id = r.id
 where r.through and r.active and r.category_id = (select id from public.vehicle_categories where name = '7 Seater')
 group by 1, 2 order by 1, 2;
