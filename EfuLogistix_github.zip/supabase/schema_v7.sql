-- EfuLogistix: database update v7 = PUSH NOTIFICATIONS  (run AFTER schema_v6.sql)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice: it only adds.
--
-- How it works
--   * the phone app registers its Firebase token (register_device)
--   * every message in the in-app inbox (notices) also calls the Edge Function "send-push"
--   * the function sends it to that person's phones through Firebase Cloud Messaging
--   * if push is not set up yet (no row in push_config), nothing happens and nothing breaks

create extension if not exists pg_net with schema extensions;

create table if not exists public.device_tokens (
  token text primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  platform text not null default 'android',
  updated_at timestamptz not null default now()
);
create index if not exists device_tokens_user_idx on public.device_tokens (user_id);

-- one row: where the send-push function lives and the shared secret the database sends with each call
create table if not exists public.push_config (
  id int primary key default 1 check (id = 1),
  url text not null,
  secret text not null
);

-- The phone calls this after sign-in (and when Firebase gives it a new token)
create or replace function public.register_device(p_token text, p_platform text default 'android')
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_token is null or length(p_token) < 20 then raise exception 'BAD_TOKEN'; end if;
  insert into device_tokens (token, user_id, platform) values (p_token, auth.uid(), coalesce(p_platform, 'android'))
  on conflict (token) do update set user_id = auth.uid(), platform = excluded.platform, updated_at = now();
end $$;

create or replace function public.unregister_device(p_token text)
returns void language sql security definer set search_path = public as $$
  delete from device_tokens where token = p_token and user_id = auth.uid();
$$;

-- Admin: set up (or change) push once. p_url = https://<project>.supabase.co/functions/v1/send-push
create or replace function public.set_push_config(p_url text, p_secret text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if p_url is null or p_url !~ '^https://' or length(coalesce(p_secret, '')) < 16 then raise exception 'BAD_CONFIG'; end if;
  insert into push_config (id, url, secret) values (1, p_url, p_secret)
  on conflict (id) do update set url = excluded.url, secret = excluded.secret;
end $$;

-- Every new inbox message is also sent as a push. Never blocks or fails the message itself.
create or replace function public.push_new_notice() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare cfg push_config%rowtype;
begin
  select * into cfg from push_config where id = 1;
  if cfg.id is null then return new; end if;
  if not exists (select 1 from device_tokens where user_id = new.user_id) then return new; end if;
  begin
    perform net.http_post(
      url := cfg.url,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', cfg.secret),
      body := jsonb_build_object('user_id', new.user_id, 'title', new.title, 'body', new.body,
                                 'kind', new.kind, 'ref_id', new.ref_id, 'notice_id', new.id)
    );
  exception when others then
    null;   -- push is best effort
  end;
  return new;
end $$;
drop trigger if exists notices_push on public.notices;
create trigger notices_push after insert on public.notices
  for each row execute function public.push_new_notice();

-- ====================================================================================
-- SECURITY AND ACCESS
-- ====================================================================================
alter table public.device_tokens enable row level security;
alter table public.push_config enable row level security;
drop policy if exists device_tokens_own on public.device_tokens;
create policy device_tokens_own on public.device_tokens for select to authenticated using (user_id = auth.uid());
revoke all on public.device_tokens from authenticated;
grant select on public.device_tokens to authenticated;
grant all on public.device_tokens to service_role;
revoke all on public.push_config from authenticated, anon;   -- nobody reads the secret from the apps
grant all on public.push_config to service_role;
grant execute on function public.register_device(text, text) to authenticated;
grant execute on function public.unregister_device(text) to authenticated;
grant execute on function public.set_push_config(text, text) to authenticated;
revoke execute on function public.push_new_notice() from public, anon, authenticated;
