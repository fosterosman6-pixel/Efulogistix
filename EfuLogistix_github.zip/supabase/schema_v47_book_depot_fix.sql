-- v47: book_depot works out the direction from the departure's own route ends, and says exactly what is wrong.
-- Run after v44. Safe to run twice.

create or replace function public.book_depot(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  lo int; hi int; fwd boolean; q record; bid uuid;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  -- direction of this departure: where its own two ends sit on the road (first end before last end = forward)
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  if lo is null or hi is null then raise exception 'BAD_STOPS_ROUTE_ENDS'; end if;
  fwd := lo < hi;
  if fp is null or tp is null then raise exception 'BAD_STOPS_MISSING'; end if;
  if (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from public.corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  bid := public.book(p - 'from_pos' - 'to_pos');
  update bookings
     set pickup_name = fs.place_name, pickup_lat = fs.lat, pickup_lng = fs.lng,
         dest_name = ts.place_name, dest_lat = ts.lat, dest_lng = ts.lng,
         km = q.km, price = case when kind = 'seat' then q.fare * seats else price end
   where id = bid;
  return bid;
end $$;
revoke all on function public.book_depot(jsonb) from public, anon;
grant execute on function public.book_depot(jsonb) to authenticated;
