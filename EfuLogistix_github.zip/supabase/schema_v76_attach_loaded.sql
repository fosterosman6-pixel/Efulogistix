-- v76: passengers and parcels already loaded (scanned on, or walk-ins added) before the driver taps "Loaded" join the trip that starts,
-- and their cash fares go into the trip total, exactly as if they had boarded after the trip started.
-- Safe to run twice.
begin;

create or replace function public.trip_attach_loaded() returns trigger
language plpgsql security definer set search_path = public as $$
declare b record; who text;
begin
  if new.status <> 'in_progress' then return new; end if;
  for b in
    select * from bookings
     where driver_id = new.driver_id and truck_id = new.truck_id and trip_id is null and status = 'picked_up'
       and kind in ('seat', 'goods') and picked_up_at >= now() - interval '12 hours'
     for update
  loop
    update bookings set trip_id = new.id where id = b.id;
    if b.pay_method = 'cash' then
      who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (new.id, 'Booking #' || b.booking_no || ' · ' || who, 0, b.seats,
              case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  end loop;
  return new;
end $$;

drop trigger if exists trip_attach_loaded on public.trips;
create trigger trip_attach_loaded after insert on public.trips
  for each row execute function public.trip_attach_loaded();

commit;
