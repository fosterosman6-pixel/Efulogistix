-- EfuLogistix Fleet: database update v2
-- Run AFTER schema.sql. Safe to run on a database that already has data: it only adds.
-- Supabase > SQL Editor > New query > paste all > Run.
--
-- Roles:  admin   = you (everything: vehicles, drivers, managers, owners, fares, settings, activity log)
--         manager = day to day for all vehicles: shifts, mileage checks, cash hand-ins, expenses, alerts,
--                   assigning drivers to vehicles, approving truck changes, service records
--         owner   = vehicle owner: sees only their own vehicles (trips, money, expenses, service, reports)
--         driver  = drives, records shifts, mileage photos, trips, stops

-- ====================================================================================
-- ROLES
-- ====================================================================================
-- In schema.sql the role 'owner' meant the manager. The first time this update runs, those
-- accounts become 'manager'; 'owner' from now on means a vehicle owner.
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'profiles_role_check' and pg_get_constraintdef(oid) like '%manager%'
  ) then
    alter table public.profiles drop constraint if exists profiles_role_check;
    update public.profiles set role = 'manager' where role = 'owner';
    alter table public.profiles add constraint profiles_role_check
      check (role in ('admin', 'manager', 'owner', 'driver'));
  end if;
end $$;

alter table public.profiles add column if not exists next_of_kin_name text;
alter table public.profiles add column if not exists next_of_kin_phone text;
alter table public.profiles add column if not exists next_of_kin_relation text;
alter table public.profiles add column if not exists language text not null default 'en';

-- vehicles belong to a vehicle owner (one owner can have many vehicles)
alter table public.trucks add column if not exists owner_id uuid references public.profiles (id) on delete set null;
create index if not exists trucks_owner_idx on public.trucks (owner_id);

-- manager level = admin or manager
create or replace function public.is_manager()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role in ('admin', 'manager') and active);
$$;
-- schema.sql's policies call is_owner(): it now means manager level too
create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_manager();
$$;
-- vehicle owner: true when the signed-in person owns that vehicle
create or replace function public.owns_truck(p_truck uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from trucks t join profiles p on p.id = auth.uid()
    where t.id = p_truck and t.owner_id = auth.uid() and p.role = 'owner' and p.active);
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and active);
$$;

create or replace function public.my_name()
returns text language sql stable security definer set search_path = public as $$
  select coalesce(nullif(full_name, ''), email, 'system') from profiles where id = auth.uid();
$$;

-- Admin adds drivers and managers in advance; when they sign up with that email they are linked.
create table if not exists public.invites (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  full_name text,
  phone text,
  role text not null default 'driver' check (role in ('manager', 'owner', 'driver')),
  truck_id uuid references public.trucks (id) on delete set null,
  created_by uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now(),
  used_by uuid references public.profiles (id) on delete set null,
  used_at timestamptz
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare inv invites%rowtype;
begin
  select * into inv from invites where lower(email) = lower(new.email) and used_by is null limit 1;
  insert into profiles (id, email, full_name, phone, role, active, truck_id)
  values (new.id, new.email,
          coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), inv.full_name),
          coalesce(nullif(new.raw_user_meta_data ->> 'phone', ''), inv.phone),
          coalesce(inv.role, 'driver'),
          inv.id is not null,          -- invited people are approved; others wait for the admin
          inv.truck_id);
  if inv.id is not null then
    update invites set used_by = new.id, used_at = now() where id = inv.id;
  end if;
  return new;
end;
$$;

-- who may change what on a profile
create or replace function public.protect_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() then
    return new;                               -- SQL editor or admin: anything
  end if;
  new.role := old.role;                       -- only the admin changes roles
  new.active := old.active;                   -- only the admin approves or blocks
  if not is_owner() then
    new.truck_id := old.truck_id;             -- owner/manager may assign trucks
  end if;
  return new;
end;
$$;

-- ====================================================================================
-- SETTINGS (admin)
-- ====================================================================================
create table if not exists public.app_settings (
  id int primary key default 1 check (id = 1),
  speed_limit_kmh int not null default 80,
  long_stop_min int not null default 30,
  unrecorded_stop_min int not null default 3,
  mileage_tolerance_km int not null default 3,
  no_signal_min int not null default 60,
  require_prdp boolean not null default false,
  updated_at timestamptz not null default now()
);
insert into public.app_settings (id) values (1) on conflict (id) do nothing;

-- ====================================================================================
-- VEHICLE CATEGORIES (admin): matola, minibus, lorry, taxi, kabaza ...
-- ====================================================================================
create table if not exists public.vehicle_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  carries_passengers boolean not null default true,
  carries_goods boolean not null default true,
  seats int not null default 0 check (seats >= 0),          -- passenger seats (0 = goods only)
  licence_classes text[] not null default '{}',              -- licence classes allowed to drive it
  active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.vehicle_categories (name, carries_passengers, carries_goods, seats, licence_classes) values
  ('Matola',  true,  true,  16, '{B,C1,C,EB,EC1,EC,D1,D,ED1,ED}'),
  ('Minibus', true,  false, 15, '{D1,D,ED1,ED}'),
  ('Lorry',   false, true,  0,  '{C1,C,EC1,EC}'),
  ('Taxi',    true,  false, 4,  '{B,EB,C1,C,D1,D}'),
  ('Kabaza',  true,  true,  1,  '{A,A1}')
on conflict (name) do nothing;

-- ====================================================================================
-- TRUCKS: papers and service
-- ====================================================================================
alter table public.trucks add column if not exists category_id uuid references public.vehicle_categories (id);
update public.trucks set category_id = (select id from public.vehicle_categories where name = 'Matola') where category_id is null;
alter table public.trucks add column if not exists seats int;   -- this vehicle's seats, if different from its category
alter table public.trucks add column if not exists current_km int;
alter table public.trucks add column if not exists oil_interval_km int not null default 5000;
alter table public.trucks add column if not exists last_oil_km int;
alter table public.trucks add column if not exists last_oil_on date;
alter table public.trucks add column if not exists insurance_to date;
alter table public.trucks add column if not exists cof_to date;

create table if not exists public.service_records (
  id uuid primary key default gen_random_uuid(),
  truck_id uuid not null references public.trucks (id) on delete cascade,
  kind text not null check (kind in ('oil', 'repair', 'tyre', 'papers', 'other')),
  km int,
  cost numeric(12, 2) not null default 0,
  note text,
  done_on date not null default current_date,
  created_by uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now()
);

create or replace function public.after_service()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'oil' then
    update trucks set last_oil_km = coalesce(new.km, current_km), last_oil_on = new.done_on where id = new.truck_id;
  end if;
  return new;
end;
$$;
drop trigger if exists after_service on public.service_records;
create trigger after_service after insert on public.service_records for each row execute function public.after_service();

-- ====================================================================================
-- DOCUMENTS (drivers and trucks)
-- ====================================================================================
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid references public.profiles (id) on delete cascade,
  truck_id uuid references public.trucks (id) on delete cascade,
  kind text not null check (kind in ('national_id', 'licence', 'prdp', 'selfie', 'police_clearance',
                                     'residence_letter', 'defensive_driving', 'insurance', 'cof', 'blue_book', 'other')),
  front_path text,
  back_path text,
  number text,
  licence_class text,
  expires_on date,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  note text,
  reviewed_by uuid references public.profiles (id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check (driver_id is not null or truck_id is not null)
);
create index if not exists documents_driver_idx on public.documents (driver_id, kind);

-- truck papers set the expiry dates on the truck
create or replace function public.after_document()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.truck_id is not null and new.status = 'approved' then
    if new.kind = 'insurance' then update trucks set insurance_to = new.expires_on where id = new.truck_id; end if;
    if new.kind = 'cof' then update trucks set cof_to = new.expires_on where id = new.truck_id; end if;
  end if;
  return new;
end;
$$;
drop trigger if exists after_document on public.documents;
create trigger after_document after insert or update on public.documents for each row execute function public.after_document();

-- what a driver still needs before going on duty ('' = nothing missing)
create or replace function public.missing_documents(p_driver uuid default auth.uid())
returns text language plpgsql stable security definer set search_path = public as $$
declare
  need text[] := array['national_id', 'licence', 'selfie'];
  k text;
  missing text[] := '{}';
  p profiles%rowtype;
begin
  if (select require_prdp from app_settings where id = 1) then need := need || 'prdp'::text; end if;
  foreach k in array need loop
    if not exists (
      select 1 from documents
      where driver_id = p_driver and kind = k and status = 'approved'
        and (expires_on is null or expires_on >= current_date)
    ) then
      missing := missing || k;
    end if;
  end loop;
  select * into p from profiles where id = p_driver;
  -- the approved licence class must fit the category of the driver's vehicle
  if p.truck_id is not null and not ('licence' = any (missing)) then
    if exists (
      select 1 from trucks t join vehicle_categories c on c.id = t.category_id
      where t.id = p.truck_id and cardinality(c.licence_classes) > 0
        and not exists (
          select 1 from documents d where d.driver_id = p_driver and d.kind = 'licence' and d.status = 'approved'
            and (d.expires_on is null or d.expires_on >= current_date) and d.licence_class = any (c.licence_classes))
    ) then
      missing := missing || 'licence_class'::text;
    end if;
  end if;
  if p.next_of_kin_name is null or p.next_of_kin_phone is null then missing := missing || 'next_of_kin'::text; end if;
  return array_to_string(missing, ',');
end;
$$;

-- ====================================================================================
-- ROUTES AND FARES (admin)
-- ====================================================================================
create table if not exists public.routes (
  id uuid primary key default gen_random_uuid(),
  from_name text not null,
  to_name text not null,
  to_lat double precision,
  to_lng double precision,
  km numeric(8, 1),
  fare numeric(12, 2) not null check (fare >= 0),
  active boolean not null default true,
  updated_by uuid references public.profiles (id) default auth.uid(),
  updated_at timestamptz not null default now()
);
alter table public.routes add column if not exists category_id uuid references public.vehicle_categories (id);
alter table public.routes drop constraint if exists routes_from_name_to_name_key;
create unique index if not exists routes_unique_per_category on public.routes (from_name, to_name, category_id) nulls not distinct;

create table if not exists public.goods_prices (
  id uuid primary key default gen_random_uuid(),
  label text not null unique,
  price numeric(12, 2) not null check (price >= 0),
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

-- raise every fare and goods price by a percentage, rounded up to the next K500
create or replace function public.raise_fares(p_pct numeric)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_pct <= 0 or p_pct > 100 then raise exception 'percentage must be between 1 and 100'; end if;
  update routes set fare = ceil(fare * (1 + p_pct / 100) / 500) * 500, updated_by = auth.uid(), updated_at = now()
    where active;
  update goods_prices set price = ceil(price * (1 + p_pct / 100) / 500) * 500, updated_at = now() where active;
  insert into activity_log (actor, actor_name, action, detail)
    values (auth.uid(), my_name(), 'Raised all fares', jsonb_build_object('percent', p_pct));
end;
$$;

-- ====================================================================================
-- SHIFTS AND MILEAGE READINGS
-- ====================================================================================
create table if not exists public.shifts (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles (id),
  truck_id uuid not null references public.trucks (id),
  status text not null default 'on_duty' check (status in ('on_duty', 'off_duty')),
  started_at timestamptz not null default now(),
  start_km int not null,
  ended_at timestamptz,
  end_km int,
  end_reason text,                       -- 'end_of_day' or 'truck_change'
  truck_photos text[] not null default '{}',
  gps_km numeric(8, 1) not null default 0,
  review text not null default 'open' check (review in ('open', 'approved', 'flagged')),
  review_note text,
  reviewed_by uuid references public.profiles (id),
  created_at timestamptz not null default now()
);
create unique index if not exists shifts_one_open_per_driver on public.shifts (driver_id) where status = 'on_duty';
create unique index if not exists shifts_one_open_per_truck on public.shifts (truck_id) where status = 'on_duty';
create index if not exists shifts_started_idx on public.shifts (started_at desc);

create table if not exists public.odometer_readings (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid references public.shifts (id) on delete cascade,
  trip_id uuid references public.trips (id) on delete set null,
  driver_id uuid not null references public.profiles (id),
  truck_id uuid not null references public.trucks (id),
  kind text not null check (kind in ('shift_start', 'trip_start', 'trip_end', 'shift_end', 'change_out', 'change_in')),
  km int not null check (km >= 0),
  photo_path text,
  lat double precision,
  lng double precision,
  gps_since_last_km numeric(8, 1),
  expected_km int,
  mismatch boolean not null default false,
  taken_at timestamptz not null default now()
);
create index if not exists readings_truck_idx on public.odometer_readings (truck_id, taken_at desc);

alter table public.trips add column if not exists shift_id uuid references public.shifts (id);
alter table public.trips add column if not exists route_id uuid references public.routes (id);
alter table public.trips add column if not exists start_km int;
alter table public.trips add column if not exists end_km int;
alter table public.trips add column if not exists gps_km numeric(8, 1);
alter table public.trips add column if not exists stops_total numeric(12, 2) not null default 0;
alter table public.trips add column if not exists pax_carried int;
alter table public.trips add column if not exists cargo_kg numeric(10, 1);   -- lorries: load weight
alter table public.trips add column if not exists cargo_note text;

-- trip total now includes money collected at stops on the way
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'trips' and column_name = 'total'
      and generation_expression ilike '%stops_total%'
  ) then
    alter table public.trips drop column if exists total;
    alter table public.trips add column total numeric(12, 2)
      generated always as (passengers * fare_per_passenger + goods_total + stops_total) stored;
  end if;
end $$;

-- a trip must belong to the driver's open shift
drop policy if exists trips_insert on public.trips;
create policy trips_insert on public.trips for insert to authenticated
  with check (
    driver_id = auth.uid() and is_active_driver() and truck_id = my_truck()
    and exists (select 1 from shifts s where s.id = shift_id and s.driver_id = auth.uid()
                and s.status = 'on_duty' and s.truck_id = truck_id)
  );

-- internal: save a reading and check it against the last one for that truck
create or replace function public.save_reading(
  p_shift uuid, p_trip uuid, p_driver uuid, p_truck uuid, p_kind text, p_km int,
  p_photo text, p_lat double precision, p_lng double precision, p_gps_since numeric
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  prev odometer_readings%rowtype;
  tol int;
  expected int;
  bad boolean := false;
  rid uuid;
  plate text;
begin
  select mileage_tolerance_km into tol from app_settings where id = 1;
  select * into prev from odometer_readings where truck_id = p_truck order by taken_at desc limit 1;
  if prev.id is not null then
    expected := prev.km + round(coalesce(p_gps_since, 0));
    bad := p_km < prev.km or abs(p_km - expected) > greatest(tol, round(coalesce(p_gps_since, 0) * 0.1));
  end if;
  insert into odometer_readings (shift_id, trip_id, driver_id, truck_id, kind, km, photo_path, lat, lng,
                                 gps_since_last_km, expected_km, mismatch)
  values (p_shift, p_trip, p_driver, p_truck, p_kind, p_km, p_photo, p_lat, p_lng, p_gps_since, expected, bad)
  returning id into rid;
  update trucks set current_km = greatest(coalesce(current_km, 0), p_km) where id = p_truck;
  if bad then
    select t.plate into plate from trucks t where t.id = p_truck;
    insert into alerts (kind, truck_id, driver_id, shift_id, trip_id, ref_id, title, detail)
    values ('mileage', p_truck, p_driver, p_shift, p_trip, rid, 'Mileage check · ' || plate,
            'Typed ' || p_km || ' km, expected about ' || expected || ' km (' || replace(p_kind, '_', ' ') || ')');
  end if;
  return rid;
end;
$$;
revoke execute on function public.save_reading(uuid, uuid, uuid, uuid, text, int, text, double precision, double precision, numeric) from public, anon, authenticated;

-- Driver: go on duty with a mileage photo
create or replace function public.start_shift(p_km int, p_photo text, p_lat double precision, p_lng double precision)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype;
  missing text;
  sid uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.role <> 'driver' or not me.active then raise exception 'not allowed' using errcode = '42501'; end if;
  if me.truck_id is null then raise exception 'NO_TRUCK'; end if;
  missing := missing_documents(me.id);
  if missing <> '' then raise exception 'MISSING_DOCUMENTS:%', missing; end if;
  if p_photo is null then raise exception 'PHOTO_REQUIRED'; end if;
  if exists (select 1 from shifts where truck_id = me.truck_id and status = 'on_duty') then
    raise exception 'TRUCK_IN_USE';
  end if;
  insert into shifts (driver_id, truck_id, start_km) values (me.id, me.truck_id, p_km) returning id into sid;
  perform save_reading(sid, null, me.id, me.truck_id, 'shift_start', p_km, p_photo, p_lat, p_lng, 0);
  return sid;
end;
$$;

-- Driver: mileage at trip start / offload (trip must be theirs)
create or replace function public.record_trip_reading(p_trip uuid, p_kind text, p_km int, p_photo text,
  p_lat double precision, p_lng double precision, p_gps_since numeric)
returns uuid language plpgsql security definer set search_path = public as $$
declare t trips%rowtype; rid uuid;
begin
  select * into t from trips where id = p_trip and driver_id = auth.uid();
  if t.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_kind not in ('trip_start', 'trip_end') then raise exception 'bad kind'; end if;
  if p_photo is null then raise exception 'PHOTO_REQUIRED'; end if;
  rid := save_reading(t.shift_id, t.id, t.driver_id, t.truck_id, p_kind, p_km, p_photo, p_lat, p_lng, p_gps_since);
  if p_kind = 'trip_start' then update trips set start_km = p_km where id = t.id;
  else update trips set end_km = p_km where id = t.id; end if;
  return rid;
end;
$$;

-- Driver: add GPS distance to the open shift
create or replace function public.add_gps_km(p_km numeric)
returns void language sql security definer set search_path = public as $$
  update shifts set gps_km = gps_km + greatest(0, least(p_km, 50))
  where driver_id = auth.uid() and status = 'on_duty';
$$;

-- ====================================================================================
-- STOPS ON THE WAY
-- ====================================================================================
create table if not exists public.trip_stops (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips (id) on delete cascade,
  place_name text,
  lat double precision,
  lng double precision,
  dropped int not null default 0 check (dropped >= 0),
  picked int not null default 0 check (picked >= 0),
  picked_to text,
  fare_each numeric(12, 2) not null default 0 check (fare_each >= 0),
  goods_off text,
  goods_on jsonb not null default '[]'::jsonb,
  goods_total numeric(12, 2) not null default 0 check (goods_total >= 0),
  amount numeric(12, 2) generated always as (picked * fare_each + goods_total) stored,
  km_from_start numeric(8, 1),
  auto boolean not null default false,       -- true = truck stood still but the driver saved no stop
  at timestamptz not null default now()
);
create index if not exists trip_stops_trip_idx on public.trip_stops (trip_id, at);

create or replace function public.after_stop()
returns trigger language plpgsql security definer set search_path = public as $$
declare tid uuid := coalesce(new.trip_id, old.trip_id);
begin
  update trips set
    stops_total = coalesce((select sum(amount) from trip_stops where trip_id = tid), 0),
    pax_carried = passengers + coalesce((select sum(picked) from trip_stops where trip_id = tid), 0)
  where id = tid;
  return null;
end;
$$;
drop trigger if exists after_stop on public.trip_stops;
create trigger after_stop after insert or update or delete on public.trip_stops
  for each row execute function public.after_stop();

-- ====================================================================================
-- TRUCK CHANGES (driver asks, owner/manager approves)
-- ====================================================================================
create table if not exists public.truck_changes (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles (id) default auth.uid(),
  from_truck uuid not null references public.trucks (id),
  to_truck uuid not null references public.trucks (id),
  reason text not null,
  note text,
  out_km int not null,
  out_photo text not null,
  parked_at text,
  out_lat double precision,
  out_lng double precision,
  in_km int not null,
  in_photo text not null,
  in_truck_photos text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending', 'approved', 'declined')),
  decided_by uuid references public.profiles (id),
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  check (from_truck <> to_truck)
);

create or replace function public.after_truck_change_request()
returns trigger language plpgsql security definer set search_path = public as $$
declare a text; b text; who text;
begin
  select plate into a from trucks where id = new.from_truck;
  select plate into b from trucks where id = new.to_truck;
  select coalesce(full_name, email) into who from profiles where id = new.driver_id;
  insert into alerts (kind, truck_id, driver_id, ref_id, title, detail)
  values ('truck_change', new.from_truck, new.driver_id, new.id, 'Truck change · ' || who,
          a || ' (' || new.out_km || ' km, ' || new.reason || coalesce(', left at ' || new.parked_at, '') || ') to '
          || b || ' (' || new.in_km || ' km)');
  return new;
end;
$$;
drop trigger if exists after_truck_change_request on public.truck_changes;
create trigger after_truck_change_request after insert on public.truck_changes
  for each row execute function public.after_truck_change_request();

-- Owner/manager: approve or decline. Approving closes the old shift and opens one on the new truck.
create or replace function public.decide_truck_change(p_id uuid, p_approve boolean)
returns void language plpgsql security definer set search_path = public as $$
declare c truck_changes%rowtype; old_shift shifts%rowtype; sid uuid;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into c from truck_changes where id = p_id for update;
  if c.id is null or c.status <> 'pending' then raise exception 'ALREADY_DECIDED'; end if;
  update truck_changes set status = case when p_approve then 'approved' else 'declined' end,
    decided_by = auth.uid(), decided_at = now() where id = p_id;
  update alerts set resolved = true where kind = 'truck_change' and ref_id = p_id;
  if not p_approve then return; end if;
  if exists (select 1 from shifts where truck_id = c.to_truck and status = 'on_duty') then
    raise exception 'TRUCK_IN_USE';
  end if;
  if exists (select 1 from trips where driver_id = c.driver_id and status = 'in_progress') then
    raise exception 'TRIP_RUNNING';
  end if;
  select * into old_shift from shifts where driver_id = c.driver_id and status = 'on_duty';
  if old_shift.id is not null then
    perform save_reading(old_shift.id, null, c.driver_id, c.from_truck, 'change_out', c.out_km, c.out_photo,
                         c.out_lat, c.out_lng, null);
    update shifts set status = 'off_duty', ended_at = now(), end_km = c.out_km, end_reason = 'truck_change'
      where id = old_shift.id;
  end if;
  update profiles set truck_id = c.to_truck where id = c.driver_id;
  insert into shifts (driver_id, truck_id, start_km, truck_photos)
    values (c.driver_id, c.to_truck, c.in_km, c.in_truck_photos) returning id into sid;
  perform save_reading(sid, null, c.driver_id, c.to_truck, 'change_in', c.in_km, c.in_photo, c.out_lat, c.out_lng, null);
end;
$$;

-- ====================================================================================
-- CASH HAND-INS (driver ends the day, owner/manager receives)
-- ====================================================================================
alter table public.expenses add column if not exists shift_id uuid references public.shifts (id);
alter table public.expenses add column if not exists paid_by text not null default 'driver' check (paid_by in ('driver', 'office'));
alter table public.expenses add column if not exists receipt_path text;

create table if not exists public.hand_ins (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid not null unique references public.shifts (id) on delete cascade,
  driver_id uuid not null references public.profiles (id),
  truck_id uuid not null references public.trucks (id),
  day date not null default current_date,
  trips int not null default 0,
  passengers int not null default 0,
  collected numeric(12, 2) not null default 0,
  driver_expenses numeric(12, 2) not null default 0,
  expected numeric(12, 2) generated always as (collected - driver_expenses) stored,
  method text not null default 'cash' check (method in ('cash', 'airtel_money', 'tnm_mpamba')),
  reference text,
  received numeric(12, 2),
  received_by uuid references public.profiles (id),
  received_at timestamptz,
  note text,
  decision text check (decision in ('accepted_as_expense', 'owed')),
  created_at timestamptz not null default now()
);

-- totals for a shift, worked out by the database (not by the phone)
create or replace function public.shift_totals(p_shift uuid,
  out trips int, out passengers int, out collected numeric, out driver_expenses numeric)
language sql stable security definer set search_path = public as $$
  select
    (select count(*)::int from trips t where t.shift_id = p_shift and t.status = 'completed'),
    (select coalesce(sum(coalesce(t.pax_carried, t.passengers)), 0)::int from trips t where t.shift_id = p_shift and t.status = 'completed'),
    (select coalesce(sum(t.total), 0) from trips t where t.shift_id = p_shift and t.status = 'completed'),
    (select coalesce(sum(e.amount), 0) from expenses e where e.shift_id = p_shift and e.paid_by = 'driver');
$$;

-- Driver: end of day. Photos of the truck, mileage, and how the cash will be handed in.
create or replace function public.end_shift(p_km int, p_photo text, p_truck_photos text[],
  p_lat double precision, p_lng double precision, p_gps_since numeric, p_method text, p_reference text)
returns uuid language plpgsql security definer set search_path = public as $$
declare s shifts%rowtype; tot record; hid uuid;
begin
  select * into s from shifts where driver_id = auth.uid() and status = 'on_duty';
  if s.id is null then raise exception 'NO_SHIFT'; end if;
  if exists (select 1 from trips where driver_id = auth.uid() and status = 'in_progress') then
    raise exception 'TRIP_RUNNING';
  end if;
  if p_photo is null or coalesce(array_length(p_truck_photos, 1), 0) < 4 then raise exception 'PHOTO_REQUIRED'; end if;
  perform save_reading(s.id, null, s.driver_id, s.truck_id, 'shift_end', p_km, p_photo, p_lat, p_lng, p_gps_since);
  update shifts set status = 'off_duty', ended_at = now(), end_km = p_km, end_reason = 'end_of_day',
    truck_photos = p_truck_photos where id = s.id;
  select * into tot from shift_totals(s.id);
  insert into hand_ins (shift_id, driver_id, truck_id, day, trips, passengers, collected, driver_expenses, method, reference)
  values (s.id, s.driver_id, s.truck_id, (s.started_at at time zone 'Africa/Blantyre')::date,
          tot.trips, tot.passengers, tot.collected, tot.driver_expenses,
          coalesce(p_method, 'cash'), nullif(p_reference, ''))
  returning id into hid;
  return hid;
end;
$$;

-- Owner/manager: money received from the driver
create or replace function public.receive_hand_in(p_id uuid, p_amount numeric, p_method text, p_reference text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare h hand_ins%rowtype; who text;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  update hand_ins set received = p_amount, method = coalesce(p_method, method), reference = coalesce(nullif(p_reference, ''), reference),
    note = nullif(p_note, ''), received_by = auth.uid(), received_at = now()
  where id = p_id returning * into h;
  if h.id is null then raise exception 'NOT_FOUND'; end if;
  if h.received < h.expected then
    select coalesce(full_name, email) into who from profiles where id = h.driver_id;
    insert into alerts (kind, truck_id, driver_id, shift_id, ref_id, title, detail)
    values ('cash_short', h.truck_id, h.driver_id, h.shift_id, h.id, 'Cash short · K' || to_char(h.expected - h.received, 'FM999,999,990'),
            who || ' handed in K' || to_char(h.received, 'FM999,999,990') || ' of K' || to_char(h.expected, 'FM999,999,990')
            || coalesce(' · ' || h.note, ''));
  end if;
end;
$$;

-- Owner/manager: what to do with a shortfall
create or replace function public.decide_shortfall(p_id uuid, p_decision text)
returns void language plpgsql security definer set search_path = public as $$
declare h hand_ins%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into h from hand_ins where id = p_id;
  if h.id is null or h.received is null then raise exception 'NOT_FOUND'; end if;
  update hand_ins set decision = p_decision where id = p_id;
  if p_decision = 'accepted_as_expense' and h.expected > h.received then
    insert into expenses (truck_id, created_by, category, amount, note, shift_id, paid_by, spent_at)
    values (h.truck_id, auth.uid(), 'other', h.expected - h.received, 'Shortfall accepted: ' || coalesce(h.note, ''),
            null, 'office', now());
  end if;
  update alerts set resolved = true where kind = 'cash_short' and ref_id = p_id;
end;
$$;

-- ====================================================================================
-- ALERTS
-- ====================================================================================
create table if not exists public.alerts (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('overspeed', 'long_stop', 'mileage', 'cash_short', 'truck_change',
                                     'no_signal', 'service_due', 'paper_expiry', 'document_expiry', 'unrecorded_stop')),
  truck_id uuid references public.trucks (id) on delete cascade,
  driver_id uuid references public.profiles (id) on delete set null,
  shift_id uuid references public.shifts (id) on delete set null,
  trip_id uuid references public.trips (id) on delete set null,
  ref_id uuid,
  title text not null,
  detail text,
  day date not null default current_date,
  seen boolean not null default false,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists alerts_created_idx on public.alerts (created_at desc);
-- one daily alert per thing for the checks below
create unique index if not exists alerts_daily_once on public.alerts (kind, coalesce(ref_id, truck_id), day)
  where kind in ('no_signal', 'service_due', 'paper_expiry', 'document_expiry');

-- Live position checks: overspeed, long stop, stop not saved by the driver
alter table public.truck_locations add column if not exists stopped_since timestamptz;
alter table public.truck_locations add column if not exists stop_logged boolean not null default false;
alter table public.truck_locations add column if not exists long_stop_alerted boolean not null default false;
alter table public.truck_locations add column if not exists last_speed_alert timestamptz;

create or replace function public.check_location()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  st app_settings%rowtype;
  moved_km double precision;
  plate text;
  who text;
  kmh double precision := coalesce(new.speed, 0) * 3.6;
begin
  select * into st from app_settings where id = 1;
  if tg_op = 'UPDATE' then
    moved_km := 2 * 6371 * asin(sqrt(
      power(sin(radians(new.lat - old.lat) / 2), 2) +
      cos(radians(old.lat)) * cos(radians(new.lat)) * power(sin(radians(new.lng - old.lng) / 2), 2)));
    if moved_km < 0.05 then
      new.stopped_since := coalesce(old.stopped_since, now());
      new.stop_logged := old.stop_logged;
      new.long_stop_alerted := old.long_stop_alerted;
    else
      new.stopped_since := null;
      new.stop_logged := false;
      new.long_stop_alerted := false;
    end if;
    new.last_speed_alert := old.last_speed_alert;
  end if;
  if new.trip_id is null then return new; end if;
  select t.plate into plate from trucks t where t.id = new.truck_id;
  select coalesce(p.full_name, p.email) into who from profiles p where p.id = new.driver_id;

  if kmh > st.speed_limit_kmh and (new.last_speed_alert is null or new.last_speed_alert < now() - interval '10 minutes') then
    new.last_speed_alert := now();
    insert into alerts (kind, truck_id, driver_id, trip_id, title, detail)
    values ('overspeed', new.truck_id, new.driver_id, new.trip_id, 'Overspeed · ' || plate,
            who || ' drove ' || round(kmh) || ' km/h (limit ' || st.speed_limit_kmh || ')');
  end if;

  if new.stopped_since is not null then
    -- truck standing still, driver saved no stop in that time: log an unrecorded stop
    if not new.stop_logged and new.stopped_since < now() - make_interval(mins => st.unrecorded_stop_min)
       and not exists (select 1 from trip_stops s where s.trip_id = new.trip_id and s.at >= new.stopped_since - interval '2 minutes') then
      new.stop_logged := true;
      insert into trip_stops (trip_id, lat, lng, auto, at, place_name)
      values (new.trip_id, new.lat, new.lng, true, new.stopped_since, 'Unrecorded stop');
      insert into alerts (kind, truck_id, driver_id, trip_id, title, detail)
      values ('unrecorded_stop', new.truck_id, new.driver_id, new.trip_id, 'Unrecorded stop · ' || plate,
              who || ' stood still for over ' || st.unrecorded_stop_min || ' min without saving a stop');
    end if;
    if not new.long_stop_alerted and new.stopped_since < now() - make_interval(mins => st.long_stop_min) then
      new.long_stop_alerted := true;
      insert into alerts (kind, truck_id, driver_id, trip_id, title, detail)
      values ('long_stop', new.truck_id, new.driver_id, new.trip_id, 'Long stop · ' || plate,
              who || ' has stood still for ' || st.long_stop_min || '+ min with a trip running');
    end if;
  end if;
  return new;
end;
$$;
drop trigger if exists check_location on public.truck_locations;
create trigger check_location before insert or update on public.truck_locations
  for each row execute function public.check_location();

-- Daily checks: no signal, oil change due, papers and licences expiring. The apps call this
-- when the owner or admin opens Alerts, so no scheduler is needed.
create or replace function public.run_checks()
returns void language plpgsql security definer set search_path = public as $$
declare st app_settings%rowtype;
begin
  if not is_owner() then return; end if;
  select * into st from app_settings where id = 1;

  insert into alerts (kind, truck_id, driver_id, ref_id, title, detail)
  select 'no_signal', l.truck_id, l.driver_id, l.truck_id, 'No signal · ' || t.plate,
         'No update for ' || round(extract(epoch from now() - l.updated_at) / 60) || ' min. Trips are saved on the phone and upload later.'
  from truck_locations l join trucks t on t.id = l.truck_id
  join shifts s on s.truck_id = l.truck_id and s.status = 'on_duty'
  where l.updated_at < now() - make_interval(mins => st.no_signal_min)
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'service_due', t.id, t.id, 'Oil change · ' || t.plate,
         case when t.current_km >= t.last_oil_km + t.oil_interval_km
              then (t.current_km - t.last_oil_km - t.oil_interval_km) || ' km overdue'
              else 'Due in ' || (t.last_oil_km + t.oil_interval_km - t.current_km) || ' km' end
  from trucks t
  where t.active and t.current_km is not null and t.last_oil_km is not null
    and t.current_km >= t.last_oil_km + t.oil_interval_km - 500
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'paper_expiry', t.id, t.id, 'Papers · ' || t.plate,
         concat_ws(' · ',
           case when t.insurance_to <= current_date + 14 then 'insurance ends ' || to_char(t.insurance_to, 'DD Mon YYYY') end,
           case when t.cof_to <= current_date + 14 then 'COF ends ' || to_char(t.cof_to, 'DD Mon YYYY') end)
  from trucks t
  where t.active and (t.insurance_to <= current_date + 14 or t.cof_to <= current_date + 14)
  on conflict do nothing;

  insert into alerts (kind, driver_id, ref_id, title, detail)
  select 'document_expiry', d.driver_id, d.id, 'Licence/permit · ' || coalesce(p.full_name, p.email),
         replace(d.kind, '_', ' ') || ' ends ' || to_char(d.expires_on, 'DD Mon YYYY')
  from documents d join profiles p on p.id = d.driver_id
  where d.driver_id is not null and d.status = 'approved' and d.expires_on <= current_date + 30 and p.active
  on conflict do nothing;
end;
$$;

-- ====================================================================================
-- ACTIVITY LOG (admin)
-- ====================================================================================
create table if not exists public.activity_log (
  id bigint generated always as identity primary key,
  at timestamptz not null default now(),
  actor uuid,
  actor_name text,
  action text not null,
  table_name text,
  row_id text,
  detail jsonb
);
create index if not exists activity_log_at_idx on public.activity_log (at desc);

create or replace function public.log_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  changes jsonb := '{}'::jsonb;
  k text;
  o jsonb := case when tg_op <> 'INSERT' then to_jsonb(old) else '{}'::jsonb end;
  n jsonb := case when tg_op <> 'DELETE' then to_jsonb(new) else '{}'::jsonb end;
  skip text[] := array['updated_at', 'created_at', 'stopped_since', 'stop_logged', 'long_stop_alerted', 'last_speed_alert', 'current_km'];
begin
  for k in select jsonb_object_keys(o || n) loop
    if not (k = any (skip)) and (o -> k) is distinct from (n -> k) then
      changes := changes || jsonb_build_object(k, jsonb_build_object('from', o -> k, 'to', n -> k));
    end if;
  end loop;
  if changes = '{}'::jsonb then return null; end if;
  insert into activity_log (actor, actor_name, action, table_name, row_id, detail)
  values (auth.uid(), coalesce(my_name(), 'system'), lower(tg_op), tg_table_name,
          coalesce(n ->> 'id', o ->> 'id'), changes);
  return null;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['vehicle_categories', 'trucks', 'profiles', 'routes', 'goods_prices', 'invites', 'app_settings', 'hand_ins',
                           'truck_changes', 'documents', 'service_records'] loop
    execute format('drop trigger if exists log_change on public.%I', t);
    execute format('create trigger log_change after insert or update or delete on public.%I
                    for each row execute function public.log_change()', t);
  end loop;
end $$;

-- ====================================================================================
-- PHOTO STORAGE (private bucket; each person writes into their own folder)
-- ====================================================================================
insert into storage.buckets (id, name, public) values ('photos', 'photos', false) on conflict (id) do nothing;

drop policy if exists photos_insert_own on storage.objects;
create policy photos_insert_own on storage.objects for insert to authenticated
  with check (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists photos_read on storage.objects;
create policy photos_read on storage.objects for select to authenticated
  using (bucket_id = 'photos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner()));

-- ====================================================================================
-- SECURITY (row level security) for the new tables, and updated rules for the old ones
-- ====================================================================================
alter table public.vehicle_categories enable row level security;
alter table public.invites enable row level security;
alter table public.app_settings enable row level security;
alter table public.service_records enable row level security;
alter table public.documents enable row level security;
alter table public.routes enable row level security;
alter table public.goods_prices enable row level security;
alter table public.shifts enable row level security;
alter table public.odometer_readings enable row level security;
alter table public.trip_stops enable row level security;
alter table public.truck_changes enable row level security;
alter table public.hand_ins enable row level security;
alter table public.alerts enable row level security;
alter table public.activity_log enable row level security;

-- trucks: only the admin adds, edits or removes vehicles (owner/manager reads)
drop policy if exists trucks_owner on public.trucks;
drop policy if exists trucks_admin on public.trucks;
create policy trucks_admin on public.trucks for all to authenticated using (is_admin()) with check (is_admin());

-- vehicle categories: everyone reads, admin changes
drop policy if exists categories_read on public.vehicle_categories;
create policy categories_read on public.vehicle_categories for select to authenticated using (true);
drop policy if exists categories_admin on public.vehicle_categories;
create policy categories_admin on public.vehicle_categories for all to authenticated using (is_admin()) with check (is_admin());

-- invites: admin only
drop policy if exists invites_admin on public.invites;
create policy invites_admin on public.invites for all to authenticated using (is_admin()) with check (is_admin());

-- settings: everyone reads, admin changes
drop policy if exists settings_read on public.app_settings;
create policy settings_read on public.app_settings for select to authenticated using (true);
drop policy if exists settings_admin on public.app_settings;
create policy settings_admin on public.app_settings for update to authenticated using (is_admin()) with check (is_admin());

-- service records: owner/manager and admin
drop policy if exists service_staff on public.service_records;
create policy service_staff on public.service_records for all to authenticated using (is_owner()) with check (is_owner());

-- documents: drivers add and see their own; admin reviews; owner/manager reads
drop policy if exists docs_read on public.documents;
create policy docs_read on public.documents for select to authenticated using (driver_id = auth.uid() or is_owner());
drop policy if exists docs_insert on public.documents;
create policy docs_insert on public.documents for insert to authenticated
  with check ((driver_id = auth.uid() and truck_id is null and status = 'pending') or is_admin());
drop policy if exists docs_admin on public.documents;
create policy docs_admin on public.documents for update to authenticated using (is_admin()) with check (is_admin());
drop policy if exists docs_admin_delete on public.documents;
create policy docs_admin_delete on public.documents for delete to authenticated using (is_admin());

-- routes and goods prices: everyone reads, only the admin changes
drop policy if exists routes_read on public.routes;
create policy routes_read on public.routes for select to authenticated using (true);
drop policy if exists routes_admin on public.routes;
create policy routes_admin on public.routes for all to authenticated using (is_admin()) with check (is_admin());
drop policy if exists goods_read on public.goods_prices;
create policy goods_read on public.goods_prices for select to authenticated using (true);
drop policy if exists goods_admin on public.goods_prices;
create policy goods_admin on public.goods_prices for all to authenticated using (is_admin()) with check (is_admin());

-- shifts: drivers see their own (created through start_shift); owner/manager reviews
drop policy if exists shifts_read on public.shifts;
create policy shifts_read on public.shifts for select to authenticated using (driver_id = auth.uid() or is_owner());
drop policy if exists shifts_review on public.shifts;
create policy shifts_review on public.shifts for update to authenticated using (is_owner()) with check (is_owner());

-- mileage readings: written only by the functions above
drop policy if exists readings_read on public.odometer_readings;
create policy readings_read on public.odometer_readings for select to authenticated using (driver_id = auth.uid() or is_owner());

-- stops: the driver adds stops to their own running trip
drop policy if exists stops_read on public.trip_stops;
create policy stops_read on public.trip_stops for select to authenticated
  using (is_owner() or exists (select 1 from trips t where t.id = trip_id and t.driver_id = auth.uid()));
drop policy if exists stops_insert on public.trip_stops;
create policy stops_insert on public.trip_stops for insert to authenticated
  with check (auto = false and exists (select 1 from trips t where t.id = trip_id and t.driver_id = auth.uid()
                                       and t.status = 'in_progress'));

-- truck changes: the driver asks; decisions go through decide_truck_change
drop policy if exists changes_read on public.truck_changes;
create policy changes_read on public.truck_changes for select to authenticated using (driver_id = auth.uid() or is_owner());
drop policy if exists changes_insert on public.truck_changes;
create policy changes_insert on public.truck_changes for insert to authenticated
  with check (driver_id = auth.uid() and status = 'pending' and from_truck = my_truck());

-- hand-ins: the driver sees their own; owner/manager sees all (changes go through the functions)
drop policy if exists handins_read on public.hand_ins;
create policy handins_read on public.hand_ins for select to authenticated using (driver_id = auth.uid() or is_owner());

-- alerts: owner/manager and admin
drop policy if exists alerts_read on public.alerts;
create policy alerts_read on public.alerts for select to authenticated using (is_owner());
drop policy if exists alerts_update on public.alerts;
create policy alerts_update on public.alerts for update to authenticated using (is_owner()) with check (is_owner());

-- activity log: admin only
drop policy if exists log_read on public.activity_log;
create policy log_read on public.activity_log for select to authenticated using (is_admin());

-- expenses: drivers add for their own shift; office expenses by owner/manager
drop policy if exists exp_insert on public.expenses;
create policy exp_insert on public.expenses for insert to authenticated
  with check (created_by = auth.uid() and (is_owner() or (is_active_driver() and truck_id = my_truck() and paid_by = 'driver')));

-- vehicle owners: read-only access to everything about their own vehicles
drop policy if exists trips_read on public.trips;
create policy trips_read on public.trips for select to authenticated
  using (driver_id = auth.uid() or is_owner() or owns_truck(truck_id));
drop policy if exists loc_read on public.truck_locations;
create policy loc_read on public.truck_locations for select to authenticated
  using (is_owner() or driver_id = auth.uid() or owns_truck(truck_id));
drop policy if exists exp_read on public.expenses;
create policy exp_read on public.expenses for select to authenticated
  using (created_by = auth.uid() or is_owner() or owns_truck(truck_id));
drop policy if exists shifts_read on public.shifts;
create policy shifts_read on public.shifts for select to authenticated
  using (driver_id = auth.uid() or is_owner() or owns_truck(truck_id));
drop policy if exists readings_read on public.odometer_readings;
create policy readings_read on public.odometer_readings for select to authenticated
  using (driver_id = auth.uid() or is_owner() or owns_truck(truck_id));
drop policy if exists stops_read on public.trip_stops;
create policy stops_read on public.trip_stops for select to authenticated
  using (is_owner() or exists (select 1 from trips t where t.id = trip_id and (t.driver_id = auth.uid() or owns_truck(t.truck_id))));
drop policy if exists handins_read on public.hand_ins;
create policy handins_read on public.hand_ins for select to authenticated
  using (driver_id = auth.uid() or is_owner() or owns_truck(truck_id));
drop policy if exists alerts_read on public.alerts;
create policy alerts_read on public.alerts for select to authenticated using (is_owner() or owns_truck(truck_id));
drop policy if exists service_staff on public.service_records;
create policy service_staff on public.service_records for all to authenticated using (is_owner()) with check (is_owner());
drop policy if exists service_owner_read on public.service_records;
create policy service_owner_read on public.service_records for select to authenticated using (owns_truck(truck_id));
drop policy if exists docs_read on public.documents;
create policy docs_read on public.documents for select to authenticated
  using (driver_id = auth.uid() or is_owner() or (truck_id is not null and owns_truck(truck_id)));
drop policy if exists changes_read on public.truck_changes;
create policy changes_read on public.truck_changes for select to authenticated
  using (driver_id = auth.uid() or is_owner() or owns_truck(from_truck) or owns_truck(to_truck));
-- an owner sees the drivers of their vehicles
drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select to authenticated
  using (id = auth.uid() or is_owner()
         or exists (select 1 from trucks t where t.id = truck_id and t.owner_id = auth.uid()));
-- an owner may view the photos of their vehicles (mileage and truck photos)
drop policy if exists photos_read on storage.objects;
create policy photos_read on storage.objects for select to authenticated
  using (bucket_id = 'photos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner()
         or exists (select 1 from public.odometer_readings r where r.photo_path = name and public.owns_truck(r.truck_id))
         or exists (select 1 from public.shifts s where name = any (s.truck_photos) and public.owns_truck(s.truck_id))
         or exists (select 1 from public.truck_changes c where (name = any (c.in_truck_photos) or name in (c.out_photo, c.in_photo))
                      and (public.owns_truck(c.from_truck) or public.owns_truck(c.to_truck)))
         or exists (select 1 from public.expenses e where e.receipt_path = name and public.owns_truck(e.truck_id))));

-- ====================================================================================
-- LIVE UPDATES
-- ====================================================================================
do $$
declare t text;
begin
  foreach t in array array['alerts', 'shifts', 'trip_stops', 'truck_changes', 'hand_ins'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;

-- ====================================================================================
-- DATA API ACCESS (Supabase stops adding this automatically for new tables from 30 Oct 2026)
-- Signed-in users only; the row rules above (RLS) still decide which rows each person sees.
-- Nothing is granted to "anon": the app always signs in first.
-- ====================================================================================
grant usage on schema public to authenticated, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated, service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- ====================================================================================
-- MAKE YOURSELF THE ADMIN (run once with your email after signing up)
-- ====================================================================================
-- update public.profiles set role = 'admin', active = true where email = 'you@example.com';
