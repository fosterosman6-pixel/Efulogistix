-- v67: choose which vehicle types serve a road. Only those types appear in Book a seat for that road.
-- Example: the local road Mankhwala - Mangochi Turn Off is served by 7 Seater only; a Mangochi - Blantyre road by Minibus only.
-- A type you add starts with the price of a type already on the road: set its real price with road_set_whole_fare and add its times with road_add_time.
-- Safe to run twice.
begin;

create or replace function public.road_set_vehicles(p_road text, p_vehicles text[])
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); n text; v uuid; src corridor_rates%rowtype;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if p_vehicles is null or array_length(p_vehicles, 1) is null then raise exception 'Give at least one vehicle type'; end if;
  foreach n in array p_vehicles loop perform _vehicle_id(n); end loop;   -- every name must exist

  select * into src from corridor_rates where corridor_id = c
     and category_id in (select id from vehicle_categories where name = any (p_vehicles)) limit 1;
  if src.corridor_id is null then select * into src from corridor_rates where corridor_id = c limit 1; end if;

  delete from corridor_overrides where corridor_id = c
     and category_id not in (select id from vehicle_categories where name = any (p_vehicles));
  delete from corridor_rates where corridor_id = c
     and category_id not in (select id from vehicle_categories where name = any (p_vehicles));

  foreach n in array p_vehicles loop
    v := _vehicle_id(n);
    if not exists (select 1 from corridor_rates where corridor_id = c and category_id = v) then
      if src.corridor_id is null then raise exception 'This road has no price yet. Run road_set_whole_fare first for "%"', n; end if;
      insert into corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
      values (c, v, src.per_km, src.min_fare, src.round_to, src.full_fare);
    end if;
  end loop;
  perform corridor_rebuild(c);   -- routes of the removed types are switched off, so they disappear from the app
end $$;
revoke all on function public.road_set_vehicles(text, text[]) from public, anon;
grant execute on function public.road_set_vehicles(text, text[]) to authenticated;

-- the local road is served by 7 Seater only
select public.road_set_vehicles('Mankhwala - Mangochi Turn Off', array['7 Seater'])
 where exists (select 1 from route_corridors where name = 'Mankhwala - Mangochi Turn Off');

commit;

-- EXAMPLES:
-- select road_set_vehicles('Mangochi - Monkey Bay', array['7 Seater']);
-- select road_set_vehicles('Mangochi - Blantyre', array['Minibus']);
select c.name as road, vc.name as vehicle from corridor_rates r join route_corridors c on c.id = r.corridor_id
  join vehicle_categories vc on vc.id = r.category_id order by 1, 2;
