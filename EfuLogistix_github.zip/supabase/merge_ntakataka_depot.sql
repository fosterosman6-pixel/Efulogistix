-- Cape Maclear Turn Off Depot and Ntakataka Turn Off Depot are the same place.
-- This leaves ONE depot called "Ntakataka Turn Off Depot" at your pin (-14.170608, 34.943866), keeping its position on
-- Mangochi - Monkey Bay and its fares. Works whether or not add_ntakataka_depot.sql was run. Safe to run twice.
-- "Cape Maclear Junction Depot" is a different depot and is not touched.
do $$
declare c uuid; old_pos int; new_pos int;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is null then raise notice 'Road Mangochi - Monkey Bay not found'; return; end if;

  insert into public.places (name, detail, lat, lng)
  values ('Ntakataka Turn Off Depot', 'Depot · M10 at the Ntakataka turn off', -14.170608, 34.943866)
  on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

  select pos into old_pos from public.corridor_stops where corridor_id = c and place_name = 'Cape Maclear Turn Off Depot';
  select pos into new_pos from public.corridor_stops where corridor_id = c and place_name = 'Ntakataka Turn Off Depot';

  if old_pos is not null and new_pos is not null then
    -- both are on the road: drop the extra one and close the gap
    delete from public.corridor_overrides where corridor_id = c and (from_pos = new_pos or to_pos = new_pos);
    delete from public.corridor_stops where corridor_id = c and pos = new_pos;
    update public.corridor_stops set pos = pos + 1000 where corridor_id = c and pos > new_pos;
    update public.corridor_stops set pos = pos - 1001 where corridor_id = c and pos >= 1000;
    update public.corridor_overrides set from_pos = from_pos + 1000 where corridor_id = c and from_pos > new_pos;
    update public.corridor_overrides set to_pos   = to_pos   + 1000 where corridor_id = c and to_pos   > new_pos;
    update public.corridor_overrides set from_pos = from_pos - 1001 where corridor_id = c and from_pos >= 1000;
    update public.corridor_overrides set to_pos   = to_pos   - 1001 where corridor_id = c and to_pos   >= 1000;
  end if;

  -- the remaining stop takes the Ntakataka name and pin
  update public.corridor_stops set place_name = 'Ntakataka Turn Off Depot', lat = -14.170608, lng = 34.943866
   where corridor_id = c and place_name = 'Cape Maclear Turn Off Depot';
end $$;

-- every other place the old name is written
update public.corridor_stops set place_name = 'Ntakataka Turn Off Depot', lat = -14.170608, lng = 34.943866 where place_name = 'Cape Maclear Turn Off Depot';
update public.routes set from_name = 'Ntakataka Turn Off Depot' where from_name = 'Cape Maclear Turn Off Depot';
update public.routes set to_name = 'Ntakataka Turn Off Depot' where to_name = 'Cape Maclear Turn Off Depot';
update public.transfer_points set hub_a = 'Ntakataka Turn Off Depot' where hub_a = 'Cape Maclear Turn Off Depot';
update public.transfer_points set hub_b = 'Ntakataka Turn Off Depot' where hub_b = 'Cape Maclear Turn Off Depot';
delete from public.places where name = 'Cape Maclear Turn Off Depot';

do $$
declare c uuid;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is not null then
    perform public.corridor_recalc_km(c);
    perform public.corridor_rebuild(c);
  end if;
end $$;

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay') and pos between 20 and 25 order by pos;
