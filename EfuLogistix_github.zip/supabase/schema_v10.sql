-- EfuLogistix: database update v10  (run AFTER schema_v9.sql)
-- START OF SHIFT: the driver must take 4 live photos of the vehicle (front, back, left, right).
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.shifts add column if not exists start_truck_photos text[] not null default '{}';
alter table public.app_settings add column if not exists require_start_photos boolean not null default true;

-- the old 4-argument version goes; the new one takes the photos too
drop function if exists public.start_shift(int, text, double precision, double precision);

create or replace function public.start_shift(p_km int, p_photo text, p_lat double precision, p_lng double precision,
                                              p_truck_photos text[] default '{}')
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype;
  missing text;
  sid uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.role <> 'driver' or not me.active then raise exception 'not allowed' using errcode = '42501'; end if;
  if me.truck_id is null then raise exception 'NO_TRUCK'; end if;
  missing := missing_documents(me.id);
  if missing <> '' then raise exception 'MISSING_DOCUMENTS:%', missing; end if;
  if p_photo is null then raise exception 'PHOTO_REQUIRED'; end if;
  if (select require_start_photos from app_settings where id = 1)
     and coalesce(array_length(p_truck_photos, 1), 0) < 4 then
    raise exception 'PHOTO_REQUIRED';
  end if;
  if exists (select 1 from shifts where truck_id = me.truck_id and status = 'on_duty') then
    raise exception 'TRUCK_IN_USE';
  end if;
  insert into shifts (driver_id, truck_id, start_km, start_truck_photos)
    values (me.id, me.truck_id, p_km, coalesce(p_truck_photos, '{}')) returning id into sid;
  perform save_reading(sid, null, me.id, me.truck_id, 'shift_start', p_km, p_photo, p_lat, p_lng, 0);
  return sid;
end;
$$;
grant execute on function public.start_shift(int, text, double precision, double precision, text[]) to authenticated;

-- the owner and the office can open these photos too
drop policy if exists photos_read on storage.objects;
create policy photos_read on storage.objects for select to authenticated
  using (bucket_id = 'photos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner()
         or exists (select 1 from public.odometer_readings r where r.photo_path = name and public.owns_truck(r.truck_id))
         or exists (select 1 from public.shifts s where (name = any (s.truck_photos) or name = any (s.start_truck_photos))
                      and public.owns_truck(s.truck_id))
         or exists (select 1 from public.truck_changes c where (name = any (c.in_truck_photos) or name in (c.out_photo, c.in_photo))
                      and (public.owns_truck(c.from_truck) or public.owns_truck(c.to_truck)))
         or exists (select 1 from public.expenses e where e.receipt_path = name and public.owns_truck(e.truck_id))
         or exists (select 1 from public.profiles p where p.avatar_path = name and public.sees_person(p.id))
         or exists (select 1 from public.trucks t where name = any (t.photos)
                      and (t.owner_id = auth.uid() or t.id = public.my_truck() or public.rides_in(t.id)))));
