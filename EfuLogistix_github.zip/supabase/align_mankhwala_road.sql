-- Puts every depot on "Mankhwala - Mangochi Turn Off" in order along the road: Mankhwala Depot first, then each depot
-- one after the other (by distance from Mankhwala Depot), ending at Mangochi Turn Off Depot. Special fares keep their depots.
-- Distances and fares are worked out again. If the order is already right nothing changes. Safe to run twice.
do $$
declare c uuid; cur text; want text; ovr record;
begin
  select id into c from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off';
  if c is null then raise notice 'Road Mankhwala - Mangochi Turn Off not found'; return; end if;
  if not exists (select 1 from public.corridor_stops where corridor_id = c and place_name = 'Mankhwala Depot') then
    raise notice 'Mankhwala Depot is not on this road'; return;
  end if;

  create temp table _ord on commit drop as
    select s.place_name, row_number() over (order by
             case when s.place_name = 'Mankhwala Depot' then 0 else 1 end,
             (6371 * 2 * asin(sqrt(power(sin(radians(s.lat - m.lat) / 2), 2) + cos(radians(m.lat)) * cos(radians(s.lat)) * power(sin(radians(s.lng - m.lng) / 2), 2))))) - 1 as np
      from public.corridor_stops s,
           (select lat, lng from public.corridor_stops where corridor_id = c and place_name = 'Mankhwala Depot') m
     where s.corridor_id = c;

  select string_agg(place_name, '|' order by pos) into cur from public.corridor_stops where corridor_id = c;
  select string_agg(place_name, '|' order by np) into want from _ord;
  if cur = want then raise notice 'Depots are already in order'; return; end if;

  -- keep the special fares by depot name while the positions change
  create temp table _ov on commit drop as
    select o.category_id, a.place_name as a_name, b.place_name as b_name, o.fare
      from public.corridor_overrides o
      join public.corridor_stops a on a.corridor_id = o.corridor_id and a.pos = o.from_pos
      join public.corridor_stops b on b.corridor_id = o.corridor_id and b.pos = o.to_pos
     where o.corridor_id = c;
  delete from public.corridor_overrides where corridor_id = c;

  update public.corridor_stops set pos = pos + 1000 where corridor_id = c;
  update public.corridor_stops s set pos = o.np from _ord o where s.corridor_id = c and s.place_name = o.place_name;

  for ovr in select v.category_id, v.fare,
                    least(pa.pos, pb.pos) as p1, greatest(pa.pos, pb.pos) as p2
               from _ov v
               join public.corridor_stops pa on pa.corridor_id = c and pa.place_name = v.a_name
               join public.corridor_stops pb on pb.corridor_id = c and pb.place_name = v.b_name loop
    insert into public.corridor_overrides (corridor_id, category_id, from_pos, to_pos, fare)
    values (c, ovr.category_id, ovr.p1, ovr.p2, ovr.fare);
  end loop;

  perform public.corridor_recalc_km(c);
  perform public.corridor_rebuild(c);
  raise notice 'Depots re-ordered along the road';
end $$;

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off') order by pos;
