-- EfuLogistix: database update v26  (run AFTER schema_v25.sql)
--   A vehicle owner can mark the alerts of their own vehicles as done (before, only the office could).
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.resolve_alert(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare a alerts%rowtype;
begin
  select * into a from alerts where id = p_id;
  if a.id is null then return; end if;
  if not (is_owner() or owns_truck(a.truck_id)) then raise exception 'not allowed' using errcode = '42501'; end if;
  if a.kind = 'truck_change' then raise exception 'REVIEW_FIRST'; end if;   -- a truck change is approved or declined, not just closed
  update alerts set resolved = true, seen = true where id = p_id;
end $$;
revoke all on function public.resolve_alert(uuid) from public, anon;
grant execute on function public.resolve_alert(uuid) to authenticated;
