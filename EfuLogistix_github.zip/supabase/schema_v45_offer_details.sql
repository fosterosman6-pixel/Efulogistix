-- v45 · A hire request shows who is asking: the passenger's name, how many people, and the note.
-- Run in the Supabase SQL editor. Safe to run twice.
drop function if exists public.my_offers();
create or replace function public.my_offers()
returns table (offer_id uuid, booking_no bigint, pickup_name text, dest_name text, pickup_lat double precision, pickup_lng double precision, dest_lat double precision, dest_lng double precision,
               price numeric, km numeric, trip_type text, pickup_at timestamptz, seconds_left int,
               passenger_name text, seats int, note text)
language sql stable security definer set search_path = public as $$
  select o.id, b.booking_no, b.pickup_name, b.dest_name, b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng, b.price, b.km, b.trip_type, b.pickup_at,
         greatest(0, 120 - extract(epoch from now() - o.offered_at)::int),
         coalesce(nullif(btrim(p.full_name), ''), b.caller_name, 'Passenger'), b.seats, b.note
    from booking_offers o
    join bookings b on b.id = o.booking_id
    left join profiles p on p.id = b.passenger_id
   where o.driver_id = auth.uid() and o.status = 'offered' and b.status = 'requested'
   order by o.offered_at;
$$;
revoke all on function public.my_offers() from public, anon;
grant execute on function public.my_offers() to authenticated;
