-- v66: change roads, depots, prices and times with ONE line of SQL each (names, not ids). The app (Dart) never needs changing for this.
-- Safe to run twice. After it, see the examples at the bottom (they are comments: copy one, edit the names, run it).
begin;

create or replace function public._road_id(p_road text) returns uuid language plpgsql stable as $$
declare c uuid;
begin
  select id into c from route_corridors where name = p_road;
  if c is null then raise exception 'No road called "%"', p_road; end if;
  return c;
end $$;

create or replace function public._vehicle_id(p_vehicle text) returns uuid language plpgsql stable as $$
declare v uuid;
begin
  select id into v from vehicle_categories where name = p_vehicle;
  if v is null then raise exception 'No vehicle type called "%"', p_vehicle; end if;
  return v;
end $$;

-- put a depot on a road, right after another depot ('' = at the very start)
create or replace function public.road_add_depot(p_road text, p_place text, p_after text default '')
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); np int; pl places%rowtype;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select * into pl from places where name = p_place;
  if pl.name is null then raise exception 'No place called "%" (add it to places first)', p_place; end if;
  if exists (select 1 from corridor_stops where corridor_id = c and place_name = p_place) then return; end if;
  if coalesce(p_after, '') = '' then np := 0;
  else
    select pos + 1 into np from corridor_stops where corridor_id = c and place_name = p_after;
    if np is null then raise exception 'The road has no depot called "%"', p_after; end if;
  end if;
  update corridor_stops set pos = pos + 1000 where corridor_id = c and pos >= np;
  update corridor_stops set pos = pos - 999  where corridor_id = c and pos >= 1000;
  update corridor_overrides set from_pos = from_pos + case when from_pos >= np then 1 else 0 end,
                                to_pos   = to_pos   + case when to_pos   >= np then 1 else 0 end where corridor_id = c;
  insert into corridor_stops (corridor_id, pos, place_name, lat, lng) values (c, np, pl.name, pl.lat, pl.lng);
  perform corridor_recalc_km(c);
  perform corridor_rebuild(c);
end $$;

-- take a depot off a road (special pair prices that used it are removed)
create or replace function public.road_remove_depot(p_road text, p_place text)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); rp int;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select pos into rp from corridor_stops where corridor_id = c and place_name = p_place;
  if rp is null then return; end if;
  delete from corridor_overrides where corridor_id = c and (from_pos = rp or to_pos = rp);
  delete from corridor_stops where corridor_id = c and pos = rp;
  update corridor_stops set pos = pos + 1000 where corridor_id = c and pos > rp;
  update corridor_stops set pos = pos - 1001 where corridor_id = c and pos >= 1000;
  update corridor_overrides set from_pos = from_pos - case when from_pos > rp then 1 else 0 end,
                                to_pos   = to_pos   - case when to_pos   > rp then 1 else 0 end where corridor_id = c;
  perform corridor_recalc_km(c);
  perform corridor_rebuild(c);
end $$;

-- move a depot to a new place in the list (right after another depot, '' = first)
create or replace function public.road_move_depot(p_road text, p_place text, p_after text default '')
returns void language plpgsql security definer set search_path = public as $$
begin
  perform road_remove_depot(p_road, p_place);
  perform road_add_depot(p_road, p_place, p_after);
end $$;

-- the price of the WHOLE road for one vehicle type; every shorter trip is worked out from it
create or replace function public.road_set_whole_fare(p_road text, p_vehicle text, p_fare numeric)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); v uuid := _vehicle_id(p_vehicle); km numeric;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select coalesce(sum(km_from_prev), 0) into km from corridor_stops where corridor_id = c;
  insert into corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
  values (c, v, case when km > 0 then round(p_fare / km, 2) else 0 end, 1000, 500, p_fare)
  on conflict (corridor_id, category_id) do update
    set full_fare = excluded.full_fare, per_km = excluded.per_km;
  perform corridor_rebuild(c);
end $$;

-- a price typed for one pair of depots (both ways). p_fare = null goes back to the worked-out price
create or replace function public.road_set_pair_fare(p_road text, p_vehicle text, p_from text, p_to text, p_fare numeric)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); v uuid := _vehicle_id(p_vehicle); a int; b int;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select pos into a from corridor_stops where corridor_id = c and place_name = p_from;
  select pos into b from corridor_stops where corridor_id = c and place_name = p_to;
  if a is null or b is null or a = b then raise exception 'Both depots must be on the road and different'; end if;
  delete from corridor_overrides where corridor_id = c and category_id = v and from_pos = least(a, b) and to_pos = greatest(a, b);
  if p_fare is not null then
    insert into corridor_overrides (corridor_id, category_id, from_pos, to_pos, fare) values (c, v, least(a, b), greatest(a, b), p_fare);
  end if;
  perform corridor_rebuild(c);
end $$;

-- a departure time. p_start = the depot the car leaves from (the first or the last depot of the road)
create or replace function public.road_add_time(p_road text, p_vehicle text, p_start text, p_time time)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); v uuid := _vehicle_id(p_vehicle); rid uuid;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select id into rid from routes where corridor_id = c and through and active and category_id = v and from_name = p_start;
  if rid is null then raise exception 'No through route for % leaving from "%"', p_vehicle, p_start; end if;
  insert into departures (route_id, leaves_at, days) values (rid, p_time, '{1,2,3,4,5,6,7}') on conflict (route_id, leaves_at) do update set active = true;
end $$;

create or replace function public.road_remove_time(p_road text, p_vehicle text, p_start text, p_time time)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road); v uuid := _vehicle_id(p_vehicle);
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  update departures d set active = false from routes r
   where d.route_id = r.id and r.corridor_id = c and r.category_id = v and r.from_name = p_start and d.leaves_at = p_time;
end $$;

-- where the cars of the long road stop and the local cars start (a trip across it needs a change of car)
create or replace function public.road_set_change_point(p_long_road text, p_stop_at text, p_local_road text, p_start_at text, p_walk_km numeric default 1.5)
returns void language plpgsql security definer set search_path = public as $$
declare a uuid := _road_id(p_long_road); b uuid := _road_id(p_local_road);
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if not exists (select 1 from corridor_stops where corridor_id = a and place_name = p_stop_at) then raise exception 'The long road has no depot "%"', p_stop_at; end if;
  if not exists (select 1 from corridor_stops where corridor_id = b and place_name = p_start_at) then raise exception 'The local road has no depot "%"', p_start_at; end if;
  insert into transfer_points (corridor_a, hub_a, corridor_b, hub_b, walk_km) values (a, p_stop_at, b, p_start_at, p_walk_km)
  on conflict (corridor_a, corridor_b) do update set hub_a = excluded.hub_a, hub_b = excluded.hub_b, walk_km = excluded.walk_km;
end $$;

do $$ declare f text; begin
  for f in select p.oid::regprocedure::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.proname like 'road\_%' loop
    execute 'revoke all on function ' || f || ' from public, anon';
    execute 'grant execute on function ' || f || ' to authenticated';
  end loop;
end $$;

commit;

-- ---------------------------------------------------------------- EXAMPLES (copy one, change the names, run it)
-- select road_set_whole_fare('Mangochi - Monkey Bay', '7 Seater', 12000);
-- select road_set_pair_fare('Mangochi - Monkey Bay', '7 Seater', 'Soko Taxi Rank', 'Monkey Bay Depot', 10000);   -- null = back to worked-out
-- select road_add_depot('Mangochi - Monkey Bay', 'Forest Taxi Rank', 'Soko Taxi Rank');                          -- after Soko Taxi Rank
-- select road_remove_depot('Mangochi - Monkey Bay', 'Forest Taxi Rank');
-- select road_move_depot('Mangochi - Monkey Bay', 'Forest Taxi Rank', 'Mankhwala Depot');
-- select road_add_time('Mangochi - Monkey Bay', '7 Seater', 'Monkey Bay Depot', '07:00');
-- select road_remove_time('Mangochi - Monkey Bay', '7 Seater', 'Monkey Bay Depot', '07:00');
-- select road_set_change_point('Mangochi - Monkey Bay', 'Soko Taxi Rank', 'Mankhwala - Mangochi Turn Off', 'Mankhwala Depot', 1.5);
