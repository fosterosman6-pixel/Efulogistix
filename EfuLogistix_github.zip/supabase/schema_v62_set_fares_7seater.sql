-- v62: 7 Seater prices.
--  * Soko Taxi Rank <-> Monkey Bay Depot = K10,000 (typed for that pair, both ways)
--  * Mangochi - Monkey Bay whole road (DMI Depot <-> Monkey Bay Depot) = K12,000, so a longer trip never costs less than a shorter one
--  * Mankhwala Depot <-> Mangochi Turn Off Depot = K10,000
-- Change any of these in Admin > Roads & depots. Safe to run twice.
begin;

do $$
declare v uuid; a uuid; b uuid; p6 int; p27 int;
begin
  select id into v from public.vehicle_categories where name = '7 Seater';
  select id into a from public.route_corridors where name = 'Mangochi - Monkey Bay';
  select id into b from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off';
  if v is null then raise exception 'No 7 Seater vehicle type'; end if;

  if a is not null then
    insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
    values (a, v, 129, 1000, 500, 12000)
    on conflict (corridor_id, category_id) do update set full_fare = 12000;
    select pos into p6  from public.corridor_stops where corridor_id = a and place_name = 'Soko Taxi Rank';
    select pos into p27 from public.corridor_stops where corridor_id = a and place_name = 'Monkey Bay Depot';
    if p6 is not null and p27 is not null then
      insert into public.corridor_overrides (corridor_id, category_id, from_pos, to_pos, fare)
      values (a, v, least(p6, p27), greatest(p6, p27), 10000)
      on conflict (corridor_id, category_id, from_pos, to_pos) do update set fare = 10000;
    end if;
    perform public.corridor_recalc_km(a);
    perform public.corridor_rebuild(a);
  end if;

  if b is not null then
    insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
    values (b, v, 129, 1000, 500, 10000)
    on conflict (corridor_id, category_id) do update set full_fare = 10000;
    perform public.corridor_rebuild(b);
  end if;
end $$;

commit;

select c.name as road, f.from_pos, f.to_pos, f.km, f.fare
  from public.route_corridors c
  cross join lateral public.corridor_fares(c.id, (select id from public.vehicle_categories where name = '7 Seater')) f
 where (c.name = 'Mankhwala - Mangochi Turn Off' and f.from_pos = 0 and f.to_pos = 1)
    or (c.name = 'Mangochi - Monkey Bay' and ((f.from_pos = 6 and f.to_pos = 27) or (f.from_pos = 27 and f.to_pos = 6) or (f.from_pos = 0 and f.to_pos = 27)));
