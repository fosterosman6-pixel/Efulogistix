-- schema_v35: security hardening. Run once in the EfuLogistix Supabase project (SQL Editor).
-- 1) Nobody who is not signed in can call the app's database functions (except the public trip-share link).
-- 2) Limits on spam: new bookings and chat messages per person.

-- 1) Close the "anon" door. Remember who may call each function today, then re-grant to exactly those.
do $$
declare f record; keep text[] := '{}';
begin
  for f in
    select p.oid, p.oid::regprocedure as sig, p.proname,
           has_function_privilege('authenticated', p.oid, 'execute') as auth_ok
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f'
       and p.proowner = (select oid from pg_roles where rolname = current_user)
  loop
    if f.proname = 'shared_trip' then continue; end if;   -- the share link works without signing in
    execute format('revoke execute on function %s from public, anon', f.sig);
    if f.auth_ok then execute format('grant execute on function %s to authenticated', f.sig); end if;
  end loop;
end $$;
-- Functions made from now on are closed to anon by default.
alter default privileges in schema public revoke execute on functions from public, anon;

-- 2) Spam limits.
create or replace function public.limit_booking_spam() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.passenger_id = auth.uid() and not public.is_manager() then
    if (select count(*) from bookings where passenger_id = new.passenger_id and created_at > now() - interval '1 hour') >= 15 then
      raise exception 'TOO_MANY_REQUESTS' using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists bookings_spam_limit on public.bookings;
create trigger bookings_spam_limit before insert on public.bookings
  for each row execute function public.limit_booking_spam();

create or replace function public.limit_chat_spam() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.sender_id = auth.uid() then
    if (select count(*) from chat_messages where sender_id = new.sender_id and created_at > now() - interval '1 minute') >= 30 then
      raise exception 'TOO_MANY_REQUESTS' using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists chat_spam_limit on public.chat_messages;
create trigger chat_spam_limit before insert on public.chat_messages
  for each row execute function public.limit_chat_spam();
