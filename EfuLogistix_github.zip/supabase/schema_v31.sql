-- EfuLogistix: database update v31  (run AFTER schema_v18.sql)
--   Passengers who drop a named pin on the map send it to the office as a place suggestion.
--   The admin still approves each one before it joins the Places list everyone sees.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

-- no more than 10 waiting suggestions per person, and not the same name twice
create or replace function public.place_sug_limit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from place_suggestions where suggested_by = new.suggested_by and status = 'pending') >= 10 then
    raise exception 'TOO_MANY_SUGGESTIONS';
  end if;
  if exists (select 1 from place_suggestions where suggested_by = new.suggested_by and status = 'pending'
             and lower(trim(name)) = lower(trim(new.name))) then
    raise exception 'ALREADY_SUGGESTED';
  end if;
  return new;
end $$;
drop trigger if exists place_sug_limit_t on public.place_suggestions;
create trigger place_sug_limit_t before insert on public.place_suggestions
  for each row execute function public.place_sug_limit();

drop policy if exists place_sug_insert on public.place_suggestions;
create policy place_sug_insert on public.place_suggestions for insert to authenticated
  with check (suggested_by = auth.uid() and status = 'pending');
