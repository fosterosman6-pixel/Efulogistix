-- EfuLogistix: database update v29  (run AFTER schema_v28.sql)
--   Marking a service or papers alert "done" now snoozes it for 7 days. Before, the check raised it again the next day.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.run_checks()
returns void language plpgsql security definer set search_path = public as $$
declare st app_settings%rowtype;
begin
  if not is_owner() then return; end if;
  select * into st from app_settings where id = 1;

  insert into alerts (kind, truck_id, driver_id, ref_id, title, detail)
  select 'no_signal', l.truck_id, l.driver_id, l.truck_id, 'No signal · ' || t.plate,
         'No update for ' || round(extract(epoch from now() - l.updated_at) / 60) || ' min. Trips are saved on the phone and upload later.'
  from truck_locations l join trucks t on t.id = l.truck_id
  join shifts s on s.truck_id = l.truck_id and s.status = 'on_duty'
  where l.updated_at < now() - make_interval(mins => st.no_signal_min)
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'service_due', t.id, t.id, 'Oil change · ' || t.plate,
         case when t.current_km >= t.last_oil_km + t.oil_interval_km
              then (t.current_km - t.last_oil_km - t.oil_interval_km) || ' km overdue'
              else 'Due in ' || (t.last_oil_km + t.oil_interval_km - t.current_km) || ' km' end
  from trucks t
  where t.active and t.current_km is not null and t.last_oil_km is not null
    and t.current_km >= t.last_oil_km + t.oil_interval_km - 500
    and not exists (select 1 from alerts a where a.kind = 'service_due' and a.ref_id = t.id
                    and a.resolved and a.created_at > now() - interval '7 days')
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'paper_expiry', t.id, t.id, 'Papers · ' || t.plate,
         concat_ws(' · ',
           case when t.insurance_to <= current_date + 14 then 'insurance ends ' || to_char(t.insurance_to, 'DD Mon YYYY') end,
           case when t.cof_to <= current_date + 14 then 'COF ends ' || to_char(t.cof_to, 'DD Mon YYYY') end)
  from trucks t
  where t.active and (t.insurance_to <= current_date + 14 or t.cof_to <= current_date + 14)
    and not exists (select 1 from alerts a where a.kind = 'paper_expiry' and a.ref_id = t.id
                    and a.resolved and a.created_at > now() - interval '7 days')
  on conflict do nothing;

  insert into alerts (kind, driver_id, ref_id, title, detail)
  select 'document_expiry', d.driver_id, d.id, 'Licence/permit · ' || coalesce(p.full_name, p.email),
         replace(d.kind, '_', ' ') || ' ends ' || to_char(d.expires_on, 'DD Mon YYYY')
  from documents d join profiles p on p.id = d.driver_id
  where d.driver_id is not null and d.status = 'approved' and d.expires_on <= current_date + 30 and p.active
  on conflict do nothing;
end;
$$;
