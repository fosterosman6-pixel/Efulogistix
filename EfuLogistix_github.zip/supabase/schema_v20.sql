-- EfuLogistix: database update v20  (run AFTER schema_v19.sql)
--   Parcel SMS: when the driver marks a parcel loaded, the receiver gets a text with the collection code (via Plivo).
-- Setup: see SMS_SETUP.md. Safe to run twice.

create table if not exists public.sms_config (
  id int primary key check (id = 1),
  url text not null,
  secret text not null
);
alter table public.sms_config enable row level security;
revoke all on public.sms_config from authenticated, anon;
grant all on public.sms_config to service_role;

create table if not exists public.sms_log (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings (id) on delete set null,
  kind text not null,
  to_phone text not null,
  body text not null,
  created_at timestamptz not null default now(),
  unique (booking_id, kind)
);
alter table public.sms_log enable row level security;
drop policy if exists sms_log_read on public.sms_log;
create policy sms_log_read on public.sms_log for select to authenticated using (public.is_manager());
revoke insert, update, delete on public.sms_log from authenticated;
grant select on public.sms_log to authenticated;
grant all on public.sms_log to service_role;

create or replace function public.set_sms_config(p_url text, p_secret text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if p_url is null or p_url !~ '^https://' or length(coalesce(p_secret, '')) < 16 then raise exception 'BAD_CONFIG'; end if;
  insert into sms_config (id, url, secret) values (1, p_url, p_secret)
  on conflict (id) do update set url = excluded.url, secret = excluded.secret;
end $$;
revoke all on function public.set_sms_config(text, text) from public, anon;
grant execute on function public.set_sms_config(text, text) to authenticated;

-- 0888 123 456 / +265 888 123 456 / 265888123456  ->  265888123456  (null if it does not look like a number)
create or replace function public._malawi_number(p text)
returns text language sql immutable as $$
  select case
    when d ~ '^265[0-9]{9}$' then d
    when d ~ '^0[0-9]{9}$' then '265' || substr(d, 2)
    when d ~ '^[0-9]{9}$' then '265' || d
    else null end
  from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) x;
$$;

-- one text; recorded once per booking and kind; never blocks the booking
create or replace function public._send_sms(p_booking uuid, p_kind text, p_to text, p_text text)
returns void language plpgsql security definer set search_path = public, extensions as $$
declare cfg sms_config%rowtype; num text := public._malawi_number(p_to); n int;
begin
  if num is null then return; end if;
  insert into sms_log (booking_id, kind, to_phone, body) values (p_booking, p_kind, num, p_text) on conflict do nothing;
  get diagnostics n = row_count;
  if n = 0 then return; end if;
  select * into cfg from sms_config where id = 1;
  if cfg.id is null then return; end if;
  begin
    perform net.http_post(url := cfg.url,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-sms-secret', cfg.secret),
      body := jsonb_build_object('to', num, 'text', p_text));
  exception when others then null;
  end;
end $$;
revoke all on function public._send_sms(uuid, text, text, text) from public, anon, authenticated;

-- parcel loaded -> receiver gets the code
create or replace function public._sms_parcel_on_way() returns trigger
language plpgsql security definer set search_path = public as $$
declare code text; sender text; plate text;
begin
  if new.kind <> 'goods' or new.status <> 'picked_up' or old.status = 'picked_up' then return new; end if;
  select c.code into code from booking_codes c where c.booking_id = new.id;
  if code is null or new.receiver_phone is null then return new; end if;
  select coalesce(nullif(split_part(full_name, ' ', 1), ''), 'Someone') into sender from profiles where id = new.passenger_id;
  select t.plate into plate from trucks t where t.id = new.truck_id;
  perform public._send_sms(new.id, 'parcel_on_way', new.receiver_phone,
    'EfuLogistix: a parcel from ' || coalesce(sender, new.caller_name, 'someone') || ' is on its way to ' || new.dest_name
    || coalesce(' in ' || plate, '') || '. Give the driver this code when you receive it: ' || code);
  return new;
end $$;
drop trigger if exists bookings_sms_parcel on public.bookings;
create trigger bookings_sms_parcel after update of status on public.bookings
  for each row execute function public._sms_parcel_on_way();
