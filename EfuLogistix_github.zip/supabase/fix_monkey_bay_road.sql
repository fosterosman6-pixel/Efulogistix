-- 1. Mankhwala Depot does not belong to the Mangochi - Monkey Bay road: take it off this road.
--    (It stays on the Mankhwala - Mangochi Turn Off road, and the change-of-car point Soko Taxi Rank / Mankhwala Depot is not touched.)
-- 2. Mangochi Main Rank <-> Monkey Bay Depot costs K10,000 for a 7 Seater in both directions (it was K1,000).
-- Safe to run twice.
do $$
declare c uuid; mp int;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is null then raise notice 'Road Mangochi - Monkey Bay not found'; return; end if;
  select pos into mp from public.corridor_stops where corridor_id = c and place_name = 'Mankhwala Depot';
  if mp is null then raise notice 'Mankhwala Depot is already off this road'; return; end if;

  delete from public.corridor_overrides where corridor_id = c and (from_pos = mp or to_pos = mp);
  delete from public.corridor_stops where corridor_id = c and pos = mp;
  update public.corridor_stops set pos = pos + 1000 where corridor_id = c and pos > mp;
  update public.corridor_stops set pos = pos - 1001 where corridor_id = c and pos >= 1000;
  update public.corridor_overrides set from_pos = case when from_pos > mp then from_pos - 1 else from_pos end,
                                          to_pos   = case when to_pos   > mp then to_pos   - 1 else to_pos   end
   where corridor_id = c;
  perform public.corridor_recalc_km(c);
  perform public.corridor_rebuild(c);
end $$;

select public.road_set_pair_fare('Mangochi - Monkey Bay', '7 Seater', 'Mangochi Main Rank', 'Monkey Bay Depot', 10000);
select public.road_set_pair_fare('Mangochi - Monkey Bay', '7 Seater', 'Monkey Bay Depot', 'Mangochi Main Rank', 10000);

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay') and pos <= 7 order by pos;
