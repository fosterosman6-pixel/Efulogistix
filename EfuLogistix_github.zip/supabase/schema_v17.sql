-- EfuLogistix: database update v17  (run AFTER schema_v16.sql)
--   Places: the admin adds or corrects places (name + coordinates) and every phone uses them. No new build needed.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.places (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(trim(name)) > 0),
  detail text not null default '',
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  created_at timestamptz not null default now()
);

alter table public.places enable row level security;
drop policy if exists places_read on public.places;
create policy places_read on public.places for select to authenticated using (true);
drop policy if exists places_write on public.places;
create policy places_write on public.places for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.places to authenticated;
grant all on public.places to service_role;

-- the two places checked on the map so far
insert into public.places (name, detail, lat, lng) values
  ('Mpondasi', 'Mangochi District', -14.461511, 35.243191),
  ('Mtamila Primary School', 'School · Mangochi District', -14.422321, 35.331800)
on conflict (name) do nothing;
