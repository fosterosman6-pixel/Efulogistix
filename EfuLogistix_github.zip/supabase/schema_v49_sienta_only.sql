-- v49: add the Sienta vehicle type, and make Sienta the only vehicle on Mangochi - Monkey Bay.
-- Run after v48. Safe to run twice. Afterwards open Admin > Roads & depots and type the whole-road fare for Sienta.
-- (It starts with the Taxi rate so there is a fare straight away.)

insert into public.vehicle_categories (name, carries_passengers, carries_goods, seats, licence_classes, hire_per_km, hire_min, fee_weekly, fee_monthly, fee_per_trip)
select 'Sienta', true, c.carries_goods, 7, c.licence_classes, c.hire_per_km, c.hire_min, c.fee_weekly, c.fee_monthly, c.fee_per_trip
  from public.vehicle_categories c where c.name = 'Taxi'
on conflict (name) do nothing;

-- Sienta runs on the road, with the Taxi rate to start with
insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
select t.corridor_id, s.id, t.per_km, t.min_fare, t.round_to, t.full_fare
  from public.corridor_rates t
  join public.vehicle_categories tx on tx.id = t.category_id and tx.name = 'Taxi'
  join public.route_corridors rc on rc.id = t.corridor_id and rc.name = 'Mangochi - Monkey Bay'
  cross join public.vehicle_categories s
 where s.name = 'Sienta'
on conflict (corridor_id, category_id) do nothing;

-- every other vehicle comes off this road
delete from public.corridor_rates r
 using public.route_corridors rc, public.vehicle_categories vc
 where rc.id = r.corridor_id and rc.name = 'Mangochi - Monkey Bay'
   and vc.id = r.category_id and vc.name <> 'Sienta';

-- rebuild the fares: Sienta's two through routes appear, the other vehicles' routes are hidden
select public.corridor_rebuild(id) from public.route_corridors where name = 'Mangochi - Monkey Bay';

-- starter times for Sienta: every 2 hours from 06:00 to 16:00, every day (change them in Admin > Timetable)
insert into departures (route_id, leaves_at, days)
select r.id, t.tm, '{1,2,3,4,5,6,7}'
  from routes r
  join vehicle_categories vc on vc.id = r.category_id and vc.name = 'Sienta'
  cross join (values ('06:00'::time), ('08:00'), ('10:00'), ('12:00'), ('14:00'), ('16:00')) as t(tm)
 where r.through and r.corridor_id is not null and r.active
on conflict (route_id, leaves_at) do nothing;
