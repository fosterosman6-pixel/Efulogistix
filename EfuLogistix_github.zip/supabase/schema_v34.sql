-- schema_v34: an owner who also drives his own vehicle can switch between Owner and Driver mode.
-- One driver per vehicle: a vehicle that already has a driver must be freed by the office first.
-- Run once in the EfuLogistix Supabase project (SQL Editor).
alter table public.profiles add column if not exists drives_own boolean not null default false;

-- Only the office (admin / SQL editor) turns "drives own vehicle" on or off.
create or replace function public.protect_drives_own()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() or coalesce(current_setting('efu.system', true), '') = 'on' then
    return new;
  end if;
  new.drives_own := old.drives_own;
  return new;
end $$;
drop trigger if exists protect_drives_own on public.profiles;
create trigger protect_drives_own before update on public.profiles
  for each row execute function public.protect_drives_own();

-- One driver per vehicle (a driver, or an owner who drives his own vehicle).
create or replace function public.one_driver_per_truck()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.truck_id is not null and (new.role = 'driver' or (new.role = 'owner' and new.drives_own)) then
    if exists (select 1 from profiles p
                where p.truck_id = new.truck_id and p.id <> new.id and p.active
                  and (p.role = 'driver' or (p.role = 'owner' and p.drives_own))) then
      raise exception 'TRUCK_HAS_DRIVER' using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists one_driver_per_truck on public.profiles;
create trigger one_driver_per_truck before insert or update of truck_id, role, drives_own, active on public.profiles
  for each row execute function public.one_driver_per_truck();

-- The switch. The role itself changes, so every driver and owner rule keeps working unchanged.
create or replace function public.switch_mode(p_mode text)
returns text language plpgsql security definer set search_path = public as $$
declare me profiles%rowtype;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_mode not in ('owner', 'driver') then raise exception 'BAD_MODE'; end if;
  select * into me from profiles where id = auth.uid() and active;
  if me.id is null or not me.drives_own or me.role not in ('owner', 'driver') then raise exception 'NOT_ALLOWED'; end if;
  if p_mode = 'driver' then
    if me.truck_id is null or not exists (select 1 from trucks t where t.id = me.truck_id and t.owner_id = me.id) then
      raise exception 'NO_TRUCK';
    end if;
  else
    if exists (select 1 from shifts s where s.driver_id = me.id and s.status = 'on_duty') then
      raise exception 'SHIFT_OPEN';
    end if;
  end if;
  perform set_config('efu.system', 'on', true);
  update profiles set role = p_mode where id = me.id;
  return p_mode;
end $$;
revoke all on function public.switch_mode(text) from public, anon;
grant execute on function public.switch_mode(text) to authenticated;
