-- v80: walk-ins belong to the TRIP, not to a timetable. The driver's route (running trip, or the route chosen on New trip)
-- decides the road and the stretch of road. Walk-ins board and get off only between the chosen depots, in the trip's direction,
-- at the admin's fare, whether or not a timetable departure exists today. Seats left = the car's seats minus everyone already loaded.
-- Safe to run twice.
begin;

-- the seats left for walk-ins: car seats, minus people and parcels already loaded, minus what the running trip already carries
create or replace function public._walkin_seats_left() returns int
language plpgsql stable security definer set search_path = public as $$
declare tk trucks%rowtype; cap int; loaded int; carried int := 0; tr trips%rowtype;
begin
  select t.* into tk from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  if tk.id is null then return 0; end if;
  select coalesce(tk.seats, c.seats, 0) into cap from vehicle_categories c where c.id = tk.category_id;
  cap := coalesce(cap, tk.seats, 0);
  loaded := public.driver_loaded_now();
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress' order by started_at desc limit 1;
  if tr.id is not null then
    select coalesce(sum(case when b.kind = 'seat' then b.seats else _goods_seats(b.goods) end), 0)::int into carried
      from bookings b where b.trip_id = tr.id and b.kind in ('seat', 'goods') and b.status in ('picked_up', 'assigned');
    carried := carried + coalesce(tr.passengers, 0);
  end if;
  return greatest(cap - loaded - carried, 0);
end $$;

-- what the walk-in screen needs: the road, the depots between the chosen start and end, seats left
create or replace function public.driver_walkin_trip(p_from text default null, p_to text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare tr trips%rowtype; tk trucks%rowtype; pick_name text; drop_name text; c record;
        b_id uuid; b_fp int; b_tp int; fp int; tp int; stops jsonb;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.* into tk from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress' order by started_at desc limit 1;
  if tr.id is not null then pick_name := tr.pickup_name; drop_name := tr.dest_name;
  else pick_name := nullif(trim(p_from), ''); drop_name := nullif(trim(p_to), ''); end if;
  if tk.id is null or pick_name is null or drop_name is null then return null; end if;

  for c in select k.id from route_corridors k
            where exists (select 1 from corridor_rates r where r.corridor_id = k.id and r.category_id = tk.category_id) loop
    fp := _stop_pos(c.id, pick_name); tp := _stop_pos(c.id, drop_name);
    if fp is not null and tp is not null and fp <> tp and (b_id is null or abs(tp - fp) < abs(b_tp - b_fp)) then
      b_id := c.id; b_fp := fp; b_tp := tp;
    end if;
  end loop;
  if b_id is null then return null; end if;

  select coalesce(jsonb_agg(jsonb_build_object('pos', s.pos, 'name', s.place_name, 'can_board', s.can_board, 'can_drop', s.can_drop,
                                               'lat', s.lat, 'lng', s.lng)
                           order by case when b_fp < b_tp then s.pos else -s.pos end), '[]'::jsonb)
    into stops from corridor_stops s
   where s.corridor_id = b_id and s.pos between least(b_fp, b_tp) and greatest(b_fp, b_tp);

  return jsonb_build_object('corridor_id', b_id, 'category_id', tk.category_id, 'forward', b_fp < b_tp,
                            'from_pos', b_fp, 'to_pos', b_tp,
                            'from_name', (select place_name from corridor_stops where corridor_id = b_id and pos = b_fp),
                            'to_name', (select place_name from corridor_stops where corridor_id = b_id and pos = b_tp),
                            'seats_left', public._walkin_seats_left(), 'stops', stops);
end $$;

-- depots a walk-in can get off at: after the boarding depot, up to the trip's end, with the admin's fare
create or replace function public.driver_walkin_trip_drops(p_corridor uuid, p_from_pos int, p_trip_from int, p_trip_to int)
returns table (pos int, name text, km numeric, fare numeric, uses int)
language plpgsql stable security definer set search_path = public as $$
declare cat uuid; fwd boolean := p_trip_from < p_trip_to;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.category_id into cat from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  return query
    select s.pos, s.place_name::text, f.km, f.fare,
           coalesce((select count(*)::int from bookings b where b.caller_name = 'Walk-in' and b.dest_name = s.place_name
                       and b.created_at > now() - interval '60 days'), 0)
      from corridor_stops s
      join corridor_fares(p_corridor, cat) f on f.from_pos = p_from_pos and f.to_pos = s.pos
     where s.corridor_id = p_corridor and s.can_drop
       and s.pos between least(p_trip_from, p_trip_to) and greatest(p_trip_from, p_trip_to)
       and ((fwd and s.pos > p_from_pos) or (not fwd and s.pos < p_from_pos))
     order by 5 desc, 3;
end $$;

-- keep the timetable walk-in under its own name, then one entry point for both kinds
do $$
begin
  if not exists (select 1 from pg_proc where proname = '_add_walkin_departure') then
    alter function public.driver_add_walkin(jsonb) rename to _add_walkin_departure;
  end if;
end $$;

create or replace function public.driver_add_walkin(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype; tk trucks%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype; tr trips%rowtype;
  c uuid := nullif(p ->> 'corridor_id', '')::uuid;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  tf int := (p ->> 'trip_from_pos')::int; tt int := (p ->> 'trip_to_pos')::int;
  n int := coalesce((p ->> 'seats')::int, 1); day date := coalesce(nullif(p ->> 'travel_on', '')::date, current_date);
  pay text := coalesce(nullif(p ->> 'pay_method', ''), 'cash'); ref text := nullif(trim(p ->> 'pay_reference'), '');
  q record; left_ int; bid uuid; bno bigint;
begin
  if c is null then return public._add_walkin_departure(p); end if;
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into me from profiles where id = auth.uid();
  select * into tk from trucks where id = me.truck_id;
  if tk.id is null then raise exception 'NO_VEHICLE'; end if;
  if pay not in ('cash', 'airtel_money', 'tnm_mpamba') then raise exception 'BAD_PAY'; end if;
  if pay <> 'cash' and ref is null then raise exception 'REFERENCE_REQUIRED'; end if;
  if n < 1 or n > 20 then raise exception 'SEATS_REQUIRED'; end if;
  if not exists (select 1 from corridor_rates where corridor_id = c and category_id = tk.category_id) then raise exception 'NOT_YOUR_VEHICLE_TYPE'; end if;

  -- on the trip's stretch of road, in the trip's direction
  if fp is null or tp is null or tf is null or tt is null
     or fp not between least(tf, tt) and greatest(tf, tt) or tp not between least(tf, tt) and greatest(tf, tt)
     or (tf < tt and not fp < tp) or (tf > tt and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  select * into fs from corridor_stops where corridor_id = c and pos = fp;
  select * into ts from corridor_stops where corridor_id = c and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from corridor_fares(c, tk.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  left_ := public._walkin_seats_left();
  if n > left_ then raise exception 'FULL:%', left_; end if;

  select * into r from routes where corridor_id = c and category_id = tk.category_id and through order by active desc limit 1;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress' order by started_at desc limit 1;

  insert into bookings (kind, passenger_id, caller_name, caller_phone, pay_method, pay_reference, status, driver_id, truck_id,
                        departure_id, route_id, category_id, travel_on, pickup_at, picked_up_at, assigned_at, trip_id, seats,
                        pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, km, price, leg, note)
  values ('seat', null, 'Walk-in', nullif(trim(p ->> 'phone'), ''), pay, ref, 'picked_up', auth.uid(), tk.id,
          null, r.id, tk.category_id, day, now(), now(), now(), tr.id, n,
          fs.place_name, fs.lat, fs.lng, ts.place_name, ts.lat, ts.lng, q.km, q.fare * n, 0, 'Walk-in added by the driver')
  returning id, booking_no into bid, bno;

  if tr.id is not null and pay = 'cash' then
    insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
    values (tr.id, 'Booking #' || bno || ' · Walk-in', 0, n, q.fare, '[]'::jsonb, 0);
  end if;
  return bid;
end $$;

revoke all on function public._walkin_seats_left(), public.driver_walkin_trip(text, text), public.driver_walkin_trip_drops(uuid, int, int, int),
                       public.driver_add_walkin(jsonb), public._add_walkin_departure(jsonb) from public, anon;
grant execute on function public.driver_walkin_trip(text, text), public.driver_walkin_trip_drops(uuid, int, int, int),
                          public.driver_add_walkin(jsonb) to authenticated;
commit;
