-- Mankhwala Depot becomes a depot on Mangochi - Monkey Bay, at the Mangochi end (before Mangochi Main Rank).
-- Safe to run twice. Other depots and special fares are moved down by one so nothing is lost.
insert into public.places (name, detail, lat, lng)
values ('Mankhwala Depot', 'Depot · M3, Mangochi', -14.487806, 35.255358)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

do $$
declare c uuid;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is null then raise notice 'Corridor Mangochi - Monkey Bay not found'; return; end if;
  if exists (select 1 from public.corridor_stops where corridor_id = c and place_name = 'Mankhwala Depot') then
    raise notice 'Mankhwala Depot is already a depot'; return;
  end if;

  update public.corridor_stops set pos = pos + 1000 where corridor_id = c;
  update public.corridor_stops set pos = pos - 999   where corridor_id = c;

  update public.corridor_overrides set from_pos = from_pos + 1000, to_pos = to_pos + 1000 where corridor_id = c;
  update public.corridor_overrides set from_pos = from_pos - 999,  to_pos = to_pos - 999  where corridor_id = c;

  insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
  values (c, 0, 'Mankhwala Depot', -14.487806, 35.255358);

  perform public.corridor_recalc_km(c);
  perform public.corridor_rebuild(c);
end $$;

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay') and pos <= 3 order by pos;
