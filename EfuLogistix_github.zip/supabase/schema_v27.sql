-- EfuLogistix: database update v27  (run AFTER schema_v26.sql)
--   In-app chat (text, photos and voice notes):
--     * passenger <-> driver, for a booking while the car is assigned, on the way, and 6 hours after it is done
--     * vehicle owner <-> driver of that owner's vehicle
--   Messages are only for the two people (and the admin, for disputes). Phone numbers stay private.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings (id) on delete cascade,
  owner_id uuid references public.profiles (id) on delete cascade,
  driver_id uuid references public.profiles (id) on delete cascade,
  sender_id uuid not null references public.profiles (id) on delete cascade,
  recipient_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null default 'text' check (kind in ('text', 'photo', 'voice')),
  body text not null default '' check (length(body) <= 1000),
  file_path text,
  seconds int,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check ((kind = 'text' and length(btrim(body)) >= 1) or (kind <> 'text' and file_path is not null)),
  check ((booking_id is not null) <> (owner_id is not null and driver_id is not null))
);
create index if not exists chat_booking_idx on public.chat_messages (booking_id, created_at);
create index if not exists chat_fleet_idx on public.chat_messages (owner_id, driver_id, created_at);
create index if not exists chat_recipient_idx on public.chat_messages (recipient_id, read_at);

alter table public.chat_messages enable row level security;
drop policy if exists chat_read on public.chat_messages;
create policy chat_read on public.chat_messages for select to authenticated
  using (sender_id = auth.uid() or recipient_id = auth.uid() or is_admin());
revoke insert, update, delete on public.chat_messages from authenticated, anon;
grant select on public.chat_messages to authenticated;

-- Send a message. For a booking pass p_booking; for owner <-> driver pass the other person in p_peer.
drop function if exists public.send_chat(uuid, uuid, text);
create or replace function public.send_chat(p_booking uuid, p_peer uuid, p_body text,
  p_kind text default 'text', p_path text default null, p_seconds int default null)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); b bookings%rowtype; body text := btrim(coalesce(p_body, ''));
        rcpt uuid; own uuid; drv uuid; myrole text; peerrole text; who text;
begin
  if me is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_kind not in ('text', 'photo', 'voice') then raise exception 'BAD_MESSAGE'; end if;
  if p_kind = 'text' and (length(body) < 1 or length(body) > 1000) then raise exception 'BAD_MESSAGE'; end if;
  if p_kind <> 'text' and (p_path is null or split_part(p_path, '/', 1) <> me::text) then raise exception 'BAD_MESSAGE'; end if;
  if (select count(*) from chat_messages where sender_id = me and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'SLOW_DOWN';
  end if;
  who := coalesce((select full_name from profiles where id = me), 'Someone');
  if p_booking is not null then
    select * into b from bookings where id = p_booking;
    if b.id is null or me not in (coalesce(b.passenger_id, me), coalesce(b.driver_id, me)) then raise exception 'not allowed' using errcode = '42501'; end if;
    if me <> coalesce(b.passenger_id, '00000000-0000-0000-0000-000000000000') and me <> coalesce(b.driver_id, '00000000-0000-0000-0000-000000000000') then
      raise exception 'not allowed' using errcode = '42501';
    end if;
    if not (b.status in ('assigned', 'picked_up') or (b.status = 'completed' and b.completed_at > now() - interval '6 hours')) then
      raise exception 'CHAT_CLOSED';
    end if;
    rcpt := case when me = b.passenger_id then b.driver_id else b.passenger_id end;
    if rcpt is null then raise exception 'NO_PARTY'; end if;
    insert into chat_messages (booking_id, sender_id, recipient_id, kind, body, file_path, seconds) values (b.id, me, rcpt, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(rcpt, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', b.id);
  else
    select role into myrole from profiles where id = me;
    select role into peerrole from profiles where id = p_peer;
    if myrole = 'owner' and peerrole = 'driver'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = p_peer and t.owner_id = me) then
      own := me; drv := p_peer;
    elsif myrole = 'driver' and peerrole = 'owner'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = me and t.owner_id = p_peer) then
      own := p_peer; drv := me;
    else
      raise exception 'not allowed' using errcode = '42501';
    end if;
    insert into chat_messages (owner_id, driver_id, sender_id, recipient_id, kind, body, file_path, seconds) values (own, drv, me, p_peer, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(p_peer, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', null);
  end if;
end $$;
revoke all on function public.send_chat(uuid, uuid, text, text, text, int) from public, anon;
grant execute on function public.send_chat(uuid, uuid, text, text, text, int) to authenticated;

-- Mark what I have read in this conversation.
create or replace function public.read_chat(p_booking uuid, p_peer uuid)
returns void language sql security definer set search_path = public as $$
  update chat_messages set read_at = now()
   where recipient_id = auth.uid() and read_at is null
     and ((p_booking is not null and booking_id = p_booking)
       or (p_booking is null and booking_id is null and sender_id = p_peer));
$$;
revoke all on function public.read_chat(uuid, uuid) from public, anon;
grant execute on function public.read_chat(uuid, uuid) to authenticated;

-- Private storage for chat pictures and voice notes: only the two people (and the admin) can open a file.
do $$ begin
  insert into storage.buckets (id, name, public) values ('chat', 'chat', false) on conflict (id) do nothing;
  begin update storage.buckets set file_size_limit = 10485760 where id = 'chat'; exception when others then null; end;
end $$;
drop policy if exists chat_files_insert on storage.objects;
create policy chat_files_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'chat' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists chat_files_read on storage.objects;
create policy chat_files_read on storage.objects for select to authenticated
  using (bucket_id = 'chat' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()
         or exists (select 1 from public.chat_messages m where m.file_path = name and m.recipient_id = auth.uid())));

-- live messages
do $$ begin
  begin alter publication supabase_realtime add table public.chat_messages;
  exception when duplicate_object then null; when undefined_object then null; end;
end $$;
