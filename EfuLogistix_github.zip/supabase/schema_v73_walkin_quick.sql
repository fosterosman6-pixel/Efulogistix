-- v73: faster walk-ins. Prices for every drop-off in one call (most used first), a two-minute undo, and the mobile money numbers shown to the passenger.
-- Safe to run twice.
begin;

-- the numbers the passenger pays to (set once with: update app_settings set airtel_number = '...', mpamba_number = '...')
alter table public.app_settings add column if not exists airtel_number text not null default '';
alter table public.app_settings add column if not exists mpamba_number text not null default '';

-- every depot a walk-in can get off at from p_from_pos, with the price for one seat, and how often this road's walk-ins used it lately
create or replace function public.driver_walkin_drops(p_departure uuid, p_from_pos int)
returns table (pos int, name text, km numeric, fare numeric, uses int)
language plpgsql stable security definer set search_path = public as $$
declare d departures%rowtype; r routes%rowtype; lo int; hi int; fwd boolean;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into d from departures where id = p_departure and active;
  select * into r from routes where id = d.route_id and active and corridor_id is not null;
  if r.id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(s.pos) filter (where s.place_name = r.from_name), min(s.pos) filter (where s.place_name = r.to_name)
    into lo, hi from corridor_stops s where s.corridor_id = r.corridor_id;
  fwd := lo < hi;
  return query
    select s.pos, s.place_name, f.km, f.fare,
           coalesce((select count(*)::int from bookings b where b.route_id = r.id and b.caller_name = 'Walk-in'
                       and b.dest_name = s.place_name and b.created_at > now() - interval '60 days'), 0)
      from corridor_stops s
      join corridor_fares(r.corridor_id, r.category_id) f on f.from_pos = p_from_pos and f.to_pos = s.pos
     where s.corridor_id = r.corridor_id and s.can_drop and ((fwd and s.pos > p_from_pos) or (not fwd and s.pos < p_from_pos))
     order by 5 desc, 3;
end $$;

-- take back a walk-in the driver added in the last two minutes (wrong depot, changed their mind)
create or replace function public.driver_undo_walkin(p_booking uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into b from bookings where id = p_booking and driver_id = auth.uid() and caller_name = 'Walk-in' for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if b.status <> 'picked_up' or b.created_at < now() - interval '2 minutes 30 seconds' then raise exception 'TOO_LATE_TO_UNDO'; end if;
  update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = 'Removed by the driver' where id = b.id;
  delete from trip_stops where trip_id = b.trip_id and place_name = 'Booking #' || b.booking_no || ' · Walk-in';
end $$;

revoke all on function public.driver_walkin_drops(uuid, int), public.driver_undo_walkin(uuid) from public, anon;
grant execute on function public.driver_walkin_drops(uuid, int), public.driver_undo_walkin(uuid) to authenticated;

-- walk-in add now returns where it boarded so the app can refresh (unchanged otherwise)
commit;
