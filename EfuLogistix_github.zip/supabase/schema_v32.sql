-- schema_v32: the admin chooses which pages each manager can open.
-- Run once in the EfuLogistix Supabase project (SQL Editor).
alter table public.profiles add column if not exists permissions text[] not null default array['Bookings','Support','Drivers & matching','Shifts & trips','Cash hand-ins','Route history','Driver wallets','EfuLogistix fees','Service','Reports'];

-- Existing managers keep what they have today.
update public.profiles set permissions = array['Bookings','Support','Drivers & matching','Shifts & trips','Cash hand-ins','Route history','Driver wallets','EfuLogistix fees','Service','Reports'] where role = 'manager';

-- Only an admin may change permissions (a manager cannot tick their own boxes).
create or replace function public.protect_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() or coalesce(current_setting('efu.system', true), '') = 'on' then
    return new;
  end if;
  new.role := old.role;
  new.active := old.active;
  new.permissions := old.permissions;
  new.account_id := old.account_id;
  new.no_shows := old.no_shows;
  if not is_owner() then
    new.truck_id := old.truck_id;
  end if;
  return new;
end;
$$;
