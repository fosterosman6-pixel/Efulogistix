-- v46: a driver is told about a new hire request (inbox + push), and the Mangochi - Monkey Bay road gets starter departure times.
-- Safe to run twice. Run after v44.

-- 1) New hire request -> notice for the driver. The push trigger on notices (v37) sends the phone alert.
create or replace function public.notify_new_offer() returns trigger
language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  if new.status <> 'offered' then return new; end if;
  select * into b from bookings where id = new.booking_id;
  insert into notices (user_id, title, body, kind, ref_id)
  values (new.driver_id, 'New hire request',
          coalesce(b.pickup_name, '') || ' → ' || coalesce(b.dest_name, '') || '. Answer within 2 minutes.',
          'offer', new.booking_id);
  return new;
end $$;

drop trigger if exists booking_offers_notify on public.booking_offers;
create trigger booking_offers_notify after insert on public.booking_offers
  for each row execute function public.notify_new_offer();

-- 2) Starter departures on the through routes (whole road, first depot to last depot, both ways).
--    Every 2 hours from 06:00 to 16:00, every day. Change them in the admin Timetable page.
insert into departures (route_id, leaves_at, days)
select r.id, t.tm, '{1,2,3,4,5,6,7}'
from routes r
cross join (values ('06:00'::time), ('08:00'), ('10:00'), ('12:00'), ('14:00'), ('16:00')) as t(tm)
where r.through and r.corridor_id is not null and r.active
on conflict (route_id, leaves_at) do nothing;
