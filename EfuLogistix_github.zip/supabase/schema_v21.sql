-- EfuLogistix: database update v21  (run AFTER schema_v20.sql, or v19 if you skipped v20)
--   Hire bookings: places outside Malawi (a bad GPS fix, e.g. "Somerset West") and trips over 1,500 km are refused.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public._in_malawi(p_lat double precision, p_lng double precision)
returns boolean language sql immutable as $$
  select p_lat between -17.5 and -9.0 and p_lng between 32.5 and 36.5;
$$;

create or replace function public.book(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype;
  st app_settings%rowtype;
  office boolean := is_owner();
  k text := p ->> 'kind';
  b bookings%rowtype;
  d departures%rowtype;
  r routes%rowtype;
  c vehicle_categories%rowtype;
  cap int; taken int; straight double precision; g jsonb; gp numeric; items jsonb := '[]'::jsonb; total numeric := 0;
  bid uuid; code text;
begin
  select * into me from profiles where id = auth.uid();
  select * into st from app_settings where id = 1;
  if not office and (me.id is null or me.role <> 'passenger' or not me.active) then
    raise exception 'not allowed' using errcode = '42501';
  end if;
  if not office and (select count(*) from bookings where passenger_id = me.id and status in ('requested', 'assigned', 'picked_up'))
       >= st.max_open_bookings then
    raise exception 'TOO_MANY_BOOKINGS';
  end if;

  b.kind := k;
  b.passenger_id := case when office then nullif(p ->> 'passenger_id', '')::uuid else me.id end;
  b.caller_name := case when office then nullif(p ->> 'caller_name', '') end;
  b.caller_phone := case when office then nullif(p ->> 'caller_phone', '') end;
  if office and b.passenger_id is null and (b.caller_name is null or b.caller_phone is null) then
    raise exception 'CALLER_REQUIRED';
  end if;
  b.pay_method := coalesce(nullif(p ->> 'pay_method', ''), 'cash');
  b.pay_reference := nullif(trim(p ->> 'pay_reference'), '');
  b.note := nullif(p ->> 'note', '');
  if b.pay_method in ('airtel_money', 'tnm_mpamba') and b.pay_reference is null and not office then
    raise exception 'REFERENCE_REQUIRED';
  end if;
  if b.pay_method = 'account' then
    b.account_id := case when office then coalesce(nullif(p ->> 'account_id', '')::uuid, me.account_id) else me.account_id end;
    if b.account_id is null or not exists (select 1 from company_accounts where id = b.account_id and active) then
      raise exception 'NO_ACCOUNT';
    end if;
  end if;

  if k in ('seat', 'goods') then
    select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
    if d.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into r from routes where id = d.route_id and active;
    if r.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into c from vehicle_categories where id = r.category_id;
    b.travel_on := (p ->> 'travel_on')::date;
    if b.travel_on is null or not (extract(isodow from b.travel_on)::int = any (d.days)) then raise exception 'NO_DEPARTURE'; end if;
    b.pickup_at := (b.travel_on + d.leaves_at) at time zone 'Africa/Blantyre';
    if b.pickup_at < now() - interval '5 minutes' then raise exception 'DEPARTED'; end if;
    b.departure_id := d.id;
    b.route_id := r.id;
    b.category_id := r.category_id;
    b.pickup_name := r.from_name;
    b.dest_name := r.to_name;
    b.dest_lat := r.to_lat;
    b.dest_lng := r.to_lng;
    if k = 'seat' then
      b.seats := coalesce((p ->> 'seats')::int, 0);
      if b.seats < 1 then raise exception 'SEATS_REQUIRED'; end if;
      cap := coalesce(d.seats, c.seats, 0);
      select coalesce(sum(x.seats), 0) into taken from bookings x
        where x.departure_id = d.id and x.travel_on = b.travel_on and x.kind = 'seat' and x.status in ('requested', 'assigned', 'picked_up');
      if taken + b.seats > cap then raise exception 'FULL:%', greatest(cap - taken, 0); end if;
      b.price := r.fare * b.seats;
    end if;
  elsif k = 'hire' then
    select * into c from vehicle_categories where id = (p ->> 'category_id')::uuid and active;
    if c.id is null or c.hire_per_km <= 0 then raise exception 'NOT_FOR_HIRE'; end if;
    b.category_id := c.id;
    b.pickup_name := nullif(trim(p ->> 'pickup_name'), '');
    b.dest_name := nullif(trim(p ->> 'dest_name'), '');
    if b.pickup_name is null or b.dest_name is null then raise exception 'PLACES_REQUIRED'; end if;
    b.pickup_lat := (p ->> 'pickup_lat')::double precision;
    b.pickup_lng := (p ->> 'pickup_lng')::double precision;
    b.dest_lat := (p ->> 'dest_lat')::double precision;
    b.dest_lng := (p ->> 'dest_lng')::double precision;
    -- places outside Malawi are a bad GPS fix, not a real trip
    if (b.pickup_lat is not null and not public._in_malawi(b.pickup_lat, b.pickup_lng))
       or (b.dest_lat is not null and not public._in_malawi(b.dest_lat, b.dest_lng)) then
      raise exception 'OUT_OF_AREA';
    end if;
    b.trip_type := coalesce(nullif(p ->> 'trip_type', ''), 'one_way');
    b.pickup_at := coalesce((p ->> 'pickup_at')::timestamptz, now());
    if b.pickup_at < now() - interval '10 minutes' then raise exception 'IN_THE_PAST'; end if;
    b.km := greatest(coalesce((p ->> 'km')::numeric, 0), 1);
    -- never less than the straight line (the phone sends the road distance)
    straight := km_between(b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng);
    if straight is not null then
      b.km := greatest(b.km, round((straight * case when b.trip_type = 'return' then 2 else 1 end)::numeric, 1));
    end if;
    if b.trip_type = 'whole_day' then b.km := greatest(b.km, 100); end if;
    if b.km > 1500 then raise exception 'TOO_FAR'; end if;
    b.rate_per_km := c.hire_per_km;
    b.price := greatest(c.hire_min, ceil(b.km * c.hire_per_km / 500) * 500);
    b.seats := coalesce((p ->> 'seats')::int, 0);
  else
    raise exception 'bad kind';
  end if;

  -- goods (on a departure, or a load on a hired lorry)
  if k = 'goods' or jsonb_array_length(coalesce(p -> 'goods', '[]'::jsonb)) > 0 then
    for g in select * from jsonb_array_elements(coalesce(p -> 'goods', '[]'::jsonb)) loop
      if coalesce((g ->> 'qty')::int, 0) < 1 then continue; end if;
      if k = 'goods' then
        select price into gp from goods_prices where label = g ->> 'label' and active;
        if gp is null then raise exception 'UNKNOWN_GOODS:%', g ->> 'label'; end if;
      else
        gp := 0;                                   -- a hired car is paid per km
      end if;
      items := items || jsonb_build_object('label', g ->> 'label', 'qty', (g ->> 'qty')::int, 'price', gp);
      total := total + gp * (g ->> 'qty')::int;
    end loop;
    if k = 'goods' and jsonb_array_length(items) = 0 then raise exception 'GOODS_REQUIRED'; end if;
    b.goods := items;
    if k = 'goods' then b.price := total; end if;
    b.receiver_name := nullif(trim(p ->> 'receiver_name'), '');
    b.receiver_phone := nullif(trim(p ->> 'receiver_phone'), '');
    if b.receiver_name is null or b.receiver_phone is null then raise exception 'RECEIVER_REQUIRED'; end if;
    code := lpad((floor(random() * 10000))::int::text, 4, '0');
  end if;

  insert into bookings (passenger_id, caller_name, caller_phone, kind, category_id, route_id, departure_id, travel_on,
    pickup_at, seats, pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, trip_type, km, rate_per_km,
    goods, receiver_name, receiver_phone, price, pay_method, pay_reference, account_id, note)
  values (b.passenger_id, b.caller_name, b.caller_phone, b.kind, b.category_id, b.route_id, b.departure_id, b.travel_on,
    b.pickup_at, coalesce(b.seats, 0), b.pickup_name, b.pickup_lat, b.pickup_lng, b.dest_name, b.dest_lat, b.dest_lng, b.trip_type, b.km,
    b.rate_per_km, coalesce(b.goods, '[]'::jsonb), b.receiver_name, b.receiver_phone, b.price, b.pay_method, b.pay_reference,
    b.account_id, b.note)
  returning id into bid;
  if code is not null then insert into booking_codes (booking_id, code) values (bid, code); end if;
  return bid;
end;
$$;
