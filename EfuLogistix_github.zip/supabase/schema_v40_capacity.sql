-- EfuLogistix: database update v40
--   Goods vehicles (Pickup, Lorry, Matola, Truck) are measured in TONNES. Passenger vehicles are measured in SEATS.
--   The owner can edit the seats / tonnes of a vehicle. On a vehicle that is already approved, the change waits for the admin.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.vehicle_categories add column if not exists by_tonnes boolean not null default false;
alter table public.vehicle_categories add column if not exists tonnes numeric(5, 1) not null default 0 check (tonnes >= 0);
update public.vehicle_categories set by_tonnes = true where name in ('Pickup', 'Lorry', 'Matola', 'Truck');
-- starting values (the admin can change them in Vehicle types)
update public.vehicle_categories set tonnes = case name when 'Pickup' then 1 when 'Matola' then 3 when 'Lorry' then 7 when 'Truck' then 10 end
  where name in ('Pickup', 'Lorry', 'Matola', 'Truck') and tonnes = 0;

alter table public.trucks add column if not exists tonnes numeric(5, 1) check (tonnes is null or tonnes > 0);
alter table public.trucks add column if not exists pending_seats int check (pending_seats is null or pending_seats >= 0);
alter table public.trucks add column if not exists pending_tonnes numeric(5, 1);
alter table public.trucks add column if not exists capacity_requested_at timestamptz;

-- What a vehicle owner may change on their own vehicle (seats and tonnes now wait for the admin once approved)
create or replace function public.protect_truck()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  if auth.uid() is null or coalesce(current_setting('efu.system', true), '') = 'on'
     or not exists (select 1 from profiles where id = auth.uid() and role = 'owner') then
    return new;                                  -- admin, managers and the database functions
  end if;
  if tg_op = 'INSERT' then
    new.owner_id := auth.uid();
    new.status := 'pending';
    new.active := false;
    new.submitted_at := now();
    new.reviewed_by := null;
    new.reviewed_at := null;
    new.review_note := null;
    new.insurance_to := null;
    new.cof_to := null;
    new.pending_seats := null;
    new.pending_tonnes := null;
    new.capacity_requested_at := null;
    return new;
  end if;
  new.owner_id := old.owner_id;
  new.status := old.status;
  new.active := old.active;
  new.reviewed_by := old.reviewed_by;
  new.reviewed_at := old.reviewed_at;
  new.review_note := old.review_note;
  new.insurance_to := old.insurance_to;
  new.cof_to := old.cof_to;
  new.current_km := old.current_km;
  new.last_oil_km := old.last_oil_km;
  new.last_oil_on := old.last_oil_on;
  new.pending_seats := old.pending_seats;
  new.pending_tonnes := old.pending_tonnes;
  new.capacity_requested_at := old.capacity_requested_at;
  if old.status = 'approved' then
    new.plate := old.plate;                      -- number plate and type are fixed once approved
    new.category_id := old.category_id;
    if new.seats is distinct from old.seats or new.tonnes is distinct from old.tonnes then
      -- keep the approved numbers; ask the admin to approve the new ones
      new.pending_seats := new.seats;
      new.pending_tonnes := new.tonnes;
      new.capacity_requested_at := now();
      new.seats := old.seats;
      new.tonnes := old.tonnes;
      for r in select id from profiles where role = 'admin' and active loop
        perform notify(r.id, 'Capacity change: ' || old.plate, 'The owner asked to change the seats or tonnes. Open Vehicles to approve or decline.', 'truck', old.id);
      end loop;
    end if;
  elsif old.status = 'rejected' then
    new.status := 'pending';                     -- owner fixed it: back to the admin
    new.submitted_at := now();
  end if;
  return new;
end;
$$;
drop trigger if exists protect_truck on public.trucks;
create trigger protect_truck before insert or update on public.trucks
  for each row execute function public.protect_truck();

-- Admin: approve or decline a seats / tonnes change
create or replace function public.review_capacity(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare t trucks%rowtype;
begin
  if not is_admin() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into t from trucks where id = p_id;
  if t.id is null then raise exception 'NOT_FOUND'; end if;
  if t.capacity_requested_at is null then raise exception 'NO_REQUEST'; end if;
  if p_approve then
    update trucks set seats = pending_seats, tonnes = pending_tonnes,
      pending_seats = null, pending_tonnes = null, capacity_requested_at = null where id = p_id;
    perform notify(t.owner_id, t.plate || ': change approved', 'The new seats / tonnes are now on your vehicle.', 'truck', t.id);
  else
    update trucks set pending_seats = null, pending_tonnes = null, capacity_requested_at = null where id = p_id;
    perform notify(t.owner_id, t.plate || ': change declined', coalesce(nullif(p_note, ''), 'The seats / tonnes stay as they were.'), 'truck', t.id);
  end if;
end;
$$;
revoke all on function public.review_capacity(uuid, boolean, text) from public, anon;
grant execute on function public.review_capacity(uuid, boolean, text) to authenticated;
