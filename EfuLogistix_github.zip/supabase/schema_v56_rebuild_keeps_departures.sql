-- Keeps the timetable when the first or last depot of a road changes.
create or replace function public.corridor_rebuild(p_corridor uuid)
returns int language plpgsql security definer set search_path = public as $$
declare n int; lo int; hi int; r record;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select min(pos), max(pos) into lo, hi from corridor_stops where corridor_id = p_corridor;
  if lo is null or lo = hi then return 0; end if;

  drop table if exists _gen;
  create temp table _gen on commit drop as
  select f.from_name, f.to_name, f.to_lat, f.to_lng, f.km, f.fare, c.category_id
    from corridor_rates c
    cross join lateral public.corridor_fares(p_corridor, c.category_id) f
   where c.corridor_id = p_corridor
     and ((f.from_pos = lo and f.to_pos = hi) or (f.from_pos = hi and f.to_pos = lo));

  update routes set active = false
   where corridor_id = p_corridor
     and not exists (select 1 from _gen g where g.from_name = routes.from_name and g.to_name = routes.to_name and g.category_id = routes.category_id);

  insert into routes (from_name, to_name, to_lat, to_lng, km, fare, category_id, corridor_id, through, active)
  select from_name, to_name, to_lat, to_lng, km, fare, category_id, p_corridor, true, true from _gen
  on conflict (from_name, to_name, category_id)
  do update set to_lat = excluded.to_lat, to_lng = excluded.to_lng, km = excluded.km, fare = excluded.fare,
                corridor_id = excluded.corridor_id, through = true, active = true, updated_at = now();


  -- when the first or last depot changes, the timetable moves with the road: departures on the old
  -- through routes are moved to the new through route of the same vehicle type and direction
  update departures d
     set route_id = n.id
    from routes o
    join corridor_stops of_ on of_.corridor_id = p_corridor and of_.place_name = o.from_name
    join corridor_stops ot on ot.corridor_id = p_corridor and ot.place_name = o.to_name
    join routes n on n.corridor_id = p_corridor and n.through and n.active and n.category_id = o.category_id
    join corridor_stops nf on nf.corridor_id = p_corridor and nf.place_name = n.from_name
    join corridor_stops nt on nt.corridor_id = p_corridor and nt.place_name = n.to_name
   where d.route_id = o.id and o.corridor_id = p_corridor and o.through and not o.active
     and (of_.pos < ot.pos) = (nf.pos < nt.pos)
     and not exists (select 1 from departures x where x.route_id = n.id and x.leaves_at = d.leaves_at);

  select count(*) into n from _gen;
  return n;
end $$;
