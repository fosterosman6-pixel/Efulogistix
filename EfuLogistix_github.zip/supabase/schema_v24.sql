-- EfuLogistix: database update v24  (run AFTER schema_v23.sql)
--   A hire can be started by the driver with one tap (no ticket needed), so phone-in customers work too.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.booking_step(p_id uuid, p_step text, p_code text, p_km numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; final numeric; final_km numeric; who text; code text;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if p_step = 'picked_up' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    -- seat passengers are only marked on board by the ticket code; a hire has one customer with the car, so the driver just starts it
    if b.kind not in ('goods', 'hire') and coalesce(current_setting('efu.boarding', true), '') <> '1' then raise exception 'CODE_REQUIRED'; end if;
    update bookings set status = 'picked_up', picked_up_at = now(), trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind in ('seat', 'goods') then
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (tr.id, 'Booking #' || b.booking_no || ' · ' || who,
              0, b.seats, case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  elsif p_step = 'no_show' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'no_show', completed_at = now() where id = p_id;
    if b.passenger_id is not null then
      perform system_on();
      update profiles set no_shows = no_shows + 1 where id = b.passenger_id;
      perform notify(b.passenger_id, 'Missed booking #' || b.booking_no, 'The car waited but you were not there. Missed bookings are counted on your profile.', 'booking', b.id);
    end if;
  elsif p_step = 'completed' then
    if b.status not in ('assigned', 'picked_up') then raise exception 'ALREADY_DECIDED'; end if;
    select c.code into code from booking_codes c where c.booking_id = b.id;
    if code is not null and coalesce(trim(p_code), '') <> code then raise exception 'WRONG_CODE'; end if;
    final := b.price;
    final_km := b.km;
    if b.kind = 'hire' and coalesce(p_km, 0) > 0 then
      -- the odometer figure may not be wildly more than what was booked; the office can settle a bigger detour
      if p_km > coalesce(b.km, 0) * 1.5 + 10 then raise exception 'KM_TOO_HIGH'; end if;
      -- a whole-day hire is always charged at least 100 km, as it was when booked
      final_km := case when b.trip_type = 'whole_day' then greatest(p_km, 100) else p_km end;
      final := greatest((select hire_min from vehicle_categories where id = b.category_id),
                        ceil(final_km * coalesce(b.rate_per_km, 0) / 500) * 500);
    end if;
    update bookings set status = 'completed', completed_at = now(), final_price = final,
      km = case when b.kind = 'hire' and coalesce(p_km, 0) > 0 then final_km else km end,
      trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind = 'hire' then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Hire #' || b.booking_no || ' · ' || who, 1, final);
    end if;
    perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' done',
      case when b.kind = 'goods' then 'Delivered to ' || coalesce(b.receiver_name, 'the receiver') || '.'
           else 'Thank you for travelling with EfuLogistix. Total K' || to_char(final, 'FM999,999,990') || '.' end, 'booking', b.id);
  else
    raise exception 'bad step';
  end if;
end;
$$;
