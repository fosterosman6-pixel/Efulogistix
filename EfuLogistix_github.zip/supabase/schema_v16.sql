-- EfuLogistix: database update v16  (run AFTER schema_v15.sql)
--   A passenger is marked on board ONLY by scanning or typing the ticket code. Parcels are unchanged.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.booking_step(p_id uuid, p_step text, p_code text, p_km numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; final numeric; who text; code text;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if p_step = 'picked_up' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    -- people (not parcels) are only marked on board by scanning or typing the ticket code
    if b.kind <> 'goods' and coalesce(current_setting('efu.boarding', true), '') <> '1' then raise exception 'CODE_REQUIRED'; end if;
    update bookings set status = 'picked_up', picked_up_at = now(), trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind in ('seat', 'goods') then
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (tr.id, 'Booking #' || b.booking_no || ' · ' || who,
              0, b.seats, case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  elsif p_step = 'no_show' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'no_show', completed_at = now() where id = p_id;
    if b.passenger_id is not null then
      perform system_on();
      update profiles set no_shows = no_shows + 1 where id = b.passenger_id;
      perform notify(b.passenger_id, 'Missed booking #' || b.booking_no, 'The car waited but you were not there. Missed bookings are counted on your profile.', 'booking', b.id);
    end if;
  elsif p_step = 'completed' then
    if b.status not in ('assigned', 'picked_up') then raise exception 'ALREADY_DECIDED'; end if;
    select c.code into code from booking_codes c where c.booking_id = b.id;
    if code is not null and coalesce(trim(p_code), '') <> code then raise exception 'WRONG_CODE'; end if;
    final := b.price;
    if b.kind = 'hire' and coalesce(p_km, 0) > 0 then
      final := greatest((select hire_min from vehicle_categories where id = b.category_id),
                        ceil(p_km * coalesce(b.rate_per_km, 0) / 500) * 500);
    end if;
    update bookings set status = 'completed', completed_at = now(), final_price = final,
      km = case when b.kind = 'hire' and coalesce(p_km, 0) > 0 then p_km else km end,
      trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind = 'hire' then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Hire #' || b.booking_no || ' · ' || who, 1, final);
    end if;
    perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' done',
      case when b.kind = 'goods' then 'Delivered to ' || coalesce(b.receiver_name, 'the receiver') || '.'
           else 'Thank you for travelling with EfuLogistix. Total K' || to_char(final, 'FM999,999,990') || '.' end, 'booking', b.id);
  else
    raise exception 'bad step';
  end if;
end;
$$;

create or replace function public.board_by_code(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare cd text := regexp_replace(coalesce(p_code, ''), '\D', '', 'g'); b bookings%rowtype; who text;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  if length(cd) <> 8 then raise exception 'BAD_CODE'; end if;
  select b2.* into b from bookings b2 join booking_tickets t on t.booking_id = b2.id
   where t.code = cd and b2.driver_id = auth.uid() and b2.status in ('assigned', 'picked_up')
   order by b2.pickup_at limit 1;
  if b.id is null then raise exception 'NO_TICKET'; end if;
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if b.status = 'picked_up' then
    return jsonb_build_object('booking_no', b.booking_no, 'name', who, 'seats', b.seats, 'already', true);
  end if;
  perform set_config('efu.boarding', '1', true);
  perform booking_step(b.id, 'picked_up', null, null);
  perform set_config('efu.boarding', '', true);
  return jsonb_build_object('booking_no', b.booking_no, 'name', who, 'seats', b.seats, 'already', false);
end $$;
