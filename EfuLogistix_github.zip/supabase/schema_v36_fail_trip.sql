-- EfuLogistix v36: a driver can stop a trip that is already under way (breakdown, accident, road blocked, passenger problem).
-- Run once in the EfuLogistix Supabase project, after v35. Safe to run twice.
--   * the booking becomes 'failed' with the reason and the place where it stopped
--   * the passenger pays only for the distance actually driven (hire: km x rate; seat: share of the price; parcel: nothing)
--   * the passenger and the office are told; the office can change the fare and send another vehicle with assign_booking
--     (that works because a failed booking can be re-opened with reopen_failed_booking)

alter table public.bookings add column if not exists failed_at timestamptz;
alter table public.bookings add column if not exists fail_reason text;
alter table public.bookings add column if not exists fail_lat double precision;
alter table public.bookings add column if not exists fail_lng double precision;
alter table public.bookings add column if not exists driven_km numeric(8, 1);
alter table public.bookings add column if not exists far_finish_km numeric(6, 1);   -- set when the driver finished this far from the drop-off
alter table public.app_settings add column if not exists finish_radius_km numeric(4, 1) not null default 2;  -- "close enough to finish"


-- allow the new status
do $$ declare c text; begin
  for c in select conname from pg_constraint
           where conrelid = 'public.bookings'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%no_show%' loop
    execute format('alter table public.bookings drop constraint %I', c);
  end loop;
  alter table public.bookings add constraint bookings_status_check
    check (status in ('requested', 'assigned', 'picked_up', 'completed', 'cancelled', 'no_show', 'declined', 'failed'));
end $$;

-- Driver: stop the trip. p_all = true stops everyone on board in this driver's vehicle (breakdown, accident, blocked road);
-- false stops only p_id (a passenger problem). Returns how many bookings were stopped.
create or replace function public.fail_trip(p_id uuid, p_reason text, p_lat double precision, p_lng double precision, p_all boolean default true)
returns int language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; n int := 0; dkm numeric; the_fee numeric; who text; rate numeric; veh text;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_reason is null or p_reason not in ('breakdown', 'accident', 'road_blocked', 'passenger_problem', 'other') then
    raise exception 'BAD_REASON';
  end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  select coalesce(t.plate, '') into veh from trucks t where t.id = my_truck();
  for b in
    select * from bookings
    where driver_id = auth.uid() and status = 'picked_up' and (p_all or id = p_id)
      and (p_id is null or p_all or id = p_id)
    for update
  loop
    -- already near the drop-off: finish it instead of calling it a failure (an accident can always be reported)
    if p_reason <> 'accident' and b.dest_lat is not null and p_lat is not null
       and public.km_between(b.dest_lat, b.dest_lng, p_lat, p_lng) <= (select finish_radius_km from app_settings where id = 1) then
      raise exception 'NEAR_DESTINATION';
    end if;
    -- distance driven since pick-up: GPS trail first, else straight line from pick-up to where it stopped
    select sum(public.km_between(a.lat, a.lng, a.nlat, a.nlng)) into dkm from (
      select lat, lng, lead(lat) over (order by at) nlat, lead(lng) over (order by at) nlng
      from gps_points where driver_id = auth.uid() and at >= coalesce(b.picked_up_at, now())
    ) a where a.nlat is not null;
    if dkm is null or dkm <= 0 then
      dkm := coalesce(public.km_between(b.pickup_lat, b.pickup_lng, p_lat, p_lng), 0) * 1.3;
    end if;
    dkm := round(least(dkm, coalesce(nullif(b.km, 0) * 1.5, dkm))::numeric, 1);
    if b.kind = 'hire' then
      rate := coalesce(b.rate_per_km, 0);
      the_fee := least(b.price, ceil(dkm * rate / 500) * 500);
    elsif b.kind = 'seat' then
      the_fee := case when coalesce(b.km, 0) > 0 then least(b.price, round(b.price * least(1, dkm / b.km) / 500) * 500) else 0 end;
    else
      the_fee := 0;                                  -- a parcel that did not arrive: the office decides
    end if;
    update bookings set status = 'failed', failed_at = now(), fail_reason = p_reason,
      fail_lat = p_lat, fail_lng = p_lng, driven_km = dkm, final_price = the_fee, completed_at = now(),
      trip_id = coalesce(tr.id, trip_id) where id = b.id;
    if tr.id is not null and b.pay_method = 'cash' and the_fee > 0 and b.kind in ('hire', 'seat') then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Stopped #' || b.booking_no, greatest(1, case when b.kind = 'seat' then b.seats else 1 end),
              the_fee / greatest(1, case when b.kind = 'seat' then b.seats else 1 end));
    end if;
    who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
    perform notify(b.passenger_id, 'Trip stopped · booking #' || b.booking_no,
      case p_reason when 'breakdown' then 'The vehicle broke down.' when 'accident' then 'There was an accident.'
                    when 'road_blocked' then 'The road is blocked.' when 'passenger_problem' then 'The driver could not continue.' else 'The trip could not continue.' end
      || ' You pay only for the ' || to_char(dkm, 'FM990.0') || ' km driven: K' || to_char(the_fee, 'FM999,999,990') || '. The office will help you.',
      'booking', b.id);
    perform notify(p.id, 'Trip stopped · ' || coalesce(nullif(veh, ''), 'vehicle') || ' · #' || b.booking_no,
      who || ' · ' || p_reason || ' · ' || to_char(dkm, 'FM990.0') || ' km driven · fare K' || to_char(the_fee, 'FM999,999,990')
      || case when p_lat is not null then ' · at ' || round(p_lat::numeric, 5) || ',' || round(p_lng::numeric, 5) else '' end,
      'booking', b.id)
    from profiles p where p.role = 'owner' and p.active;
    n := n + 1;
  end loop;
  if n = 0 then raise exception 'NOTHING_TO_STOP'; end if;
  return n;
end;
$$;
revoke execute on function public.fail_trip(uuid, text, double precision, double precision, boolean) from public, anon;
grant execute on function public.fail_trip(uuid, text, double precision, double precision, boolean) to authenticated;

-- Office: change the fare of a stopped trip (for example waive it, or charge a bit more)
create or replace function public.set_failed_fare(p_id uuid, p_amount numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'BAD_AMOUNT'; end if;
  update bookings set final_price = least(p_amount, price) where id = p_id and status = 'failed' returning * into b;
  if b.id is null then raise exception 'ALREADY_DECIDED'; end if;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' fare updated', 'The fare for the stopped trip is now K' || to_char(b.final_price, 'FM999,999,990') || '.', 'booking', b.id);
end;
$$;
revoke execute on function public.set_failed_fare(uuid, numeric) from public, anon;
grant execute on function public.set_failed_fare(uuid, numeric) to authenticated;

-- Office: put the stopped booking back in the queue so another vehicle can be sent to where it stopped (then assign_booking)
create or replace function public.reopen_failed_booking(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  update bookings set status = 'requested', truck_id = null, driver_id = null, trip_id = null, arrived_at = null,
    picked_up_at = null, completed_at = null, assigned_at = null,
    pickup_lat = coalesce(fail_lat, pickup_lat), pickup_lng = coalesce(fail_lng, pickup_lng),
    pickup_name = 'Where the first car stopped',
    price = greatest(0, price - coalesce(final_price, 0)), final_price = null
  where id = p_id and status = 'failed' returning * into b;
  if b.id is null then raise exception 'ALREADY_DECIDED'; end if;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · another car is coming', 'The office is sending another vehicle to where you are.', 'booking', b.id);
end;
$$;
revoke execute on function public.reopen_failed_booking(uuid) from public, anon;
grant execute on function public.reopen_failed_booking(uuid) to authenticated;

-- one row per vehicle for reports: how often trips were stopped
create or replace view public.vehicle_failures with (security_invoker = true) as
  select t.id as truck_id, t.plate, count(*) as stopped_trips, max(b.failed_at) as last_stopped,
         count(*) filter (where b.fail_reason = 'breakdown') as breakdowns
  from bookings b join trucks t on t.id = b.truck_id where b.status = 'failed' group by t.id, t.plate;

-- Finishing: when a driver taps Done more than finish_radius_km (default 2) from the drop-off, the booking is flagged
-- and the office is told. It is never blocked, because some places have rough coordinates.
create or replace function public._flag_far_finish() returns trigger
language plpgsql security definer set search_path = public as $$
declare loc truck_locations%rowtype; away double precision; lim numeric;
begin
  if new.status = 'completed' and old.status = 'picked_up' and new.dest_lat is not null and new.driver_id is not null then
    select * into loc from truck_locations where driver_id = new.driver_id and updated_at > now() - interval '15 minutes' limit 1;
    if loc.truck_id is not null then
      away := public.km_between(new.dest_lat, new.dest_lng, loc.lat, loc.lng);
      select finish_radius_km into lim from app_settings where id = 1;
      if away > lim then
        new.far_finish_km := round(away::numeric, 1);
        perform notify(p.id, 'Finished far from drop-off · #' || new.booking_no,
          to_char(away, 'FM990.0') || ' km from ' || coalesce(new.dest_name, 'the drop-off') || ' when the driver tapped Done. Please check.', 'booking', new.id)
        from profiles p where p.role = 'owner' and p.active;
      end if;
    end if;
  end if;
  return new;
end;
$$;
revoke execute on function public._flag_far_finish() from public, anon, authenticated;
drop trigger if exists bookings_far_finish on public.bookings;
create trigger bookings_far_finish before update of status on public.bookings
  for each row execute function public._flag_far_finish();

-- Same 2 km rule at the PICK-UP point: "I've arrived" or picking up more than finish_radius_km from the pick-up
-- is allowed (rough coordinates) but flagged, and the office is told.
alter table public.bookings add column if not exists far_pickup_km numeric(6, 1);
create or replace function public._flag_far_pickup() returns trigger
language plpgsql security definer set search_path = public as $$
declare loc truck_locations%rowtype; away double precision; lim numeric;
begin
  if new.pickup_lat is not null and new.driver_id is not null and new.far_pickup_km is null
     and ((new.arrived_at is not null and old.arrived_at is null) or (new.status = 'picked_up' and old.status = 'assigned')) then
    select * into loc from truck_locations where driver_id = new.driver_id and updated_at > now() - interval '15 minutes' limit 1;
    if loc.truck_id is not null then
      away := public.km_between(new.pickup_lat, new.pickup_lng, loc.lat, loc.lng);
      select finish_radius_km into lim from app_settings where id = 1;
      if away > lim then
        new.far_pickup_km := round(away::numeric, 1);
        perform notify(p.id, 'Pick-up far from the point · #' || new.booking_no,
          to_char(away, 'FM990.0') || ' km from ' || coalesce(new.pickup_name, 'the pick-up point') || ' when the driver marked it. Please check.', 'booking', new.id)
        from profiles p where p.role = 'owner' and p.active;
      end if;
    end if;
  end if;
  return new;
end;
$$;
revoke execute on function public._flag_far_pickup() from public, anon, authenticated;
drop trigger if exists bookings_far_pickup on public.bookings;
create trigger bookings_far_pickup before update of status, arrived_at on public.bookings
  for each row execute function public._flag_far_pickup();
