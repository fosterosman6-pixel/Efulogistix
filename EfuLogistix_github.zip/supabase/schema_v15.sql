-- v15 · Car categories by size: "5 Seater" and "7 Seater" (next to Taxi, which has 4 seats).
-- Hire prices and EfuLogistix fees start as a copy of Taxi; change them in the admin panel. Safe to run again.
insert into public.vehicle_categories (name, carries_passengers, carries_goods, seats, licence_classes, hire_per_km, hire_min, fee_weekly, fee_monthly, fee_per_trip)
select v.name, true, false, v.seats, '{B,EB,C1,C,D1,D}'::text[], c.hire_per_km, c.hire_min, c.fee_weekly, c.fee_monthly, c.fee_per_trip
from (values ('5 Seater', 5), ('7 Seater', 7)) as v(name, seats)
join public.vehicle_categories c on c.name = 'Taxi'
on conflict (name) do nothing;
