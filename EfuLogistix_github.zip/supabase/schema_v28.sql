-- EfuLogistix: database update v28  (run AFTER schema_v27.sql)
--   A chat notice can open its chat: owner <-> driver notices now carry the sender, booking chats already carry the booking.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.send_chat(p_booking uuid, p_peer uuid, p_body text,
  p_kind text default 'text', p_path text default null, p_seconds int default null)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); b bookings%rowtype; body text := btrim(coalesce(p_body, ''));
        rcpt uuid; own uuid; drv uuid; myrole text; peerrole text; who text;
begin
  if me is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_kind not in ('text', 'photo', 'voice') then raise exception 'BAD_MESSAGE'; end if;
  if p_kind = 'text' and (length(body) < 1 or length(body) > 1000) then raise exception 'BAD_MESSAGE'; end if;
  if p_kind <> 'text' and (p_path is null or split_part(p_path, '/', 1) <> me::text) then raise exception 'BAD_MESSAGE'; end if;
  if (select count(*) from chat_messages where sender_id = me and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'SLOW_DOWN';
  end if;
  who := coalesce((select full_name from profiles where id = me), 'Someone');
  if p_booking is not null then
    select * into b from bookings where id = p_booking;
    if b.id is null or me not in (coalesce(b.passenger_id, me), coalesce(b.driver_id, me)) then raise exception 'not allowed' using errcode = '42501'; end if;
    if me <> coalesce(b.passenger_id, '00000000-0000-0000-0000-000000000000') and me <> coalesce(b.driver_id, '00000000-0000-0000-0000-000000000000') then
      raise exception 'not allowed' using errcode = '42501';
    end if;
    if not (b.status in ('assigned', 'picked_up') or (b.status = 'completed' and b.completed_at > now() - interval '6 hours')) then
      raise exception 'CHAT_CLOSED';
    end if;
    rcpt := case when me = b.passenger_id then b.driver_id else b.passenger_id end;
    if rcpt is null then raise exception 'NO_PARTY'; end if;
    insert into chat_messages (booking_id, sender_id, recipient_id, kind, body, file_path, seconds) values (b.id, me, rcpt, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(rcpt, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', b.id);
  else
    select role into myrole from profiles where id = me;
    select role into peerrole from profiles where id = p_peer;
    if myrole = 'owner' and peerrole = 'driver'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = p_peer and t.owner_id = me) then
      own := me; drv := p_peer;
    elsif myrole = 'driver' and peerrole = 'owner'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = me and t.owner_id = p_peer) then
      own := p_peer; drv := me;
    else
      raise exception 'not allowed' using errcode = '42501';
    end if;
    insert into chat_messages (owner_id, driver_id, sender_id, recipient_id, kind, body, file_path, seconds) values (own, drv, me, p_peer, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(p_peer, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat_peer', me);   -- ref = who wrote, so the notice can open the chat
  end if;
end $$;
revoke all on function public.send_chat(uuid, uuid, text, text, text, int) from public, anon;
grant execute on function public.send_chat(uuid, uuid, text, text, text, int) to authenticated;
