-- EfuLogistix: database update v25  (run AFTER schema_v24.sql)
--   The admin can invite someone as any role: Admin, Manager, Vehicle owner, Driver or Passenger.
--   (Before, an invite could only be Manager, Owner or Driver.)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.invites drop constraint if exists invites_role_check;
alter table public.invites add constraint invites_role_check
  check (role in ('admin', 'manager', 'owner', 'driver', 'passenger'));
