-- v43: goods details (size, fragile, declared value, photo), proof-of-delivery photo, change a booking.
-- Run after v42. Safe to run twice.

alter table public.bookings add column if not exists goods_size text check (goods_size in ('small', 'medium', 'large'));
alter table public.bookings add column if not exists fragile boolean not null default false;
alter table public.bookings add column if not exists declared_value numeric(12, 2);
alter table public.bookings add column if not exists goods_photo text;
alter table public.bookings add column if not exists delivery_photo text;

-- Passenger: add the goods details to a goods booking just made
create or replace function public.set_goods_extras(p_booking uuid, p_size text, p_fragile boolean, p_declared numeric, p_photo text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update bookings set goods_size = nullif(p_size, ''), fragile = coalesce(p_fragile, false),
         declared_value = case when p_declared is null or p_declared < 0 then null else p_declared end,
         goods_photo = nullif(p_photo, '')
  where id = p_booking and kind = 'goods' and status in ('requested', 'assigned')
    and (passenger_id = auth.uid() or is_owner());
  if not found then raise exception 'CANNOT_CHANGE'; end if;
end;
$$;
revoke all on function public.set_goods_extras(uuid, text, boolean, numeric, text) from public, anon;
grant execute on function public.set_goods_extras(uuid, text, boolean, numeric, text) to authenticated;

-- Driver: photo of the goods handed over (proof of delivery)
create or replace function public.set_delivery_photo(p_booking uuid, p_path text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update bookings set delivery_photo = nullif(p_path, '')
  where id = p_booking and kind = 'goods' and status in ('picked_up', 'completed')
    and (driver_id = auth.uid() or is_owner());
  if not found then raise exception 'CANNOT_CHANGE'; end if;
end;
$$;
revoke all on function public.set_delivery_photo(uuid, text) from public, anon;
grant execute on function public.set_delivery_photo(uuid, text) to authenticated;

-- Passenger: change a booking until the car has arrived.
--  hire: new time and/or pick-up place. seat: fewer seats. any: a note for the driver.
create or replace function public.change_booking(
  p_id uuid, p_pickup_at timestamptz default null, p_pickup_name text default null,
  p_lat double precision default null, p_lng double precision default null,
  p_seats int default null, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; what text := '';
begin
  select * into b from bookings where id = p_id for update;
  if b.id is null or not (b.passenger_id = auth.uid() or is_owner()) then raise exception 'CANNOT_CHANGE'; end if;
  if b.status not in ('requested', 'assigned') or b.arrived_at is not null then raise exception 'CANNOT_CHANGE'; end if;
  if p_pickup_at is not null and b.kind = 'hire' then
    if p_pickup_at < now() then raise exception 'BAD_TIME'; end if;
    update bookings set pickup_at = p_pickup_at, travel_on = (p_pickup_at at time zone 'Africa/Blantyre')::date where id = p_id;
    what := what || ' time';
  end if;
  if nullif(trim(coalesce(p_pickup_name, '')), '') is not null and b.kind = 'hire' then
    update bookings set pickup_name = trim(p_pickup_name), pickup_lat = p_lat, pickup_lng = p_lng where id = p_id;
    what := what || ' pick-up';
  end if;
  if p_seats is not null and b.kind = 'seat' then
    if p_seats < 1 or p_seats >= b.seats then raise exception 'BAD_SEATS'; end if;
    update bookings set price = round(b.price / b.seats * p_seats, 2), seats = p_seats where id = p_id;
    what := what || ' seats';
  end if;
  if p_note is not null then
    update bookings set note = nullif(trim(p_note), '') where id = p_id;
    what := what || ' note';
  end if;
  if what = '' then raise exception 'NOTHING_TO_CHANGE'; end if;
  perform notify(b.driver_id, 'Booking #' || b.booking_no || ' changed', 'Changed:' || what || '. Open your pick-ups.', 'booking', b.id);
end;
$$;
revoke all on function public.change_booking(uuid, timestamptz, text, double precision, double precision, int, text) from public, anon;
grant execute on function public.change_booking(uuid, timestamptz, text, double precision, double precision, int, text) to authenticated;
