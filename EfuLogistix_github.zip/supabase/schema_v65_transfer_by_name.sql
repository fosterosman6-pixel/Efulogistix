-- v65: change-of-car trips that can start or end at a depot that is only on the local road (e.g. Mangochi Turn Off Depot).
-- plan_transfer / book_transfer now also take the depot NAMES; plan_transfer without a vehicle type only says what kind of trip it is.
-- Safe to run twice. Run after v63.
begin;
drop function if exists public.plan_transfer(uuid, int, int, uuid);

create or replace function public.plan_transfer(p_corridor uuid, p_from int, p_to int, p_category uuid default null,
                                                p_from_name text default null, p_to_name text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  t transfer_points%rowtype; ha int; hb int; fn text; tn text; fb int; tb int; k text;
  af int; at_ int; qa record; qb record; la jsonb; lb jsonb; head jsonb;
begin
  select * into t from transfer_points where corridor_a = p_corridor limit 1;
  if t.id is null then return null; end if;
  select pos into ha from corridor_stops where corridor_id = t.corridor_a and place_name = t.hub_a;
  select pos into hb from corridor_stops where corridor_id = t.corridor_b and place_name = t.hub_b;
  if ha is null or hb is null then return null; end if;
  if p_from is not null then select place_name into fn from corridor_stops where corridor_id = p_corridor and pos = p_from; else fn := p_from_name; end if;
  if p_to   is not null then select place_name into tn from corridor_stops where corridor_id = p_corridor and pos = p_to;   else tn := p_to_name;   end if;
  if fn is null or tn is null then return null; end if;

  if p_from is not null and p_from > ha and (p_to is null or p_to < ha) then
    select pos into tb from corridor_stops where corridor_id = t.corridor_b and place_name = tn and pos > hb;
    if tb is null then return null; end if;
    k := 'out'; af := p_from; at_ := ha;
  elsif p_to is not null and p_to > ha and (p_from is null or p_from < ha) then
    select pos into fb from corridor_stops where corridor_id = t.corridor_b and place_name = fn and pos > hb;
    if fb is null then return null; end if;
    k := 'in'; af := ha; at_ := p_to;
  else
    return null;
  end if;

  head := jsonb_build_object('kind', k, 'a_from', af, 'a_to', at_, 'hub_a', t.hub_a, 'hub_b', t.hub_b, 'walk_km', t.walk_km);
  if p_category is null then return head; end if;

  select f.km, f.fare into qa from corridor_fares(t.corridor_a, p_category) f where f.from_pos = af and f.to_pos = at_;
  if k = 'out' then
    select f.km, f.fare into qb from corridor_fares(t.corridor_b, p_category) f where f.from_pos = hb and f.to_pos = tb;
  else
    select f.km, f.fare into qb from corridor_fares(t.corridor_b, p_category) f where f.from_pos = fb and f.to_pos = hb;
  end if;
  if qa.fare is null or qb.fare is null then return null; end if;
  if k = 'out' then
    la := jsonb_build_object('from_name', fn, 'to_name', t.hub_a, 'km', qa.km, 'fare', qa.fare);
    lb := jsonb_build_object('from_name', t.hub_b, 'to_name', tn, 'km', qb.km, 'fare', qb.fare);
    return head || jsonb_build_object('legs', jsonb_build_array(la, lb), 'total', qa.fare + qb.fare);
  else
    lb := jsonb_build_object('from_name', fn, 'to_name', t.hub_b, 'km', qb.km, 'fare', qb.fare);
    la := jsonb_build_object('from_name', t.hub_a, 'to_name', tn, 'km', qa.km, 'fare', qa.fare);
    return head || jsonb_build_object('legs', jsonb_build_array(lb, la), 'total', qa.fare + qb.fare);
  end if;
end $$;
revoke all on function public.plan_transfer(uuid, int, int, uuid, text, text) from public, anon;
grant execute on function public.plan_transfer(uuid, int, int, uuid, text, text) to authenticated;

-- book both parts at once. p = the same keys as book_depot (departure_id is the long-road car chosen by the passenger).
create or replace function public.book_transfer(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; t transfer_points%rowtype; plan jsonb; k text;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  ha int; hb int; sp int; a_id uuid; b_id uuid; ba bookings%rowtype; bb bookings%rowtype; one uuid; two uuid;
  pass_a time; need time; c record; dn departures%rowtype; found boolean := false; spb int; walk_min numeric;
  fb int; tb int;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into t from transfer_points where corridor_a = r.corridor_id limit 1;
  plan := public.plan_transfer(r.corridor_id, fp, tp, r.category_id, p ->> 'from_name', p ->> 'to_name');
  if plan is null then raise exception 'NO_TRANSFER'; end if;
  k := plan ->> 'kind';
  select pos into ha from corridor_stops where corridor_id = t.corridor_a and place_name = t.hub_a;
  select pos into hb from corridor_stops where corridor_id = t.corridor_b and place_name = t.hub_b;
  walk_min := t.walk_km / 5 * 60 + 10;      -- walking at 5 km/h plus 10 minutes to spare

  -- the long-road part first (this also sets the right direction for the chosen time)
  a_id := public.book_depot((p - 'corridor_id') || jsonb_build_object(
            'from_pos', case when k = 'out' then fp else ha end, 'to_pos', case when k = 'out' then ha else tp end));
  select * into ba from bookings where id = a_id;
  select * into d from departures where id = ba.departure_id;
  select * into r from routes where id = d.route_id;
  select min(pos) into sp from corridor_stops where corridor_id = r.corridor_id and place_name = r.from_name;
  pass_a := (d.leaves_at + (public._km_between_pos(r.corridor_id, sp, ha) / t.speed_kmh * 60) * interval '1 minute')::time;

  if k = 'out' then
    -- local car: first one that leaves Mankhwala after the passenger has arrived at Soko and walked
    need := (pass_a + walk_min * interval '1 minute')::time;
    select pos into tb from corridor_stops where corridor_id = t.corridor_b and place_name = plan -> 'legs' -> 1 ->> 'to_name';
    select x.* into dn from departures x join routes r2 on r2.id = x.route_id
     where r2.corridor_id = t.corridor_b and r2.through and r2.active and r2.category_id = r.category_id and x.active
       and (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r2.from_name)
         < (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r2.to_name)
       and x.leaves_at >= need and extract(isodow from ba.travel_on)::int = any (x.days)
     order by x.leaves_at limit 1;
    if dn.id is null then raise exception 'NO_CONNECTION'; end if;
    b_id := public.book_depot((p - 'corridor_id') || jsonb_build_object('departure_id', dn.id, 'from_pos', hb, 'to_pos', tb));
    one := a_id; two := b_id;
  else
    -- local car first: the last one that gets to Mankhwala (and the walk) before the long-road car reaches Soko
    select pos into fb from corridor_stops where corridor_id = t.corridor_b and place_name = plan -> 'legs' -> 0 ->> 'from_name';
    for c in select d3.id as id, d3.leaves_at, r3.from_name from departures d3 join routes r3 on r3.id = d3.route_id
              where r3.corridor_id = t.corridor_b and r3.through and r3.active and r3.category_id = r.category_id and d3.active
                and (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r3.from_name)
                  > (select pos from corridor_stops where corridor_id = t.corridor_b and place_name = r3.to_name)
                and extract(isodow from ba.travel_on)::int = any (d3.days)
              order by d3.leaves_at desc loop
      select pos into spb from corridor_stops where corridor_id = t.corridor_b and place_name = c.from_name;
      if (c.leaves_at + (public._km_between_pos(t.corridor_b, spb, hb) / t.speed_kmh * 60 + walk_min) * interval '1 minute')::time <= pass_a
         and c.leaves_at + (public._km_between_pos(t.corridor_b, spb, hb) / t.speed_kmh * 60) * interval '1 minute' >= c.leaves_at then
        select * into dn from departures where id = c.id; found := true; exit;
      end if;
    end loop;
    if not found then raise exception 'NO_CONNECTION'; end if;
    b_id := public.book_depot((p - 'corridor_id') || jsonb_build_object('departure_id', dn.id, 'from_pos', fb, 'to_pos', hb));
    one := b_id; two := a_id;
  end if;

  select * into ba from bookings where id = one;
  select * into bb from bookings where id = two;
  update bookings set leg = 1,
         transfer_note = 'Change of car at ' || ba.dest_name || '. Then ' || bb.pickup_name || ' → ' || bb.dest_name || ' with another driver.'
   where id = one;
  update bookings set leg = 2, parent_id = one,
         transfer_note = 'Change of car: comes from ' || ba.dest_name || ' (booked together with #' || ba.booking_no || ').'
   where id = two;
  return one;
end $$;
revoke all on function public.book_transfer(jsonb) from public, anon;
grant execute on function public.book_transfer(jsonb) to authenticated;

commit;

select jsonb_pretty(public.plan_transfer(
  (select id from route_corridors where name = 'Mangochi - Monkey Bay'),
  (select pos from corridor_stops where corridor_id = (select id from route_corridors where name = 'Mangochi - Monkey Bay') and place_name = 'Makawa Trading Centre Depot'),
  null, (select id from vehicle_categories where name = '7 Seater'), null, 'Mangochi Turn Off Depot')) as makawa_to_turn_off;
