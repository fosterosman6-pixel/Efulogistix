-- EfuLogistix: database update v41
--   Anyone signed in can suggest a place (before, only drivers could; a passenger's named pin was silently dropped).
--   The admin still approves every suggestion in Places. Limit: 15 waiting suggestions per person.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

drop policy if exists place_sug_insert on public.place_suggestions;
create policy place_sug_insert on public.place_suggestions for insert to authenticated
  with check (suggested_by = auth.uid() and status = 'pending' and length(trim(name)) between 2 and 80);

create or replace function public.limit_place_suggestions() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and (select count(*) from place_suggestions where suggested_by = new.suggested_by and status = 'pending') >= 15 then
    raise exception 'TOO_MANY_REQUESTS' using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists place_suggestions_limit on public.place_suggestions;
create trigger place_suggestions_limit before insert on public.place_suggestions
  for each row execute function public.limit_place_suggestions();
