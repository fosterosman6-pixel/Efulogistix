-- v64: put Mangochi Turn Off Depot back on the pin you sent (-15.044939, 35.188968, M3/M8 junction near Machinga).
-- Fixes the place AND the copy of it inside the depot lists, then recalculates distances and fares. Safe to run twice.
begin;
insert into public.places (name, detail, lat, lng)
values ('Mangochi Turn Off Depot', 'Depot · M3 / M8 junction, near Machinga', -15.044939, 35.188968)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

update public.corridor_stops set lat = -15.044939, lng = 35.188968
 where place_name = 'Mangochi Turn Off Depot';

-- hop distances that were not typed by hand are worked out again
update public.corridor_stops set km_locked = false
 where place_name = 'Mangochi Turn Off Depot' and km_locked = false;
select public.corridor_recalc_km(corridor_id) from (select distinct corridor_id from public.corridor_stops where place_name = 'Mangochi Turn Off Depot') x;
select public.corridor_rebuild(corridor_id) from (select distinct corridor_id from public.corridor_stops where place_name = 'Mangochi Turn Off Depot') x;
commit;

select p.name, p.lat, p.lng from public.places p where p.name = 'Mangochi Turn Off Depot';
select c.name as road, s.pos, s.place_name, s.lat, s.lng, s.km_from_prev
  from public.corridor_stops s join public.route_corridors c on c.id = s.corridor_id
 where s.place_name = 'Mangochi Turn Off Depot';
