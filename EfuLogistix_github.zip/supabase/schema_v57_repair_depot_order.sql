-- Repairs the depot list of Mangochi - Monkey Bay (removes the repeated depots) and puts every depot in its right place.
-- Safe to run more than once. Special depot-to-depot fares on this road are cleared (their numbers no longer match).
begin;
do $$
declare c uuid;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is null then raise exception 'Road Mangochi - Monkey Bay not found'; end if;

  delete from public.corridor_overrides where corridor_id = c;
  delete from public.corridor_stops where corridor_id = c;

  insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
  select c, v.pos, p.name, p.lat, p.lng
    from (values
      (0,'DMI Depot'),(1,'Changamile Depot'),(2,'Mtavu Depot'),(3,'Mpima Depot'),(4,'Mankhwala Depot'),
      (5,'Mangochi Main Rank'),(6,'Soko Taxi Rank'),(7,'Mpondasi Trading centre'),(8,'Bishop''s House, Diocese of Mangochi'),
      (9,'Samama Depot'),(10,'Bolera Depot'),(11,'Umar Farook Masjid Depot'),(12,'Malichi Depot'),(13,'Namiasi Depot'),
      (14,'Malemia Depot'),(15,'Maldeco Road block Depot'),(16,'Koche Depot'),(17,'Nkopora Turn Off Depot'),
      (18,'Makokola Turn Off Depot'),(19,'Makawa Trading Centre Depot'),(20,'Nabale Depot'),(21,'Nkhudzi Bay Depot'),
      (22,'Cape Maclear Turn Off Depot'),(23,'Chirombo Depot'),(24,'Mbalamanja Depot'),(25,'Cape Maclear Junction Depot'),
      (26,'Namazizi Depot'),(27,'Monkey Bay Depot')
    ) as v(pos, name)
    join public.places p on p.name = v.name;

  if (select count(*) from public.corridor_stops where corridor_id = c) <> 28 then
    raise exception 'Some depots are missing from Places - run the places file first';
  end if;

  perform public.corridor_recalc_km(c);
  perform public.corridor_rebuild(c);
end $$;
commit;

select count(*) as depots, round(sum(km_from_prev), 1) as whole_road_km
  from public.corridor_stops where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay');
