-- schema_v33: a driver rates the passenger after a completed trip.
-- Run once in the EfuLogistix Supabase project (SQL Editor).
create table if not exists public.passenger_ratings (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings (id) on delete cascade,
  driver_id uuid not null references public.profiles (id) on delete cascade,
  passenger_id uuid references public.profiles (id) on delete set null,
  stars int not null check (stars between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);
create index if not exists passenger_ratings_pax_idx on public.passenger_ratings (passenger_id, created_at desc);

alter table public.passenger_ratings enable row level security;
drop policy if exists pax_ratings_read on public.passenger_ratings;
create policy pax_ratings_read on public.passenger_ratings for select to authenticated
  using (driver_id = auth.uid() or public.is_manager());

create or replace function public.rate_passenger(p_booking uuid, p_stars int, p_comment text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; adm record; who text;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_stars is null or p_stars < 1 or p_stars > 5 then raise exception 'BAD_STARS'; end if;
  select * into b from bookings where id = p_booking and driver_id = auth.uid();
  if b.id is null then raise exception 'BOOKING_NOT_FOUND'; end if;
  if b.status <> 'completed' then raise exception 'NOT_COMPLETED'; end if;
  if exists (select 1 from passenger_ratings where booking_id = p_booking) then raise exception 'ALREADY_RATED'; end if;
  insert into passenger_ratings (booking_id, driver_id, passenger_id, stars, comment)
  values (p_booking, auth.uid(), b.passenger_id, p_stars, nullif(btrim(p_comment), ''));
  if p_stars <= 2 then
    select coalesce(nullif(full_name, ''), email, 'A driver') into who from profiles where id = auth.uid();
    for adm in select id from profiles where role in ('admin', 'manager') and active loop
      perform public.notify(adm.id, 'Passenger rated ' || p_stars || ' star' || case when p_stars = 1 then '' else 's' end,
                            who || ' on booking #' || b.booking_no || coalesce(': ' || nullif(btrim(p_comment), ''), ''), 'rating', p_booking);
    end loop;
  end if;
end $$;
revoke all on function public.rate_passenger(uuid, int, text) from public, anon;
grant execute on function public.rate_passenger(uuid, int, text) to authenticated;
