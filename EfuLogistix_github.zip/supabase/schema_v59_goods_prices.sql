-- v59: starter goods prices, so "Send goods" has items to choose from.
-- Each price is for the WHOLE road (Mangochi - Monkey Bay, 76 km). A shorter trip pays its share, rounded to K500, never below K500.
-- Safe to run twice: it never changes a price that already exists. Change any price in Admin > Fares > Goods.
insert into public.goods_prices (label, price, active) values
  ('Envelope / documents',        2000, true),
  ('Small parcel',                3000, true),
  ('Bag / suitcase',              4000, true),
  ('Box (medium)',                5000, true),
  ('Cooler / fish box',           5000, true),
  ('Sack (up to 50 kg)',          6000, true),
  ('Mattress',                    8000, true),
  ('Bicycle',                     8000, true),
  ('Large box / drum',           10000, true)
on conflict (label) do nothing;

-- make sure they are visible even if the items were added earlier and switched off by mistake: leave those alone (admin choice)
select label, price, active from public.goods_prices order by price, label;
