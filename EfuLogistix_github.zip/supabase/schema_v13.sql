-- v13 · The driver's wallet grows after EVERY completed trip (not only when the owner confirms the day's hand-in).
-- Each completed trip adds wallet_pct % of its total. When the owner confirms the day's hand-in, the wallet is
-- adjusted to wallet_pct % of (money collected − driver expenses): up or down by the difference.
-- Run after schema_v12.sql.

alter table public.wallet_entries add column if not exists trip_id uuid unique references public.trips (id) on delete cascade;

create or replace function public.credit_trip_wallet() returns trigger
language plpgsql security definer set search_path = public as $$
declare pct numeric; share numeric; own uuid;
begin
  if new.status = 'completed' and old.status is distinct from 'completed' then
    select wallet_pct into pct from app_settings where id = 1;
    share := round(greatest(new.total, 0) * coalesce(pct, 10) / 100);
    if share > 0 then
      select owner_id into own from trucks where id = new.truck_id;
      insert into wallet_entries (driver_id, owner_id, trip_id, kind, amount, day, note)
      values (new.driver_id, own, new.id, 'earn', share, current_date,
              'Trip #' || new.trip_no || ' · ' || trim_scale(coalesce(pct, 10)) || '% of K' || to_char(new.total, 'FM999,999,990'))
      on conflict (trip_id) do nothing;
      perform notify(new.driver_id, '+ K' || to_char(share, 'FM999,999,990') || ' in your wallet',
                     'Trip #' || new.trip_no || ' completed.', 'wallet', new.id);
    end if;
  end if;
  return new;
end $$;

drop trigger if exists trips_wallet on public.trips;
create trigger trips_wallet after update of status on public.trips
  for each row execute function public.credit_trip_wallet();

-- hand-in confirmed: true the day up (or down, when there were expenses) to the share of money after expenses
create or replace function public.receive_hand_in(p_id uuid, p_amount numeric, p_method text, p_reference text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare h hand_ins%rowtype; first_time boolean; who text; own uuid; pct numeric; share numeric; already numeric; adj numeric;
begin
  select * into h from hand_ins where id = p_id;
  if h.id is null then raise exception 'NOT_FOUND'; end if;
  if not (is_owner() or owns_truck(h.truck_id)) then raise exception 'not allowed' using errcode = '42501'; end if;
  first_time := h.received is null;
  update hand_ins set received = p_amount, method = coalesce(p_method, method), reference = coalesce(nullif(p_reference, ''), reference),
    note = nullif(p_note, ''), received_by = auth.uid(), received_at = now()
  where id = p_id returning * into h;
  select owner_id into own from trucks where id = h.truck_id;
  if first_time then
    select wallet_pct into pct from app_settings where id = 1;
    share := round(greatest(h.expected, 0) * coalesce(pct, 10) / 100);
    select coalesce(sum(w.amount), 0) into already
      from wallet_entries w join trips t on t.id = w.trip_id where t.shift_id = h.shift_id;
    adj := share - already;
    if adj <> 0 then
      insert into wallet_entries (driver_id, owner_id, hand_in_id, kind, amount, day, note)
      values (h.driver_id, own, h.id, 'earn', adj, h.day,
              'Day adjusted: ' || trim_scale(coalesce(pct, 10)) || '% of K' || to_char(greatest(h.expected, 0), 'FM999,999,990') || ' after expenses')
      on conflict (hand_in_id) do nothing;
      perform notify(h.driver_id,
        case when adj > 0 then '+ K' || to_char(adj, 'FM999,999,990') else '− K' || to_char(-adj, 'FM999,999,990') end || ' wallet adjustment',
        'Hand-in for ' || to_char(h.day, 'Dy DD Mon') || ' confirmed. Your share is worked out after expenses.', 'wallet', h.id);
    end if;
  end if;
  if h.received < h.expected then
    select coalesce(full_name, email) into who from profiles where id = h.driver_id;
    insert into alerts (kind, truck_id, driver_id, shift_id, ref_id, title, detail)
    values ('cash_short', h.truck_id, h.driver_id, h.shift_id, h.id, 'Cash short · K' || to_char(h.expected - h.received, 'FM999,999,990'),
            who || ' handed in K' || to_char(h.received, 'FM999,999,990') || ' of K' || to_char(h.expected, 'FM999,999,990')
            || coalesce(' · ' || h.note, ''));
  end if;
end;
$$;

-- trips already completed whose day is not confirmed yet: credit them now
insert into wallet_entries (driver_id, owner_id, trip_id, kind, amount, day, note)
select t.driver_id, tr.owner_id, t.id, 'earn',
       round(greatest(t.total, 0) * coalesce((select wallet_pct from app_settings where id = 1), 10) / 100),
       t.started_at::date,
       'Trip #' || t.trip_no || ' · ' || trim_scale(coalesce((select wallet_pct from app_settings where id = 1), 10)) || '% of K' || to_char(t.total, 'FM999,999,990')
from trips t join trucks tr on tr.id = t.truck_id
where t.status = 'completed' and t.total > 0
  and not exists (select 1 from hand_ins h where h.shift_id = t.shift_id and h.received is not null)
on conflict (trip_id) do nothing;

-- tidy notes written as "10.00%"
update wallet_entries set note = regexp_replace(note, '(\d+)\.00%', '\1%') where note ~ '\d+\.00%';
