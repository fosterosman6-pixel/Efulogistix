-- v71: the driver adds a walk-in passenger at a depot. The walk-in is saved as a seat booking that is already on board,
-- on the trip's own road only (no change of car). Seats, the road-ordered stops list, earnings and fees then work as for any booking.
-- Safe to run twice.
begin;

-- today's departures a driver can load for: their vehicle type, going from the depot side they choose
create or replace function public.driver_walkin_departures(p_day date)
returns table (departure_id uuid, leaves_at time, from_name text, to_name text, seats int, booked int)
language plpgsql stable security definer set search_path = public as $$
declare tk trucks%rowtype;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.* into tk from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  if tk.id is null then raise exception 'NO_VEHICLE'; end if;
  return query
    select d.id, d.leaves_at, r.from_name, r.to_name, s.seats::int, s.booked::int
      from departures d join routes r on r.id = d.route_id
      join departure_seats(p_day) s on s.departure_id = d.id
     where d.active and r.active and r.corridor_id is not null and r.through and r.category_id = tk.category_id
       and extract(isodow from p_day)::int = any (d.days)
     order by d.leaves_at, r.from_name;
end $$;

-- what the walk-in screen needs for one departure: seats left and the depots in the car's direction of travel
create or replace function public.driver_walkin_info(p_departure uuid, p_day date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare d departures%rowtype; r routes%rowtype; lo int; hi int; fwd boolean; s record; cap int; taken int; stops jsonb;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into d from departures where id = p_departure and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  fwd := lo < hi;
  select s2.seats, s2.booked into s from departure_seats(p_day) s2 where s2.departure_id = d.id;
  select coalesce(jsonb_agg(jsonb_build_object('pos', cs.pos, 'name', cs.place_name, 'can_board', cs.can_board, 'can_drop', cs.can_drop,
                                               'lat', cs.lat, 'lng', cs.lng)
                           order by case when fwd then cs.pos else -cs.pos end), '[]'::jsonb)
    into stops from corridor_stops cs where cs.corridor_id = r.corridor_id;
  return jsonb_build_object('corridor_id', r.corridor_id, 'category_id', r.category_id, 'forward', fwd,
                            'from_name', r.from_name, 'to_name', r.to_name, 'leaves_at', d.leaves_at,
                            'seats', coalesce(s.seats, 0), 'booked', coalesce(s.booked, 0),
                            'seats_left', greatest(coalesce(s.seats, 0) - coalesce(s.booked, 0), 0), 'stops', stops);
end $$;

-- add the walk-in: p = {departure_id, travel_on, from_pos, to_pos, seats, pay_method, pay_reference, phone}
create or replace function public.driver_add_walkin(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype; tk trucks%rowtype; d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  lo int; hi int; fwd boolean; fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int; n int := coalesce((p ->> 'seats')::int, 1);
  day date := (p ->> 'travel_on')::date; q record; cap int; taken int; pay text := coalesce(nullif(p ->> 'pay_method', ''), 'cash');
  ref text := nullif(trim(p ->> 'pay_reference'), ''); tr trips%rowtype; bid uuid; bno bigint;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into me from profiles where id = auth.uid();
  select * into tk from trucks where id = me.truck_id;
  if tk.id is null then raise exception 'NO_VEHICLE'; end if;
  if pay not in ('cash', 'airtel_money', 'tnm_mpamba') then raise exception 'BAD_PAY'; end if;
  if pay <> 'cash' and ref is null then raise exception 'REFERENCE_REQUIRED'; end if;
  if n < 1 or n > 20 then raise exception 'SEATS_REQUIRED'; end if;

  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null or day is null or not (extract(isodow from day)::int = any (d.days)) then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active and corridor_id is not null;
  if r.id is null or r.category_id is distinct from tk.category_id then raise exception 'NOT_YOUR_VEHICLE_TYPE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  fwd := lo < hi;
  if fp is null or tp is null or (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  -- seats: same count as for booked passengers (every seat booking not finished or cancelled)
  cap := coalesce(d.seats, tk.seats, (select c.seats from vehicle_categories c where c.id = r.category_id), 0);
  select coalesce(sum(x.seats), 0) into taken from bookings x
   where x.departure_id = d.id and x.travel_on = day and x.kind = 'seat' and x.status in ('requested', 'assigned', 'picked_up');
  if taken + n > cap then raise exception 'FULL:%', greatest(cap - taken, 0); end if;

  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  insert into bookings (kind, passenger_id, caller_name, caller_phone, pay_method, pay_reference, status, driver_id, truck_id,
                        departure_id, route_id, category_id, travel_on, pickup_at, picked_up_at, assigned_at, trip_id, seats,
                        pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, km, price, leg, note)
  values ('seat', null, 'Walk-in', nullif(trim(p ->> 'phone'), ''), pay, ref, 'picked_up', auth.uid(), tk.id,
          d.id, r.id, r.category_id, day, now(), now(), now(), tr.id, n,
          fs.place_name, fs.lat, fs.lng, ts.place_name, ts.lat, ts.lng, q.km, q.fare * n, 0, 'Walk-in added by the driver')
  returning id, booking_no into bid, bno;

  if tr.id is not null and pay = 'cash' then
    insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
    values (tr.id, 'Booking #' || bno || ' · Walk-in', 0, n, q.fare, '[]'::jsonb, 0);
  end if;
  return bid;
end $$;

revoke all on function public.driver_walkin_departures(date), public.driver_walkin_info(uuid, date), public.driver_add_walkin(jsonb) from public, anon;
grant execute on function public.driver_walkin_departures(date), public.driver_walkin_info(uuid, date), public.driver_add_walkin(jsonb) to authenticated;

commit;
