-- v72: one car carries passengers, walk-ins and parcels on the same trip.
-- A large parcel takes seats off the count: each parcel item has "seats_used" (0 = takes none). Set it in SQL with goods_set_seats.
-- Seats left = car seats - booked seats - walk-ins - seats used by parcels. Passengers, walk-ins and parcels are all refused when it is full.
-- Safe to run twice.
begin;

alter table public.goods_prices add column if not exists seats_used int not null default 0 check (seats_used >= 0);
-- starting values: the big items take one seat each (change with goods_set_seats)
update public.goods_prices set seats_used = 1 where label in ('Mattress', 'Bicycle', 'Large box / drum') and seats_used = 0;

create or replace function public.goods_set_seats(p_label text, p_seats int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  update goods_prices set seats_used = greatest(p_seats, 0), updated_at = now() where label = p_label;
  if not found then raise exception 'No parcel item called "%"', p_label; end if;
end $$;
revoke all on function public.goods_set_seats(text, int) from public, anon;
grant execute on function public.goods_set_seats(text, int) to authenticated;

-- seats a parcel booking's items use
create or replace function public._goods_seats(p_goods jsonb)
returns int language sql stable security definer set search_path = public as $$
  select coalesce(sum(coalesce((e ->> 'qty')::int, 0) * coalesce(g.seats_used, 0)), 0)::int
    from jsonb_array_elements(coalesce(p_goods, '[]'::jsonb)) e left join goods_prices g on g.label = e ->> 'label';
$$;

-- seats taken on one departure and day: passengers + walk-ins + seats used by parcels
create or replace function public._departure_taken(p_departure uuid, p_day date)
returns int language sql stable security definer set search_path = public as $$
  select coalesce(sum(case when b.kind = 'seat' then b.seats else _goods_seats(b.goods) end), 0)::int
    from bookings b where b.departure_id = p_departure and b.travel_on = p_day
     and b.kind in ('seat', 'goods') and b.status in ('requested', 'assigned', 'picked_up');
$$;

create or replace function public.departure_seats(p_day date)
returns table (departure_id uuid, seats int, booked int)
language sql stable security definer set search_path = public as $$
  select d.id, coalesce(d.seats, c.seats, 0), _departure_taken(d.id, p_day)
  from departures d join routes r on r.id = d.route_id left join vehicle_categories c on c.id = r.category_id
  where d.active and r.active;
$$;

-- one check for every way a booking is made (app, office, walk-in)
create or replace function public.check_car_full() returns trigger language plpgsql security definer set search_path = public as $$
declare need int; cap int; taken int;
begin
  if new.departure_id is null or new.travel_on is null or new.kind not in ('seat', 'goods') then return new; end if;
  if new.status not in ('requested', 'assigned', 'picked_up') then return new; end if;
  need := case when new.kind = 'seat' then new.seats else _goods_seats(new.goods) end;
  if need <= 0 then return new; end if;
  select coalesce(d.seats, c.seats, 0) into cap from departures d join routes r on r.id = d.route_id
    left join vehicle_categories c on c.id = r.category_id where d.id = new.departure_id;
  taken := _departure_taken(new.departure_id, new.travel_on)
           - case when tg_op = 'UPDATE' and old.status in ('requested', 'assigned', 'picked_up') then
               case when old.kind = 'seat' then old.seats else _goods_seats(old.goods) end else 0 end;
  if taken + need > coalesce(cap, 0) then raise exception 'FULL:%', greatest(coalesce(cap, 0) - taken, 0); end if;
  return new;
end $$;
drop trigger if exists bookings_car_full on public.bookings;
create trigger bookings_car_full before insert on public.bookings for each row execute function public.check_car_full();

-- the driver's walk-in screen counts the same way
create or replace function public.driver_add_walkin(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype; tk trucks%rowtype; d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  lo int; hi int; fwd boolean; fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int; n int := coalesce((p ->> 'seats')::int, 1);
  day date := (p ->> 'travel_on')::date; q record; pay text := coalesce(nullif(p ->> 'pay_method', ''), 'cash');
  ref text := nullif(trim(p ->> 'pay_reference'), ''); tr trips%rowtype; bid uuid; bno bigint;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into me from profiles where id = auth.uid();
  select * into tk from trucks where id = me.truck_id;
  if tk.id is null then raise exception 'NO_VEHICLE'; end if;
  if pay not in ('cash', 'airtel_money', 'tnm_mpamba') then raise exception 'BAD_PAY'; end if;
  if pay <> 'cash' and ref is null then raise exception 'REFERENCE_REQUIRED'; end if;
  if n < 1 or n > 20 then raise exception 'SEATS_REQUIRED'; end if;

  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null or day is null or not (extract(isodow from day)::int = any (d.days)) then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active and corridor_id is not null;
  if r.id is null or r.category_id is distinct from tk.category_id then raise exception 'NOT_YOUR_VEHICLE_TYPE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  fwd := lo < hi;
  if fp is null or tp is null or (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  -- the check_car_full trigger refuses the booking (FULL:n) when the car has no room, parcels included
  insert into bookings (kind, passenger_id, caller_name, caller_phone, pay_method, pay_reference, status, driver_id, truck_id,
                        departure_id, route_id, category_id, travel_on, pickup_at, picked_up_at, assigned_at, trip_id, seats,
                        pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, km, price, leg, note)
  values ('seat', null, 'Walk-in', nullif(trim(p ->> 'phone'), ''), pay, ref, 'picked_up', auth.uid(), tk.id,
          d.id, r.id, r.category_id, day, now(), now(), now(), tr.id, n,
          fs.place_name, fs.lat, fs.lng, ts.place_name, ts.lat, ts.lng, q.km, q.fare * n, 0, 'Walk-in added by the driver')
  returning id, booking_no into bid, bno;

  if tr.id is not null and pay = 'cash' then
    insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
    values (tr.id, 'Booking #' || bno || ' · Walk-in', 0, n, q.fare, '[]'::jsonb, 0);
  end if;
  return bid;
end $$;

commit;

-- EXAMPLES
-- select goods_set_seats('Mattress', 2);      -- a mattress takes 2 seats
-- select goods_set_seats('Bicycle', 0);       -- a bicycle takes none
-- select label, price, seats_used from goods_prices order by price;
