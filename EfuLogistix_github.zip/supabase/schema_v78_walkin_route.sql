-- v78: walk-ins follow the route the driver started. From the running trip (pickup depot to destination depot) this finds the road,
-- the direction, the stretch of road the trip covers, and the scheduled departure of that road nearest to now for the driver's vehicle type.
-- Walk-ins then board and get off only on that stretch. Returns nothing when there is no running trip or no matching road,
-- and the app falls back to the departure list. Safe to run twice.
begin;

create or replace function public._stop_pos(p_corridor uuid, p_name text) returns int
language plpgsql stable security definer set search_path = public as $$
declare pos_ int; n int;
begin
  select min(pos) into pos_ from corridor_stops where corridor_id = p_corridor and lower(trim(place_name)) = lower(trim(p_name));
  if pos_ is not null then return pos_; end if;
  if length(trim(p_name)) < 3 then return null; end if;
  select min(pos), count(distinct place_name) into pos_, n from corridor_stops
   where corridor_id = p_corridor and lower(place_name) like lower(trim(p_name)) || '%';
  return case when n = 1 then pos_ else null end;
end $$;

create or replace function public.driver_walkin_route(p_day date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare tr trips%rowtype; tk trucks%rowtype; c record; b_id uuid; b_fp int; b_tp int; fp int; tp int; fwd boolean; dep record;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.* into tk from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress' order by started_at desc limit 1;
  if tk.id is null or tr.id is null then return null; end if;

  -- the shortest road that has both the pickup depot and the destination depot
  for c in select id from route_corridors loop
    fp := _stop_pos(c.id, tr.pickup_name); tp := _stop_pos(c.id, tr.dest_name);
    if fp is not null and tp is not null and fp <> tp then
      if b_id is null or abs(tp - fp) < abs(b_tp - b_fp) then
        b_id := c.id; b_fp := fp; b_tp := tp;
      end if;
    end if;
  end loop;
  if b_id is null then return null; end if;
  fwd := b_fp < b_tp;

  -- the through departure of that road in the trip's direction, nearest to the time now
  select d.id as id, d.leaves_at into dep
    from departures d join routes r on r.id = d.route_id
   where d.active and r.active and r.corridor_id = b_id and r.through and r.category_id = tk.category_id
     and extract(isodow from p_day)::int = any (d.days)
     and (_stop_pos(b_id, r.from_name) < _stop_pos(b_id, r.to_name)) = fwd
   order by abs(extract(epoch from (d.leaves_at - (now() at time zone 'Africa/Blantyre')::time))) limit 1;
  if dep.id is null then return null; end if;
  return jsonb_build_object('departure_id', dep.id, 'from_pos', b_fp, 'to_pos', b_tp,
                            'from_name', tr.pickup_name, 'to_name', tr.dest_name);
end $$;

revoke all on function public._stop_pos(uuid, text), public.driver_walkin_route(date) from public, anon;
grant execute on function public.driver_walkin_route(date) to authenticated;
commit;
