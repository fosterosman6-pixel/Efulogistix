-- EfuLogistix: database update v8  (run AFTER schema_v7.sql)
--   1. QR boarding tickets      2. Reminders (papers, insurance, servicing)      3. Share-my-trip link
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice: it only adds.

-- ====================================================================================
-- 1. QR BOARDING TICKETS
-- The passenger's booking shows a QR code (and the same 8 digits). The driver scans it, or types the digits.
-- ====================================================================================
create table if not exists public.booking_tickets (
  booking_id uuid primary key references public.bookings (id) on delete cascade,
  code text not null,
  created_at timestamptz not null default now()
);
create index if not exists booking_tickets_code_idx on public.booking_tickets (code);

-- Passenger (own booking): get the ticket code, made the first time
create or replace function public.my_ticket(p_booking uuid)
returns text language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; c text;
begin
  select * into b from bookings where id = p_booking and (passenger_id = auth.uid() or is_owner());
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if b.status not in ('requested', 'assigned', 'picked_up') then raise exception 'NO_TICKET'; end if;
  select code into c from booking_tickets where booking_id = b.id;
  if c is null then
    c := lpad((floor(random() * 100000000))::bigint::text, 8, '0');
    insert into booking_tickets (booking_id, code) values (b.id, c)
    on conflict (booking_id) do nothing;
    select code into c from booking_tickets where booking_id = b.id;
  end if;
  return c;
end $$;

-- Driver: scan or type the code -> that passenger is marked on board
create or replace function public.board_by_code(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare cd text := regexp_replace(coalesce(p_code, ''), '\D', '', 'g'); b bookings%rowtype; who text;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  if length(cd) <> 8 then raise exception 'BAD_CODE'; end if;
  select b2.* into b from bookings b2 join booking_tickets t on t.booking_id = b2.id
   where t.code = cd and b2.driver_id = auth.uid() and b2.status in ('assigned', 'picked_up')
   order by b2.pickup_at limit 1;
  if b.id is null then raise exception 'NO_TICKET'; end if;
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if b.status = 'picked_up' then
    return jsonb_build_object('booking_no', b.booking_no, 'name', who, 'seats', b.seats, 'already', true);
  end if;
  perform booking_step(b.id, 'picked_up', null, null);
  return jsonb_build_object('booking_no', b.booking_no, 'name', who, 'seats', b.seats, 'already', false);
end $$;

-- ====================================================================================
-- 2. REMINDERS: papers, insurance, servicing  (a push + inbox message, once per stage)
-- ====================================================================================
create table if not exists public.reminder_log (
  key text primary key,
  sent_at timestamptz not null default now()
);

create or replace function public._bucket(d int) returns int language sql immutable as $$
  select case when d <= 0 then 0 when d <= 7 then 7 when d <= 14 then 14 when d <= 30 then 30 end;
$$;

create or replace function public.send_reminders()
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; k text; msg text; bk int; who uuid; label text;
begin
  -- truck papers (insurance, certificate of fitness)
  for r in
    select t.id, t.plate, t.owner_id, x.kind, x.due
    from trucks t
    cross join lateral (values ('Insurance', t.insurance_to), ('Certificate of fitness', t.cof_to)) as x(kind, due)
    where t.active and x.due is not null and x.due <= current_date + 30
  loop
    bk := _bucket((r.due - current_date)::int);
    k := 'truck:' || r.id || ':' || r.kind || ':' || r.due || ':' || bk;
    if exists (select 1 from reminder_log where key = k) then continue; end if;
    insert into reminder_log (key) values (k);
    msg := r.kind || ' for ' || r.plate || case when r.due < current_date then ' ran out on ' else ' runs out on ' end
           || to_char(r.due, 'DD Mon YYYY') || '.';
    for who in select owner_id from trucks where id = r.id and owner_id is not null
               union select id from profiles where truck_id = r.id and role = 'driver' and active loop
      perform notify(who, case when r.due < current_date then 'EXPIRED · ' else 'Renew soon · ' end || r.kind, msg, 'reminder', null);
      n := n + 1;
    end loop;
  end loop;

  -- driver papers (latest approved one of each kind)
  for r in
    select distinct on (d.driver_id, d.kind) d.driver_id, d.kind, d.expires_on, p.truck_id, p.full_name
    from documents d join profiles p on p.id = d.driver_id
    where d.driver_id is not null and d.status = 'approved' and d.expires_on is not null and p.active
    order by d.driver_id, d.kind, d.expires_on desc
  loop
    if r.expires_on > current_date + 30 then continue; end if;
    bk := _bucket((r.expires_on - current_date)::int);
    k := 'doc:' || r.driver_id || ':' || r.kind || ':' || r.expires_on || ':' || bk;
    if exists (select 1 from reminder_log where key = k) then continue; end if;
    insert into reminder_log (key) values (k);
    label := replace(initcap(replace(r.kind, '_', ' ')), 'Prdp', 'PrDP');
    msg := label || case when r.expires_on < current_date then ' ran out on ' else ' runs out on ' end
           || to_char(r.expires_on, 'DD Mon YYYY') || '. Upload the new one in the app.';
    perform notify(r.driver_id, case when r.expires_on < current_date then 'EXPIRED · ' else 'Renew soon · ' end || label, msg, 'reminder', null);
    n := n + 1;
    if r.truck_id is not null then
      perform notify((select owner_id from trucks where id = r.truck_id), 'Driver paper · ' || label,
                     r.full_name || ': ' || msg, 'reminder', null);
    end if;
  end loop;

  -- oil change due (within 500 km, or past)
  for r in
    select t.id, t.plate, t.owner_id, t.current_km, t.last_oil_km, t.oil_interval_km
    from trucks t
    where t.active and t.current_km is not null and t.last_oil_km is not null
      and t.current_km >= t.last_oil_km + t.oil_interval_km - 500
  loop
    k := 'oil:' || r.id || ':' || r.last_oil_km;
    if exists (select 1 from reminder_log where key = k) then continue; end if;
    insert into reminder_log (key) values (k);
    msg := r.plate || ' needs an oil change ' ||
           case when r.current_km >= r.last_oil_km + r.oil_interval_km
                then '(' || (r.current_km - r.last_oil_km - r.oil_interval_km) || ' km overdue).'
                else 'in about ' || (r.last_oil_km + r.oil_interval_km - r.current_km) || ' km.' end;
    for who in select owner_id from trucks where id = r.id and owner_id is not null
               union select id from profiles where truck_id = r.id and role = 'driver' and active loop
      perform notify(who, 'Service due · ' || r.plate, msg, 'reminder', null);
      n := n + 1;
    end loop;
  end loop;

  delete from reminder_log where sent_at < now() - interval '2 years';
  return n;
end $$;

-- Admin button / manual run
create or replace function public.run_reminders() returns int
language plpgsql security definer set search_path = public as $$
begin
  if not (is_admin() or is_owner()) then raise exception 'NOT_ALLOWED'; end if;
  return send_reminders();
end $$;

-- every morning 07:00 Malawi time (05:00 UTC), if the database has the pg_cron add-on (Supabase: Database > Extensions > pg_cron)
do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule('efu-reminders') where exists (select 1 from cron.job where jobname = 'efu-reminders');
  perform cron.schedule('efu-reminders', '0 5 * * *', 'select public.send_reminders()');
exception when others then
  raise notice 'pg_cron not available: switch it on under Database > Extensions, then run this file again. (%)', sqlerrm;
end $$;

-- ====================================================================================
-- 3. SHARE MY TRIP: a link anyone can open (no login) while the trip is running
-- ====================================================================================
alter table public.app_settings add column if not exists share_base_url text
  not null default 'https://fosterosman6-pixel.github.io/Efulogistix/share/';

create table if not exists public.trip_shares (
  token text primary key,
  booking_id uuid not null references public.bookings (id) on delete cascade,
  created_by uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists trip_shares_booking_idx on public.trip_shares (booking_id);

-- Passenger: make (or reuse) a link for an assigned / running booking
create or replace function public.share_trip(p_booking uuid)
returns text language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tk text; base text;
begin
  select * into b from bookings where id = p_booking and passenger_id = auth.uid();
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if b.status not in ('assigned', 'picked_up') then raise exception 'NOT_RUNNING'; end if;
  select token into tk from trip_shares where booking_id = b.id order by created_at desc limit 1;
  if tk is null then
    tk := replace(gen_random_uuid()::text, '-', '');
    insert into trip_shares (token, booking_id) values (tk, b.id);
  end if;
  select share_base_url into base from app_settings where id = 1;
  return rtrim(base, '?') || '?t=' || tk;
end $$;

-- Passenger: stop sharing
create or replace function public.stop_sharing(p_booking uuid)
returns void language sql security definer set search_path = public as $$
  delete from trip_shares where booking_id = p_booking
    and exists (select 1 from bookings b where b.id = p_booking and b.passenger_id = auth.uid());
$$;

-- Anyone with the link: where is the car? Shows only what a family member needs.
create or replace function public.shared_trip(p_token text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare b bookings%rowtype; t trucks%rowtype; l truck_locations%rowtype; drv text; pax text;
begin
  select b2.* into b from bookings b2 join trip_shares s on s.booking_id = b2.id where s.token = p_token;
  if b.id is null then return jsonb_build_object('state', 'invalid'); end if;
  if b.status in ('completed', 'cancelled', 'no_show', 'declined') then
    return jsonb_build_object('state', 'ended', 'status', b.status);
  end if;
  if b.status = 'requested' or b.truck_id is null then
    return jsonb_build_object('state', 'waiting', 'pickup', b.pickup_name, 'dest', b.dest_name);
  end if;
  select * into t from trucks where id = b.truck_id;
  select * into l from truck_locations where truck_id = b.truck_id;
  select split_part(full_name, ' ', 1) into drv from profiles where id = b.driver_id;
  select split_part(full_name, ' ', 1) into pax from profiles where id = b.passenger_id;
  return jsonb_build_object(
    'state', case when b.status = 'picked_up' then 'on_trip' else 'coming' end,
    'passenger', pax, 'driver', drv, 'plate', t.plate,
    'vehicle', trim(coalesce(t.colour, '') || ' ' || coalesce(t.make, '')),
    'pickup', b.pickup_name, 'dest', b.dest_name,
    'pickup_lat', b.pickup_lat, 'pickup_lng', b.pickup_lng, 'dest_lat', b.dest_lat, 'dest_lng', b.dest_lng,
    'lat', l.lat, 'lng', l.lng, 'updated_at', l.updated_at);
end $$;

-- ====================================================================================
-- SECURITY AND ACCESS
-- ====================================================================================
alter table public.booking_tickets enable row level security;
alter table public.reminder_log enable row level security;
alter table public.trip_shares enable row level security;
revoke all on public.booking_tickets, public.reminder_log, public.trip_shares from authenticated, anon;
grant all on public.booking_tickets, public.reminder_log, public.trip_shares to service_role;

grant execute on function public.my_ticket(uuid) to authenticated;
grant execute on function public.board_by_code(text) to authenticated;
grant execute on function public.run_reminders() to authenticated;
grant execute on function public.share_trip(uuid) to authenticated;
grant execute on function public.stop_sharing(uuid) to authenticated;
grant execute on function public.shared_trip(text) to anon, authenticated;
revoke execute on function public.send_reminders() from public, anon, authenticated;
revoke execute on function public._bucket(int) from public, anon, authenticated;
