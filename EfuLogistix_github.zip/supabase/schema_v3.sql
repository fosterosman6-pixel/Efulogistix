-- EfuLogistix: database update v3
-- Run AFTER schema.sql and schema_v2.sql. Safe on a database with data: it only adds.
-- Supabase > SQL Editor > New query > paste all > Run.
--
-- What v3 adds
--   * passengers: book a seat on a route, hire a whole car (per km), send goods with a receiver code
--   * company monthly accounts for passengers
--   * vehicle owners upload their own vehicles, photos and papers; the admin checks before it goes on the road
--   * drivers wait for a vehicle; the manager (admin panel) matches them and sets an office meeting
--   * daily money goes straight to the vehicle owner, who confirms it
--   * driver wallet: 10% of each day's money after expenses, paid out by the owner every Monday
--   * EfuLogistix fee: weekly, monthly or per trip, price per category set by the admin
--   * full GPS trail (uploaded later when there was no signal), "tracking stopped" alert
--   * messages to people (notices) and a profile picture
--
-- Phone app = passengers, drivers, vehicle owners. Admin and managers use the web admin panel.

-- ====================================================================================
-- ROLES: add passenger
-- ====================================================================================
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'profiles_role_check' and pg_get_constraintdef(oid) like '%passenger%'
  ) then
    alter table public.profiles drop constraint if exists profiles_role_check;
    alter table public.profiles add constraint profiles_role_check
      check (role in ('admin', 'manager', 'owner', 'driver', 'passenger'));
  end if;
end $$;

-- company monthly accounts (a business whose staff book and pay once a month)
create table if not exists public.company_accounts (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  contact_name text,
  phone text,
  email text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists avatar_path text;
alter table public.profiles add column if not exists account_id uuid references public.company_accounts (id) on delete set null;
alter table public.profiles add column if not exists no_shows int not null default 0;

create or replace function public.is_vehicle_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'owner' and active);
$$;

create or replace function public.is_passenger()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'passenger' and active);
$$;

-- Sign-up: the app sends the chosen role (passenger, driver or owner).
-- Passengers and vehicle owners can start at once (the admin checks every vehicle anyway).
-- Drivers wait for the admin to approve them. Managers and admins are only made by the admin.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  inv invites%rowtype;
  asked text := lower(coalesce(new.raw_user_meta_data ->> 'role', 'driver'));
  r text;
begin
  select * into inv from invites where lower(email) = lower(new.email) and used_by is null limit 1;
  r := coalesce(inv.role, case when asked in ('passenger', 'driver', 'owner') then asked else 'driver' end);
  insert into profiles (id, email, full_name, phone, role, active, truck_id)
  values (new.id, new.email,
          coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), inv.full_name),
          coalesce(nullif(new.raw_user_meta_data ->> 'phone', ''), inv.phone),
          r,
          inv.id is not null or r in ('passenger', 'owner'),
          inv.truck_id);
  if inv.id is not null then
    update invites set used_by = new.id, used_at = now() where id = inv.id;
  end if;
  return new;
end;
$$;

-- Database functions below change some protected fields on purpose; they switch this on for that moment.
create or replace function public.system_on()
returns void language sql as $$ select set_config('efu.system', 'on', true); $$;
revoke execute on function public.system_on() from public, anon, authenticated;

create or replace function public.protect_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or is_admin() or coalesce(current_setting('efu.system', true), '') = 'on' then
    return new;
  end if;
  new.role := old.role;              -- only the admin changes roles
  new.active := old.active;          -- only the admin approves or blocks
  new.account_id := old.account_id;  -- only the office links a company account
  new.no_shows := old.no_shows;
  if not is_owner() then
    new.truck_id := old.truck_id;    -- managers assign vehicles (after the office meeting)
  end if;
  return new;
end;
$$;

-- ====================================================================================
-- SETTINGS
-- ====================================================================================
alter table public.app_settings add column if not exists wallet_pct numeric(5, 2) not null default 10;
alter table public.app_settings add column if not exists office_phone text not null default '';
alter table public.app_settings add column if not exists office_place text not null default 'EfuLogistix office, Mangochi';
alter table public.app_settings add column if not exists max_open_bookings int not null default 5;
alter table public.app_settings add column if not exists stop_min_seconds int not null default 120;
alter table public.app_settings add column if not exists stop_speed_kmh numeric(5, 1) not null default 5;

-- ====================================================================================
-- MESSAGES TO PEOPLE (shown under the bell in the phone app)
-- ====================================================================================
create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  body text,
  kind text,
  ref_id uuid,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notices_user_idx on public.notices (user_id, created_at desc);

create or replace function public.notify(p_user uuid, p_title text, p_body text, p_kind text default null, p_ref uuid default null)
returns void language sql security definer set search_path = public as $$
  insert into notices (user_id, title, body, kind, ref_id)
  select p_user, p_title, p_body, p_kind, p_ref where p_user is not null;
$$;
revoke execute on function public.notify(uuid, text, text, text, uuid) from public, anon, authenticated;

-- ====================================================================================
-- VEHICLE CATEGORIES: hire rates and EfuLogistix fees (admin sets)
-- ====================================================================================
alter table public.vehicle_categories add column if not exists hire_per_km numeric(12, 2) not null default 0;
alter table public.vehicle_categories add column if not exists hire_min numeric(12, 2) not null default 0;
alter table public.vehicle_categories add column if not exists fee_weekly numeric(12, 2) not null default 0;
alter table public.vehicle_categories add column if not exists fee_monthly numeric(12, 2) not null default 0;
alter table public.vehicle_categories add column if not exists fee_per_trip numeric(12, 2) not null default 0;

-- ====================================================================================
-- VEHICLES SENT BY OWNERS
-- ====================================================================================
alter table public.trucks add column if not exists status text not null default 'approved';
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'trucks_status_check') then
    alter table public.trucks add constraint trucks_status_check check (status in ('pending', 'approved', 'rejected'));
  end if;
end $$;
alter table public.trucks add column if not exists make text;
alter table public.trucks add column if not exists colour text;
alter table public.trucks add column if not exists year int;
alter table public.trucks add column if not exists photos text[] not null default '{}';
alter table public.trucks add column if not exists submitted_at timestamptz;
alter table public.trucks add column if not exists review_note text;
alter table public.trucks add column if not exists reviewed_by uuid references public.profiles (id);
alter table public.trucks add column if not exists reviewed_at timestamptz;
alter table public.trucks add column if not exists fee_plan text not null default 'monthly';
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'trucks_fee_plan_check') then
    alter table public.trucks add constraint trucks_fee_plan_check check (fee_plan in ('weekly', 'monthly', 'per_trip'));
  end if;
end $$;

-- What a vehicle owner may change on their own vehicle
create or replace function public.protect_truck()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or coalesce(current_setting('efu.system', true), '') = 'on'
     or not exists (select 1 from profiles where id = auth.uid() and role = 'owner') then
    return new;                                  -- admin, managers and the database functions
  end if;
  if tg_op = 'INSERT' then
    new.owner_id := auth.uid();
    new.status := 'pending';
    new.active := false;
    new.submitted_at := now();
    new.reviewed_by := null;
    new.reviewed_at := null;
    new.review_note := null;
    new.insurance_to := null;
    new.cof_to := null;
    return new;
  end if;
  new.owner_id := old.owner_id;
  new.status := old.status;
  new.active := old.active;
  new.reviewed_by := old.reviewed_by;
  new.reviewed_at := old.reviewed_at;
  new.review_note := old.review_note;
  new.insurance_to := old.insurance_to;
  new.cof_to := old.cof_to;
  new.current_km := old.current_km;
  new.last_oil_km := old.last_oil_km;
  new.last_oil_on := old.last_oil_on;
  if old.status = 'approved' then
    new.plate := old.plate;                      -- number plate and type are fixed once approved
    new.category_id := old.category_id;
  elsif old.status = 'rejected' then
    new.status := 'pending';                     -- owner fixed it: back to the admin
    new.submitted_at := now();
  end if;
  return new;
end;
$$;
drop trigger if exists protect_truck on public.trucks;
create trigger protect_truck before insert or update on public.trucks
  for each row execute function public.protect_truck();

drop policy if exists trucks_owner_insert on public.trucks;
create policy trucks_owner_insert on public.trucks for insert to authenticated
  with check (owner_id = auth.uid() and is_vehicle_owner());
drop policy if exists trucks_owner_update on public.trucks;
create policy trucks_owner_update on public.trucks for update to authenticated
  using (owner_id = auth.uid() and is_vehicle_owner()) with check (owner_id = auth.uid());
drop policy if exists trucks_owner_delete on public.trucks;
create policy trucks_owner_delete on public.trucks for delete to authenticated
  using (owner_id = auth.uid() and is_vehicle_owner() and status <> 'approved');

-- Admin: approve or send back a vehicle. Approving also approves the papers sent with it.
create or replace function public.review_truck(p_id uuid, p_approve boolean, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare t trucks%rowtype;
begin
  if not is_admin() then raise exception 'not allowed' using errcode = '42501'; end if;
  update trucks set status = case when p_approve then 'approved' else 'rejected' end,
    active = p_approve, review_note = nullif(p_note, ''), reviewed_by = auth.uid(), reviewed_at = now()
  where id = p_id returning * into t;
  if t.id is null then raise exception 'NOT_FOUND'; end if;
  if p_approve then
    update documents set status = 'approved', reviewed_by = auth.uid(), reviewed_at = now()
      where truck_id = p_id and status = 'pending';
    perform notify(t.owner_id, t.plate || ' is approved', 'Your vehicle can go on the road. The office will match a driver.', 'truck', t.id);
  else
    perform notify(t.owner_id, t.plate || ' needs changes', coalesce(nullif(p_note, ''), 'Please check the details and photos and send again.'), 'truck', t.id);
  end if;
end;
$$;

-- Vehicle papers sent by owners. A new paper waits for the admin; the vehicle keeps running meanwhile.
alter table public.documents drop constraint if exists documents_kind_check;
alter table public.documents add constraint documents_kind_check check (kind in (
  'national_id', 'licence', 'prdp', 'selfie', 'police_clearance', 'residence_letter', 'defensive_driving',
  'insurance', 'cof', 'blue_book', 'road_tax', 'other'));
drop policy if exists docs_insert on public.documents;
create policy docs_insert on public.documents for insert to authenticated
  with check (
    (driver_id = auth.uid() and truck_id is null and status = 'pending')
    or (driver_id is null and truck_id is not null and status = 'pending' and owns_truck(truck_id))
    or is_admin());

-- ====================================================================================
-- DRIVERS WAITING, OFFICE MEETINGS (manager in the admin panel)
-- ====================================================================================
create table if not exists public.driver_matches (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles (id) on delete cascade,
  truck_id uuid not null references public.trucks (id) on delete cascade,
  meet_at timestamptz not null,
  place text not null,
  status text not null default 'invited' check (status in ('invited', 'agreed', 'not_agreed', 'cancelled')),
  note text,
  created_by uuid references public.profiles (id) default auth.uid(),
  decided_by uuid references public.profiles (id),
  decided_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index if not exists matches_one_open_per_driver on public.driver_matches (driver_id) where status = 'invited';
create index if not exists matches_truck_idx on public.driver_matches (truck_id, created_at desc);

create or replace function public.match_driver(p_driver uuid, p_truck uuid, p_meet_at timestamptz, p_place text, p_note text)
returns uuid language plpgsql security definer set search_path = public as $$
declare d profiles%rowtype; t trucks%rowtype; mid uuid; when_txt text;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into d from profiles where id = p_driver;
  select * into t from trucks where id = p_truck;
  if d.id is null or d.role <> 'driver' or not d.active then raise exception 'NOT_A_DRIVER'; end if;
  if t.id is null or t.status <> 'approved' then raise exception 'TRUCK_NOT_APPROVED'; end if;
  if exists (select 1 from driver_matches where driver_id = p_driver and status = 'invited') then
    raise exception 'ALREADY_INVITED';
  end if;
  insert into driver_matches (driver_id, truck_id, meet_at, place, note)
  values (p_driver, p_truck, p_meet_at,
          coalesce(nullif(p_place, ''), (select office_place from app_settings where id = 1)), nullif(p_note, ''))
  returning id into mid;
  when_txt := to_char(p_meet_at at time zone 'Africa/Blantyre', 'Dy DD Mon, HH24:MI');
  perform notify(p_driver, 'Meet the owner of ' || t.plate,
    when_txt || ' at ' || coalesce(nullif(p_place, ''), 'the office') || '. Bring your licence and ID.', 'match', mid);
  perform notify(t.owner_id, 'Meet a driver for ' || t.plate,
    coalesce(d.full_name, d.email) || ' · ' || when_txt || ' at ' || coalesce(nullif(p_place, ''), 'the office') || '.', 'match', mid);
  return mid;
end;
$$;

-- After the meeting: Agreed gives the driver the vehicle; Not agreed puts the driver back in the waiting list.
create or replace function public.decide_match(p_id uuid, p_agreed boolean, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare m driver_matches%rowtype; t trucks%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into m from driver_matches where id = p_id for update;
  if m.id is null or m.status <> 'invited' then raise exception 'ALREADY_DECIDED'; end if;
  select * into t from trucks where id = m.truck_id;
  update driver_matches set status = case when p_agreed then 'agreed' else 'not_agreed' end,
    note = coalesce(nullif(p_note, ''), note), decided_by = auth.uid(), decided_at = now() where id = p_id;
  if p_agreed then
    update profiles set truck_id = m.truck_id where id = m.driver_id;
    perform notify(m.driver_id, 'You drive ' || t.plate || ' now', 'Start your shift from the app. Hand in the money to the owner each day.', 'match', m.id);
    perform notify(t.owner_id, (select coalesce(full_name, email) from profiles where id = m.driver_id) || ' drives ' || t.plate,
                   'The driver hands in each day''s money to you. Confirm it in Cash.', 'match', m.id);
  else
    perform notify(m.driver_id, 'Not matched with ' || t.plate, 'You stay on the waiting list. The office will find another vehicle.', 'match', m.id);
  end if;
end;
$$;

create or replace function public.cancel_match(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m driver_matches%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  update driver_matches set status = 'cancelled', decided_by = auth.uid(), decided_at = now()
    where id = p_id and status = 'invited' returning * into m;
  if m.id is null then raise exception 'ALREADY_DECIDED'; end if;
  perform notify(m.driver_id, 'Office meeting cancelled', 'The office will contact you with a new time.', 'match', m.id);
  perform notify((select owner_id from trucks where id = m.truck_id), 'Office meeting cancelled', null, 'match', m.id);
end;
$$;

-- Managers free a vehicle from a driver (driver goes back to the waiting list)
create or replace function public.unassign_driver(p_driver uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  if exists (select 1 from shifts where driver_id = p_driver and status = 'on_duty') then raise exception 'ON_DUTY'; end if;
  update profiles set truck_id = null where id = p_driver;
  perform notify(p_driver, 'Vehicle removed', 'You are back on the waiting list.', 'match', null);
end;
$$;

-- ====================================================================================
-- MONEY GOES TO THE VEHICLE OWNER · DRIVER WALLET
-- ====================================================================================
create table if not exists public.wallet_entries (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles (id) on delete cascade,
  owner_id uuid references public.profiles (id) on delete set null,   -- null = company vehicle (office pays)
  hand_in_id uuid unique references public.hand_ins (id) on delete cascade,
  kind text not null check (kind in ('earn', 'deduct', 'payout')),
  amount numeric(12, 2) not null,     -- earn is +, deduct and payout are −
  day date not null default current_date,
  method text,
  reference text,
  note text,
  created_by uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists wallet_driver_idx on public.wallet_entries (driver_id, created_at desc);
create index if not exists wallet_owner_idx on public.wallet_entries (owner_id, created_at desc);

-- Owner (own vehicles) or office (company vehicles): money received from the driver.
-- The first time it is received, the driver's share goes into the wallet.
create or replace function public.receive_hand_in(p_id uuid, p_amount numeric, p_method text, p_reference text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare h hand_ins%rowtype; first_time boolean; who text; own uuid; pct numeric; share numeric;
begin
  select * into h from hand_ins where id = p_id;
  if h.id is null then raise exception 'NOT_FOUND'; end if;
  if not (is_owner() or owns_truck(h.truck_id)) then raise exception 'not allowed' using errcode = '42501'; end if;
  first_time := h.received is null;
  update hand_ins set received = p_amount, method = coalesce(p_method, method), reference = coalesce(nullif(p_reference, ''), reference),
    note = nullif(p_note, ''), received_by = auth.uid(), received_at = now()
  where id = p_id returning * into h;
  select owner_id into own from trucks where id = h.truck_id;
  if first_time then
    select wallet_pct into pct from app_settings where id = 1;
    share := round(greatest(h.expected, 0) * coalesce(pct, 10) / 100);
    if share > 0 then
      insert into wallet_entries (driver_id, owner_id, hand_in_id, kind, amount, day, note)
      values (h.driver_id, own, h.id, 'earn', share, h.day,
              coalesce(pct, 10) || '% of K' || to_char(greatest(h.expected, 0), 'FM999,999,990'))
      on conflict (hand_in_id) do nothing;
      perform notify(h.driver_id, '+ K' || to_char(share, 'FM999,999,990') || ' in your wallet',
                     'Hand-in for ' || to_char(h.day, 'Dy DD Mon') || ' confirmed. Paid out on Monday.', 'wallet', h.id);
    end if;
  end if;
  if h.received < h.expected then
    select coalesce(full_name, email) into who from profiles where id = h.driver_id;
    insert into alerts (kind, truck_id, driver_id, shift_id, ref_id, title, detail)
    values ('cash_short', h.truck_id, h.driver_id, h.shift_id, h.id, 'Cash short · K' || to_char(h.expected - h.received, 'FM999,999,990'),
            who || ' handed in K' || to_char(h.received, 'FM999,999,990') || ' of K' || to_char(h.expected, 'FM999,999,990')
            || coalesce(' · ' || h.note, ''));
  end if;
end;
$$;

create or replace function public.decide_shortfall(p_id uuid, p_decision text)
returns void language plpgsql security definer set search_path = public as $$
declare h hand_ins%rowtype;
begin
  select * into h from hand_ins where id = p_id;
  if h.id is null or h.received is null then raise exception 'NOT_FOUND'; end if;
  if not (is_owner() or owns_truck(h.truck_id)) then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_decision not in ('accepted_as_expense', 'owed') then raise exception 'bad decision'; end if;
  update hand_ins set decision = p_decision where id = p_id;
  if p_decision = 'accepted_as_expense' and h.expected > h.received then
    insert into expenses (truck_id, created_by, category, amount, note, shift_id, paid_by, spent_at)
    values (h.truck_id, auth.uid(), 'other', h.expected - h.received, 'Shortfall accepted: ' || coalesce(h.note, ''),
            null, 'office', now());
  end if;
  update alerts set resolved = true where kind = 'cash_short' and ref_id = p_id;
end;
$$;

-- owners may add office expenses (repairs, tyres) for their own vehicles
drop policy if exists exp_insert on public.expenses;
create policy exp_insert on public.expenses for insert to authenticated
  with check (created_by = auth.uid() and (
    is_owner()
    or (owns_truck(truck_id) and paid_by = 'office')
    or (is_active_driver() and truck_id = my_truck() and paid_by = 'driver')));

-- Owner pays the driver's wallet (every Monday). A shortfall can be taken off first.
create or replace function public.pay_wallet(p_driver uuid, p_deduct numeric, p_method text, p_reference text, p_note text)
returns numeric language plpgsql security definer set search_path = public as $$
declare own uuid; bal numeric; ded numeric := greatest(coalesce(p_deduct, 0), 0); paid numeric;
begin
  if is_vehicle_owner() then own := auth.uid();
  elsif is_owner() then own := null;           -- office pays for company vehicles
  else raise exception 'not allowed' using errcode = '42501'; end if;
  select coalesce(sum(amount), 0) into bal from wallet_entries where driver_id = p_driver and owner_id is not distinct from own;
  if bal <= 0 then raise exception 'NOTHING_TO_PAY'; end if;
  if ded > bal then raise exception 'DEDUCT_TOO_BIG'; end if;
  if ded > 0 then
    insert into wallet_entries (driver_id, owner_id, kind, amount, note)
    values (p_driver, own, 'deduct', -ded, coalesce(nullif(p_note, ''), 'Shortfall taken off'));
  end if;
  paid := bal - ded;
  if paid > 0 then
    insert into wallet_entries (driver_id, owner_id, kind, amount, method, reference, note)
    values (p_driver, own, 'payout', -paid, coalesce(p_method, 'cash'), nullif(p_reference, ''), 'Paid out');
  end if;
  perform notify(p_driver, 'Wallet paid · K' || to_char(paid, 'FM999,999,990'),
    case when ded > 0 then 'K' || to_char(ded, 'FM999,999,990') || ' taken off: ' || coalesce(nullif(p_note, ''), 'shortfall') else 'Thank you for your work this week.' end,
    'wallet', null);
  return paid;
end;
$$;

-- ====================================================================================
-- EFULOGISTIX FEE (weekly, monthly or per trip; price per category set by the admin)
-- ====================================================================================
create table if not exists public.fee_bills (
  id uuid primary key default gen_random_uuid(),
  truck_id uuid not null references public.trucks (id) on delete cascade,
  owner_id uuid references public.profiles (id) on delete set null,
  plan text not null check (plan in ('weekly', 'monthly', 'per_trip')),
  period_start date not null,
  period_end date not null,
  trips int not null default 0,
  amount numeric(12, 2) not null,
  status text not null default 'due' check (status in ('due', 'paid', 'waived')),
  method text,
  reference text,
  reported_at timestamptz,          -- owner says "I paid, reference ..."
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  unique (truck_id, plan, period_start)
);
create index if not exists fee_bills_owner_idx on public.fee_bills (owner_id, period_start desc);

-- Office: make the bills for one week (weekly vehicles) or one month (monthly and per-trip vehicles)
create or replace function public.make_fee_bills(p_period text, p_day date)
returns int language plpgsql security definer set search_path = public as $$
declare s date; e date; n int := 0; k int;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_period = 'week' then
    s := date_trunc('week', p_day)::date; e := s + 6;
    insert into fee_bills (truck_id, owner_id, plan, period_start, period_end, amount)
    select t.id, t.owner_id, 'weekly', s, e, c.fee_weekly
    from trucks t join vehicle_categories c on c.id = t.category_id
    where t.status = 'approved' and t.fee_plan = 'weekly' and t.owner_id is not null and c.fee_weekly > 0
      and coalesce(t.reviewed_at, t.created_at)::date <= e
    on conflict do nothing;
    get diagnostics n = row_count;
  elsif p_period = 'month' then
    s := date_trunc('month', p_day)::date; e := (s + interval '1 month')::date - 1;
    insert into fee_bills (truck_id, owner_id, plan, period_start, period_end, amount)
    select t.id, t.owner_id, 'monthly', s, e, c.fee_monthly
    from trucks t join vehicle_categories c on c.id = t.category_id
    where t.status = 'approved' and t.fee_plan = 'monthly' and t.owner_id is not null and c.fee_monthly > 0
      and coalesce(t.reviewed_at, t.created_at)::date <= e
    on conflict do nothing;
    get diagnostics n = row_count;
    insert into fee_bills (truck_id, owner_id, plan, period_start, period_end, trips, amount)
    select t.id, t.owner_id, 'per_trip', s, e, x.trips, x.trips * c.fee_per_trip
    from trucks t join vehicle_categories c on c.id = t.category_id
    join lateral (
      select count(*)::int as trips from trips r
      where r.truck_id = t.id and r.status = 'completed'
        and (r.started_at at time zone 'Africa/Blantyre')::date between s and e
    ) x on true
    where t.status = 'approved' and t.fee_plan = 'per_trip' and t.owner_id is not null and c.fee_per_trip > 0 and x.trips > 0
    on conflict do nothing;
    get diagnostics k = row_count;
    n := n + k;
  else
    raise exception 'period must be week or month';
  end if;
  insert into notices (user_id, title, body, kind)
  select distinct b.owner_id, 'EfuLogistix fee', 'A new fee bill is ready. Open Cash > Fees.', 'fee'
  from fee_bills b where b.period_start = s and b.created_at > now() - interval '1 minute' and b.owner_id is not null;
  return n;
end;
$$;

-- Owner: "I paid this bill" (the office still confirms)
create or replace function public.report_fee_paid(p_id uuid, p_method text, p_reference text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update fee_bills set method = p_method, reference = nullif(p_reference, ''), reported_at = now()
  where id = p_id and owner_id = auth.uid() and status = 'due';
  if not found then raise exception 'NOT_FOUND'; end if;
end;
$$;

-- Office: confirm paid, or waive
create or replace function public.settle_fee(p_id uuid, p_status text, p_method text, p_reference text)
returns void language plpgsql security definer set search_path = public as $$
declare b fee_bills%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_status not in ('paid', 'waived', 'due') then raise exception 'bad status'; end if;
  update fee_bills set status = p_status, method = coalesce(nullif(p_method, ''), method),
    reference = coalesce(nullif(p_reference, ''), reference), paid_at = case when p_status = 'paid' then now() end
  where id = p_id returning * into b;
  if b.id is null then raise exception 'NOT_FOUND'; end if;
  if p_status = 'paid' then
    perform notify(b.owner_id, 'Fee received · K' || to_char(b.amount, 'FM999,999,990'), 'Thank you.', 'fee', b.id);
  end if;
end;
$$;

-- ====================================================================================
-- PASSENGER BOOKINGS
-- ====================================================================================
-- timetable: departures on a route (route = from, to, category, fare)
create table if not exists public.departures (
  id uuid primary key default gen_random_uuid(),
  route_id uuid not null references public.routes (id) on delete cascade,
  leaves_at time not null,
  days int[] not null default '{1,2,3,4,5,6,7}',   -- 1 = Monday ... 7 = Sunday
  seats int check (seats is null or seats > 0),   -- empty = the category's seats
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (route_id, leaves_at)
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_no bigint generated always as identity,
  passenger_id uuid references public.profiles (id) on delete set null,
  caller_name text,                   -- booked by the office for someone who phoned
  caller_phone text,
  kind text not null check (kind in ('seat', 'hire', 'goods')),
  category_id uuid references public.vehicle_categories (id),
  route_id uuid references public.routes (id) on delete set null,
  departure_id uuid references public.departures (id) on delete set null,
  travel_on date,
  pickup_at timestamptz not null,
  seats int not null default 0 check (seats >= 0),
  pickup_name text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  dest_name text not null,
  dest_lat double precision,
  dest_lng double precision,
  trip_type text check (trip_type in ('one_way', 'return', 'whole_day')),
  km numeric(8, 1),
  rate_per_km numeric(12, 2),
  goods jsonb not null default '[]'::jsonb,       -- [{ "label": "50 kg bag of maize", "qty": 4, "price": 1500 }]
  receiver_name text,
  receiver_phone text,
  price numeric(12, 2) not null default 0,
  final_price numeric(12, 2),
  pay_method text not null default 'cash' check (pay_method in ('cash', 'airtel_money', 'tnm_mpamba', 'account')),
  pay_reference text,
  account_id uuid references public.company_accounts (id) on delete set null,
  note text,                                      -- from the passenger
  status text not null default 'requested'
    check (status in ('requested', 'assigned', 'picked_up', 'completed', 'cancelled', 'no_show', 'declined')),
  truck_id uuid references public.trucks (id) on delete set null,
  driver_id uuid references public.profiles (id) on delete set null,
  trip_id uuid references public.trips (id) on delete set null,
  message text,                                   -- from the office to the passenger
  assigned_by uuid references public.profiles (id),
  assigned_at timestamptz,
  picked_up_at timestamptz,
  completed_at timestamptz,
  cancelled_at timestamptz,
  cancel_reason text,
  created_by uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists bookings_passenger_idx on public.bookings (passenger_id, pickup_at desc);
create index if not exists bookings_driver_idx on public.bookings (driver_id, status, pickup_at);
create index if not exists bookings_status_idx on public.bookings (status, pickup_at);
create index if not exists bookings_departure_idx on public.bookings (departure_id, travel_on);

-- the receiver's collection code: only the person who booked (and the office) can read it; the driver asks the receiver
create table if not exists public.booking_codes (
  booking_id uuid primary key references public.bookings (id) on delete cascade,
  code text not null
);

create or replace function public.km_between(a_lat double precision, a_lng double precision, b_lat double precision, b_lng double precision)
returns double precision language sql immutable as $$
  select case when a_lat is null or b_lat is null then null else
    2 * 6371 * asin(sqrt(power(sin(radians(b_lat - a_lat) / 2), 2)
      + cos(radians(a_lat)) * cos(radians(b_lat)) * power(sin(radians(b_lng - a_lng) / 2), 2))) end;
$$;

-- seats still free on each departure for one day (passengers can't read other people's bookings)
create or replace function public.departure_seats(p_day date)
returns table (departure_id uuid, seats int, booked int)
language sql stable security definer set search_path = public as $$
  select d.id, coalesce(d.seats, c.seats, 0),
         coalesce((select sum(b.seats)::int from bookings b where b.departure_id = d.id and b.travel_on = p_day
                    and b.kind = 'seat' and b.status in ('requested', 'assigned', 'picked_up')), 0)
  from departures d join routes r on r.id = d.route_id left join vehicle_categories c on c.id = r.category_id
  where d.active and r.active;
$$;

-- Passenger (or the office for a caller): make a booking. Prices are worked out here, not on the phone.
-- p: kind, departure_id, travel_on, seats, goods [{label, qty}], receiver_name, receiver_phone,
--    category_id, pickup_name/lat/lng, dest_name/lat/lng, trip_type, km, pickup_at,
--    pay_method, pay_reference, note, caller_name, caller_phone, account_id (office only)
create or replace function public.book(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype;
  st app_settings%rowtype;
  office boolean := is_owner();
  k text := p ->> 'kind';
  b bookings%rowtype;
  d departures%rowtype;
  r routes%rowtype;
  c vehicle_categories%rowtype;
  cap int; taken int; straight double precision; g jsonb; gp numeric; items jsonb := '[]'::jsonb; total numeric := 0;
  bid uuid; code text;
begin
  select * into me from profiles where id = auth.uid();
  select * into st from app_settings where id = 1;
  if not office and (me.id is null or me.role <> 'passenger' or not me.active) then
    raise exception 'not allowed' using errcode = '42501';
  end if;
  if not office and (select count(*) from bookings where passenger_id = me.id and status in ('requested', 'assigned', 'picked_up'))
       >= st.max_open_bookings then
    raise exception 'TOO_MANY_BOOKINGS';
  end if;

  b.kind := k;
  b.passenger_id := case when office then nullif(p ->> 'passenger_id', '')::uuid else me.id end;
  b.caller_name := case when office then nullif(p ->> 'caller_name', '') end;
  b.caller_phone := case when office then nullif(p ->> 'caller_phone', '') end;
  if office and b.passenger_id is null and (b.caller_name is null or b.caller_phone is null) then
    raise exception 'CALLER_REQUIRED';
  end if;
  b.pay_method := coalesce(nullif(p ->> 'pay_method', ''), 'cash');
  b.pay_reference := nullif(trim(p ->> 'pay_reference'), '');
  b.note := nullif(p ->> 'note', '');
  if b.pay_method in ('airtel_money', 'tnm_mpamba') and b.pay_reference is null and not office then
    raise exception 'REFERENCE_REQUIRED';
  end if;
  if b.pay_method = 'account' then
    b.account_id := case when office then coalesce(nullif(p ->> 'account_id', '')::uuid, me.account_id) else me.account_id end;
    if b.account_id is null or not exists (select 1 from company_accounts where id = b.account_id and active) then
      raise exception 'NO_ACCOUNT';
    end if;
  end if;

  if k in ('seat', 'goods') then
    select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
    if d.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into r from routes where id = d.route_id and active;
    if r.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into c from vehicle_categories where id = r.category_id;
    b.travel_on := (p ->> 'travel_on')::date;
    if b.travel_on is null or not (extract(isodow from b.travel_on)::int = any (d.days)) then raise exception 'NO_DEPARTURE'; end if;
    b.pickup_at := (b.travel_on + d.leaves_at) at time zone 'Africa/Blantyre';
    if b.pickup_at < now() - interval '5 minutes' then raise exception 'DEPARTED'; end if;
    b.departure_id := d.id;
    b.route_id := r.id;
    b.category_id := r.category_id;
    b.pickup_name := r.from_name;
    b.dest_name := r.to_name;
    b.dest_lat := r.to_lat;
    b.dest_lng := r.to_lng;
    if k = 'seat' then
      b.seats := coalesce((p ->> 'seats')::int, 0);
      if b.seats < 1 then raise exception 'SEATS_REQUIRED'; end if;
      cap := coalesce(d.seats, c.seats, 0);
      select coalesce(sum(x.seats), 0) into taken from bookings x
        where x.departure_id = d.id and x.travel_on = b.travel_on and x.kind = 'seat' and x.status in ('requested', 'assigned', 'picked_up');
      if taken + b.seats > cap then raise exception 'FULL:%', greatest(cap - taken, 0); end if;
      b.price := r.fare * b.seats;
    end if;
  elsif k = 'hire' then
    select * into c from vehicle_categories where id = (p ->> 'category_id')::uuid and active;
    if c.id is null or c.hire_per_km <= 0 then raise exception 'NOT_FOR_HIRE'; end if;
    b.category_id := c.id;
    b.pickup_name := nullif(trim(p ->> 'pickup_name'), '');
    b.dest_name := nullif(trim(p ->> 'dest_name'), '');
    if b.pickup_name is null or b.dest_name is null then raise exception 'PLACES_REQUIRED'; end if;
    b.pickup_lat := (p ->> 'pickup_lat')::double precision;
    b.pickup_lng := (p ->> 'pickup_lng')::double precision;
    b.dest_lat := (p ->> 'dest_lat')::double precision;
    b.dest_lng := (p ->> 'dest_lng')::double precision;
    b.trip_type := coalesce(nullif(p ->> 'trip_type', ''), 'one_way');
    b.pickup_at := coalesce((p ->> 'pickup_at')::timestamptz, now());
    if b.pickup_at < now() - interval '10 minutes' then raise exception 'IN_THE_PAST'; end if;
    b.km := greatest(coalesce((p ->> 'km')::numeric, 0), 1);
    -- never less than the straight line (the phone sends the road distance)
    straight := km_between(b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng);
    if straight is not null then
      b.km := greatest(b.km, round((straight * case when b.trip_type = 'return' then 2 else 1 end)::numeric, 1));
    end if;
    if b.trip_type = 'whole_day' then b.km := greatest(b.km, 100); end if;
    b.rate_per_km := c.hire_per_km;
    b.price := greatest(c.hire_min, ceil(b.km * c.hire_per_km / 500) * 500);
    b.seats := coalesce((p ->> 'seats')::int, 0);
  else
    raise exception 'bad kind';
  end if;

  -- goods (on a departure, or a load on a hired lorry)
  if k = 'goods' or jsonb_array_length(coalesce(p -> 'goods', '[]'::jsonb)) > 0 then
    for g in select * from jsonb_array_elements(coalesce(p -> 'goods', '[]'::jsonb)) loop
      if coalesce((g ->> 'qty')::int, 0) < 1 then continue; end if;
      if k = 'goods' then
        select price into gp from goods_prices where label = g ->> 'label' and active;
        if gp is null then raise exception 'UNKNOWN_GOODS:%', g ->> 'label'; end if;
      else
        gp := 0;                                   -- a hired car is paid per km
      end if;
      items := items || jsonb_build_object('label', g ->> 'label', 'qty', (g ->> 'qty')::int, 'price', gp);
      total := total + gp * (g ->> 'qty')::int;
    end loop;
    if k = 'goods' and jsonb_array_length(items) = 0 then raise exception 'GOODS_REQUIRED'; end if;
    b.goods := items;
    if k = 'goods' then b.price := total; end if;
    b.receiver_name := nullif(trim(p ->> 'receiver_name'), '');
    b.receiver_phone := nullif(trim(p ->> 'receiver_phone'), '');
    if b.receiver_name is null or b.receiver_phone is null then raise exception 'RECEIVER_REQUIRED'; end if;
    code := lpad((floor(random() * 10000))::int::text, 4, '0');
  end if;

  insert into bookings (passenger_id, caller_name, caller_phone, kind, category_id, route_id, departure_id, travel_on,
    pickup_at, seats, pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, trip_type, km, rate_per_km,
    goods, receiver_name, receiver_phone, price, pay_method, pay_reference, account_id, note)
  values (b.passenger_id, b.caller_name, b.caller_phone, b.kind, b.category_id, b.route_id, b.departure_id, b.travel_on,
    b.pickup_at, coalesce(b.seats, 0), b.pickup_name, b.pickup_lat, b.pickup_lng, b.dest_name, b.dest_lat, b.dest_lng, b.trip_type, b.km,
    b.rate_per_km, coalesce(b.goods, '[]'::jsonb), b.receiver_name, b.receiver_phone, b.price, b.pay_method, b.pay_reference,
    b.account_id, b.note)
  returning id into bid;
  if code is not null then insert into booking_codes (booking_id, code) values (bid, code); end if;
  return bid;
end;
$$;

-- Passenger: cancel (free) while no car has picked them up
create or replace function public.cancel_booking(p_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = nullif(p_reason, '')
  where id = p_id and status in ('requested', 'assigned')
    and (passenger_id = auth.uid() or is_owner())
  returning * into b;
  if b.id is null then raise exception 'CANNOT_CANCEL'; end if;
  perform notify(b.driver_id, 'Booking #' || b.booking_no || ' cancelled',
                 b.pickup_name || ' → ' || b.dest_name || ' · ' || to_char(b.pickup_at at time zone 'Africa/Blantyre', 'Dy HH24:MI'), 'booking', b.id);
end;
$$;

-- Office: decline with a reason
create or replace function public.decline_booking(p_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  update bookings set status = 'declined', cancelled_at = now(), cancel_reason = nullif(p_reason, '')
  where id = p_id and status in ('requested', 'assigned') returning * into b;
  if b.id is null then raise exception 'CANNOT_CANCEL'; end if;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' not possible', coalesce(nullif(p_reason, ''), 'Please call the office.'), 'booking', b.id);
  perform notify(b.driver_id, 'Booking #' || b.booking_no || ' removed', null, 'booking', b.id);
end;
$$;

-- Office: give a booking to a vehicle (and its driver). Another type of vehicle re-prices a hire.
create or replace function public.assign_booking(p_id uuid, p_truck uuid, p_message text)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; t trucks%rowtype; drv profiles%rowtype; c vehicle_categories%rowtype; new_price numeric;
begin
  if not is_owner() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into b from bookings where id = p_id for update;
  if b.id is null or b.status not in ('requested', 'assigned') then raise exception 'ALREADY_DECIDED'; end if;
  select * into t from trucks where id = p_truck;
  if t.id is null or t.status <> 'approved' or not t.active then raise exception 'TRUCK_NOT_APPROVED'; end if;
  -- the driver on duty with it, otherwise its regular driver
  select p.* into drv from profiles p
    left join shifts s on s.driver_id = p.id and s.status = 'on_duty' and s.truck_id = t.id
    where p.role = 'driver' and p.active and (p.truck_id = t.id or s.id is not null)
    order by (s.id is not null) desc limit 1;
  if drv.id is null then raise exception 'NO_DRIVER'; end if;
  new_price := b.price;
  if b.kind = 'hire' and t.category_id is distinct from b.category_id then
    select * into c from vehicle_categories where id = t.category_id;
    if c.hire_per_km > 0 then new_price := greatest(c.hire_min, ceil(b.km * c.hire_per_km / 500) * 500); end if;
  end if;
  if b.driver_id is not null and b.driver_id <> drv.id then
    perform notify(b.driver_id, 'Booking #' || b.booking_no || ' moved to another vehicle', null, 'booking', b.id);
  end if;
  update bookings set status = 'assigned', truck_id = t.id, driver_id = drv.id, assigned_by = auth.uid(), assigned_at = now(),
    message = nullif(p_message, ''), price = new_price,
    category_id = case when kind = 'hire' then coalesce(t.category_id, category_id) else category_id end,
    rate_per_km = case when kind = 'hire' and c.id is not null then c.hire_per_km else rate_per_km end
  where id = p_id;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · car assigned',
    t.plate || coalesce(' · ' || t.colour, '') || coalesce(' ' || t.make, '') || ' · driver ' || coalesce(drv.full_name, '') || coalesce(' · ' || drv.phone, '')
    || case when new_price <> b.price then ' · new price K' || to_char(new_price, 'FM999,999,990') else '' end
    || coalesce(' · ' || nullif(p_message, ''), ''), 'booking', b.id);
  perform notify(drv.id, 'New pickup · ' || to_char(b.pickup_at at time zone 'Africa/Blantyre', 'Dy HH24:MI'),
    coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, '') || ' · ' || b.pickup_name || ' → ' || b.dest_name,
    'booking', b.id);
end;
$$;

-- Driver: picked up, no-show, or done (goods need the receiver's code; a hire can send the real km).
-- Cash bookings are added to the driver's running trip, so the day's hand-in includes them.
create or replace function public.booking_step(p_id uuid, p_step text, p_code text, p_km numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; final numeric; who text; code text;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if p_step = 'picked_up' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'picked_up', picked_up_at = now(), trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind in ('seat', 'goods') then
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (tr.id, 'Booking #' || b.booking_no || ' · ' || who,
              0, b.seats, case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  elsif p_step = 'no_show' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'no_show', completed_at = now() where id = p_id;
    if b.passenger_id is not null then
      perform system_on();
      update profiles set no_shows = no_shows + 1 where id = b.passenger_id;
      perform notify(b.passenger_id, 'Missed booking #' || b.booking_no, 'The car waited but you were not there. Missed bookings are counted on your profile.', 'booking', b.id);
    end if;
  elsif p_step = 'completed' then
    if b.status not in ('assigned', 'picked_up') then raise exception 'ALREADY_DECIDED'; end if;
    select c.code into code from booking_codes c where c.booking_id = b.id;
    if code is not null and coalesce(trim(p_code), '') <> code then raise exception 'WRONG_CODE'; end if;
    final := b.price;
    if b.kind = 'hire' and coalesce(p_km, 0) > 0 then
      final := greatest((select hire_min from vehicle_categories where id = b.category_id),
                        ceil(p_km * coalesce(b.rate_per_km, 0) / 500) * 500);
    end if;
    update bookings set status = 'completed', completed_at = now(), final_price = final,
      km = case when b.kind = 'hire' and coalesce(p_km, 0) > 0 then p_km else km end,
      trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind = 'hire' then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Hire #' || b.booking_no || ' · ' || who, 1, final);
    end if;
    perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' done',
      case when b.kind = 'goods' then 'Delivered to ' || coalesce(b.receiver_name, 'the receiver') || '.'
           else 'Thank you for travelling with EfuLogistix. Total K' || to_char(final, 'FM999,999,990') || '.' end, 'booking', b.id);
  else
    raise exception 'bad step';
  end if;
end;
$$;

-- ====================================================================================
-- FULL GPS TRAIL (saved on the phone while there is no signal, uploaded later)
-- ====================================================================================
create table if not exists public.gps_points (
  id bigint generated always as identity primary key,
  driver_id uuid not null references public.profiles (id) on delete cascade,
  truck_id uuid references public.trucks (id) on delete cascade,
  shift_id uuid references public.shifts (id) on delete set null,
  trip_id uuid references public.trips (id) on delete set null,
  lat double precision not null,
  lng double precision not null,
  speed real,                  -- metres per second
  accuracy real,
  at timestamptz not null,     -- phone time when the point was taken
  saved_at timestamptz not null default now(),
  unique (driver_id, at)
);
create index if not exists gps_truck_at_idx on public.gps_points (truck_id, at);

-- p_points: [{ "lat":..., "lng":..., "speed":..., "acc":..., "at":"2026-10-26T08:00:00Z", "trip":"uuid" }]
create or replace function public.upload_gps(p_points jsonb)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  insert into gps_points (driver_id, truck_id, shift_id, trip_id, lat, lng, speed, accuracy, at)
  select auth.uid(), coalesce(s.truck_id, my_truck()), s.id,
         case when x ->> 'trip' ~ '^[0-9a-f-]{36}$' then (x ->> 'trip')::uuid end,
         (x ->> 'lat')::double precision, (x ->> 'lng')::double precision,
         (x ->> 'speed')::real, (x ->> 'acc')::real, (x ->> 'at')::timestamptz
  from jsonb_array_elements(p_points) x
  left join lateral (
    select id, truck_id from shifts
    where driver_id = auth.uid() and started_at <= (x ->> 'at')::timestamptz + interval '5 minutes'
      and (ended_at is null or ended_at >= (x ->> 'at')::timestamptz - interval '5 minutes')
    order by started_at desc limit 1
  ) s on true
  where (x ->> 'at')::timestamptz <= now() + interval '5 minutes'
    and (x ->> 'at')::timestamptz > now() - interval '30 days'
  on conflict (driver_id, at) do nothing;
  get diagnostics n = row_count;
  return n;
end;
$$;

-- "Tracking stopped": the phone says location was switched off (or back on) during a shift
alter table public.alerts drop constraint if exists alerts_kind_check;
alter table public.alerts add constraint alerts_kind_check check (kind in (
  'overspeed', 'long_stop', 'mileage', 'cash_short', 'truck_change', 'no_signal', 'service_due', 'paper_expiry',
  'document_expiry', 'unrecorded_stop', 'tracking_off'));

create or replace function public.report_tracking(p_on boolean, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare s shifts%rowtype; plate text; who text;
begin
  select * into s from shifts where driver_id = auth.uid() and status = 'on_duty';
  if s.id is null then return; end if;
  if p_on then
    update alerts set resolved = true where kind = 'tracking_off' and shift_id = s.id and not resolved;
    return;
  end if;
  if exists (select 1 from alerts where kind = 'tracking_off' and shift_id = s.id and not resolved) then return; end if;
  select t.plate into plate from trucks t where t.id = s.truck_id;
  select coalesce(full_name, email) into who from profiles where id = auth.uid();
  insert into alerts (kind, truck_id, driver_id, shift_id, title, detail)
  values ('tracking_off', s.truck_id, auth.uid(), s.id, 'Tracking stopped · ' || plate,
          who || ': ' || coalesce(nullif(p_reason, ''), 'location was switched off') || '.');
end;
$$;

-- ====================================================================================
-- WHO CAN SEE WHICH PERSON (name, phone, picture)
-- ====================================================================================
create or replace function public.sees_person(p_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select p_id = auth.uid() or is_owner()
    -- owner: drivers of their vehicles, and drivers invited to meet them
    or exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = p_id and t.owner_id = auth.uid())
    or exists (select 1 from driver_matches m join trucks t on t.id = m.truck_id
               where m.driver_id = p_id and t.owner_id = auth.uid() and m.status in ('invited', 'agreed'))
    -- driver: the owner of their vehicle, or of a vehicle they are invited to see
    or exists (select 1 from trucks t where t.owner_id = p_id and t.id = (select truck_id from profiles where id = auth.uid()))
    or exists (select 1 from driver_matches m join trucks t on t.id = m.truck_id
               where m.driver_id = auth.uid() and t.owner_id = p_id and m.status = 'invited')
    -- passenger and driver of the same booking
    or exists (select 1 from bookings b where b.passenger_id = auth.uid() and b.driver_id = p_id and b.status in ('assigned', 'picked_up', 'completed'))
    or exists (select 1 from bookings b where b.driver_id = auth.uid() and b.passenger_id = p_id);
$$;

drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select to authenticated using (sees_person(id));

-- passengers follow the car they booked
create or replace function public.rides_in(p_truck uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from bookings b where b.passenger_id = auth.uid() and b.truck_id = p_truck
                 and b.status in ('assigned', 'picked_up'));
$$;
drop policy if exists loc_read on public.truck_locations;
create policy loc_read on public.truck_locations for select to authenticated
  using (is_owner() or driver_id = auth.uid() or owns_truck(truck_id) or rides_in(truck_id));

-- ====================================================================================
-- PHOTOS: profile pictures and vehicle photos
-- ====================================================================================
drop policy if exists photos_read on storage.objects;
create policy photos_read on storage.objects for select to authenticated
  using (bucket_id = 'photos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner()
         or exists (select 1 from public.odometer_readings r where r.photo_path = name and public.owns_truck(r.truck_id))
         or exists (select 1 from public.shifts s where name = any (s.truck_photos) and public.owns_truck(s.truck_id))
         or exists (select 1 from public.truck_changes c where (name = any (c.in_truck_photos) or name in (c.out_photo, c.in_photo))
                      and (public.owns_truck(c.from_truck) or public.owns_truck(c.to_truck)))
         or exists (select 1 from public.expenses e where e.receipt_path = name and public.owns_truck(e.truck_id))
         or exists (select 1 from public.profiles p where p.avatar_path = name and public.sees_person(p.id))
         or exists (select 1 from public.trucks t where name = any (t.photos)
                      and (t.owner_id = auth.uid() or t.id = public.my_truck() or public.rides_in(t.id)))));

-- ====================================================================================
-- SECURITY for the new tables
-- ====================================================================================
alter table public.company_accounts enable row level security;
alter table public.notices enable row level security;
alter table public.driver_matches enable row level security;
alter table public.wallet_entries enable row level security;
alter table public.fee_bills enable row level security;
alter table public.departures enable row level security;
alter table public.bookings enable row level security;
alter table public.gps_points enable row level security;

drop policy if exists accounts_read on public.company_accounts;
create policy accounts_read on public.company_accounts for select to authenticated
  using (is_owner() or id = (select account_id from profiles where id = auth.uid()));
drop policy if exists accounts_office on public.company_accounts;
create policy accounts_office on public.company_accounts for all to authenticated using (is_owner()) with check (is_owner());

drop policy if exists notices_own on public.notices;
create policy notices_own on public.notices for select to authenticated using (user_id = auth.uid());
drop policy if exists notices_mark_read on public.notices;
create policy notices_mark_read on public.notices for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists matches_read on public.driver_matches;
create policy matches_read on public.driver_matches for select to authenticated
  using (is_owner() or driver_id = auth.uid() or owns_truck(truck_id));

drop policy if exists wallet_read on public.wallet_entries;
create policy wallet_read on public.wallet_entries for select to authenticated
  using (is_owner() or driver_id = auth.uid() or owner_id = auth.uid());

drop policy if exists fees_read on public.fee_bills;
create policy fees_read on public.fee_bills for select to authenticated using (is_owner() or owner_id = auth.uid());

drop policy if exists departures_read on public.departures;
create policy departures_read on public.departures for select to authenticated using (true);
drop policy if exists departures_admin on public.departures;
create policy departures_admin on public.departures for all to authenticated using (is_admin()) with check (is_admin());

drop policy if exists bookings_read on public.bookings;
create policy bookings_read on public.bookings for select to authenticated
  using (passenger_id = auth.uid() or driver_id = auth.uid() or is_owner() or (truck_id is not null and owns_truck(truck_id)));

drop policy if exists gps_read on public.gps_points;
create policy gps_read on public.gps_points for select to authenticated
  using (is_owner() or driver_id = auth.uid() or owns_truck(truck_id));

alter table public.booking_codes enable row level security;
drop policy if exists codes_read on public.booking_codes;
create policy codes_read on public.booking_codes for select to authenticated
  using (exists (select 1 from bookings b where b.id = booking_id and (b.passenger_id = auth.uid() or is_owner())));

-- ====================================================================================
-- ACTIVITY LOG for the new tables
-- ====================================================================================
do $$
declare t text;
begin
  foreach t in array array['company_accounts', 'driver_matches', 'wallet_entries', 'fee_bills', 'departures', 'bookings'] loop
    execute format('drop trigger if exists log_change on public.%I', t);
    execute format('create trigger log_change after insert or update or delete on public.%I
                    for each row execute function public.log_change()', t);
  end loop;
end $$;

-- ====================================================================================
-- LIVE UPDATES
-- ====================================================================================
do $$
declare t text;
begin
  foreach t in array array['bookings', 'notices', 'driver_matches', 'wallet_entries'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object or undefined_object then null;
    end;
  end loop;
end $$;

-- ====================================================================================
-- DATA API ACCESS (Supabase stops adding this automatically for new tables from 30 Oct 2026)
-- ====================================================================================
grant usage on schema public to authenticated, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated, service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;
revoke execute on function public.system_on() from public, anon, authenticated;
revoke execute on function public.notify(uuid, text, text, text, uuid) from public, anon, authenticated;

-- ====================================================================================
-- EXAMPLE PRICES (change them in the admin panel). Only fills empty values.
-- ====================================================================================
update public.vehicle_categories set hire_per_km = v.km, hire_min = v.mn, fee_weekly = v.w, fee_monthly = v.m, fee_per_trip = v.t
from (values ('Kabaza', 300, 1000, 2500, 9000, 100),
             ('Taxi', 900, 5000, 7500, 27000, 300),
             ('Matola', 1200, 15000, 15000, 55000, 500),
             ('Minibus', 1100, 15000, 15000, 55000, 500),
             ('Lorry', 2500, 40000, 25000, 90000, 1500)) as v(name, km, mn, w, m, t)
where vehicle_categories.name = v.name and vehicle_categories.hire_per_km = 0 and vehicle_categories.fee_monthly = 0;
