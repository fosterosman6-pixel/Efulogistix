-- EfuLogistix: database update v9  (run AFTER schema_v8.sql)
--   Owner daily summary (with money checks) · parcel tracking links · driver "my week" · late pickups for the office
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

-- ====================================================================================
-- 1. OWNER DAILY SUMMARY  (message + push, every evening)
-- ====================================================================================
create or replace function public.send_owner_digests()
returns int language plpgsql security definer set search_path = public as $$
declare o record; n int := 0; trips_n int; money numeric; drv numeric; oth numeric; received numeric;
  waiting int; short_n int; short_sum numeric; idle text; msg text; vehicles int;
begin
  for o in select distinct t.owner_id as id from trucks t where t.owner_id is not null and t.active loop
    select count(*) into vehicles from trucks where owner_id = o.id and active;
    select count(*), coalesce(sum(x.total), 0) into trips_n, money
      from trips x join trucks t on t.id = x.truck_id
      where t.owner_id = o.id and x.status <> 'cancelled' and (x.started_at at time zone 'Africa/Blantyre')::date = (now() at time zone 'Africa/Blantyre')::date;
    select coalesce(sum(h.driver_expenses), 0), coalesce(sum(h.received), 0),
           count(*) filter (where h.received is null),
           count(*) filter (where h.received is not null and h.received < h.expected),
           coalesce(sum(h.expected - h.received) filter (where h.received is not null and h.received < h.expected), 0)
      into drv, received, waiting, short_n, short_sum
      from hand_ins h join trucks t on t.id = h.truck_id where t.owner_id = o.id and h.day = (now() at time zone 'Africa/Blantyre')::date;
    select coalesce(sum(e.amount), 0) into oth from expenses e join trucks t on t.id = e.truck_id
      where t.owner_id = o.id and e.spent_at::date = (now() at time zone 'Africa/Blantyre')::date and coalesce(e.paid_by, 'owner') <> 'driver';
    select string_agg(t.plate, ', ') into idle from trucks t
      where t.owner_id = o.id and t.active and not exists (
        select 1 from shifts s where s.truck_id = t.id and (s.started_at at time zone 'Africa/Blantyre')::date = (now() at time zone 'Africa/Blantyre')::date);
    if trips_n = 0 and idle is null then continue; end if;
    msg := trips_n || ' trips · taken K' || to_char(money, 'FM999,999,990')
        || ' · expenses K' || to_char(drv + oth, 'FM999,999,990')
        || ' · handed in K' || to_char(received, 'FM999,999,990');
    if short_n > 0 then msg := msg || E'\nCHECK: ' || short_n || ' hand-in(s) came in short by K' || to_char(short_sum, 'FM999,999,990') || '.'; end if;
    if waiting > 0 then msg := msg || E'\n' || waiting || ' hand-in(s) still waiting for you to confirm.'; end if;
    if idle is not null and vehicles > 0 then msg := msg || E'\nDid not work today: ' || idle || '.'; end if;
    perform notify(o.id, 'Today · ' || to_char(now() at time zone 'Africa/Blantyre', 'DD Mon'), msg, 'digest', null);
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.run_owner_digests() returns int
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  return send_owner_digests();
end $$;

-- every evening 18:30 Malawi time (16:30 UTC); needs the pg_cron add-on (see PUSH_SETUP.md)
do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule('efu-owner-digest') where exists (select 1 from cron.job where jobname = 'efu-owner-digest');
  perform cron.schedule('efu-owner-digest', '30 16 * * *', 'select public.send_owner_digests()');
exception when others then
  raise notice 'pg_cron not available: enable it under Database > Extensions, then run this file again. (%)', sqlerrm;
end $$;

-- ====================================================================================
-- 2. PARCEL TRACKING: the share link now also tells the receiver it is a parcel
-- ====================================================================================
create or replace function public.shared_trip(p_token text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare b bookings%rowtype; t trucks%rowtype; l truck_locations%rowtype; drv text; pax text;
begin
  select b2.* into b from bookings b2 join trip_shares s on s.booking_id = b2.id where s.token = p_token;
  if b.id is null then return jsonb_build_object('state', 'invalid'); end if;
  if b.status in ('completed', 'cancelled', 'no_show', 'declined') then
    return jsonb_build_object('state', 'ended', 'status', b.status, 'kind', b.kind);
  end if;
  if b.status = 'requested' or b.truck_id is null then
    return jsonb_build_object('state', 'waiting', 'kind', b.kind, 'pickup', b.pickup_name, 'dest', b.dest_name);
  end if;
  select * into t from trucks where id = b.truck_id;
  select * into l from truck_locations where truck_id = b.truck_id;
  select split_part(full_name, ' ', 1) into drv from profiles where id = b.driver_id;
  select split_part(full_name, ' ', 1) into pax from profiles where id = b.passenger_id;
  return jsonb_build_object(
    'state', case when b.status = 'picked_up' then 'on_trip' else 'coming' end,
    'kind', b.kind, 'receiver', split_part(coalesce(b.receiver_name, ''), ' ', 1),
    'passenger', pax, 'driver', drv, 'plate', t.plate,
    'vehicle', trim(coalesce(t.colour, '') || ' ' || coalesce(t.make, '')),
    'pickup', b.pickup_name, 'dest', b.dest_name,
    'pickup_lat', b.pickup_lat, 'pickup_lng', b.pickup_lng, 'dest_lat', b.dest_lat, 'dest_lng', b.dest_lng,
    'lat', l.lat, 'lng', l.lng, 'updated_at', l.updated_at);
end $$;

-- ====================================================================================
-- 3. DRIVER: MY WEEK
-- ====================================================================================
create or replace function public.my_week()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare me profiles%rowtype; monday timestamptz; d_today numeric; d_week numeric; n_week int; pax int;
  tr_week numeric; tg numeric; avg_r numeric; n_r bigint; day_n int;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.role <> 'driver' then raise exception 'NOT_ALLOWED'; end if;
  monday := date_trunc('week', now() at time zone 'Africa/Blantyre') at time zone 'Africa/Blantyre';
  select coalesce(sum(x.total), 0) into d_today from trips x
    where x.driver_id = me.id and x.status <> 'cancelled'
      and (x.started_at at time zone 'Africa/Blantyre')::date = (now() at time zone 'Africa/Blantyre')::date;
  select coalesce(sum(x.total), 0), count(*), coalesce(sum(coalesce(x.pax_carried, x.passengers)), 0)::int
    into d_week, n_week, pax from trips x where x.driver_id = me.id and x.status <> 'cancelled' and x.started_at >= monday;
  select count(distinct (x.started_at at time zone 'Africa/Blantyre')::date) into day_n from trips x
    where x.driver_id = me.id and x.status <> 'cancelled' and x.started_at >= monday;
  if me.truck_id is not null then
    select weekly_target into tg from trucks where id = me.truck_id;
    select coalesce(sum(x.total), 0) into tr_week from trips x
      where x.truck_id = me.truck_id and x.status <> 'cancelled' and x.started_at >= monday;
  end if;
  select round(avg(r.stars)::numeric, 1), count(*) into avg_r, n_r from ratings r where r.driver_id = me.id;
  return jsonb_build_object('today', d_today, 'week', d_week, 'trips', n_week, 'passengers', pax, 'days', day_n,
    'target', tg, 'vehicle_week', tr_week, 'rating', avg_r, 'ratings', n_r);
end $$;

-- ====================================================================================
-- 4. OFFICE: LATE PICKUPS (car assigned, passenger not yet picked up, time has passed)
-- ====================================================================================
create or replace function public.late_pickups(p_min int default 15)
returns table (booking_id uuid, booking_no bigint, passenger text, pickup_name text, pickup_at timestamptz,
               minutes_late int, plate text, driver text, driver_phone text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  return query
  select b.id, b.booking_no, coalesce(pp.full_name, b.caller_name, 'Passenger'), b.pickup_name, b.pickup_at,
         (extract(epoch from (now() - b.pickup_at)) / 60)::int, t.plate, d.full_name, d.phone
  from bookings b
  left join profiles pp on pp.id = b.passenger_id
  left join profiles d on d.id = b.driver_id
  left join trucks t on t.id = b.truck_id
  where b.status = 'assigned' and b.pickup_at < now() - make_interval(mins => greatest(p_min, 1))
  order by b.pickup_at;
end $$;

-- ====================================================================================
-- SECURITY AND ACCESS
-- ====================================================================================
revoke execute on function public.send_owner_digests() from public, anon, authenticated;
grant execute on function public.run_owner_digests() to authenticated;
grant execute on function public.shared_trip(text) to anon, authenticated;
grant execute on function public.my_week() to authenticated;
grant execute on function public.late_pickups(int) to authenticated;
