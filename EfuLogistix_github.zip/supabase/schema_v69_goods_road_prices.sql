-- v69: parcel prices per road, set in SQL. A road with no row uses the normal parcel price list (goods_prices).
-- A price here is the price for the WHOLE road; a shorter trip pays its share by distance (rounded to K500, never below K500).
-- Safe to run twice.
begin;

create table if not exists public.goods_road_prices (
  corridor_id uuid not null references public.route_corridors(id) on delete cascade,
  label       text not null,
  price       numeric(12,2) not null check (price >= 0),
  updated_at  timestamptz not null default now(),
  primary key (corridor_id, label)
);
alter table public.goods_road_prices enable row level security;
drop policy if exists goods_road_read on public.goods_road_prices;
create policy goods_road_read on public.goods_road_prices for select to authenticated using (true);
drop policy if exists goods_road_admin on public.goods_road_prices;
create policy goods_road_admin on public.goods_road_prices for all to authenticated using (is_admin()) with check (is_admin());

-- set one item's price on one road
create or replace function public.goods_set_road_price(p_road text, p_label text, p_price numeric)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road);
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if not exists (select 1 from goods_prices where label = p_label) then raise exception 'No parcel item called "%"', p_label; end if;
  insert into goods_road_prices (corridor_id, label, price) values (c, p_label, p_price)
  on conflict (corridor_id, label) do update set price = excluded.price, updated_at = now();
end $$;

-- go back to the normal list price for one item (or every item when p_label is null)
create or replace function public.goods_clear_road_price(p_road text, p_label text default null)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid := _road_id(p_road);
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  delete from goods_road_prices where corridor_id = c and (p_label is null or label = p_label);
end $$;

revoke all on function public.goods_set_road_price(text, text, numeric), public.goods_clear_road_price(text, text) from public, anon;
grant execute on function public.goods_set_road_price(text, text, numeric), public.goods_clear_road_price(text, text) to authenticated;


-- book_depot (v69): parcels also use a price set for the road in goods_road_prices. Before: if the chosen time is on the road's other direction, the same time and vehicle going the passenger's way is booked instead.
create or replace function public.book_depot(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  lo int; hi int; fwd boolean; q record; bid uuid; tot numeric; scale numeric;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  if lo is null or hi is null then raise exception 'BAD_STOPS_ROUTE_ENDS'; end if;
  fwd := lo < hi;
  if fp is null or tp is null then raise exception 'BAD_STOPS_MISSING'; end if;
  if (fwd and not fp < tp) or (not fwd and not fp > tp) then
    -- the chosen time belongs to the road's other direction: use the same time and vehicle type going the passenger's way
    select d2.* into d from departures d2 join routes r2 on r2.id = d2.route_id
     where r2.corridor_id = r.corridor_id and r2.through and r2.active and r2.category_id = r.category_id
       and r2.id <> r.id and d2.leaves_at = d.leaves_at and d2.active
     order by d2.id limit 1;
    if d.id is null then raise exception 'BAD_STOPS_DIRECTION'; end if;
    p := jsonb_set(p, '{departure_id}', to_jsonb(d.id::text));
    select * into r from routes where id = d.route_id;
    select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
      into lo, hi from corridor_stops where corridor_id = r.corridor_id;
    fwd := lo < hi;
    if (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from public.corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  bid := public.book(p - 'from_pos' - 'to_pos');
  update bookings
     set pickup_name = fs.place_name, pickup_lat = fs.lat, pickup_lng = fs.lng,
         dest_name = ts.place_name, dest_lat = ts.lat, dest_lng = ts.lng,
         km = q.km, price = case when kind = 'seat' then q.fare * seats else price end
   where id = bid;

  if (p ->> 'kind') = 'goods' then
    select coalesce(sum(s.km_from_prev), 0) into tot from corridor_stops s where s.corridor_id = r.corridor_id;
    if tot > 0 then
      scale := least(1, q.km / tot);
      update bookings b2
         set goods = coalesce((select jsonb_agg(jsonb_set(e.item, '{price}',
                                    to_jsonb(greatest(500, round(coalesce((select g.price from goods_road_prices g where g.corridor_id = r.corridor_id and g.label = e.item ->> 'label'), (e.item ->> 'price')::numeric) * scale / 500) * 500))) order by e.ord)
                                 from jsonb_array_elements(b2.goods) with ordinality as e(item, ord)), '[]'::jsonb)
       where b2.id = bid;
      update bookings b2
         set price = coalesce((select sum((e ->> 'price')::numeric * (e ->> 'qty')::int) from jsonb_array_elements(b2.goods) e), 0)
       where b2.id = bid;
    end if;
  end if;
  return bid;
end $$;
revoke all on function public.book_depot(jsonb) from public, anon;
grant execute on function public.book_depot(jsonb) to authenticated;

commit;

-- EXAMPLES
-- select goods_set_road_price('Mangochi - Chiponde', 'Bag / suitcase', 2500);
-- select goods_clear_road_price('Mangochi - Chiponde');          -- back to the normal list
-- select label, price from goods_prices order by price;           -- the names to use
