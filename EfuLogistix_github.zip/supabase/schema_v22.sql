-- EfuLogistix: database update v22  (run AFTER schema_v21.sql)
--   Bookings are automatic:
--     * seat and parcel bookings go straight to a vehicle on duty for that departure (no office step)
--     * hire requests keep being offered to nearby drivers (a driver who said no is asked again after 5 minutes)
--     * only when nothing works for a while does a booking wait for the office
--   Admin > Settings > Hire requests switch (auto_offer) turns all of this on or off.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public._offer_booking(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; pick record;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind <> 'hire' or b.pickup_lat is null or b.pickup_lng is null then return; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return; end if;
  if b.pickup_at > now() + interval '90 minutes' then return; end if;   -- later bookings stay with the office
  if exists (select 1 from booking_offers where booking_id = b.id and status = 'offered') then return; end if;
  select s.driver_id, s.truck_id,
         public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) as km
    into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join truck_locations l on l.truck_id = s.truck_id and l.updated_at > now() - interval '10 minutes'
   where s.status = 'on_duty'
     and (b.category_id is null or t.category_id = b.category_id)
     and not exists (select 1 from trips tr where tr.driver_id = s.driver_id and tr.status = 'in_progress')
     and not exists (select 1 from booking_offers o where o.booking_id = b.id and o.driver_id = s.driver_id
                      and (o.status = 'offered' or o.answered_at > now() - interval '5 minutes'))   -- a driver who said no is asked again after 5 minutes
     and not exists (select 1 from booking_offers o where o.driver_id = s.driver_id and o.status = 'offered')
     and public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) <= 60
   order by km limit 1;
  if pick.driver_id is null then return; end if;
  insert into booking_offers (booking_id, driver_id, truck_id) values (b.id, pick.driver_id, pick.truck_id);
  perform notify(pick.driver_id, 'New hire request · ' || round(pick.km::numeric, 1) || ' km away',
    b.pickup_name || ' → ' || b.dest_name || ' · K' || to_char(b.price, 'FM999,999,990') || '. Open Booked pickups to accept (2 minutes).', 'booking', b.id);
end $$;

create or replace function public.expire_offers() returns int
language plpgsql security definer set search_path = public as $$
declare o record; n int := 0;
begin
  for o in select * from booking_offers where status = 'offered' and offered_at < now() - interval '2 minutes' loop
    update booking_offers set status = 'expired', answered_at = now() where id = o.id;
    perform notify(o.driver_id, 'Hire request expired', 'It was offered to another driver.', 'booking', o.booking_id);
    perform public._offer_booking(o.booking_id);
    n := n + 1;
  end loop;
  -- offers on bookings the office already handled
  update booking_offers set status = 'cancelled', answered_at = now()
   where status = 'offered' and booking_id in (select id from bookings where status <> 'requested');
  -- hire requests nobody has taken yet (no open offer): try the drivers again, for up to 30 minutes
  for o in select b.id from bookings b
            where b.status = 'requested' and b.kind = 'hire' and b.created_at > now() - interval '30 minutes'
              and not exists (select 1 from booking_offers x where x.booking_id = b.id and x.status = 'offered') loop
    perform public._offer_booking(o.id);
  end loop;
  return n;
end $$;

-- Give a booking to a vehicle and tell the passenger and the driver
create or replace function public._assign_to_truck(p_booking uuid, p_truck uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; t trucks%rowtype; drv profiles%rowtype;
begin
  select * into b from bookings where id = p_booking and status = 'requested' for update;
  if b.id is null then return false; end if;
  select * into t from trucks where id = p_truck;
  select p.* into drv from profiles p
    left join shifts s on s.driver_id = p.id and s.status = 'on_duty' and s.truck_id = t.id
   where p.role = 'driver' and p.active and (p.truck_id = t.id or s.id is not null)
   order by (s.id is not null) desc limit 1;
  if t.id is null or drv.id is null then return false; end if;
  update bookings set status = 'assigned', truck_id = t.id, driver_id = drv.id, assigned_at = now(),
         message = 'Assigned automatically' where id = b.id;
  update booking_offers set status = 'cancelled', answered_at = now() where booking_id = b.id and status = 'offered';
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · car assigned',
    t.plate || coalesce(' · ' || t.colour, '') || coalesce(' ' || t.make, '') || ' · driver ' || coalesce(drv.full_name, '') || coalesce(' · ' || drv.phone, ''),
    'booking', b.id);
  perform notify(drv.id, 'New pickup · ' || to_char(b.pickup_at at time zone 'Africa/Blantyre', 'Dy HH24:MI'),
    coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, '') || ' · ' || b.pickup_name || ' → ' || b.dest_name,
    'booking', b.id);
  return true;
end $$;
revoke all on function public._assign_to_truck(uuid, uuid) from public, anon, authenticated;

-- Seat / parcel booking: pick the vehicle on duty that already carries this departure, else the least busy one with room
create or replace function public._auto_assign(p_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; d departures%rowtype; pick uuid;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind not in ('seat', 'goods') or b.category_id is null then return false; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return false; end if;
  select * into d from departures where id = b.departure_id;
  select t.id into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join vehicle_categories c on c.id = t.category_id
   where s.status = 'on_duty' and t.category_id = b.category_id
     and ((b.kind = 'seat' and c.carries_passengers) or (b.kind = 'goods' and c.carries_goods))
     and (b.kind <> 'seat' or coalesce(d.seats, t.seats, c.seats) >=
          b.seats + coalesce((select sum(x.seats) from bookings x
                               where x.truck_id = t.id and x.departure_id = b.departure_id and x.travel_on = b.travel_on
                                 and x.kind = 'seat' and x.status in ('assigned', 'picked_up')), 0))
   order by exists (select 1 from bookings x where x.truck_id = t.id and x.departure_id = b.departure_id and x.travel_on = b.travel_on
                      and x.status in ('assigned', 'picked_up')) desc,
            (select count(*) from bookings x where x.truck_id = t.id and x.status in ('assigned', 'picked_up')),
            random()
   limit 1;
  if pick is null then return false; end if;
  return public._assign_to_truck(b.id, pick);
end $$;
revoke all on function public._auto_assign(uuid) from public, anon, authenticated;

create or replace function public._auto_assign_on_new_booking() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind in ('seat', 'goods') and new.pickup_at <= now() + interval '3 hours' then
    perform public._auto_assign(new.id);
  end if;
  return new;
end $$;
drop trigger if exists bookings_auto_assign on public.bookings;
create trigger bookings_auto_assign after insert on public.bookings for each row execute function public._auto_assign_on_new_booking();

-- Every minute: bookings that could not be placed yet (no vehicle on duty) are tried again once the departure is within 3 hours
create or replace function public.auto_assign_pending() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select id from bookings
            where status = 'requested' and kind in ('seat', 'goods')
              and pickup_at <= now() + interval '3 hours' and pickup_at > now() - interval '30 minutes' loop
    if public._auto_assign(r.id) then n := n + 1; end if;
  end loop;
  return n;
end $$;
revoke all on function public.auto_assign_pending() from public, anon, authenticated;

do $$ begin
  perform cron.schedule('efu-auto-assign', '* * * * *', 'select public.auto_assign_pending()');
exception when others then null;
end $$;
