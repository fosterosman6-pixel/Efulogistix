-- v68: create a whole new road with ONE line of SQL. Safe to run twice (a road that exists is left alone).
-- Every depot must already be a pin in places. Distances come from the pins; type a distance later in Admin if you know it.
begin;

create or replace function public.road_new(p_name text, p_depots text[], p_vehicles text[], p_whole_fare numeric,
                                           p_times time[] default null)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid; i int; n text; km numeric; v uuid; rid uuid; t time;
begin
  if auth.uid() is not null and not is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if exists (select 1 from route_corridors where name = p_name) then raise notice 'Road "%" already exists, nothing changed', p_name; return; end if;
  if array_length(p_depots, 1) is null or array_length(p_depots, 1) < 2 then raise exception 'A road needs at least two depots'; end if;
  if array_length(p_vehicles, 1) is null then raise exception 'Give at least one vehicle type'; end if;
  if p_whole_fare is null or p_whole_fare <= 0 then raise exception 'Give the price of the whole road'; end if;
  foreach n in array p_vehicles loop perform _vehicle_id(n); end loop;
  foreach n in array p_depots loop
    if not exists (select 1 from places where name = n) then raise exception 'No place called "%" (add the pin to places first)', n; end if;
  end loop;

  insert into route_corridors (name) values (p_name) returning id into c;
  for i in 1 .. array_length(p_depots, 1) loop
    insert into corridor_stops (corridor_id, pos, place_name, lat, lng)
    select c, i - 1, p.name, p.lat, p.lng from places p where p.name = p_depots[i];
  end loop;
  perform corridor_recalc_km(c);
  select coalesce(sum(km_from_prev), 0) into km from corridor_stops where corridor_id = c;
  foreach n in array p_vehicles loop
    insert into corridor_rates (corridor_id, category_id, per_km, min_fare, round_to, full_fare)
    values (c, _vehicle_id(n), case when km > 0 then round(p_whole_fare / km, 2) else 0 end, 1000, 500, p_whole_fare);
  end loop;
  perform corridor_rebuild(c);

  if p_times is not null then
    for rid in select id from routes where corridor_id = c and through and active loop
      foreach t in array p_times loop
        insert into departures (route_id, leaves_at, days) values (rid, t, '{1,2,3,4,5,6,7}') on conflict (route_id, leaves_at) do nothing;
      end loop;
    end loop;
  end if;
end $$;
revoke all on function public.road_new(text, text[], text[], numeric, time[]) from public, anon;
grant execute on function public.road_new(text, text[], text[], numeric, time[]) to authenticated;
commit;

-- EXAMPLE (copy, change, run): a road Mangochi Main Rank -> Chiponde, Minibus only, K15,000 for the whole road, cars every 2 hours
-- select road_new('Mangochi - Chiponde', array['Mangochi Main Rank', 'Chiponde Depot'], array['Minibus'], 15000,
--                 array['06:00','08:00','10:00','12:00','14:00','16:00']::time[]);
