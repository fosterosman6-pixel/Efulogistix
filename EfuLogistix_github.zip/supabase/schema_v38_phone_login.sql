-- EfuLogistix v38: sign in with a phone number (SMS code). Run once in the EfuLogistix Supabase project, after v37. Safe to run twice.
-- New accounts made by phone have no email: the profile takes the phone number, and the role the person chose
-- (passenger is active at once; driver and vehicle owner wait for approval, same as email sign-up).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  inv invites%rowtype;
  asked text := lower(coalesce(new.raw_user_meta_data ->> 'role', case when new.email is null then 'passenger' else 'driver' end));
  r text;
  ph text;
begin
  if new.email is not null then
    select * into inv from invites where lower(email) = lower(new.email) and used_by is null limit 1;
  end if;
  r := coalesce(inv.role, case when asked in ('passenger', 'driver', 'owner') then asked else 'driver' end);
  ph := coalesce(nullif(new.raw_user_meta_data ->> 'phone', ''), inv.phone, case when new.phone is not null and new.phone <> '' then '+' || new.phone end);
  insert into profiles (id, email, full_name, phone, role, active, truck_id)
  values (new.id, new.email,
          coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), inv.full_name),
          ph,
          r,
          inv.id is not null or r in ('passenger', 'owner'),
          inv.truck_id);
  if inv.id is not null then
    update invites set used_by = new.id, used_at = now() where id = inv.id;
  end if;
  return new;
end;
$$;
