-- EfuLogistix v37: passenger extras. Run once in the EfuLogistix Supabase project, after v36. Safe to run twice.
--   saved places (Home, Work ...), emergency contact, favourite drivers, invite friends (referral codes),
--   notification settings (mute pushes for bookings or chat).

-- ---------------------------------------------------------------- saved places
create table if not exists public.saved_places (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  label text not null check (length(btrim(label)) between 1 and 30),
  name text not null check (length(btrim(name)) between 1 and 120),
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  created_at timestamptz not null default now()
);
create index if not exists saved_places_user_idx on public.saved_places (user_id, created_at);
alter table public.saved_places enable row level security;
drop policy if exists saved_places_own on public.saved_places;
create policy saved_places_own on public.saved_places for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke all on public.saved_places from anon;
grant select, insert, delete on public.saved_places to authenticated;
create or replace function public._limit_saved_places() returns trigger language plpgsql as $$
begin
  if (select count(*) from saved_places where user_id = new.user_id) >= 10 then raise exception 'TOO_MANY_PLACES'; end if;
  return new;
end $$;
drop trigger if exists saved_places_limit on public.saved_places;
create trigger saved_places_limit before insert on public.saved_places for each row execute function public._limit_saved_places();

-- ---------------------------------------------------------------- emergency contact
alter table public.profiles add column if not exists emergency_name text;
alter table public.profiles add column if not exists emergency_phone text;

-- ---------------------------------------------------------------- favourite drivers
create table if not exists public.favourite_drivers (
  user_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  driver_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, driver_id)
);
alter table public.favourite_drivers enable row level security;
drop policy if exists favourite_drivers_own on public.favourite_drivers;
create policy favourite_drivers_own on public.favourite_drivers for all to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid()
    and exists (select 1 from bookings b where b.passenger_id = auth.uid() and b.driver_id = favourite_drivers.driver_id and b.status = 'completed'));
revoke all on public.favourite_drivers from anon;
grant select, insert, delete on public.favourite_drivers to authenticated;

-- ---------------------------------------------------------------- invite friends
create table if not exists public.referral_codes (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  code text not null unique
);
create table if not exists public.referrals (
  referred_id uuid primary key references public.profiles (id) on delete cascade,
  referrer_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.referral_codes enable row level security;
alter table public.referrals enable row level security;
drop policy if exists referral_codes_own on public.referral_codes;
create policy referral_codes_own on public.referral_codes for select to authenticated using (user_id = auth.uid());
drop policy if exists referrals_mine on public.referrals;
create policy referrals_mine on public.referrals for select to authenticated using (referrer_id = auth.uid() or referred_id = auth.uid());
revoke all on public.referral_codes, public.referrals from anon, authenticated;
grant select on public.referral_codes, public.referrals to authenticated;

-- my code (made the first time)
create or replace function public.my_referral_code() returns text
language plpgsql security definer set search_path = public as $$
declare c text; i int := 0;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  select code into c from referral_codes where user_id = auth.uid();
  if c is not null then return c; end if;
  loop
    c := upper(substr(translate(encode(gen_random_bytes(6), 'base64'), '+/=OIL01', 'ABCDEFGH'), 1, 6));
    begin
      insert into referral_codes (user_id, code) values (auth.uid(), c);
      return c;
    exception when unique_violation then
      i := i + 1;
      if i > 10 then raise; end if;
      select code into c from referral_codes where user_id = auth.uid();
      if c is not null then return c; end if;
    end;
  end loop;
end $$;

-- a new person types the code of the friend who invited them (once)
create or replace function public.use_referral_code(p_code text) returns void
language plpgsql security definer set search_path = public as $$
declare r uuid;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  select user_id into r from referral_codes where code = upper(btrim(p_code));
  if r is null then raise exception 'BAD_CODE'; end if;
  if r = auth.uid() then raise exception 'OWN_CODE'; end if;
  if exists (select 1 from referrals where referred_id = auth.uid()) then raise exception 'ALREADY_USED'; end if;
  if exists (select 1 from bookings where passenger_id = auth.uid() and status = 'completed') then raise exception 'NOT_NEW'; end if;
  insert into referrals (referred_id, referrer_id) values (auth.uid(), r);
  perform notify(r, 'A friend joined with your code', coalesce((select full_name from profiles where id = auth.uid()), 'Someone') || ' used your invite code.', 'system', null);
end $$;
revoke execute on function public.my_referral_code(), public.use_referral_code(text) from public, anon;
grant execute on function public.my_referral_code(), public.use_referral_code(text) to authenticated;

-- ---------------------------------------------------------------- notification settings
create table if not exists public.notify_prefs (
  user_id uuid primary key default auth.uid() references public.profiles (id) on delete cascade,
  muted text[] not null default '{}' check (muted <@ array['booking', 'chat'])
);
alter table public.notify_prefs enable row level security;
drop policy if exists notify_prefs_own on public.notify_prefs;
create policy notify_prefs_own on public.notify_prefs for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke all on public.notify_prefs from anon;
grant select, insert, update on public.notify_prefs to authenticated;

-- the push is skipped when the person muted that kind (the message still lands in the inbox).
-- Only if the push tables from v7 exist (they do once v7 has been run).
do $outer$ begin
  if to_regclass('public.push_config') is not null and to_regclass('public.device_tokens') is not null then
    execute $fn$
create or replace function public.push_new_notice() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare cfg push_config%rowtype;
begin
  select * into cfg from push_config where id = 1;
  if cfg.id is null then return new; end if;
  if not exists (select 1 from device_tokens where user_id = new.user_id) then return new; end if;
  if new.kind is not null and exists (select 1 from notify_prefs p where p.user_id = new.user_id and new.kind = any (p.muted)) then
    return new;
  end if;
  begin
    perform net.http_post(
      url := cfg.url,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', cfg.secret),
      body := jsonb_build_object('user_id', new.user_id, 'title', new.title, 'body', new.body,
                                 'kind', new.kind, 'ref_id', new.ref_id, 'notice_id', new.id)
    );
  exception when others then
    null;   -- push is best effort
  end;
  return new;
end $$;
    $fn$;
  end if;
end $outer$;
