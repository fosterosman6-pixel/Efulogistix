-- EfuLogistix: database update v18  (run AFTER schema_v17.sql)
--   Drivers can suggest a place from where they stand; the admin approves it into the Places list.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.place_suggestions (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) > 0),
  detail text not null default '',
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  suggested_by uuid not null references public.profiles (id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now()
);

alter table public.place_suggestions enable row level security;
drop policy if exists place_sug_read on public.place_suggestions;
create policy place_sug_read on public.place_suggestions for select to authenticated
  using (suggested_by = auth.uid() or public.is_admin());
drop policy if exists place_sug_insert on public.place_suggestions;
create policy place_sug_insert on public.place_suggestions for insert to authenticated
  with check (suggested_by = auth.uid() and status = 'pending' and public.is_active_driver());
revoke update, delete on public.place_suggestions from authenticated;
grant select, insert on public.place_suggestions to authenticated;
grant all on public.place_suggestions to service_role;

-- Admin: approve (adds or corrects the place) or reject a suggestion
create or replace function public.decide_place_suggestion(p_id uuid, p_approve boolean)
returns void language plpgsql security definer set search_path = public as $$
declare s place_suggestions%rowtype;
begin
  if not is_admin() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into s from place_suggestions where id = p_id and status = 'pending' for update;
  if s.id is null then raise exception 'ALREADY_DECIDED'; end if;
  if p_approve then
    insert into places (name, detail, lat, lng) values (trim(s.name), s.detail, s.lat, s.lng)
    on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;
  end if;
  update place_suggestions set status = case when p_approve then 'approved' else 'rejected' end where id = p_id;
  perform notify(s.suggested_by, case when p_approve then 'Place added: ' else 'Place not added: ' end || s.name,
    case when p_approve then 'Thank you. The office added this place for everyone.' else 'The office could not add this place.' end, null, null);
end $$;
revoke all on function public.decide_place_suggestion(uuid, boolean) from public, anon;
grant execute on function public.decide_place_suggestion(uuid, boolean) to authenticated;
