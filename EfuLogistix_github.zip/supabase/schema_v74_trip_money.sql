-- v74: the end-of-trip money summary. One call gives every rand of a trip, split into cash (to hand in) and already paid
-- (Airtel Money, TNM Mpamba, company account), by booked passengers, walk-ins, parcels and hire. Read by the driver, the truck's owner and the office.
-- Safe to run twice.
begin;

create or replace function public._trip_group(b bookings) returns text language sql immutable as $$
  select case when b.kind = 'goods' then 'parcel'
              when b.kind = 'hire' then 'hire'
              when b.passenger_id is null and b.caller_name = 'Walk-in' then 'walkin'
              else 'booked' end;
$$;

create or replace function public.trip_money(p_trip uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  t trips%rowtype; me uuid := auth.uid(); cash jsonb; paid jsonb; cash_sum numeric; paid_sum numeric; booking_cash numeric;
  cap int; used int; wallet numeric; pct numeric;
begin
  select * into t from trips where id = p_trip;
  if t.id is null then return null; end if;
  if me is not null and not (t.driver_id = me or is_owner() or owns_truck(t.truck_id)) then raise exception 'NOT_ALLOWED'; end if;

  select coalesce(jsonb_agg(jsonb_build_object('group', grp, 'count', n, 'amount', amount) order by grp), '[]'::jsonb), coalesce(sum(amount), 0)
    into cash, booking_cash
    from (select _trip_group(b) as grp, count(*)::int as n, coalesce(sum(coalesce(b.final_price, b.price)), 0) as amount
            from bookings b where b.trip_id = t.id and b.status in ('picked_up', 'completed') and b.pay_method = 'cash' group by 1) x;
  select coalesce(jsonb_agg(jsonb_build_object('group', grp, 'method', method, 'count', n, 'amount', amount) order by grp, method), '[]'::jsonb), coalesce(sum(amount), 0)
    into paid, paid_sum
    from (select _trip_group(b) as grp, b.pay_method as method, count(*)::int as n, coalesce(sum(coalesce(b.final_price, b.price)), 0) as amount
            from bookings b where b.trip_id = t.id and b.status in ('picked_up', 'completed') and b.pay_method <> 'cash' group by 1, 2) y;
  -- cash the driver is handing in (trip total) can include stops on the way that are not bookings
  cash_sum := coalesce(t.total, 0);

  select coalesce(tk.seats, c.seats, 0) into cap from trucks tk left join vehicle_categories c on c.id = tk.category_id where tk.id = t.truck_id;
  select coalesce(sum(case when b.kind = 'seat' then b.seats when b.kind = 'goods' then _goods_seats(b.goods) else 0 end), 0)::int into used
    from bookings b where b.trip_id = t.id and b.status in ('picked_up', 'completed');

  select amount into wallet from wallet_entries where trip_id = t.id and kind is not null limit 1;
  select wallet_pct into pct from app_settings where id = 1;
  if wallet is null then wallet := round(greatest(cash_sum, 0) * coalesce(pct, 10) / 100); end if;

  return jsonb_build_object(
    'trip_no', t.trip_no, 'from', t.pickup_name, 'to', t.dest_name, 'started_at', t.started_at, 'ended_at', t.ended_at,
    'status', t.status, 'km', coalesce(t.end_km - t.start_km, t.gps_km, t.actual_km),
    'cash', cash, 'cash_booking_total', booking_cash,
    'cash_other_stops', greatest(cash_sum - booking_cash, 0),
    'hand_in', cash_sum,
    'paid', paid, 'paid_total', paid_sum,
    'all_total', cash_sum + paid_sum,
    'seats_used', used, 'seats_cap', coalesce(cap, 0),
    'wallet_share', wallet, 'wallet_pct', coalesce(pct, 10));
end $$;

-- the people behind one line of the summary
create or replace function public.trip_money_lines(p_trip uuid, p_group text, p_cash boolean)
returns table (booking_no bigint, who text, pickup_name text, dest_name text, seats int, amount numeric, method text, at timestamptz, goods jsonb)
language plpgsql stable security definer set search_path = public as $$
declare t trips%rowtype; me uuid := auth.uid();
begin
  select * into t from trips where id = p_trip;
  if t.id is null then return; end if;
  if me is not null and not (t.driver_id = me or is_owner() or owns_truck(t.truck_id)) then raise exception 'NOT_ALLOWED'; end if;
  return query
    select b.booking_no, coalesce((select p.full_name from profiles p where p.id = b.passenger_id), b.caller_name, 'Passenger'),
           b.pickup_name, b.dest_name, b.seats, coalesce(b.final_price, b.price), b.pay_method, coalesce(b.picked_up_at, b.pickup_at), b.goods
      from bookings b
     where b.trip_id = p_trip and b.status in ('picked_up', 'completed') and _trip_group(b) = p_group
       and ((p_cash and b.pay_method = 'cash') or (not p_cash and b.pay_method <> 'cash'))
     order by coalesce(b.picked_up_at, b.pickup_at);
end $$;

revoke all on function public.trip_money(uuid), public.trip_money_lines(uuid, text, boolean) from public, anon;
grant execute on function public.trip_money(uuid), public.trip_money_lines(uuid, text, boolean) to authenticated;

commit;
