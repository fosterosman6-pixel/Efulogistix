-- EfuLogistix: database update v19  (run AFTER schema_v18.sql)
--   1. Hire requests are offered to the nearest free driver (accept or decline, 2 minutes), then the next one.
--      If nobody accepts, the booking stays "Waiting for office" as before.
--   2. "Car has arrived" button and an automatic "car is almost there" message to the passenger.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.app_settings add column if not exists auto_offer boolean not null default true;
alter table public.bookings add column if not exists arrived_at timestamptz;
alter table public.bookings add column if not exists near_notified_at timestamptz;

-- ====================================================================================
-- 1. OFFERS
-- ====================================================================================
create table if not exists public.booking_offers (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  driver_id uuid not null references public.profiles (id) on delete cascade,
  truck_id uuid not null references public.trucks (id) on delete cascade,
  status text not null default 'offered' check (status in ('offered', 'accepted', 'declined', 'expired', 'cancelled')),
  offered_at timestamptz not null default now(),
  answered_at timestamptz
);
create unique index if not exists booking_offers_one_open on public.booking_offers (booking_id) where status = 'offered';
create index if not exists booking_offers_driver_idx on public.booking_offers (driver_id, status);

alter table public.booking_offers enable row level security;
drop policy if exists booking_offers_read on public.booking_offers;
create policy booking_offers_read on public.booking_offers for select to authenticated
  using (driver_id = auth.uid() or public.is_manager());
revoke insert, update, delete on public.booking_offers from authenticated;
grant select on public.booking_offers to authenticated;
grant all on public.booking_offers to service_role;

create or replace function public._km_between(a_lat double precision, a_lng double precision, b_lat double precision, b_lng double precision)
returns double precision language sql immutable as $$
  select 2 * 6371 * asin(sqrt(
    power(sin(radians(b_lat - a_lat) / 2), 2) +
    cos(radians(a_lat)) * cos(radians(b_lat)) * power(sin(radians(b_lng - a_lng) / 2), 2)));
$$;

-- Offer a waiting hire booking to the nearest free driver with the right kind of vehicle.
create or replace function public._offer_booking(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; pick record;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind <> 'hire' or b.pickup_lat is null or b.pickup_lng is null then return; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return; end if;
  if b.pickup_at > now() + interval '90 minutes' then return; end if;   -- later bookings stay with the office
  if exists (select 1 from booking_offers where booking_id = b.id and status = 'offered') then return; end if;
  select s.driver_id, s.truck_id,
         public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) as km
    into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join truck_locations l on l.truck_id = s.truck_id and l.updated_at > now() - interval '10 minutes'
   where s.status = 'on_duty'
     and (b.category_id is null or t.category_id = b.category_id)
     and not exists (select 1 from trips tr where tr.driver_id = s.driver_id and tr.status = 'in_progress')
     and not exists (select 1 from booking_offers o where o.booking_id = b.id and o.driver_id = s.driver_id)
     and not exists (select 1 from booking_offers o where o.driver_id = s.driver_id and o.status = 'offered')
     and public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) <= 60
   order by km limit 1;
  if pick.driver_id is null then return; end if;
  insert into booking_offers (booking_id, driver_id, truck_id) values (b.id, pick.driver_id, pick.truck_id);
  perform notify(pick.driver_id, 'New hire request · ' || round(pick.km::numeric, 1) || ' km away',
    b.pickup_name || ' → ' || b.dest_name || ' · K' || to_char(b.price, 'FM999,999,990') || '. Open Booked pickups to accept (2 minutes).', 'booking', b.id);
end $$;
revoke all on function public._offer_booking(uuid) from public, anon, authenticated;

create or replace function public._offer_on_new_booking() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public._offer_booking(new.id);
  return new;
end $$;
drop trigger if exists bookings_offer on public.bookings;
create trigger bookings_offer after insert on public.bookings for each row execute function public._offer_on_new_booking();

-- Driver: accept or decline an offer
create or replace function public.answer_offer(p_offer uuid, p_accept boolean)
returns void language plpgsql security definer set search_path = public as $$
declare o booking_offers%rowtype; b bookings%rowtype; t trucks%rowtype; drv profiles%rowtype;
begin
  select * into o from booking_offers where id = p_offer and driver_id = auth.uid() for update;
  if o.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if o.status <> 'offered' then raise exception 'ALREADY_DECIDED'; end if;
  select * into b from bookings where id = o.booking_id for update;
  if not p_accept then
    update booking_offers set status = 'declined', answered_at = now() where id = o.id;
    perform public._offer_booking(o.booking_id);
    return;
  end if;
  if b.status <> 'requested' then
    update booking_offers set status = 'cancelled', answered_at = now() where id = o.id;
    raise exception 'ALREADY_DECIDED';
  end if;
  select * into t from trucks where id = o.truck_id;
  select * into drv from profiles where id = o.driver_id;
  update bookings set status = 'assigned', truck_id = t.id, driver_id = drv.id, assigned_at = now(),
    message = 'Accepted by the driver',
    category_id = coalesce(b.category_id, t.category_id)
   where id = b.id;
  update booking_offers set status = 'accepted', answered_at = now() where id = o.id;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · car assigned',
    t.plate || coalesce(' · ' || t.colour, '') || coalesce(' ' || t.make, '') || ' · driver ' || coalesce(drv.full_name, '') || coalesce(' · ' || drv.phone, ''),
    'booking', b.id);
end $$;
revoke all on function public.answer_offer(uuid, boolean) from public, anon;
grant execute on function public.answer_offer(uuid, boolean) to authenticated;

-- Every minute: offers nobody answered in 2 minutes go to the next driver
create or replace function public.expire_offers() returns int
language plpgsql security definer set search_path = public as $$
declare o record; n int := 0;
begin
  for o in select * from booking_offers where status = 'offered' and offered_at < now() - interval '2 minutes' loop
    update booking_offers set status = 'expired', answered_at = now() where id = o.id;
    perform notify(o.driver_id, 'Hire request expired', 'It was offered to another driver.', 'booking', o.booking_id);
    perform public._offer_booking(o.booking_id);
    n := n + 1;
  end loop;
  -- offers on bookings the office already handled
  update booking_offers set status = 'cancelled', answered_at = now()
   where status = 'offered' and booking_id in (select id from bookings where status <> 'requested');
  return n;
end $$;
revoke all on function public.expire_offers() from public, anon, authenticated;

do $$ begin
  perform cron.schedule('efu-expire-offers', '* * * * *', 'select public.expire_offers()');
exception when others then null;
end $$;

-- ====================================================================================
-- 2. ARRIVAL
-- ====================================================================================
create or replace function public.booking_arrived(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() and status = 'assigned' for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if b.arrived_at is not null then return; end if;
  update bookings set arrived_at = now() where id = b.id;
  perform notify(b.passenger_id, 'Your car has arrived', 'Booking #' || b.booking_no || ' · show your ticket to the driver.', 'booking', b.id);
end $$;
revoke all on function public.booking_arrived(uuid) from public, anon;
grant execute on function public.booking_arrived(uuid) to authenticated;

-- when the car comes within 1.5 km of the pick-up point, tell the passenger once
create or replace function public._car_near_pickup() returns trigger
language plpgsql security definer set search_path = public as $$
declare b record; km double precision;
begin
  for b in select * from bookings
            where truck_id = new.truck_id and status = 'assigned' and near_notified_at is null
              and pickup_lat is not null and pickup_lng is not null loop
    km := public._km_between(new.lat, new.lng, b.pickup_lat, b.pickup_lng);
    if km <= 1.5 then
      update bookings set near_notified_at = now() where id = b.id;
      perform notify(b.passenger_id, 'Your car is almost there', 'Booking #' || b.booking_no || ' · about ' || greatest(1, round(km * 2)::int) || ' min away. Be ready at ' || b.pickup_name || '.', 'booking', b.id);
    end if;
  end loop;
  return new;
end $$;
drop trigger if exists truck_locations_near on public.truck_locations;
create trigger truck_locations_near after insert or update of lat, lng on public.truck_locations
  for each row execute function public._car_near_pickup();

-- Driver: the requests waiting for my answer (the driver cannot read the booking itself until accepting)
drop function if exists public.my_offers();
create or replace function public.my_offers()
returns table (offer_id uuid, booking_no bigint, pickup_name text, dest_name text, pickup_lat double precision, pickup_lng double precision, dest_lat double precision, dest_lng double precision,
               price numeric, km numeric, trip_type text, pickup_at timestamptz, seconds_left int)
language sql stable security definer set search_path = public as $$
  select o.id, b.booking_no, b.pickup_name, b.dest_name, b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng, b.price, b.km, b.trip_type, b.pickup_at,
         greatest(0, 120 - extract(epoch from now() - o.offered_at)::int)
    from booking_offers o join bookings b on b.id = o.booking_id
   where o.driver_id = auth.uid() and o.status = 'offered' and b.status = 'requested'
   order by o.offered_at;
$$;
revoke all on function public.my_offers() from public, anon;
grant execute on function public.my_offers() to authenticated;
