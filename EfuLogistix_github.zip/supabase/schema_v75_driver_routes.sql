-- Every driver can search all depots. Fixed depot routes with admin fares go only to passenger cars, and only on roads the admin gave their vehicle type; goods vehicles type the destination and fare, or wait for hire.
-- v75: the driver's New trip screen offers every depot as a starting point and every depot ahead as a destination,
-- with the admin's fare for the driver's own vehicle type. Nothing is typed by hand. A new road or depot appears here with no app change.
-- Safe to run twice.
begin;

-- every depot a driver can start a trip from (on any road served by the driver's vehicle type)
create or replace function public.driver_start_depots()
returns table (name text, lat double precision, lng double precision)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  -- every depot, for every vehicle type, so any driver can search a pickup depot
  return query
    select distinct on (s.place_name) s.place_name, s.lat, s.lng
      from corridor_stops s
     where s.can_board
     order by s.place_name;
end $$;

-- from one depot: every depot ahead on every road (both directions) with the km and fare for the driver's vehicle type.
-- A depot on two roads is listed once, using the shorter road.
create or replace function public.driver_depot_routes(p_from text)
returns table (to_name text, to_lat double precision, to_lng double precision, km numeric, fare numeric, corridor_id uuid, from_pos int, to_pos int)
language plpgsql stable security definer set search_path = public as $$
declare cat uuid; from_name text; n_found int;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.category_id into cat from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  if not coalesce((select carries_passengers from vehicle_categories where id = cat), false) then return; end if;
  -- the start name may be spelled differently ("Soko Taxi rank", "Soko"): match ignoring case, then a unique name that starts with it
  from_name := (select s.place_name from corridor_stops s where lower(trim(s.place_name)) = lower(trim(p_from)) limit 1);
  if from_name is null and length(trim(p_from)) >= 3 then
    select min(n), count(*) into from_name, n_found
      from (select distinct place_name as n from corridor_stops where lower(place_name) like lower(trim(p_from)) || '%') q;
    if n_found <> 1 then from_name := null; end if;
  end if;
  if from_name is null then return; end if;
  return query
    select distinct on (x.to_name) x.to_name, x.to_lat, x.to_lng, x.km, x.fare, x.corridor_id, x.from_pos, x.to_pos
      from (
        select d.place_name as to_name, d.lat as to_lat, d.lng as to_lng, f.km, f.fare, c.id as corridor_id, a.pos as from_pos, d.pos as to_pos
          from route_corridors c
          join corridor_stops a on a.corridor_id = c.id and a.place_name = from_name and a.can_board
          join corridor_stops d on d.corridor_id = c.id and d.can_drop and d.pos <> a.pos
          join corridor_fares(c.id, cat) f on f.from_pos = a.pos and f.to_pos = d.pos
         where exists (select 1 from corridor_rates r where r.corridor_id = c.id and r.category_id = cat)
      ) x
     order by x.to_name, x.km;
end $$;

revoke all on function public.driver_start_depots(), public.driver_depot_routes(text) from public, anon;
grant execute on function public.driver_start_depots(), public.driver_depot_routes(text) to authenticated;

commit;
