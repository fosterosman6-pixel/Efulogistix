-- Adds "Ntakataka Turn Off Depot" (M10, pin -14.170608, 34.943866) as a depot on Mangochi - Monkey Bay,
-- right after Cape Maclear Turn Off Depot. Distances and fares are worked out by the road. Safe to run twice.
insert into public.places (name, detail, lat, lng)
values ('Ntakataka Turn Off Depot', 'Depot · M10 at the Ntakataka turn off', -14.170608, 34.943866)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

select public.road_add_depot('Mangochi - Monkey Bay', 'Ntakataka Turn Off Depot', 'Cape Maclear Turn Off Depot');

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay') and pos between 21 and 25 order by pos;
