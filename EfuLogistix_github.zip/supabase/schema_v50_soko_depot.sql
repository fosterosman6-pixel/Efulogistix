-- Soko Taxi Rank becomes a depot on Mangochi - Monkey Bay, between Mangochi Main Rank and Mpondasi.
-- Safe to run twice. Existing depot positions and special fares are moved down by one so nothing is lost.
insert into public.places (name, detail, lat, lng)
values ('Soko Taxi Rank', 'Depot · Soko, Mangochi', -14.479339, 35.256940)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

do $$
declare c uuid;
begin
  select id into c from public.route_corridors where name = 'Mangochi - Monkey Bay';
  if c is null then raise notice 'Corridor Mangochi - Monkey Bay not found'; return; end if;
  if exists (select 1 from public.corridor_stops where corridor_id = c and place_name = 'Soko Taxi Rank') then
    raise notice 'Soko Taxi Rank is already a depot'; return;
  end if;

  update public.corridor_stops set pos = pos + 1000 where corridor_id = c and pos >= 1;
  update public.corridor_stops set pos = pos - 999   where corridor_id = c and pos >= 1000;

  update public.corridor_overrides set from_pos = from_pos + 1000 where corridor_id = c and from_pos >= 1;
  update public.corridor_overrides set to_pos   = to_pos   + 1000 where corridor_id = c and to_pos   >= 1;
  update public.corridor_overrides set from_pos = from_pos - 999  where corridor_id = c and from_pos >= 1000;
  update public.corridor_overrides set to_pos   = to_pos   - 999  where corridor_id = c and to_pos   >= 1000;

  insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
  values (c, 1, 'Soko Taxi Rank', -14.479339, 35.256940);

  -- the stop after Soko (Mpondasi) is measured again, unless you typed that distance yourself
  perform public.corridor_recalc_km(c);
  perform public.corridor_rebuild(c);
end $$;

select pos, place_name, km_from_prev from public.corridor_stops
 where corridor_id = (select id from public.route_corridors where name = 'Mangochi - Monkey Bay') and pos <= 3 order by pos;
