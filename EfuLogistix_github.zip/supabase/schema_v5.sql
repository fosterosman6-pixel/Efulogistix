-- EfuLogistix: database update v5  (run AFTER schema_v4.sql)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice: it only adds.
--
-- v5 adds
--   * ratings: a passenger rates the driver after a completed booking (1-5 stars + comment)
--   * repeat complaints: vehicles and drivers with several reports in the last 30 days
--   * weekly income target for each vehicle, with progress
--   * a "today" summary for the admin panel

-- ====================================================================================
-- RATINGS
-- ====================================================================================
create table if not exists public.ratings (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings (id) on delete cascade,
  passenger_id uuid not null references public.profiles (id) on delete cascade,
  driver_id uuid references public.profiles (id) on delete set null,
  truck_id uuid references public.trucks (id) on delete set null,
  stars int not null check (stars between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);
create index if not exists ratings_driver_idx on public.ratings (driver_id, created_at desc);

create or replace function public.rate_booking(p_booking uuid, p_stars int, p_comment text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; adm record; who text;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_stars is null or p_stars < 1 or p_stars > 5 then raise exception 'BAD_STARS'; end if;
  select * into b from bookings where id = p_booking and passenger_id = auth.uid();
  if b.id is null then raise exception 'BOOKING_NOT_FOUND'; end if;
  if b.status <> 'completed' then raise exception 'NOT_COMPLETED'; end if;
  if exists (select 1 from ratings where booking_id = p_booking) then raise exception 'ALREADY_RATED'; end if;
  insert into ratings (booking_id, passenger_id, driver_id, truck_id, stars, comment)
  values (p_booking, auth.uid(), b.driver_id, b.truck_id, p_stars, nullif(btrim(p_comment), ''));
  if p_stars <= 2 then
    select coalesce(nullif(full_name, ''), email, 'A passenger') into who from profiles where id = auth.uid();
    for adm in select id from profiles where role in ('admin', 'manager') and active loop
      perform public.notify(adm.id, 'Low rating: ' || p_stars || ' star' || case when p_stars = 1 then '' else 's' end,
                            who || ' on booking #' || b.booking_no || coalesce(': ' || nullif(btrim(p_comment), ''), ''), 'rating', p_booking);
    end loop;
  end if;
end $$;

-- Average stars for a driver: the driver, the office, the vehicle's owner, or a passenger who rode with him
create or replace function public.driver_rating(p_driver uuid)
returns table (average numeric, ratings bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (auth.uid() = p_driver or public.is_manager() or public.sees_person(p_driver)
          or exists (select 1 from bookings x where x.driver_id = p_driver and x.passenger_id = auth.uid())) then
    raise exception 'NOT_ALLOWED';
  end if;
  return query select round(avg(r.stars)::numeric, 1), count(*) from ratings r where r.driver_id = p_driver;
end $$;

-- ====================================================================================
-- REPEAT COMPLAINTS (office only)
-- ====================================================================================
create or replace function public.repeat_complaints(p_days int default 30, p_min int default 3)
returns table (kind text, id uuid, name text, reports bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  return query
  select 'vehicle'::text, t.id, t.plate, count(*)
    from support_tickets s join trucks t on t.id = s.truck_id
   where s.created_at > now() - make_interval(days => p_days)
   group by t.id, t.plate having count(*) >= p_min
  union all
  select 'driver'::text, d.id, coalesce(nullif(d.full_name, ''), d.email), count(*)
    from support_tickets s
    join lateral (select coalesce((select x.driver_id from trips x where x.id = s.trip_id),
                                  (select y.driver_id from bookings y where y.id = s.booking_id)) as did) z on true
    join profiles d on d.id = z.did
   where s.created_at > now() - make_interval(days => p_days)
   group by d.id, d.full_name, d.email having count(*) >= p_min
  order by 4 desc;
end $$;

create or replace function public.low_rated_drivers(p_min_ratings int default 3, p_below numeric default 3.5)
returns table (driver_id uuid, name text, average numeric, ratings bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  return query
  select r.driver_id, coalesce(nullif(p.full_name, ''), p.email), round(avg(r.stars)::numeric, 1), count(*)
    from ratings r join profiles p on p.id = r.driver_id
   where r.driver_id is not null
   group by r.driver_id, p.full_name, p.email
  having count(*) >= p_min_ratings and avg(r.stars) < p_below
   order by 3;
end $$;

-- ====================================================================================
-- WEEKLY TARGET PER VEHICLE
-- ====================================================================================
alter table public.trucks add column if not exists weekly_target numeric(12, 2);

create or replace function public.set_truck_target(p_truck uuid, p_amount numeric)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.is_manager() or public.owns_truck(p_truck)) then raise exception 'NOT_ALLOWED'; end if;
  if p_amount is not null and p_amount < 0 then raise exception 'BAD_AMOUNT'; end if;
  update trucks set weekly_target = p_amount where id = p_truck;
end $$;

-- Target, money handed in since Monday, and the percentage reached
create or replace function public.target_progress(p_truck uuid)
returns table (target numeric, collected numeric, percent numeric)
language plpgsql stable security definer set search_path = public as $$
declare tg numeric; got numeric; monday date := (date_trunc('week', now()))::date;
begin
  if not (public.is_manager() or public.owns_truck(p_truck)) then raise exception 'NOT_ALLOWED'; end if;
  select t.weekly_target into tg from trucks t where t.id = p_truck;
  select coalesce(sum(h.collected - h.driver_expenses), 0) into got from hand_ins h where h.truck_id = p_truck and h.day >= monday;
  return query select tg, got, case when tg is not null and tg > 0 then round(got * 100 / tg, 0) end;
end $$;

-- ====================================================================================
-- TODAY (admin panel)
-- ====================================================================================
create or replace function public.today_summary()
returns table (trips_today bigint, collected_today numeric, vehicles_on_duty bigint, people_waiting bigint,
               vehicles_waiting bigint, open_tickets bigint, open_incidents bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  return query select
    (select count(*) from trips where started_at::date = current_date and status <> 'cancelled'),
    (select coalesce(sum(collected), 0) from hand_ins where day = current_date),
    (select count(distinct truck_id) from shifts where status = 'on_duty'),
    (select count(*) from profiles where not active and role in ('driver', 'owner', 'passenger')),
    (select count(*) from trucks where status = 'pending'),
    (select count(*) from support_tickets where status <> 'solved'),
    (select count(*) from incidents where status = 'open');
end $$;

-- ====================================================================================
-- SECURITY AND ACCESS
-- ====================================================================================
alter table public.ratings enable row level security;
drop policy if exists ratings_read on public.ratings;
create policy ratings_read on public.ratings for select to authenticated
  using (passenger_id = auth.uid() or public.is_manager() or driver_id = auth.uid() or public.owns_truck(truck_id));
revoke insert, update, delete on public.ratings from authenticated;
grant select on public.ratings to authenticated;
grant all on public.ratings to service_role;
grant execute on function public.rate_booking(uuid, int, text) to authenticated;
grant execute on function public.driver_rating(uuid) to authenticated;
grant execute on function public.repeat_complaints(int, int) to authenticated;
grant execute on function public.low_rated_drivers(int, numeric) to authenticated;
grant execute on function public.set_truck_target(uuid, numeric) to authenticated;
grant execute on function public.target_progress(uuid) to authenticated;
grant execute on function public.today_summary() to authenticated;
