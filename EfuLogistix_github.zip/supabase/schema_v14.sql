-- v14 · More vehicle categories: Pickup, Truck, Bus, Coach (the app already has their photos).
-- Hire prices and EfuLogistix fees start as a copy of a similar category; change them in the admin panel (Vehicle types).
-- Safe to run again.
insert into public.vehicle_categories (name, carries_passengers, carries_goods, seats, licence_classes, hire_per_km, hire_min, fee_weekly, fee_monthly, fee_per_trip)
select v.name, v.pax, v.goods, v.seats, v.lic, c.hire_per_km, c.hire_min, c.fee_weekly, c.fee_monthly, c.fee_per_trip
from (values
  ('Pickup', true,  true,  3,  '{B,EB,C1,C}'::text[],        'Taxi'),
  ('Truck',  false, true,  0,  '{C,EC1,EC}'::text[],         'Lorry'),
  ('Bus',    true,  false, 60, '{D,ED1,ED}'::text[],         'Minibus'),
  ('Coach',  true,  false, 50, '{D,ED1,ED}'::text[],         'Minibus')
) as v(name, pax, goods, seats, lic, copy_of)
join public.vehicle_categories c on c.name = v.copy_of
on conflict (name) do nothing;
