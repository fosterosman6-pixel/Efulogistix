\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
reset role;
insert into results select 'number 0888123456', _malawi_number('0888 123 456')='265888123456', _malawi_number('0888 123 456');
insert into results select 'number +265', _malawi_number('+265 888 123 456')='265888123456', '';
insert into results select 'bad number', _malawi_number('12')  is null, '';
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000f1','own@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000c1','pax@x.com');
update profiles set role='owner', active=true where email='own@x.com';
update profiles set role='passenger', active=true, full_name='Fatima Banda' where email='pax@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='drv@x.com';
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,receiver_name,receiver_phone,driver_id,truck_id) values ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000c1','goods','assigned',0,5000,now(),'cash','Mangochi','Monkey Bay','Ali','0999 111 222','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01');
insert into booking_codes(booking_id,code) values ('00000000-0000-0000-0000-0000000000d1','4821');
update bookings set status='picked_up' where id='00000000-0000-0000-0000-0000000000d1';
insert into results select 'receiver text logged', (select count(*) from sms_log where kind='parcel_on_way' and to_phone='265999111222' and body like '%4821%')=1, (select body from sms_log limit 1);
update bookings set status='assigned' where id='00000000-0000-0000-0000-0000000000d1';
update bookings set status='picked_up' where id='00000000-0000-0000-0000-0000000000d1';
insert into results select 'sent only once', (select count(*) from sms_log)=1, '';
select * from results;
