\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='admin', active=true where email='admin@x.com';
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='drv@x.com';
insert into shifts(id,driver_id,truck_id,start_km) values ('00000000-0000-0000-0000-000000000511','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',100);
insert into trips(id,driver_id,truck_id,shift_id,pickup_name,dest_name,dest_lat,dest_lng,passengers,fare_per_passenger) values ('00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-000000000511','A','B',0,0,6,8000);
insert into results select 'nothing before completion', (select count(*) from wallet_entries)=0, '';
update trips set status='completed', ended_at=now() where id='00000000-0000-0000-0000-0000000000c1';
insert into results select 'trip credited 10%', (select amount from wallet_entries where trip_id='00000000-0000-0000-0000-0000000000c1')=4800, (select string_agg(amount::text,',') from wallet_entries);
insert into results select 'driver told', (select count(*) from notices where title like '+ K4,800%')=1, '';
update trips set status='completed' where id='00000000-0000-0000-0000-0000000000c1';
insert into results select 'not credited twice', (select count(*) from wallet_entries)=1, '';
insert into trips(id,driver_id,truck_id,shift_id,pickup_name,dest_name,dest_lat,dest_lng,passengers,fare_per_passenger) values ('00000000-0000-0000-0000-0000000000c2','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-000000000511','B','C',0,0,5,8000);
update trips set status='cancelled' where id='00000000-0000-0000-0000-0000000000c2';
insert into results select 'cancelled earns nothing', (select count(*) from wallet_entries)=1, '';
-- day collected 48000, driver expenses 8000 -> expected 40000 -> share 4000; already 4800 -> adjust -800
insert into hand_ins(id,shift_id,driver_id,truck_id,collected,driver_expenses) values ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-000000000511','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',48000,8000);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000f1');
select public.receive_hand_in('00000000-0000-0000-0000-0000000000d1',40000,'cash',null,null);
reset role;
insert into results select 'balance equals 10% after expenses', (select sum(amount) from wallet_entries where driver_id='00000000-0000-0000-0000-0000000000e1')=4000, (select string_agg(amount::text,',') from wallet_entries);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000f1');
select public.pay_wallet('00000000-0000-0000-0000-0000000000e1',0,'cash',null,null);
reset role;
insert into results select 'paid out clears wallet', (select sum(amount) from wallet_entries)=0, '';
select name, ok, info from results order by 1;
