\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com');
update profiles set role='admin', active=true where email='admin@x.com';
update profiles set role='driver', active=true where email='drv@x.com';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
insert into place_suggestions(name,detail,lat,lng,suggested_by) values ('Chitundu shop','Mangochi',-14.4,35.2,'00000000-0000-0000-0000-0000000000e1');
insert into results select 'driver suggests', (select count(*) from place_suggestions)=1, '';
select public.decide_place_suggestion((select id from place_suggestions), true);
insert into results select 'driver cannot approve', (select status from place_suggestions)='pending', '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
select public.decide_place_suggestion((select id from place_suggestions), true);
insert into results select 'admin approves into places', (select count(*) from places where name='Chitundu shop')=1 and (select status from place_suggestions)='approved', '';
reset role;
insert into results select 'driver told', (select count(*) from notices where title like 'Place added%')=1, '';
select * from results;
