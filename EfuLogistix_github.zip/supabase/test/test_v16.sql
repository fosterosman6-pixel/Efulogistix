\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000f1','own@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000c1','pax@x.com');
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='drv@x.com';
insert into bookings(id,passenger_id,kind,status,driver_id,truck_id,seats,price,pickup_at,pay_method,pickup_name,dest_name) values ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000c1','seat','assigned','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',1,8000,now(),'cash','A','B');
insert into booking_tickets values ('00000000-0000-0000-0000-0000000000d1','12345678');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
select public.booking_step('00000000-0000-0000-0000-0000000000d1','picked_up',null,null);
insert into results select 'tap without code refused', (select status from bookings)='assigned', '';
select public.board_by_code('1234-5678');
insert into results select 'code boards', (select status from bookings)='picked_up', '';
reset role;
select * from results;
