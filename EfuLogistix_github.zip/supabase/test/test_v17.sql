\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com');
update profiles set role='admin', active=true where email='admin@x.com';
update profiles set role='driver', active=true where email='drv@x.com';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
insert into results select 'driver reads places', (select count(*) from places)=2, '';
insert into places(name,lat,lng) values ('Hack',1,1);
insert into results select 'driver cannot add', (select count(*) from places)=2, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into places(name,detail,lat,lng) values ('Test place','x',-14.5,35.2);
insert into results select 'admin adds', (select count(*) from places)=3, '';
reset role;
select * from results;
