-- LOCAL ONLY. Tests for v27 (chat). Not for Supabase.
\set ON_ERROR_STOP off
begin;
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','pax@x.com'),('00000000-0000-0000-0000-0000000000a2','drv@x.com'),
 ('00000000-0000-0000-0000-0000000000a3','own@x.com'),('00000000-0000-0000-0000-0000000000a4','other@x.com'),('00000000-0000-0000-0000-0000000000a5','drv2@x.com');
update profiles set role='passenger', active=true where email in ('pax@x.com','other@x.com');
update profiles set role='driver', active=true where email in ('drv@x.com','drv2@x.com');
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,status,active) values ('00000000-0000-0000-0000-0000000000b1','T1','00000000-0000-0000-0000-0000000000a3','approved',true);
update profiles set truck_id='00000000-0000-0000-0000-0000000000b1' where email='drv@x.com';
insert into bookings(id,passenger_id,driver_id,kind,status,price,pickup_at,pay_method,pickup_name,dest_name) values
 ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000a2','seat','assigned',9000,now(),'cash','A','B'),
 ('00000000-0000-0000-0000-0000000000d2','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000a2','seat','cancelled',9000,now(),'cash','A','B');
create or replace function pg_temp.chat(uid text, bk uuid, peer uuid, txt text) returns text language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub',uid,true);
  execute 'set local role authenticated';
  perform public.send_chat(bk, peer, txt);
  execute 'reset role';
  return 'OK';
exception when others then execute 'reset role'; return sqlerrm; end $$;
insert into results select 'passenger writes to driver on an assigned booking', pg_temp.chat('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1',null,'Hello driver')='OK', '';
insert into results select 'driver answers the passenger', pg_temp.chat('00000000-0000-0000-0000-0000000000a2','00000000-0000-0000-0000-0000000000d1',null,'On my way')='OK', '';
insert into results select 'recipient is the other person and got a notice', (select count(*) from chat_messages where booking_id='00000000-0000-0000-0000-0000000000d1' and recipient_id='00000000-0000-0000-0000-0000000000a2')=1 and (select count(*) from notices where user_id='00000000-0000-0000-0000-0000000000a1' and kind='chat')=1, '';
insert into results select 'a stranger cannot write on the booking', pg_temp.chat('00000000-0000-0000-0000-0000000000a4','00000000-0000-0000-0000-0000000000d1',null,'hi') like '%not allowed%', '';
insert into results select 'a cancelled booking is closed', pg_temp.chat('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d2',null,'hi')='CHAT_CLOSED', '';
insert into results select 'empty message refused', pg_temp.chat('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1',null,'   ')='BAD_MESSAGE', '';
insert into results select 'owner writes to the driver of own vehicle', pg_temp.chat('00000000-0000-0000-0000-0000000000a3',null,'00000000-0000-0000-0000-0000000000a2','Service due')='OK', '';
insert into results select 'driver writes to own owner', pg_temp.chat('00000000-0000-0000-0000-0000000000a2',null,'00000000-0000-0000-0000-0000000000a3','Ok boss')='OK', '';
insert into results select 'owner cannot write to a driver of another vehicle', pg_temp.chat('00000000-0000-0000-0000-0000000000a3',null,'00000000-0000-0000-0000-0000000000a5','hi') like '%not allowed%', '';
insert into results select 'passenger cannot write to the owner', pg_temp.chat('00000000-0000-0000-0000-0000000000a1',null,'00000000-0000-0000-0000-0000000000a3','hi') like '%not allowed%', '';
-- reading: the stranger sees nothing, the passenger sees their own thread
set local role authenticated; select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000a4',true);
create temp table seen_stranger as select count(*)::int n from chat_messages;
reset role;
insert into results select 'a stranger reads no messages', (select n from seen_stranger)=0, (select n::text from seen_stranger);
insert into results select 'a voice note can be sent', pg_temp.chat('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1',null,'')='BAD_MESSAGE', 'empty text still refused';
create or replace function pg_temp.media(uid text, bk uuid, k text, pth text) returns text language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub',uid,true);
  execute 'set local role authenticated';
  perform public.send_chat(bk, null, '', k, pth, 7);
  execute 'reset role';
  return 'OK';
exception when others then execute 'reset role'; return sqlerrm; end $$;
insert into results select 'voice note with own folder path is accepted', pg_temp.media('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1','voice','00000000-0000-0000-0000-0000000000a1/v1.m4a')='OK', '';
insert into results select 'photo with someone else''s folder is refused', pg_temp.media('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1','photo','00000000-0000-0000-0000-0000000000a2/p1.jpg')='BAD_MESSAGE', '';
insert into results select 'voice without a file is refused', pg_temp.media('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000d1','voice',null)='BAD_MESSAGE', '';
select name, case when ok then 'PASS' else 'FAIL' end, coalesce(info,'') from results;
rollback;
