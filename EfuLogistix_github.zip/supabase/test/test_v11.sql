\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='admin', active=true where email='admin@x.com';
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='drv@x.com';
insert into shifts(id,driver_id,truck_id,start_km,started_at) values ('00000000-0000-0000-0000-000000000511','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',100, now()-interval '7 days');
create temp table n1 as select public.send_stale_shift_notices() n;
insert into results select 'driver + owner told', (select n from n1)=2, (select n::text from n1);
create temp table n2 as select public.send_stale_shift_notices() n;
insert into results select 'told once per day', (select n from n2)=0, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
do $$ begin perform public.admin_close_shift('00000000-0000-0000-0000-000000000511'); insert into results values('driver cannot close shifts',false,''); exception when others then insert into results values('driver cannot close shifts', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
select public.admin_close_shift('00000000-0000-0000-0000-000000000511','test');
reset role;
insert into results select 'shift closed + flagged', (select status||review||end_reason from shifts where id='00000000-0000-0000-0000-000000000511')='off_dutyflaggedadmin_closed', '';
insert into results select 'driver told shift was closed', (select count(*) from notices where title like 'Your shift was closed%')=1, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$ begin perform public.admin_close_shift('00000000-0000-0000-0000-000000000511'); insert into results values('cannot close twice',false,''); exception when others then insert into results values('cannot close twice', sqlerrm='NOT_ON_DUTY', sqlerrm); end $$;
reset role;
-- running trip blocks closing
insert into shifts(id,driver_id,truck_id,start_km) values ('00000000-0000-0000-0000-000000000512','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',200);
insert into trips(driver_id,truck_id,shift_id,pickup_name,dest_name,dest_lat,dest_lng) values ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-000000000512','A','B',0,0);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$ begin perform public.admin_close_shift('00000000-0000-0000-0000-000000000512'); insert into results values('running trip blocks closing',false,''); exception when others then insert into results values('running trip blocks closing', sqlerrm='TRIP_RUNNING', sqlerrm); end $$;
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
