\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000c1','pax@x.com');
update profiles set role='passenger', active=true where email='pax@x.com';
insert into vehicle_categories(name,seats,hire_per_km,hire_min,active) values ('TestCar',4,900,5000,true);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000c1');
create temp table r2(n text);
grant all on r2 to authenticated;
do $$ declare cid uuid; begin
  select id into cid from vehicle_categories where name='TestCar';
  begin perform book(jsonb_build_object('kind','hire','category_id',cid,'pickup_name','Somerset West','pickup_lat',-34.08,'pickup_lng',18.84,'dest_name','Mangochi','dest_lat',-14.47,'dest_lng',35.26));
  exception when others then insert into r2 values (sqlerrm); end;
  begin perform book(jsonb_build_object('kind','hire','category_id',cid,'pickup_name','Mangochi','pickup_lat',-14.47,'pickup_lng',35.26,'dest_name','Mpondasi','dest_lat',-14.46,'dest_lng',35.24,'km',5));
  insert into r2 values ('ok'); exception when others then insert into r2 values (sqlerrm); end;
end $$;
insert into results select 'outside Malawi refused', exists (select 1 from r2 where n='OUT_OF_AREA'), (select string_agg(n,',') from r2);
insert into results select 'Malawi trip accepted', exists (select 1 from r2 where n='ok'), '';
select * from results;
