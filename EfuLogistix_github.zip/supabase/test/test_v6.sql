\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),
 ('00000000-0000-0000-0000-0000000000d1','p1@x.com'),('00000000-0000-0000-0000-0000000000d2','p2@x.com'),('00000000-0000-0000-0000-0000000000d3','p3@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='passenger', active=true where email in ('p1@x.com','p2@x.com','p3@x.com');
insert into results select 'everyone got a referral code', count(*)=0, count(*)::text from profiles where referral_code is null;
insert into results select 'codes are unique', (select count(distinct referral_code) from profiles)=(select count(*) from profiles), '';
insert into vehicle_categories(id,name,seats) values ('00000000-0000-0000-0000-0000000000c1','Minibus',2) on conflict do nothing;
insert into routes(id,from_name,to_name,fare,category_id) values ('00000000-0000-0000-0000-000000000a01','Mangochi','Blantyre',9000,(select id from vehicle_categories where name='Minibus' limit 1));
insert into departures(id,route_id,leaves_at,seats) values ('00000000-0000-0000-0000-000000000d01','00000000-0000-0000-0000-000000000a01','06:00',2);
\set day '(current_date + 3)'
-- p1 books both seats, p3 joins the waiting list when full
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table b1 as select public.book(jsonb_build_object('kind','seat','departure_id','00000000-0000-0000-0000-000000000d01','travel_on',(current_date+3)::text,'seats',2)) id;
grant select on b1 to authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d3');
do $$ begin perform public.join_waitlist('00000000-0000-0000-0000-000000000d01', current_date+3, 1); insert into results values('joined waiting list when full', true, ''); exception when others then insert into results values('joined waiting list when full', false, sqlerrm); end $$;
do $$ begin perform public.join_waitlist('00000000-0000-0000-0000-000000000d01', current_date+3, 1); insert into results values('cannot join twice',false,''); exception when others then insert into results values('cannot join twice', sqlerrm='ALREADY_WAITING', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
select public.join_waitlist('00000000-0000-0000-0000-000000000d01', current_date+3, 2);
-- p1 cancels both seats: first in line (p3, 1 seat) is told, then p2 (2 seats) does not fit in the 1 left
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.cancel_booking((select id from b1), 'plans changed');
reset role;
insert into results select 'first in line told', (select count(*) from notices where user_id='00000000-0000-0000-0000-0000000000d3' and kind='waitlist')=1, '';
insert into results select 'second (needs 2) told too, 2 seats free', (select count(*) from notices where user_id='00000000-0000-0000-0000-0000000000d2' and kind='waitlist')=0, (select count(*)::text from notices where user_id='00000000-0000-0000-0000-0000000000d2' and kind='waitlist');
insert into results select 'told status saved', (select status from waitlist where passenger_id='00000000-0000-0000-0000-0000000000d3')='told', '';
-- seats still free: join when there is room is refused
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d3');
do $$ begin perform public.join_waitlist('00000000-0000-0000-0000-000000000d01', current_date+3, 1); insert into results values('no waiting when seats free',false,''); exception when others then insert into results values('no waiting when seats free', sqlerrm='SEATS_AVAILABLE', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
select public.leave_waitlist((select id from waitlist where passenger_id='00000000-0000-0000-0000-0000000000d2'));
insert into results select 'left waiting list', (select status from waitlist where passenger_id='00000000-0000-0000-0000-0000000000d2')='cancelled', '';
-- referrals
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table c1 as select code from public.my_referral();
grant select on c1 to authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
do $$ begin perform public.use_referral((select code from c1)); insert into results values('referral code used', true, ''); exception when others then insert into results values('referral code used', false, sqlerrm); end $$;
do $$ begin perform public.use_referral((select code from c1)); insert into results values('cannot use a code twice',false,''); exception when others then insert into results values('cannot use a code twice', sqlerrm='ALREADY_USED', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
do $$ begin perform public.use_referral((select code from c1)); insert into results values('cannot use own code',false,''); exception when others then insert into results values('cannot use own code', sqlerrm='OWN_CODE', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d3');
do $$ begin perform public.use_referral('ZZZZZZ'); insert into results values('bad code refused',false,''); exception when others then insert into results values('bad code refused', sqlerrm='BAD_CODE', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
insert into results select 'inviter sees 1 person and a notice', (select people from public.my_referral())=1 and (select count(*) from notices where kind='referral')=1, (select people::text from public.my_referral());
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
