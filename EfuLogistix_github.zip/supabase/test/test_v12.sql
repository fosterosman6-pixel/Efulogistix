\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='admin', active=true where email='admin@x.com';
update profiles set role='owner', active=true where email='own@x.com';
update profiles set role='driver', active=true where email='drv@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved');
-- a bill whose period ended 30 days ago and is not paid
insert into fee_bills(id,truck_id,owner_id,plan,period_start,period_end,amount) values ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000f1','weekly',current_date-37,current_date-31,5000);
insert into results select 'overdue counted', public.overdue_fee_count('00000000-0000-0000-0000-0000000000f1')=1, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$ begin perform public.match_driver('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',now()+interval '1 day','','');
  insert into results values('match blocked',false,''); exception when others then insert into results values('match blocked', sqlerrm='FEES_OVERDUE', sqlerrm); end $$;
reset role;
create temp table n1 as select public.send_overdue_fee_notices() n;
insert into results select 'owner told', (select n from n1)=1 and (select count(*) from notices where title like 'Fee overdue%')=1, '';
insert into results select 'alert raised', (select count(*) from alerts where kind='fee_overdue' and not resolved)=1, '';
create temp table n2 as select public.send_overdue_fee_notices() n;
insert into results select 'told once a week', (select n from n2)=0, '';
update fee_bills set status='paid' where id='00000000-0000-0000-0000-0000000000b1';
select public.send_overdue_fee_notices();
insert into results select 'alert closed when paid', (select count(*) from alerts where kind='fee_overdue' and not resolved)=0, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$ begin perform public.match_driver('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',now()+interval '1 day','',''); insert into results values('match allowed after paying',true,''); exception when others then insert into results values('match allowed after paying',false,sqlerrm); end $$;
reset role;
-- a recent bill is not overdue
insert into fee_bills(truck_id,owner_id,plan,period_start,period_end,amount) values ('00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000f1','monthly',current_date-6,current_date,5000);
insert into results select 'recent bill not overdue', public.overdue_fee_count('00000000-0000-0000-0000-0000000000f1')=0, '';
select name, ok, info from results order by 1;
