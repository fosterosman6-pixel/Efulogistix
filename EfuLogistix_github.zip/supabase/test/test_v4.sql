\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000b1','owner@x.com'),
 ('00000000-0000-0000-0000-0000000000c1','driver@x.com'),('00000000-0000-0000-0000-0000000000d1','pax@x.com'),
 ('00000000-0000-0000-0000-0000000000e1','owner2@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='owner', active=true where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000e1');
update profiles set role='driver', active=true where id='00000000-0000-0000-0000-0000000000c1';
update profiles set role='passenger', active=true where id='00000000-0000-0000-0000-0000000000d1';
insert into trucks(id,plate,owner_id) values ('00000000-0000-0000-0000-000000000f01','MZ 1',(select id from profiles where email='owner@x.com')),
 ('00000000-0000-0000-0000-000000000f02','MZ 2',(select id from profiles where email='owner2@x.com'));
update profiles set truck_id='00000000-0000-0000-0000-000000000f01' where email='driver@x.com';
insert into shifts(id,driver_id,truck_id,status,start_km,end_km,ended_at,started_at) values
 ('00000000-0000-0000-0000-000000000501',(select id from profiles where email='driver@x.com'),'00000000-0000-0000-0000-000000000f01','off_duty',1000,1200,now(),now());
insert into trips(id,driver_id,truck_id,pickup_name,dest_name,dest_lat,dest_lng,passengers,fare_per_passenger,status,shift_id)
 values ('00000000-0000-0000-0000-000000000601',(select id from profiles where email='driver@x.com'),'00000000-0000-0000-0000-000000000f01','A','B',-14,35,10,5000,'completed','00000000-0000-0000-0000-000000000501');
insert into hand_ins(shift_id,driver_id,truck_id,collected,driver_expenses) values
 ('00000000-0000-0000-0000-000000000501',(select id from profiles where email='driver@x.com'),'00000000-0000-0000-0000-000000000f01',50000,5000);
insert into expenses(truck_id,created_by,category,litres,amount,paid_by) values
 ('00000000-0000-0000-0000-000000000f01',(select id from profiles where email='driver@x.com'),'fuel',40,60000,'office'),
 ('00000000-0000-0000-0000-000000000f01',(select id from profiles where email='driver@x.com'),'repair',null,7000,'office');

-- passenger reports; safety is urgent
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table t1 as select public.report_problem('safety','Driver was speeding') id;
create temp table t2 as select public.report_problem('overcharged','Charged too much') id;
grant select on t1, t2 to authenticated;
insert into results select 'passenger sees own 2 tickets', count(*)=2, count(*)::text from support_tickets;
insert into results select 'safety ticket is urgent', (select priority from support_tickets where id=(select id from t1))='urgent', '';
insert into results select 'bad reason refused', (select count(*) from (select 1) x where false)=0, '' ;
do $$ begin perform public.report_problem('nonsense','x'); insert into results values('bad reason refused',false,'no error'); exception when others then insert into results values('bad reason refused', sqlerrm='BAD_REASON', sqlerrm); end $$;
select public.ticket_reply((select id from t1),'It happened on the Mangochi road');
-- other user cannot see or reply
select pg_temp.as_user('00000000-0000-0000-0000-0000000000c1');
insert into results select 'driver cannot see passenger ticket', count(*)=0, count(*)::text from support_tickets;
do $$ begin perform public.ticket_reply((select id from t1),'hi'); insert into results values('driver cannot reply',false,''); exception when others then insert into results values('driver cannot reply', sqlerrm='TICKET_NOT_FOUND', sqlerrm); end $$;
-- direct insert blocked
do $$ begin insert into support_tickets(reason) values('other'); insert into results values('direct insert blocked',false,''); exception when others then insert into results values('direct insert blocked',true,sqlerrm); end $$;
-- admin: inbox, reply, status
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into results select 'admin sees both tickets', count(*)=2, count(*)::text from support_tickets;
insert into results select 'admin got notices (2 tickets + 1 msg)', count(*)=3, count(*)::text from notices where user_id='00000000-0000-0000-0000-0000000000a1' and kind='support';
select public.ticket_reply((select id from t1),'We are looking into it');
insert into results select 'staff reply moves to in_progress', (select status from support_tickets where id=(select id from t1))='in_progress', '';
select public.ticket_set_status((select id from t1),'solved');
reset role;
insert into results select 'passenger notified of reply and solved', (select count(*) from notices where user_id='00000000-0000-0000-0000-0000000000d1')=2, (select count(*)::text from notices where user_id='00000000-0000-0000-0000-0000000000d1');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.ticket_reply((select id from t1),'Still not fixed');
insert into results select 'person reply reopens solved ticket', (select status from support_tickets where id=(select id from t1))='open', '';
do $$ begin perform public.ticket_set_status((select id from t1),'solved'); insert into results values('passenger cannot set status',false,''); exception when others then insert into results values('passenger cannot set status', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;

-- SOS
select pg_temp.as_user('00000000-0000-0000-0000-0000000000c1');
create temp table i1 as select public.raise_incident('breakdown',-14.48,35.26,'Flat tyre') id;
grant select on i1 to authenticated;
insert into results select 'incident saved with truck', (select truck_id from incidents where id=(select id from i1))='00000000-0000-0000-0000-000000000f01', '';
reset role;
insert into results select 'owner + admin notified of breakdown', (select count(*) from notices where kind='breakdown')=2, (select count(*)::text from notices where kind='breakdown');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
insert into results select 'other owner cannot see incident', count(*)=0, count(*)::text from incidents;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
insert into results select 'owner sees incident', count(*)=1, count(*)::text from incidents;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
select public.handle_incident((select id from i1));
insert into results select 'admin handled incident', (select status from incidents where id=(select id from i1))='handled','';

-- fuel economy + statement
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
insert into results select 'fuel economy 200km/40L = 5', (select km_per_litre from public.fuel_economy('00000000-0000-0000-0000-000000000f01', current_date-1, current_date+1))=5, (select km_per_litre::text from public.fuel_economy('00000000-0000-0000-0000-000000000f01', current_date-1, current_date+1));
do $$ begin perform * from public.fuel_economy('00000000-0000-0000-0000-000000000f02', current_date-1, current_date+1); insert into results values('owner blocked from other truck fuel',false,''); exception when others then insert into results values('owner blocked from other truck fuel', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
insert into results select 'statement: only my truck', count(*)=1, count(*)::text from public.owner_statement(current_date-1, current_date+1);
insert into results select 'statement profit = 50000-5000-67000-0', (select profit from public.owner_statement(current_date-1, current_date+1))=(50000-5000-67000), (select profit::text from public.owner_statement(current_date-1, current_date+1));
insert into results select 'statement trips/pax', (select trips=1 and passengers=10 from public.owner_statement(current_date-1, current_date+1)),'';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into results select 'admin statement sees all trucks', count(*)=2, count(*)::text from public.owner_statement(current_date-1, current_date+1);
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
