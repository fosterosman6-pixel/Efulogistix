\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','MC 1234','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01', next_of_kin_name='A', next_of_kin_phone='1' where email='drv@x.com';
insert into documents(driver_id,kind,status) values ('00000000-0000-0000-0000-0000000000e1','national_id','approved'),('00000000-0000-0000-0000-0000000000e1','licence','approved'),('00000000-0000-0000-0000-0000000000e1','selfie','approved');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
do $$ begin perform public.start_shift(1000,'odo.jpg',null,null); insert into results values('no side photos = refused',false,''); exception when others then insert into results values('no side photos = refused', sqlerrm='PHOTO_REQUIRED', sqlerrm); end $$;
do $$ begin perform public.start_shift(1000,'odo.jpg',null,null,array['a','b','c']); insert into results values('3 photos = refused',false,''); exception when others then insert into results values('3 photos = refused', sqlerrm='PHOTO_REQUIRED', sqlerrm); end $$;
do $$ begin perform public.start_shift(1000,null,null,null,array['a','b','c','d']); insert into results values('no mileage photo = refused',false,''); exception when others then insert into results values('no mileage photo = refused', sqlerrm='PHOTO_REQUIRED', sqlerrm); end $$;
create temp table s1 as select public.start_shift(1000,'odo.jpg',null,null,array['f.jpg','b.jpg','l.jpg','r.jpg']) id;
grant select on s1 to authenticated;
reset role;
insert into results select '4 photos = shift starts and photos saved', (select cardinality(start_truck_photos) from shifts where id=(select id from s1))=4, '';
-- setting off: old-style call works
update app_settings set require_start_photos=false where id=1;
update shifts set status='off_duty' where id=(select id from s1);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
do $$ begin perform public.start_shift(1010,'odo2.jpg',null,null); insert into results values('setting off = photos optional', true, ''); exception when others then insert into results values('setting off = photos optional', false, sqlerrm); end $$;
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
