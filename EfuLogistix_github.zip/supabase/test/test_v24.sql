-- LOCAL ONLY. Tests for v24 (a driver can start a hire without a ticket). Not for Supabase.
\set ON_ERROR_STOP off
begin;
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000e1','drv@x.com');
update profiles set role='driver', active=true where email='drv@x.com';
insert into bookings(id,caller_name,caller_phone,driver_id,kind,status,price,km,rate_per_km,trip_type,pickup_at,pay_method,pickup_name,dest_name) values
 ('00000000-0000-0000-0000-0000000000d1','Phone caller','0999000000','00000000-0000-0000-0000-0000000000e1','hire','assigned',27000,30,900,'one_way',now(),'cash','A','B'),
 ('00000000-0000-0000-0000-0000000000d2','Phone caller','0999000000','00000000-0000-0000-0000-0000000000e1','seat','assigned',9000,0,0,null,now(),'cash','A','B');
create or replace function pg_temp.step(id uuid, s text) returns text language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000e1',true);
  execute 'set local role authenticated';
  perform public.booking_step(id, s, null, null);
  execute 'reset role';
  return 'OK';
exception when others then execute 'reset role'; return sqlerrm; end $$;
create temp table r1 as select pg_temp.step('00000000-0000-0000-0000-0000000000d1','picked_up') as r;
insert into results select 'hire (phone-in, no ticket) can be started', (select r from r1)='OK' and (select status from bookings where id='00000000-0000-0000-0000-0000000000d1')='picked_up', (select r from r1);
insert into results select 'a seat still needs the ticket', pg_temp.step('00000000-0000-0000-0000-0000000000d2','picked_up')='CODE_REQUIRED', '';
select name, case when ok then 'PASS' else 'FAIL' end, coalesce(info,'') from results;
rollback;
