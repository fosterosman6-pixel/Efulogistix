\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000d1','p1@x.com'),('00000000-0000-0000-0000-0000000000d2','p2@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='passenger', active=true where email like 'p%@x.com';
-- no config yet: notice does not call out
select public.notify('00000000-0000-0000-0000-0000000000d1','Hello','No push yet','test',null);
insert into results select 'no config = no call, no error', count(*)=0, count(*)::text from net_calls;
-- register token
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.register_device('tok_aaaaaaaaaaaaaaaaaaaaaaaa');
do $$ begin perform public.register_device('x'); insert into results values('short token refused',false,''); exception when others then insert into results values('short token refused', sqlerrm='BAD_TOKEN', sqlerrm); end $$;
insert into results select 'owner sees own token', count(*)=1, count(*)::text from device_tokens;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
insert into results select 'other user sees none', count(*)=0, count(*)::text from device_tokens;
do $$ begin perform public.set_push_config('https://x.supabase.co/functions/v1/send-push','0123456789abcdef0123'); insert into results values('passenger cannot set config',false,''); exception when others then insert into results values('passenger cannot set config', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
do $$ begin perform * from push_config; insert into results values('apps cannot read the secret',false,''); exception when others then insert into results values('apps cannot read the secret', true, sqlerrm); end $$;
-- same phone, new user: token moves
select public.register_device('tok_aaaaaaaaaaaaaaaaaaaaaaaa');
reset role;
insert into results select 'token moves to latest user', (select user_id from device_tokens where token='tok_aaaaaaaaaaaaaaaaaaaaaaaa')='00000000-0000-0000-0000-0000000000d2', '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$ begin perform public.set_push_config('http://bad','short'); insert into results values('bad config refused',false,''); exception when others then insert into results values('bad config refused', sqlerrm='BAD_CONFIG', sqlerrm); end $$;
select public.set_push_config('https://x.supabase.co/functions/v1/send-push','0123456789abcdef0123');
reset role;
-- with config: notice to a person with a token calls out; without token does not
select public.notify('00000000-0000-0000-0000-0000000000d2','Seat free','Book now','waitlist',null);
select public.notify('00000000-0000-0000-0000-0000000000d1','No phone','x','test',null);
insert into results select 'one push call (only user with a token)', count(*)=1, count(*)::text from net_calls;
insert into results select 'call carries secret + message', (select headers->>'x-push-secret' from net_calls limit 1)='0123456789abcdef0123' and (select body->>'title' from net_calls limit 1)='Seat free', '';
insert into results select 'notice still saved', (select count(*) from notices)=3, (select count(*)::text from notices);
-- a failing http call must not break the notice
create or replace function net.http_post(url text, headers jsonb default '{}', body jsonb default '{}', timeout_milliseconds int default 5000) returns bigint
language plpgsql as $$ begin raise exception 'network down'; end $$;
select public.notify('00000000-0000-0000-0000-0000000000d2','Another','x','test',null);
insert into results select 'failed push does not block the notice', (select count(*) from notices where title='Another')=1, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
select public.unregister_device('tok_aaaaaaaaaaaaaaaaaaaaaaaa');
insert into results select 'unregister removes token', count(*)=0, count(*)::text from device_tokens;
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
