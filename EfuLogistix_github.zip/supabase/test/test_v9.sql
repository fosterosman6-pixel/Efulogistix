\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated, anon;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000d1','p1@x.com'),
 ('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='passenger', active=true, full_name='Mary Banda' where email='p1@x.com';
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,make,colour,weekly_target) values
 ('00000000-0000-0000-0000-000000000b01','MC 1234','00000000-0000-0000-0000-0000000000f1','Toyota','white',100000),
 ('00000000-0000-0000-0000-000000000b02','MC 9999','00000000-0000-0000-0000-0000000000f1','Toyota','red',null);
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01', full_name='Peter Phiri' where email='drv@x.com';
insert into shifts(id,driver_id,truck_id,status,start_km) values ('00000000-0000-0000-0000-000000000511','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','on_duty',100);
insert into trips(driver_id,truck_id,pickup_name,dest_name,dest_lat,dest_lng,passengers,fare_per_passenger,status)
 values ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','A','B',0,0,10,1000,'completed'),
        ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01','A','C',0,0,5,1000,'in_progress');
insert into hand_ins(shift_id,driver_id,truck_id,collected,driver_expenses,received)
 values ('00000000-0000-0000-0000-000000000511','00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',15000,1000,12000);
-- digest
create temp table d1 as select public.send_owner_digests() n;
insert into results select 'one digest to the owner', (select n from d1)=1, (select n::text from d1);
insert into results select 'digest has trips + money', (select body from notices where kind='digest') like '2 trips · taken K15,000%', (select body from notices where kind='digest');
insert into results select 'digest flags short hand-in', (select body from notices where kind='digest') like '%CHECK: 1 hand-in(s) came in short by K2,000%', '';
insert into results select 'digest names the idle vehicle', (select body from notices where kind='digest') like '%Did not work today: MC 9999%', '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
do $$ begin perform public.run_owner_digests(); insert into results values('passenger cannot run digests',false,''); exception when others then insert into results values('passenger cannot run digests', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
do $$ begin perform public.my_week(); insert into results values('passenger cannot read my_week',false,''); exception when others then insert into results values('passenger cannot read my_week', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
do $$ begin perform * from public.late_pickups(); insert into results values('passenger cannot see late pickups',false,''); exception when others then insert into results values('passenger cannot see late pickups', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
-- my week
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
create temp table w1 as select public.my_week() j;
grant select on w1 to authenticated;
insert into results select 'my_week totals', (select (j->>'week')::numeric from w1)=15000 and (select (j->>'trips')::int from w1)=2 and (select (j->>'passengers')::int from w1)=15 and (select (j->>'target')::numeric from w1)=100000, (select j::text from w1);
insert into results select 'my_week today = week when all today', (select (j->>'today')::numeric from w1)=15000, '';
-- late pickups
reset role;
insert into bookings(passenger_id,kind,pickup_at,seats,pickup_name,dest_name,price,status,truck_id,driver_id,receiver_name)
 values ('00000000-0000-0000-0000-0000000000d1','goods',now()-interval '40 minutes',0,'Mangochi','Zomba',3000,'assigned','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000e1','Joseph Mwale Jr');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
create temp table l1 as select * from public.late_pickups(15);
grant select on l1 to authenticated;
insert into results select 'late pickup listed', (select count(*) from l1)=1 and (select minutes_late from l1) between 39 and 41 and (select plate from l1)='MC 1234', (select minutes_late::text from l1);
insert into results select 'not late within 60 min threshold', (select count(*) from public.late_pickups(60))=0, '';
-- parcel link
reset role;
update bookings set status='picked_up' where kind='goods';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table s1 as select public.share_trip((select id from bookings where kind='goods')) url;
grant select on s1 to anon;
reset role;
create temp table v1(j jsonb); grant all on v1 to anon;
set role anon;
insert into v1 select public.shared_trip(split_part((select url from s1),'?t=',2));
reset role;
insert into results select 'parcel link says parcel + receiver first name', (select j->>'kind' from v1)='goods' and (select j->>'receiver' from v1)='Joseph', (select j::text from v1);
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
