\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000b1','owner@x.com'),
 ('00000000-0000-0000-0000-0000000000c1','driver@x.com'),('00000000-0000-0000-0000-0000000000d1','pax@x.com'),
 ('00000000-0000-0000-0000-0000000000d2','pax2@x.com'),('00000000-0000-0000-0000-0000000000e1','owner2@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='owner', active=true where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000e1');
update profiles set role='driver', active=true where id='00000000-0000-0000-0000-0000000000c1';
update profiles set role='passenger', active=true where id in ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000d2');
insert into trucks(id,plate,owner_id) values ('00000000-0000-0000-0000-000000000f01','MZ 1',(select id from profiles where email='owner@x.com')),
 ('00000000-0000-0000-0000-000000000f02','MZ 2',(select id from profiles where email='owner2@x.com'));
update profiles set truck_id='00000000-0000-0000-0000-000000000f01' where id='00000000-0000-0000-0000-0000000000c1';
insert into shifts(id,driver_id,truck_id,status,start_km,end_km,ended_at) values
 ('00000000-0000-0000-0000-000000000501','00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-000000000f01','off_duty',1000,1200,now());
insert into hand_ins(shift_id,driver_id,truck_id,collected,driver_expenses) values
 ('00000000-0000-0000-0000-000000000501','00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-000000000f01',50000,5000);
insert into bookings(id,passenger_id,kind,pickup_at,pickup_name,dest_name,status,truck_id,driver_id) values
 ('00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000d1','seat',now(),'A','B','completed','00000000-0000-0000-0000-000000000f01','00000000-0000-0000-0000-0000000000c1'),
 ('00000000-0000-0000-0000-000000000b02','00000000-0000-0000-0000-0000000000d1','seat',now(),'A','B','assigned','00000000-0000-0000-0000-000000000f01','00000000-0000-0000-0000-0000000000c1'),
 ('00000000-0000-0000-0000-000000000b03','00000000-0000-0000-0000-0000000000d2','seat',now(),'A','B','completed','00000000-0000-0000-0000-000000000f01','00000000-0000-0000-0000-0000000000c1'),
 ('00000000-0000-0000-0000-000000000b04','00000000-0000-0000-0000-0000000000d2','seat',now(),'A','B','completed','00000000-0000-0000-0000-000000000f01','00000000-0000-0000-0000-0000000000c1');

select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.rate_booking('00000000-0000-0000-0000-000000000b01', 2, 'Late and rude');
insert into results select 'rating saved', count(*)=1, count(*)::text from ratings;
do $$ begin perform public.rate_booking('00000000-0000-0000-0000-000000000b01', 5); insert into results values('cannot rate twice',false,''); exception when others then insert into results values('cannot rate twice', sqlerrm='ALREADY_RATED', sqlerrm); end $$;
do $$ begin perform public.rate_booking('00000000-0000-0000-0000-000000000b02', 5); insert into results values('cannot rate unfinished booking',false,''); exception when others then insert into results values('cannot rate unfinished booking', sqlerrm='NOT_COMPLETED', sqlerrm); end $$;
do $$ begin perform public.rate_booking('00000000-0000-0000-0000-000000000b03', 5); insert into results values('cannot rate someone elses booking',false,''); exception when others then insert into results values('cannot rate someone elses booking', sqlerrm='BOOKING_NOT_FOUND', sqlerrm); end $$;
do $$ begin perform public.rate_booking('00000000-0000-0000-0000-000000000b01', 9); insert into results values('stars out of range refused',false,''); exception when others then insert into results values('stars out of range refused', sqlerrm='BAD_STARS', sqlerrm); end $$;
insert into results select 'passenger can read driver average', (select average from public.driver_rating('00000000-0000-0000-0000-0000000000c1'))=2.0, (select average::text from public.driver_rating('00000000-0000-0000-0000-0000000000c1'));
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
select public.rate_booking('00000000-0000-0000-0000-000000000b03', 1);
select public.rate_booking('00000000-0000-0000-0000-000000000b04', 3);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
do $$ begin perform * from public.driver_rating('00000000-0000-0000-0000-0000000000c1'); insert into results values('unrelated owner blocked from rating',false,''); exception when others then insert into results values('unrelated owner blocked from rating', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into results select 'admin told of low ratings (2 low)', count(*)=2, count(*)::text from notices where kind='rating';
insert into results select 'low rated driver listed (avg 2.0)', (select average from public.low_rated_drivers(3, 3.5))=2.0, (select average::text from public.low_rated_drivers(3, 3.5));
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
insert into results select 'owner sees own driver average', (select ratings from public.driver_rating('00000000-0000-0000-0000-0000000000c1'))=3, '';
do $$ begin perform * from public.low_rated_drivers(); insert into results values('owner cannot list low rated',false,''); exception when others then insert into results values('owner cannot list low rated', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;

-- repeat complaints: 3 tickets on truck 1
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.report_problem('driver_late','late 1', null, '00000000-0000-0000-0000-000000000b01');
select public.report_problem('driver_late','late 2', null, '00000000-0000-0000-0000-000000000b01');
select public.report_problem('overcharged','over', null, '00000000-0000-0000-0000-000000000b01');
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into results select 'repeat complaints flags vehicle and driver', (select count(*) from public.repeat_complaints(30,3))=2, (select count(*)::text from public.repeat_complaints(30,3));
insert into results select 'higher threshold hides them', (select count(*) from public.repeat_complaints(30,4))=0, '';

-- targets
select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
select public.set_truck_target('00000000-0000-0000-0000-000000000f01', 90000);
insert into results select 'target progress = 50%', (select percent from public.target_progress('00000000-0000-0000-0000-000000000f01'))=50, (select percent::text from public.target_progress('00000000-0000-0000-0000-000000000f01'));
do $$ begin perform public.set_truck_target('00000000-0000-0000-0000-000000000f02', 1); insert into results values('owner cannot set other target',false,''); exception when others then insert into results values('owner cannot set other target', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
-- today
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into results select 'today summary: collected + open tickets', (select collected_today=50000 and open_tickets=3 from public.today_summary()), (select collected_today||'/'||open_tickets from public.today_summary());
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
do $$ begin perform * from public.today_summary(); insert into results values('passenger cannot see summary',false,''); exception when others then insert into results values('passenger cannot see summary', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
