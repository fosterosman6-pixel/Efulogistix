-- LOCAL ONLY. Tests for v26 (owner marks own alerts done). Not for Supabase.
\set ON_ERROR_STOP off
begin;
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000a1','own1@x.com'),('00000000-0000-0000-0000-0000000000a2','own2@x.com');
update profiles set role='owner', active=true where email in ('own1@x.com','own2@x.com');
insert into trucks(id,plate,owner_id,status,active) values ('00000000-0000-0000-0000-0000000000b1','T1','00000000-0000-0000-0000-0000000000a1','approved',true),('00000000-0000-0000-0000-0000000000b2','T2','00000000-0000-0000-0000-0000000000a2','approved',true);
insert into alerts(id,kind,truck_id,title) values ('00000000-0000-0000-0000-0000000000c1','mileage','00000000-0000-0000-0000-0000000000b1','m1'),('00000000-0000-0000-0000-0000000000c2','mileage','00000000-0000-0000-0000-0000000000b2','m2');
create or replace function pg_temp.res(uid text, aid uuid) returns text language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub',uid,true);
  execute 'set local role authenticated';
  perform public.resolve_alert(aid);
  execute 'reset role';
  return 'OK';
exception when others then execute 'reset role'; return sqlerrm; end $$;
create temp table r1 as select pg_temp.res('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000c1') as r;
insert into results select 'owner marks own vehicle alert done', (select r from r1)='OK' and (select resolved from alerts where id='00000000-0000-0000-0000-0000000000c1'), (select r from r1);
insert into results select 'owner cannot close another owner''s alert', pg_temp.res('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000c2') like '%not allowed%' and not (select resolved from alerts where id='00000000-0000-0000-0000-0000000000c2'), '';
select name, case when ok then 'PASS' else 'FAIL' end, coalesce(info,'') from results;
rollback;
