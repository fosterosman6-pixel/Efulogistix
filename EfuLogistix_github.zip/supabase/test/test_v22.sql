\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000f1','own@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000c1','pax@x.com'),('00000000-0000-0000-0000-0000000000c2','pax2@x.com');
update profiles set role='owner', active=true where email='own@x.com';
update profiles set role='passenger', active=true where email in ('pax@x.com','pax2@x.com');
insert into vehicle_categories(id,name,seats,carries_passengers,carries_goods,hire_per_km,hire_min,active) values ('00000000-0000-0000-0000-00000000ca01','TestMatola',4,true,true,0,0,true);
insert into trucks(id,plate,owner_id,status,category_id) values ('00000000-0000-0000-0000-000000000b01','MZ 4521','00000000-0000-0000-0000-0000000000f1','approved','00000000-0000-0000-0000-00000000ca01');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='drv@x.com';
insert into shifts(driver_id,truck_id,start_km) values ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',1);
insert into routes(id,from_name,to_name,fare,category_id) values ('00000000-0000-0000-0000-0000000000a1','Mangochi','Monkey Bay',8000,'00000000-0000-0000-0000-00000000ca01');
insert into departures(id,route_id,leaves_at) values ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000a1',(now() at time zone 'Africa/Blantyre')::time);
-- seat booking for a departure leaving about now
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,category_id,route_id,departure_id,travel_on) values
 ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000c1','seat','requested',3,24000,now(),'cash','Mangochi','Monkey Bay','00000000-0000-0000-0000-00000000ca01','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b1',current_date);
insert into results select 'seat booking assigned automatically', (select status||coalesce(truck_id::text,'') from bookings where id='00000000-0000-0000-0000-0000000000d1')='assigned00000000-0000-0000-0000-000000000b01', '';
insert into results select 'passenger told', (select count(*) from notices where title like '%car assigned%')=1, '';
-- 3 + 2 seats > 4: second booking must wait
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,category_id,route_id,departure_id,travel_on) values
 ('00000000-0000-0000-0000-0000000000d2','00000000-0000-0000-0000-0000000000c2','seat','requested',2,16000,now(),'cash','Mangochi','Monkey Bay','00000000-0000-0000-0000-00000000ca01','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b1',current_date);
insert into results select 'full vehicle: second booking waits', (select status from bookings where id='00000000-0000-0000-0000-0000000000d2')='requested', '';
-- 1 seat fits
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,category_id,route_id,departure_id,travel_on) values
 ('00000000-0000-0000-0000-0000000000d3','00000000-0000-0000-0000-0000000000c2','seat','requested',1,8000,now(),'cash','Mangochi','Monkey Bay','00000000-0000-0000-0000-00000000ca01','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b1',current_date);
insert into results select 'one more seat fits the same vehicle', (select status from bookings where id='00000000-0000-0000-0000-0000000000d3')='assigned', '';
-- future departure is not touched yet; the sweep handles it later
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,category_id,route_id,departure_id,travel_on) values
 ('00000000-0000-0000-0000-0000000000d4','00000000-0000-0000-0000-0000000000c2','seat','requested',1,8000,now()+interval '5 hours','cash','Mangochi','Monkey Bay','00000000-0000-0000-0000-00000000ca01','00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b1',current_date);
insert into results select 'later departure waits', (select status from bookings where id='00000000-0000-0000-0000-0000000000d4')='requested', '';
update bookings set pickup_at = now() + interval '1 hour' where id='00000000-0000-0000-0000-0000000000d4';
select public.auto_assign_pending();
insert into results select 'sweep assigns when near', (select status from bookings where id='00000000-0000-0000-0000-0000000000d4')='requested', 'capacity 4 already used 4 -> still waits';
select * from results;
