-- LOCAL ONLY. Tests for v23 (hire price when the trip ends). Run on a database with schema up to v23. Not for Supabase.
\set ON_ERROR_STOP off
begin;
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000e1','drv@x.com'),('00000000-0000-0000-0000-0000000000c1','pax@x.com');
update profiles set role='driver', active=true where email='drv@x.com';
update profiles set role='passenger', active=true where email='pax@x.com';
insert into vehicle_categories(id,name,seats,carries_passengers,carries_goods,hire_per_km,hire_min,active)
 values ('00000000-0000-0000-0000-00000000ca02','TestTaxi',4,true,false,900,5000,true);
-- three hires already on board: one way (30 km), whole day (booked 100 km), and one more one way
insert into bookings(id,passenger_id,driver_id,kind,status,price,km,rate_per_km,trip_type,pickup_at,pay_method,pickup_name,dest_name,category_id) values
 ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-0000000000e1','hire','picked_up',27000,30,900,'one_way',now(),'cash','A','B','00000000-0000-0000-0000-00000000ca02'),
 ('00000000-0000-0000-0000-0000000000d2','00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-0000000000e1','hire','picked_up',90000,100,900,'whole_day',now(),'cash','A','B','00000000-0000-0000-0000-00000000ca02'),
 ('00000000-0000-0000-0000-0000000000d3','00000000-0000-0000-0000-0000000000c1','00000000-0000-0000-0000-0000000000e1','hire','picked_up',27000,30,900,'one_way',now(),'cash','A','B','00000000-0000-0000-0000-00000000ca02');
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000e1',true);
set local role authenticated;
select public.booking_step('00000000-0000-0000-0000-0000000000d1','completed',null,32.4);
reset role;
insert into results select 'normal hire: 32.4 km x K900 rounded up to K500 = K29,500', (select final_price from bookings where id='00000000-0000-0000-0000-0000000000d1')=29500, (select final_price::text from bookings where id='00000000-0000-0000-0000-0000000000d1');
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000e1',true);
set local role authenticated;
select public.booking_step('00000000-0000-0000-0000-0000000000d2','completed',null,60);
reset role;
insert into results select 'whole day with 60 km on the odometer is still charged 100 km', (select final_price from bookings where id='00000000-0000-0000-0000-0000000000d2')=90000 and (select km from bookings where id='00000000-0000-0000-0000-0000000000d2')=100, (select final_price||' / '||km from bookings where id='00000000-0000-0000-0000-0000000000d2');
create or replace function pg_temp.try_km(k numeric) returns text language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000e1',true);
  execute 'set local role authenticated';
  perform public.booking_step('00000000-0000-0000-0000-0000000000d3','completed',null,k);
  execute 'reset role';
  return 'OK';
exception when others then execute 'reset role'; return sqlerrm; end $$;
insert into results select 'an odometer figure of 5000 km on a 30 km booking is refused', pg_temp.try_km(5000)='KM_TOO_HIGH', pg_temp.try_km(5000);
insert into results select 'the booking stays open after the refusal', (select status from bookings where id='00000000-0000-0000-0000-0000000000d3')='picked_up', '';
create temp table detour as select pg_temp.try_km(50) as r;
insert into results select 'a real detour (50 km on a 30 km booking) is accepted and priced K45,000', (select r from detour)='OK' and (select final_price from bookings where id='00000000-0000-0000-0000-0000000000d3')=45000, (select r from detour)||' '||coalesce((select final_price::text from bookings where id='00000000-0000-0000-0000-0000000000d3'),'');
select name, case when ok then 'PASS' else 'FAIL' end, coalesce(info,'') from results;
rollback;
