\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated, anon;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com'),('00000000-0000-0000-0000-0000000000d1','p1@x.com'),
 ('00000000-0000-0000-0000-0000000000d2','p2@x.com'),('00000000-0000-0000-0000-0000000000e1','drv@x.com'),
 ('00000000-0000-0000-0000-0000000000e2','drv2@x.com'),('00000000-0000-0000-0000-0000000000f1','own@x.com');
update profiles set role='admin', active=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set role='passenger', active=true, full_name='Mary Banda' where email='p1@x.com';
update profiles set role='passenger', active=true where email='p2@x.com';
update profiles set role='owner', active=true where email='own@x.com';
insert into trucks(id,plate,owner_id,make,colour,insurance_to,cof_to,current_km,last_oil_km,oil_interval_km)
 values ('00000000-0000-0000-0000-000000000b01','MC 1234','00000000-0000-0000-0000-0000000000f1','Toyota','white',current_date+5,current_date+90,15000,10000,5000);
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01', full_name='Peter Phiri' where email='drv@x.com';
update profiles set role='driver', active=true, full_name='Other Driver' where email='drv2@x.com';
insert into truck_locations(truck_id,driver_id,lat,lng) values ('00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000e1',-14.47,35.26);
insert into bookings(id,passenger_id,kind,pickup_at,seats,pickup_name,dest_name,price,status,truck_id,driver_id,pickup_lat,pickup_lng)
 values ('00000000-0000-0000-0000-000000000c01','00000000-0000-0000-0000-0000000000d1','seat',now()+interval '1 hour',1,'Mangochi','Blantyre',9000,'assigned','00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000e1',-14.48,35.25),
        ('00000000-0000-0000-0000-000000000c02','00000000-0000-0000-0000-0000000000d1','seat',now()+interval '2 hour',1,'Mangochi','Zomba',5000,'completed',null,null,null,null);
-- 1. tickets
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table t1 as select public.my_ticket('00000000-0000-0000-0000-000000000c01') code;
grant select on t1 to authenticated;
insert into results select 'ticket is 8 digits', (select code ~ '^\d{8}$' from t1), (select code from t1);
insert into results select 'same ticket on second ask', public.my_ticket('00000000-0000-0000-0000-000000000c01')=(select code from t1), '';
do $$ begin perform public.my_ticket('00000000-0000-0000-0000-000000000c02'); insert into results values('no ticket for finished booking',false,''); exception when others then insert into results values('no ticket for finished booking', sqlerrm='NO_TICKET', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
do $$ begin perform public.my_ticket('00000000-0000-0000-0000-000000000c01'); insert into results values('others cannot get my ticket',false,''); exception when others then insert into results values('others cannot get my ticket', true, sqlerrm); end $$;
do $$ begin perform * from booking_tickets; insert into results values('tickets table closed to apps',false,''); exception when others then insert into results values('tickets table closed to apps', true, ''); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e2');
do $$ begin perform public.board_by_code((select code from t1)); insert into results values('wrong driver cannot board',false,''); exception when others then insert into results values('wrong driver cannot board', sqlerrm='NO_TICKET', sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
do $$ begin perform public.board_by_code('12ab'); insert into results values('short code refused',false,''); exception when others then insert into results values('short code refused', sqlerrm='BAD_CODE', sqlerrm); end $$;
create temp table r1 as select public.board_by_code('EFU-' || (select code from t1)) j;
grant select on r1 to authenticated;
insert into results select 'driver scan boards passenger', (select j->>'name' from r1)='Mary Banda' and (select j->>'already' from r1)='false', (select j::text from r1);
reset role;
insert into results select 'booking now picked_up', (select status from bookings where id='00000000-0000-0000-0000-000000000c01')='picked_up', '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
insert into results select 'second scan says already on board', (select public.board_by_code((select code from t1))->>'already')='true', '';
-- 3. share
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d2');
do $$ begin perform public.share_trip('00000000-0000-0000-0000-000000000c01'); insert into results values('others cannot share my trip',false,''); exception when others then insert into results values('others cannot share my trip', true, sqlerrm); end $$;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table s1 as select public.share_trip('00000000-0000-0000-0000-000000000c01') url;
grant select on s1 to authenticated, anon;
insert into results select 'link made', (select url like 'https://%?t=%' from s1), (select url from s1);
insert into results select 'same link reused', public.share_trip('00000000-0000-0000-0000-000000000c01')=(select url from s1), '';
reset role;
create temp table v1(j jsonb);
grant all on v1 to anon;
set role anon;
insert into v1 select public.shared_trip(split_part((select url from s1),'?t=',2));
reset role;
insert into results select 'anyone with link sees car + position', (select j->>'state' from v1)='on_trip' and (select j->>'plate' from v1)='MC 1234' and (select (j->>'lat')::float from v1)=-14.47, (select j::text from v1);
insert into results select 'link shows first names only (no phone, no surname)', (select j->>'passenger' from v1)='Mary' and (select j->>'driver' from v1)='Peter' and (select j::text from v1) !~ 'Banda|Phiri|phone', '';
insert into results select 'bad link = invalid', (select public.shared_trip('nope')->>'state')='invalid', '';
set role anon;
do $$ begin perform * from trip_shares; insert into results values('anon cannot list links',false,''); exception when others then insert into results values('anon cannot list links', true, ''); end $$;
reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
select public.stop_sharing('00000000-0000-0000-0000-000000000c01');
reset role;
insert into results select 'stopped link is invalid', (select public.shared_trip(split_part((select url from s1),'?t=',2))->>'state')='invalid', '';
-- link ends when trip done
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
create temp table s2 as select public.share_trip('00000000-0000-0000-0000-000000000c01') url;
grant select on s2 to authenticated;
reset role;
update bookings set status='completed' where id='00000000-0000-0000-0000-000000000c01';
insert into results select 'link says ended after trip', (select public.shared_trip(split_part((select url from s2),'?t=',2))->>'state')='ended', '';
-- 2. reminders
insert into documents(driver_id,kind,expires_on,status) values ('00000000-0000-0000-0000-0000000000e1','licence',current_date+10,'approved');
insert into documents(driver_id,kind,expires_on,status) values ('00000000-0000-0000-0000-0000000000e1','licence',current_date-400,'approved');
create temp table n1 as select public.send_reminders() n;
-- insurance in 5 days: owner + driver; licence in 10 days: driver + owner; oil 5000 km reached (15000>=10000+5000): owner + driver
insert into results select 'insurance reminder to owner and driver', (select count(*) from notices where kind='reminder' and title like 'Renew soon · Insurance' )=2, (select count(*)::text from notices where kind='reminder' and title like '%Insurance');
insert into results select 'no reminder for cof 90 days away', (select count(*) from notices where title like '%fitness%')=0, '';
insert into results select 'licence reminder uses newest paper only', (select count(*) from notices where title like '%Licence' and user_id='00000000-0000-0000-0000-0000000000e1')=1, (select count(*)::text from notices where title like '%Licence');
insert into results select 'oil reminder to owner + driver', (select count(*) from notices where title like 'Service due%')=2, '';
create temp table n2 as select public.send_reminders() n;
insert into results select 'second run sends nothing new', (select n from n2)=0, (select n::text from n2);
-- bucket moves: insurance now 3 days away still same bucket (7) -> nothing; expired -> new message
update trucks set insurance_to = current_date - 1 where id='00000000-0000-0000-0000-000000000b01';
create temp table n3 as select public.send_reminders() n;
insert into results select 'expired = new EXPIRED message', (select count(*) from notices where title like 'EXPIRED · Insurance')=2, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000d1');
do $$ begin perform public.run_reminders(); insert into results values('passenger cannot run reminders',false,''); exception when others then insert into results values('passenger cannot run reminders', sqlerrm='NOT_ALLOWED', sqlerrm); end $$;
do $$ begin perform public.send_reminders(); insert into results values('send_reminders closed to apps',false,''); exception when others then insert into results values('send_reminders closed to apps', true, ''); end $$;
reset role;
select case when ok then 'PASS' else 'FAIL' end r, name, info from results order by ok, name;
select 'TOTAL '||count(*) filter (where ok)||' pass, '||count(*) filter (where not ok)||' fail' from results;
