\set ON_ERROR_STOP off
create temp table results(name text, ok boolean, info text);
grant all on results to authenticated;
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', u::text, false); execute 'set role authenticated'; end $$;
reset role;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000f1','own@x.com'),('00000000-0000-0000-0000-0000000000e1','near@x.com'),('00000000-0000-0000-0000-0000000000e2','far@x.com'),('00000000-0000-0000-0000-0000000000c1','pax@x.com');
update profiles set role='owner', active=true where email='own@x.com';
update profiles set role='passenger', active=true where email='pax@x.com';
insert into trucks(id,plate,owner_id,status) values ('00000000-0000-0000-0000-000000000b01','NEAR 1','00000000-0000-0000-0000-0000000000f1','approved'),('00000000-0000-0000-0000-000000000b02','FAR 2','00000000-0000-0000-0000-0000000000f1','approved');
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b01' where email='near@x.com';
update profiles set role='driver', active=true, truck_id='00000000-0000-0000-0000-000000000b02' where email='far@x.com';
insert into shifts(driver_id,truck_id,start_km) values ('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-000000000b01',1),('00000000-0000-0000-0000-0000000000e2','00000000-0000-0000-0000-000000000b02',1);
insert into truck_locations(truck_id,driver_id,lat,lng) values ('00000000-0000-0000-0000-000000000b01','00000000-0000-0000-0000-0000000000e1',-14.48,35.26),('00000000-0000-0000-0000-000000000b02','00000000-0000-0000-0000-0000000000e2',-14.60,35.30);
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,pickup_lat,pickup_lng) values ('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000c1','hire','requested',0,40000,now(),'cash','Rank','Zomba',-14.478,35.2645);
insert into results select 'offered to nearest', (select driver_id from booking_offers where status='offered')='00000000-0000-0000-0000-0000000000e1', (select count(*)::text from booking_offers);
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
select public.answer_offer((select id from booking_offers where status='offered'), false);
reset role;
insert into results select 'decline goes to next', (select driver_id from booking_offers where status='offered')='00000000-0000-0000-0000-0000000000e2', '';
update booking_offers set offered_at = now() - interval '3 minutes' where status='offered';
select public.expire_offers();
insert into results select 'expiry: no one left, stays requested', (select count(*) from booking_offers where status='offered')=0 and (select status from bookings)='requested', (select string_agg(status,',') from booking_offers);
-- fresh booking, accept
insert into bookings(id,passenger_id,kind,status,seats,price,pickup_at,pay_method,pickup_name,dest_name,pickup_lat,pickup_lng) values ('00000000-0000-0000-0000-0000000000d2','00000000-0000-0000-0000-0000000000c1','hire','requested',0,30000,now(),'cash','Rank','Liwonde',-14.478,35.2645);
insert into results select 'declined driver not asked again', (select driver_id from booking_offers where booking_id='00000000-0000-0000-0000-0000000000d2' and status='offered')='00000000-0000-0000-0000-0000000000e1', '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
select public.answer_offer((select id from booking_offers where booking_id='00000000-0000-0000-0000-0000000000d2' and status='offered'), true);
reset role;
insert into results select 'accept assigns', (select status||driver_id::text from bookings where id='00000000-0000-0000-0000-0000000000d2')='assigned00000000-0000-0000-0000-0000000000e1', '';
insert into results select 'passenger told', (select count(*) from notices where title like '%car assigned%')=1, '';
-- near notice
update truck_locations set lat=-14.4785, lng=35.2648 where truck_id='00000000-0000-0000-0000-000000000b01';
insert into results select 'almost there notice', (select count(*) from notices where title='Your car is almost there')=1, '';
update truck_locations set lat=-14.4786 where truck_id='00000000-0000-0000-0000-000000000b01';
insert into results select 'only once', (select count(*) from notices where title='Your car is almost there')=1, '';
select pg_temp.as_user('00000000-0000-0000-0000-0000000000e1');
select public.booking_arrived('00000000-0000-0000-0000-0000000000d2');
reset role;
insert into results select 'arrived notice', (select count(*) from notices where title='Your car has arrived')=1, '';
select * from results;
