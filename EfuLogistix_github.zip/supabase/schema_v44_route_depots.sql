-- v44 · Route depots with automatic fares.
-- A "corridor" is a road with depots in order. Fares between every pair of depots (both ways) are worked out
-- from the road distance: rate per km x km, never below the minimum, rounded to the step. The result is written into
-- the normal "routes" table, so drivers and passengers see depot-to-depot fares without any app change.
-- Run the whole file in the Supabase SQL editor. Safe to run twice.

create table if not exists public.route_corridors (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  road_factor numeric(4, 2) not null default 1.05 check (road_factor between 1 and 3),  -- the depots follow the road, so only a small bend allowance
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.corridor_stops (
  corridor_id uuid not null references public.route_corridors (id) on delete cascade,
  pos int not null check (pos >= 0),
  place_name text not null,
  lat double precision not null,
  lng double precision not null,
  km_from_prev numeric(7, 1) not null default 0 check (km_from_prev >= 0),
  km_locked boolean not null default false,        -- true = typed or measured by the admin, never overwritten
  can_board boolean not null default true,
  can_drop boolean not null default true,
  primary key (corridor_id, pos)
);

create table if not exists public.corridor_rates (
  corridor_id uuid not null references public.route_corridors (id) on delete cascade,
  category_id uuid not null references public.vehicle_categories (id) on delete cascade,
  per_km numeric(8, 2) not null check (per_km >= 0),
  min_fare numeric(12, 2) not null default 1000 check (min_fare >= 0),
  round_to numeric(8, 2) not null default 500 check (round_to > 0),
  primary key (corridor_id, category_id)
);

-- a fare the admin typed for one pair of depots (same both ways); kept when the rate changes
create table if not exists public.corridor_overrides (
  corridor_id uuid not null references public.route_corridors (id) on delete cascade,
  category_id uuid not null references public.vehicle_categories (id) on delete cascade,
  from_pos int not null,
  to_pos int not null,
  fare numeric(12, 2) not null check (fare >= 0),
  primary key (corridor_id, category_id, from_pos, to_pos),
  check (from_pos < to_pos)
);

alter table public.routes add column if not exists corridor_id uuid references public.route_corridors (id) on delete set null;
create index if not exists routes_corridor_idx on public.routes (corridor_id);

do $$
declare t text;
begin
  foreach t in array array['route_corridors', 'corridor_stops', 'corridor_rates', 'corridor_overrides'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists %I on public.%I', t || '_read', t);
    execute format('create policy %I on public.%I for select to authenticated using (true)', t || '_read', t);
    execute format('drop policy if exists %I on public.%I', t || '_write', t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t || '_write', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- straight-line km between two points
create or replace function public._corridor_km(la1 double precision, lo1 double precision, la2 double precision, lo2 double precision)
returns double precision language sql immutable as $$
  select 6371 * 2 * asin(sqrt(
    power(sin(radians(la2 - la1) / 2), 2) +
    cos(radians(la1)) * cos(radians(la2)) * power(sin(radians(lo2 - lo1) / 2), 2)))
$$;

-- fill the distance of every hop that is not locked: straight line x road factor
create or replace function public.corridor_recalc_km(p_corridor uuid)
returns void language plpgsql security definer set search_path = public as $$
declare f numeric;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select road_factor into f from route_corridors where id = p_corridor;
  update corridor_stops s
     set km_from_prev = round((public._corridor_km(p.lat, p.lng, s.lat, s.lng) * f)::numeric, 1)
    from corridor_stops p
   where s.corridor_id = p_corridor and p.corridor_id = p_corridor
     and p.pos = s.pos - 1 and not s.km_locked and s.pos > 0;
end $$;

-- the fare, distance and names of every pair of depots for one vehicle type (both ways)
create or replace function public.corridor_fares(p_corridor uuid, p_category uuid)
returns table (from_pos int, to_pos int, from_name text, to_name text, to_lat double precision, to_lng double precision, km numeric, fare numeric)
language sql stable security definer set search_path = public as $$
  with cum as (
    select pos, place_name, lat, lng, can_board, can_drop,
           sum(km_from_prev) over (order by pos) as km
      from corridor_stops where corridor_id = p_corridor
  )
  select a.pos, b.pos, a.place_name, b.place_name, b.lat, b.lng,
         round(abs(b.km - a.km), 1),
         coalesce(
           o.fare,
           greatest(r.min_fare, round((r.per_km * abs(b.km - a.km)) / r.round_to) * r.round_to)
         )
    from cum a
    join cum b on a.pos <> b.pos and a.can_board and b.can_drop
    join corridor_rates r on r.corridor_id = p_corridor and r.category_id = p_category
    left join corridor_overrides o
      on o.corridor_id = p_corridor and o.category_id = p_category
     and o.from_pos = least(a.pos, b.pos) and o.to_pos = greatest(a.pos, b.pos)
   order by 1, 2
$$;

-- keep ONE through fare per vehicle type and direction (first depot <-> last depot) in the normal fares list.
-- That is what the timetable, drivers and owners use. Fares between the other depots are worked out on demand
-- (corridor_fares), so the fares list does not fill up with thousands of rows.
alter table public.routes add column if not exists through boolean not null default false;

create or replace function public.corridor_rebuild(p_corridor uuid)
returns int language plpgsql security definer set search_path = public as $$
declare n int; lo int; hi int; r record;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  select min(pos), max(pos) into lo, hi from corridor_stops where corridor_id = p_corridor;
  if lo is null or lo = hi then return 0; end if;

  create temp table _gen on commit drop as
  select f.from_name, f.to_name, f.to_lat, f.to_lng, f.km, f.fare, c.category_id
    from corridor_rates c
    cross join lateral public.corridor_fares(p_corridor, c.category_id) f
   where c.corridor_id = p_corridor
     and ((f.from_pos = lo and f.to_pos = hi) or (f.from_pos = hi and f.to_pos = lo));

  update routes set active = false
   where corridor_id = p_corridor
     and not exists (select 1 from _gen g where g.from_name = routes.from_name and g.to_name = routes.to_name and g.category_id = routes.category_id);

  insert into routes (from_name, to_name, to_lat, to_lng, km, fare, category_id, corridor_id, through, active)
  select from_name, to_name, to_lat, to_lng, km, fare, category_id, p_corridor, true, true from _gen
  on conflict (from_name, to_name, category_id)
  do update set to_lat = excluded.to_lat, to_lng = excluded.to_lng, km = excluded.km, fare = excluded.fare,
                corridor_id = excluded.corridor_id, through = true, active = true, updated_at = now();

  select count(*) into n from _gen;
  return n;
end $$;
revoke all on function public.corridor_fares(uuid, uuid) from public, anon;
grant execute on function public.corridor_fares(uuid, uuid) to authenticated;

-- book a seat from one depot to another on a timetable departure of the through route
create or replace function public.book_depot(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  lo int; hi int; fwd boolean; q record; bid uuid;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(pos), max(pos) into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  fwd := exists (select 1 from corridor_stops where corridor_id = r.corridor_id and pos = lo and place_name = r.from_name);
  if fp is null or tp is null or (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS'; end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS'; end if;
  select f.km, f.fare into q from public.corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS'; end if;

  bid := public.book(p - 'from_pos' - 'to_pos');
  update bookings
     set pickup_name = fs.place_name, pickup_lat = fs.lat, pickup_lng = fs.lng,
         dest_name = ts.place_name, dest_lat = ts.lat, dest_lng = ts.lng,
         km = q.km, price = case when kind = 'seat' then q.fare * seats else price end
   where id = bid;
  return bid;
end $$;
revoke all on function public.book_depot(jsonb) from public, anon;
grant execute on function public.book_depot(jsonb) to authenticated;

revoke all on function public.corridor_recalc_km(uuid) from public, anon;
revoke all on function public.corridor_rebuild(uuid) from public, anon;
grant execute on function public.corridor_recalc_km(uuid) to authenticated;
grant execute on function public.corridor_rebuild(uuid) to authenticated;

-- ------------------------------------------------------------------ Mangochi -> Monkey Bay
-- the start depot (position it as you like in Places later)
insert into public.places (name, detail, lat, lng) values
  ('Mangochi Main Rank', 'Rank · Mangochi District', -14.481278, 35.260416)
on conflict (name) do nothing;

-- the depots, in road order
insert into public.places (name, detail, lat, lng) values
  ('Mpondasi Trading centre', 'Depot · Mangochi District', -14.461282, 35.243105),
  ('Bishop''s House, Diocese of Mangochi', 'Depot · Mangochi District', -14.446666, 35.223769),
  ('Samama Depot', 'Depot · Mangochi District', -14.434122, 35.217173),
  ('Bolera Depot', 'Depot · Mangochi District', -14.401995, 35.201984),
  ('Umar Farook Masjid Depot', 'Depot · Mangochi District', -14.394921, 35.196997),
  ('Malichi Depot', 'Depot · Mangochi District', -14.390145, 35.192457),
  ('Namiasi Depot', 'Depot · Mangochi District', -14.383035, 35.186792),
  ('Malemia Depot', 'Depot · Mangochi District', -14.364289, 35.167168),
  ('Maldeco Road block Depot', 'Depot · Mangochi District', -14.345586, 35.153077),
  ('Koche Depot', 'Depot · Mangochi District', -14.332417, 35.142004),
  ('Nkopora Turn Off Depot', 'Depot · Mangochi District', -14.324167, 35.135000),
  ('Makokola Turn Off Depot', 'Depot · Mangochi District', -14.317935, 35.127946),
  ('Makawa Trading Centre Depot', 'Depot · Mangochi District', -14.309315, 35.119124),
  ('Nabale Depot', 'Depot · Mangochi District', -14.229558, 35.049886),
  ('Nkhudzi Bay Depot', 'Depot · Mangochi District', -14.201429, 35.008054),
  ('Cape Maclear Turn Off Depot', 'Depot · Mangochi District', -14.170259, 34.942795),
  ('Chirombo Depot', 'Depot · Mangochi District', -14.157172, 34.935844),
  ('Mbalamanja Depot', 'Depot · Mangochi District', -14.153432, 34.932136),
  ('Cape Maclear Junction Depot', 'Depot · Mangochi District', -14.126602, 34.917733),
  ('Namazizi Depot', 'Depot · Mangochi District', -14.111950, 34.917046),
  ('Monkey Bay Depot', 'Depot · Mangochi District', -14.075014, 34.919301)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

insert into public.route_corridors (name) values ('Mangochi - Monkey Bay') on conflict (name) do nothing;
update public.route_corridors set road_factor = 1.05 where name = 'Mangochi - Monkey Bay' and road_factor = 1.30;

insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
select c.id, v.pos, p.name, p.lat, p.lng
  from public.route_corridors c
  join (values
    (0, 'Mangochi Main Rank'), (1, 'Mpondasi Trading centre'), (2, 'Bishop''s House, Diocese of Mangochi'),
    (3, 'Samama Depot'), (4, 'Bolera Depot'), (5, 'Umar Farook Masjid Depot'), (6, 'Malichi Depot'),
    (7, 'Namiasi Depot'), (8, 'Malemia Depot'), (9, 'Maldeco Road block Depot'), (10, 'Koche Depot'),
    (11, 'Nkopora Turn Off Depot'), (12, 'Makokola Turn Off Depot'), (13, 'Makawa Trading Centre Depot'),
    (14, 'Nabale Depot'), (15, 'Nkhudzi Bay Depot'), (16, 'Cape Maclear Turn Off Depot'), (17, 'Chirombo Depot'),
    (18, 'Mbalamanja Depot'), (19, 'Cape Maclear Junction Depot'), (20, 'Namazizi Depot'), (21, 'Monkey Bay Depot')
  ) as v(pos, name) on true
  join public.places p on p.name = v.name
 where c.name = 'Mangochi - Monkey Bay'
on conflict (corridor_id, pos) do update set place_name = excluded.place_name, lat = excluded.lat, lng = excluded.lng;

-- starting rates per km (about K 129 per km for a taxi, as on your Monkey Bay fare); change them any time
insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to)
select c.id, vc.id, v.per_km, 1000, 500
  from public.route_corridors c
  join (values
    ('Kabaza', 81), ('Taxi', 129), ('5 Seater', 137), ('7 Seater', 137),
    ('Matola', 129), ('Minibus', 121), ('Bus', 110), ('Coach', 120)
  ) as v(name, per_km) on true
  join public.vehicle_categories vc on vc.name = v.name
 where c.name = 'Mangochi - Monkey Bay'
on conflict (corridor_id, category_id) do nothing;

select public.corridor_recalc_km(id) from public.route_corridors where name = 'Mangochi - Monkey Bay';
select public.corridor_rebuild(id) as fares_written from public.route_corridors where name = 'Mangochi - Monkey Bay';
