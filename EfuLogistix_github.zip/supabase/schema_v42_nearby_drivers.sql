-- EfuLogistix: database update v42  (run AFTER schema_v41)
--   The passenger home map shows the free drivers nearby (vehicle type, distance, moving car).
--   No names, plates or phone numbers are given out, only the type of vehicle and an approximate position.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.nearby_drivers(p_lat double precision, p_lng double precision, p_km double precision default 15)
returns table (truck_id uuid, lat double precision, lng double precision, km double precision, category text)
language sql stable security definer set search_path = public as $$
  select l.truck_id,
         round(l.lat::numeric, 4)::double precision,
         round(l.lng::numeric, 4)::double precision,
         round(public._km_between(l.lat, l.lng, p_lat, p_lng)::numeric, 1)::double precision as km,
         c.name
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join truck_locations l on l.truck_id = s.truck_id and l.updated_at > now() - interval '3 minutes'
    left join vehicle_categories c on c.id = t.category_id
   where auth.uid() is not null
     and s.status = 'on_duty'
     and not exists (select 1 from trips tr where tr.driver_id = s.driver_id and tr.status = 'in_progress')
     and public._km_between(l.lat, l.lng, p_lat, p_lng) <= least(greatest(p_km, 1), 30)
   order by km
   limit 15;
$$;
revoke all on function public.nearby_drivers(double precision, double precision, double precision) from public, anon;
grant execute on function public.nearby_drivers(double precision, double precision, double precision) to authenticated;
