// Supabase Edge Function: send-sms
// Called by the database with header x-sms-secret. Sends one text message through TelcoMW (if TELCOMW_API_KEY is set) or Plivo.
//
// Secrets to set (Supabase > Edge Functions > Secrets):
//   SMS_SECRET        same text you gave to set_sms_config(...)
//   TELCOMW_API_KEY, TELCOMW_SENDER_ID   TelcoMW (Malawi). If set, they are used instead of Plivo.
//   PLIVO_AUTH_ID     from the Plivo console (Auth ID)
//   PLIVO_AUTH_TOKEN  from the Plivo console (Auth Token)
//   PLIVO_SENDER      the sender: your Plivo number, or the registered sender name (e.g. EfuLogist)
Deno.serve(async (req) => {
  if (req.headers.get("x-sms-secret") !== Deno.env.get("SMS_SECRET")) {
    return new Response("forbidden", { status: 403 });
  }
  const { to, text } = await req.json();
  const dst = String(to ?? "").replace(/\D/g, "");
  if (dst.length < 9 || !text) return new Response("bad request", { status: 400 });
  const telcoKey = Deno.env.get("TELCOMW_API_KEY");
  let res: Response;
  if (telcoKey) {
    res = await fetch("https://telcomw.com/api/v3/sms/send", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": telcoKey, "Idempotency-Key": crypto.randomUUID() },
      body: JSON.stringify({ to: dst, message: String(text).slice(0, 300), sender_id: Deno.env.get("TELCOMW_SENDER_ID") }),
    });
  } else {
    const id = Deno.env.get("PLIVO_AUTH_ID")!;
    const token = Deno.env.get("PLIVO_AUTH_TOKEN")!;
    res = await fetch(`https://api.plivo.com/v1/Account/${id}/Message/`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${id}:${token}`) },
      body: JSON.stringify({ src: Deno.env.get("PLIVO_SENDER"), dst, text: String(text).slice(0, 300) }),
    });
  }
  return new Response(await res.text(), { status: res.ok ? 200 : 502 });
});
