// Supabase Edge Function: send-push
// Called by the database (trigger on notices) with header x-push-secret. Sends the message to the
// person's phones through Firebase Cloud Messaging (HTTP v1).
//
// Secrets to set (Supabase > Edge Functions > Secrets, or `supabase secrets set`):
//   PUSH_SECRET           same text you gave to set_push_config(...)
//   FIREBASE_SERVICE_ACCOUNT   the whole JSON of the Firebase service-account key
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const sa = JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT") ?? "{}");
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

function b64url(data: ArrayBuffer | string): string {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function accessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const head = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  }));
  const pem = String(sa.private_key).replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${head}.${claim}`));
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${head}.${claim}.${b64url(sig)}`,
    }),
  });
  const j = await res.json();
  if (!j.access_token) throw new Error("google auth failed: " + JSON.stringify(j));
  return j.access_token;
}

Deno.serve(async (req) => {
  if (req.headers.get("x-push-secret") !== Deno.env.get("PUSH_SECRET")) {
    return new Response("forbidden", { status: 403 });
  }
  const m = await req.json();
  const { data: rows } = await admin.from("device_tokens").select("token").eq("user_id", m.user_id);
  if (!rows?.length) return new Response("no devices");
  const token = await accessToken();
  const url = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;
  let sent = 0;
  for (const { token: t } of rows) {
    const r = await fetch(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message: {
          token: t,
          notification: { title: String(m.title ?? "EfuLogistix"), body: String(m.body ?? "") },
          data: { kind: String(m.kind ?? ""), ref_id: String(m.ref_id ?? ""), notice_id: String(m.notice_id ?? "") },
          android: { priority: "HIGH" },
        },
      }),
    });
    if (r.ok) sent++;
    else if (r.status === 404 || r.status === 400) {
      const body = await r.text();
      if (body.includes("UNREGISTERED") || body.includes("INVALID_ARGUMENT")) {
        await admin.from("device_tokens").delete().eq("token", t); // dead token: phone uninstalled the app
      }
    }
  }
  return new Response(`sent ${sent}/${rows.length}`);
});
