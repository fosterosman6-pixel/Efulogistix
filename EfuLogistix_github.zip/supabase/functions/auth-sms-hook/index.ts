// Supabase Edge Function: auth-sms-hook
// Supabase Auth calls this ("Send SMS Hook") whenever someone asks for a sign-in code.
// It sends the code by SMS through TelcoMW (Malawi, K15 per SMS) when TELCOMW_API_KEY is set, otherwise through Plivo.
//
// Secrets (Supabase > Edge Functions > Secrets):
//   SEND_SMS_HOOK_SECRET   shown when you create the hook (starts with  v1,whsec_ ), paste it whole
//   TELCOMW_API_KEY, TELCOMW_SENDER_ID   (TelcoMW dashboard: API key, and an approved sender ID)
//   or, instead: PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN, PLIVO_SENDER
// Deploy with "Verify JWT" OFF (the call is checked with the hook secret instead).

function b64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}
function bytesToB64(bytes: ArrayBuffer): string {
  let s = "";
  for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
  return btoa(s);
}
function sameText(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

// Standard Webhooks: HMAC-SHA256 of "<id>.<timestamp>.<body>" with the secret, base64
async function verified(req: Request, body: string): Promise<boolean> {
  const secret = (Deno.env.get("SEND_SMS_HOOK_SECRET") ?? "").replace(/^v1,whsec_/, "");
  if (!secret) return false;
  const id = req.headers.get("webhook-id") ?? "";
  const ts = req.headers.get("webhook-timestamp") ?? "";
  const sigs = (req.headers.get("webhook-signature") ?? "").split(" ");
  if (!id || !ts || Math.abs(Date.now() / 1000 - Number(ts)) > 300) return false;
  const key = await crypto.subtle.importKey("raw", b64ToBytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = bytesToB64(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${id}.${ts}.${body}`)));
  return sigs.some((s) => sameText(s.replace(/^v1,/, ""), mac));
}

const fail = (code: number, message: string) =>
  new Response(JSON.stringify({ error: { http_code: code, message } }), { status: code, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  const body = await req.text();
  if (!(await verified(req, body))) return fail(401, "not allowed");
  let phone = "", otp = "";
  try {
    const p = JSON.parse(body);
    phone = String(p?.user?.phone ?? "").replace(/\D/g, "");
    otp = String(p?.sms?.otp ?? "");
  } catch {
    return fail(400, "bad request");
  }
  if (phone.length < 9 || !/^\d{4,8}$/.test(otp)) return fail(400, "bad request");
  const text = `Your EfuLogistix code is ${otp}. Do not share it.`;
  let res: Response;
  const telcoKey = Deno.env.get("TELCOMW_API_KEY");
  if (telcoKey) {
    // webhook-id is the same on a retry, so a retry is never charged twice
    const idem = (req.headers.get("webhook-id") ?? crypto.randomUUID()).replace(/[^A-Za-z0-9._-]/g, "").slice(0, 64).padEnd(8, "0");
    res = await fetch("https://telcomw.com/api/v3/sms/send", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": telcoKey, "Idempotency-Key": idem },
      body: JSON.stringify({ to: phone, message: text, sender_id: Deno.env.get("TELCOMW_SENDER_ID") }),
    });
  } else {
    const id = Deno.env.get("PLIVO_AUTH_ID")!;
    const token = Deno.env.get("PLIVO_AUTH_TOKEN")!;
    res = await fetch(`https://api.plivo.com/v1/Account/${id}/Message/`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${id}:${token}`) },
      body: JSON.stringify({ src: Deno.env.get("PLIVO_SENDER"), dst: phone, text }),
    });
  }
  if (!res.ok) return fail(502, "could not send the code");
  return new Response("{}", { status: 200, headers: { "Content-Type": "application/json" } });
});
