-- Admin: see the trips running now and finish / cancel one a driver cannot close.
-- Safe to run more than once.

create or replace function public.admin_live_trips()
returns table (trip_id uuid, trip_no bigint, driver_name text, plate text, pickup_name text, dest_name text,
               started_at timestamptz, total numeric, aboard int, waiting int)
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not is_admin() then raise exception 'NOT_ADMIN'; end if;
  return query
  select t.id, t.trip_no, p.full_name, k.plate, t.pickup_name, t.dest_name, t.started_at, t.total,
         (select count(*)::int from bookings b where b.trip_id = t.id and b.status = 'picked_up'),
         (select count(*)::int from bookings b where b.driver_id = t.driver_id and b.status = 'assigned')
  from trips t
  left join profiles p on p.id = t.driver_id
  left join trucks k on k.id = t.truck_id
  where t.status = 'in_progress'
  order by t.started_at;
end;
$$;

-- p_action: 'complete' | 'cancel' | 'fix'
create or replace function public.admin_trip_action(p_trip uuid, p_action text, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare t trips%rowtype; n int;
begin
  if auth.uid() is null or not is_admin() then raise exception 'NOT_ADMIN'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'REASON_REQUIRED'; end if;
  select * into t from trips where id = p_trip for update;
  if t.id is null then raise exception 'NO_SUCH_TRIP'; end if;
  if t.status <> 'in_progress' then raise exception 'TRIP_ALREADY_ENDED'; end if;

  if p_action in ('complete', 'fix') then
    update bookings set status = 'completed', completed_at = coalesce(completed_at, now())
      where trip_id = p_trip and status = 'picked_up';
    get diagnostics n = row_count;
  elsif p_action = 'cancel' then
    -- bookings that were on board go back to waiting for the same driver
    update bookings set status = 'assigned', trip_id = null, picked_up_at = null
      where trip_id = p_trip and status = 'picked_up';
    get diagnostics n = row_count;
  else
    raise exception 'BAD_ACTION';
  end if;

  if p_action = 'complete' then
    update trips set status = 'completed', ended_at = now() where id = p_trip;
  elsif p_action = 'cancel' then
    update trips set status = 'cancelled', ended_at = now() where id = p_trip;
  end if;

  insert into activity_log (actor, actor_name, action, table_name, row_id, detail)
  values (auth.uid(), my_name(), 'admin_trip_' || p_action, 'trips', p_trip::text,
          jsonb_build_object('reason', p_reason, 'trip_no', t.trip_no, 'bookings_changed', n));
end;
$$;

revoke execute on function public.admin_live_trips() from public, anon;
revoke execute on function public.admin_trip_action(uuid, text, text) from public, anon;
grant execute on function public.admin_live_trips() to authenticated;
grant execute on function public.admin_trip_action(uuid, text, text) to authenticated;
