-- v70: a trip with a change of car. The second driver is told where the passenger is (waiting / on car 1 / at the change point / missed car 1),
-- and the passenger sees that the second driver was told. Times are estimates from distance and speed (no live tracking).
-- Safe to run twice.
begin;

-- one call gives the status of the other part of a linked trip, to the passenger, either driver, or the office
create or replace function public.leg_status(p_booking uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  b bookings%rowtype; o bookings%rowtype; st text; spd numeric; eta timestamptz; walk numeric; who text; me uuid := auth.uid();
begin
  select * into b from bookings where id = p_booking and leg in (1, 2);
  if b.id is null then return null; end if;
  if b.leg = 1 then
    select * into o from bookings where parent_id = b.id limit 1;
  else
    select * into o from bookings where id = b.parent_id;
  end if;
  if o.id is null then return null; end if;
  if me is not null and not (is_admin() or me = b.passenger_id or me = b.driver_id or me = o.driver_id) then raise exception 'NOT_ALLOWED'; end if;

  -- state of part 1 (the long-road car)
  declare p1 bookings%rowtype := case when b.leg = 1 then b else o end; p2 bookings%rowtype := case when b.leg = 1 then o else b end;
  begin
    st := case p1.status when 'picked_up' then 'on_car' when 'completed' then 'at_change' when 'no_show' then 'missed'
                         when 'cancelled' then 'cancelled' when 'declined' then 'cancelled' else 'waiting' end;
    select coalesce(min(t.speed_kmh), 45), coalesce(min(t.walk_km), 1.5) into spd, walk from transfer_points t;
    eta := case when p1.picked_up_at is not null and coalesce(p1.km, 0) > 0
                then p1.picked_up_at + (p1.km / spd * 60) * interval '1 minute' end;
    who := coalesce((select full_name from profiles where id = p1.passenger_id), p1.caller_name, 'Passenger');
    return jsonb_build_object(
      'state', st,
      'passenger', who,
      'passenger_phone', coalesce((select phone from profiles where id = p1.passenger_id), p1.caller_phone),
      'leg1_driver', (select full_name from profiles where id = p1.driver_id),
      'leg1_driver_phone', (select phone from profiles where id = p1.driver_id),
      'leg1_plate', (select plate from trucks where id = p1.truck_id),
      'leg1_from', p1.pickup_name, 'leg1_to', p1.dest_name,
      'boarded_at', p1.picked_up_at, 'arrives_at', eta, 'dropped_at', case when st = 'at_change' then p1.completed_at end,
      'walk_min', round(walk / 5 * 60 + 10),
      'leg2_driver', (select full_name from profiles where id = p2.driver_id),
      'leg2_driver_phone', (select phone from profiles where id = p2.driver_id),
      'leg2_driver_told', p2.driver_id is not null and p1.status in ('picked_up', 'completed', 'no_show'));
  end;
end $$;
revoke all on function public.leg_status(uuid) from public, anon;
grant execute on function public.leg_status(uuid) to authenticated;

-- messages to the second driver when the first driver moves the passenger on
create or replace function public.leg_status_notify() returns trigger language plpgsql security definer set search_path = public as $$
declare
  b2 bookings%rowtype; who text; spd numeric; walk numeric; eta timestamptz; hhmm text; tz text := 'Africa/Johannesburg';
begin
  if new.leg <> 1 or new.status is not distinct from old.status then return new; end if;
  select * into b2 from bookings where parent_id = new.id and status in ('requested', 'assigned') limit 1;
  if b2.id is null or b2.driver_id is null then return new; end if;
  who := coalesce((select full_name from profiles where id = new.passenger_id), new.caller_name, 'The passenger');
  select coalesce(min(t.speed_kmh), 45), coalesce(min(t.walk_km), 1.5) into spd, walk from transfer_points t;
  if new.status = 'picked_up' then
    eta := now() + (coalesce(new.km, 0) / spd * 60) * interval '1 minute';
    perform notify(b2.driver_id, who || ' is on the first car',
      'Boarded at ' || new.pickup_name || ' ' || to_char(now() at time zone tz, 'HH24:MI') || '. Arrives ' || new.dest_name || ' about '
        || to_char(eta at time zone tz, 'HH24:MI') || '. Joins your trip at ' || b2.pickup_name || '.', 'leg_status', b2.id);
  elsif new.status = 'completed' then
    perform notify(b2.driver_id, who || ' is at ' || new.dest_name,
      'Walking to ' || b2.pickup_name || ', about ' || round(walk / 5 * 60 + 10) || ' min. Wait if you can.', 'leg_status', b2.id);
  elsif new.status = 'no_show' then
    perform notify(b2.driver_id, who || ' missed the first car',
      'The first car left without them. You can leave on time. The office is arranging another car.', 'leg_status', b2.id);
  end if;
  return new;
end $$;
drop trigger if exists bookings_leg_status_notify on public.bookings;
create trigger bookings_leg_status_notify after update of status on public.bookings
  for each row execute function public.leg_status_notify();

commit;
