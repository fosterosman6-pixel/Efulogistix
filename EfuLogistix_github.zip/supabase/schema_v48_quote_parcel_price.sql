-- v48: the fare you set for the WHOLE road is the anchor; every shorter trip is its share by distance.
-- Example: Mangochi - Monkey Bay is K10,000, so Nkope to Mpondasi pays K10,000 x (km between them / km of the whole road).
-- Also: one call gives the quote for a pair of depots for every vehicle type, and parcels are priced by distance.
-- Run after v47. Safe to run twice.

alter table public.corridor_rates add column if not exists full_fare numeric(12, 2) check (full_fare is null or full_fare >= 0);

create or replace function public.corridor_fares(p_corridor uuid, p_category uuid)
returns table (from_pos int, to_pos int, from_name text, to_name text, to_lat double precision, to_lng double precision, km numeric, fare numeric)
language sql stable security definer set search_path = public as $$
  with cum as (
    select pos, place_name, lat, lng, can_board, can_drop,
           sum(km_from_prev) over (order by pos) as km
      from corridor_stops where corridor_id = p_corridor
  ), tot as (select max(km) as total from cum)
  select a.pos, b.pos, a.place_name, b.place_name, b.lat, b.lng,
         round(abs(b.km - a.km), 1),
         coalesce(
           o.fare,
           greatest(r.min_fare,
                    round((case when r.full_fare is not null and t.total > 0
                                then r.full_fare * abs(b.km - a.km) / t.total
                                else r.per_km * abs(b.km - a.km) end) / r.round_to) * r.round_to)
         )
    from cum a
    join cum b on a.pos <> b.pos and a.can_board and b.can_drop
    cross join tot t
    join corridor_rates r on r.corridor_id = p_corridor and r.category_id = p_category
    left join corridor_overrides o
      on o.corridor_id = p_corridor and o.category_id = p_category
     and o.from_pos = least(a.pos, b.pos) and o.to_pos = greatest(a.pos, b.pos)
   order by 1, 2
$$;
revoke all on function public.corridor_fares(uuid, uuid) from public, anon;
grant execute on function public.corridor_fares(uuid, uuid) to authenticated;

drop function if exists public.corridor_quote(uuid, int, int);
-- fare quote: the working (km, rate, minimum, rounding) and the result, for every vehicle type
create or replace function public.corridor_quote(p_corridor uuid, p_from int, p_to int)
returns table (category_id uuid, km numeric, fare numeric, per_km numeric, min_fare numeric, round_to numeric, overridden boolean, total_km numeric, full_fare numeric)
language sql stable security definer set search_path = public as $$
  select r.category_id, f.km, f.fare, r.per_km, r.min_fare, r.round_to,
         exists (select 1 from corridor_overrides o
                  where o.corridor_id = p_corridor and o.category_id = r.category_id
                    and o.from_pos = least(p_from, p_to) and o.to_pos = greatest(p_from, p_to)),
         (select coalesce(sum(s.km_from_prev), 0) from corridor_stops s where s.corridor_id = p_corridor),
         r.full_fare
    from corridor_rates r
    cross join lateral public.corridor_fares(p_corridor, r.category_id) f
   where r.corridor_id = p_corridor and f.from_pos = p_from and f.to_pos = p_to
$$;
revoke all on function public.corridor_quote(uuid, int, int) from public, anon;
grant execute on function public.corridor_quote(uuid, int, int) to authenticated;

-- book_depot: same as v47, and a parcel's item prices are scaled to the share of the whole road it travels
-- (each item's list price is the price for the whole road; rounded to K500; never below K500)
create or replace function public.book_depot(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  lo int; hi int; fwd boolean; q record; bid uuid; tot numeric; scale numeric;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  if lo is null or hi is null then raise exception 'BAD_STOPS_ROUTE_ENDS'; end if;
  fwd := lo < hi;
  if fp is null or tp is null then raise exception 'BAD_STOPS_MISSING'; end if;
  if (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from public.corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  bid := public.book(p - 'from_pos' - 'to_pos');
  update bookings
     set pickup_name = fs.place_name, pickup_lat = fs.lat, pickup_lng = fs.lng,
         dest_name = ts.place_name, dest_lat = ts.lat, dest_lng = ts.lng,
         km = q.km, price = case when kind = 'seat' then q.fare * seats else price end
   where id = bid;

  if (p ->> 'kind') = 'goods' then
    select coalesce(sum(s.km_from_prev), 0) into tot from corridor_stops s where s.corridor_id = r.corridor_id;
    if tot > 0 then
      scale := least(1, q.km / tot);
      update bookings b2
         set goods = coalesce((select jsonb_agg(jsonb_set(e.item, '{price}',
                                    to_jsonb(greatest(500, round((e.item ->> 'price')::numeric * scale / 500) * 500))) order by e.ord)
                                 from jsonb_array_elements(b2.goods) with ordinality as e(item, ord)), '[]'::jsonb)
       where b2.id = bid;
      update bookings b2
         set price = coalesce((select sum((e ->> 'price')::numeric * (e ->> 'qty')::int) from jsonb_array_elements(b2.goods) e), 0)
       where b2.id = bid;
    end if;
  end if;
  return bid;
end $$;
revoke all on function public.book_depot(jsonb) from public, anon;
grant execute on function public.book_depot(jsonb) to authenticated;
