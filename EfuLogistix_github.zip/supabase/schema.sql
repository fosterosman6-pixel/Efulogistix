-- EfuLogistix Fleet: database setup
-- Paste this whole file into Supabase > SQL Editor > New query, then press Run.

-- ============ TABLES ============

create table if not exists public.trucks (
  id uuid primary key default gen_random_uuid(),
  plate text not null unique,
  model text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text,
  phone text,
  role text not null default 'driver' check (role in ('owner', 'driver')),
  active boolean not null default false,          -- owner approves drivers
  truck_id uuid references public.trucks (id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  trip_no bigint generated always as identity,
  driver_id uuid not null references public.profiles (id),
  truck_id uuid not null references public.trucks (id),
  pickup_name text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  dest_name text not null,
  dest_lat double precision not null,
  dest_lng double precision not null,
  passengers integer not null default 0 check (passengers >= 0),
  fare_per_passenger numeric(12, 2) not null default 0 check (fare_per_passenger >= 0),
  goods jsonb not null default '[]'::jsonb,       -- [{ "label": "3 bags maize", "amount": 3000 }]
  goods_total numeric(12, 2) not null default 0 check (goods_total >= 0),
  total numeric(12, 2) generated always as (passengers * fare_per_passenger + goods_total) stored,
  planned_km numeric(8, 1),
  actual_km numeric(8, 1),
  status text not null default 'in_progress' check (status in ('in_progress', 'completed', 'cancelled')),
  started_at timestamptz not null default now(),
  ended_at timestamptz
);
create index if not exists trips_started_idx on public.trips (started_at desc);
create index if not exists trips_driver_idx on public.trips (driver_id, started_at desc);
-- a driver can only have one trip running at a time
create unique index if not exists trips_one_running_per_driver
  on public.trips (driver_id) where status = 'in_progress';

-- one row per truck: its latest position (keeps the database small)
create table if not exists public.truck_locations (
  truck_id uuid primary key references public.trucks (id) on delete cascade,
  driver_id uuid references public.profiles (id) on delete set null,
  trip_id uuid references public.trips (id) on delete set null,
  lat double precision not null,
  lng double precision not null,
  speed double precision,
  updated_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  truck_id uuid not null references public.trucks (id),
  created_by uuid not null references public.profiles (id) default auth.uid(),
  category text not null check (category in ('fuel', 'repair', 'tyre', 'other')),
  litres numeric(8, 2),
  amount numeric(12, 2) not null check (amount >= 0),
  note text,
  spent_at timestamptz not null default now()
);
create index if not exists expenses_spent_idx on public.expenses (spent_at desc);

-- ============ HELPERS ============

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'owner' and active);
$$;

create or replace function public.is_active_driver()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'driver' and active);
$$;

create or replace function public.my_truck()
returns uuid language sql stable security definer set search_path = public as $$
  select truck_id from profiles where id = auth.uid();
$$;

-- new sign-ups get a driver profile that waits for owner approval
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name, phone)
  values (new.id, new.email,
          new.raw_user_meta_data ->> 'full_name',
          new.raw_user_meta_data ->> 'phone');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- drivers may not change their own role, approval or truck
create or replace function public.protect_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  -- auth.uid() is null in the SQL Editor, so you can still set the owner there
  if auth.uid() is not null and not is_owner() then
    new.role := old.role;
    new.active := old.active;
    new.truck_id := old.truck_id;
  end if;
  return new;
end;
$$;
drop trigger if exists protect_profile on public.profiles;
create trigger protect_profile before update on public.profiles
  for each row execute function public.protect_profile();

-- ============ SECURITY (row level security) ============

alter table public.trucks enable row level security;
alter table public.profiles enable row level security;
alter table public.trips enable row level security;
alter table public.truck_locations enable row level security;
alter table public.expenses enable row level security;

-- trucks: everyone signed in can read; only owner changes
drop policy if exists trucks_read on public.trucks;
create policy trucks_read on public.trucks for select to authenticated using (true);
drop policy if exists trucks_owner on public.trucks;
create policy trucks_owner on public.trucks for all to authenticated
  using (is_owner()) with check (is_owner());

-- profiles: you see yourself; owner sees and edits everyone
drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select to authenticated
  using (id = auth.uid() or is_owner());
drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles for update to authenticated
  using (id = auth.uid() or is_owner()) with check (id = auth.uid() or is_owner());

-- trips: drivers create and update their own; owner sees all
drop policy if exists trips_read on public.trips;
create policy trips_read on public.trips for select to authenticated
  using (driver_id = auth.uid() or is_owner());
drop policy if exists trips_insert on public.trips;
create policy trips_insert on public.trips for insert to authenticated
  with check (driver_id = auth.uid() and is_active_driver() and truck_id = my_truck());
drop policy if exists trips_update on public.trips;
create policy trips_update on public.trips for update to authenticated
  using ((driver_id = auth.uid() and status = 'in_progress') or is_owner())
  with check (driver_id = auth.uid() or is_owner());

-- live locations: a driver writes only their own truck's row
drop policy if exists loc_read on public.truck_locations;
create policy loc_read on public.truck_locations for select to authenticated
  using (is_owner() or driver_id = auth.uid());
drop policy if exists loc_insert on public.truck_locations;
create policy loc_insert on public.truck_locations for insert to authenticated
  with check (is_active_driver() and truck_id = my_truck() and driver_id = auth.uid());
drop policy if exists loc_update on public.truck_locations;
create policy loc_update on public.truck_locations for update to authenticated
  using (truck_id = my_truck() or is_owner())
  with check ((is_active_driver() and truck_id = my_truck() and driver_id = auth.uid()) or is_owner());

-- expenses: drivers add for their truck and see their own; owner does everything
drop policy if exists exp_read on public.expenses;
create policy exp_read on public.expenses for select to authenticated
  using (created_by = auth.uid() or is_owner());
drop policy if exists exp_insert on public.expenses;
create policy exp_insert on public.expenses for insert to authenticated
  with check (created_by = auth.uid() and (is_owner() or (is_active_driver() and truck_id = my_truck())));
drop policy if exists exp_owner on public.expenses;
create policy exp_owner on public.expenses for delete to authenticated using (is_owner());

-- ============ LIVE UPDATES ============
do $$
begin
  begin alter publication supabase_realtime add table public.truck_locations; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.trips; exception when duplicate_object then null; end;
end $$;

-- ====================================================================================
-- DATA API ACCESS (Supabase stops adding this automatically for new tables from 30 Oct 2026)
-- Signed-in users only; the row rules above (RLS) still decide which rows each person sees.
-- Nothing is granted to "anon": the app always signs in first.
-- ====================================================================================
grant usage on schema public to authenticated, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated, service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- ============ MAKE YOURSELF THE OWNER ============
-- 1. Sign up in the app with your own email.
-- 2. Run this line with your email:
-- update public.profiles set role = 'owner', active = true where email = 'you@example.com';
