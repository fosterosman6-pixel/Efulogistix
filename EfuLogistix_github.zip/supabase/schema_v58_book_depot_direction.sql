-- book_depot: if the chosen time is on the road's other direction, the same time and vehicle going the passenger's way is booked instead.
create or replace function public.book_depot(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  d departures%rowtype; r routes%rowtype; fs corridor_stops%rowtype; ts corridor_stops%rowtype;
  fp int := (p ->> 'from_pos')::int; tp int := (p ->> 'to_pos')::int;
  lo int; hi int; fwd boolean; q record; bid uuid; tot numeric; scale numeric;
begin
  select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
  if d.id is null then raise exception 'NO_DEPARTURE'; end if;
  select * into r from routes where id = d.route_id and active;
  if r.id is null or r.corridor_id is null then raise exception 'NO_DEPARTURE'; end if;
  select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
    into lo, hi from corridor_stops where corridor_id = r.corridor_id;
  if lo is null or hi is null then raise exception 'BAD_STOPS_ROUTE_ENDS'; end if;
  fwd := lo < hi;
  if fp is null or tp is null then raise exception 'BAD_STOPS_MISSING'; end if;
  if (fwd and not fp < tp) or (not fwd and not fp > tp) then
    -- the chosen time belongs to the road's other direction: use the same time and vehicle type going the passenger's way
    select d2.* into d from departures d2 join routes r2 on r2.id = d2.route_id
     where r2.corridor_id = r.corridor_id and r2.through and r2.active and r2.category_id = r.category_id
       and r2.id <> r.id and d2.leaves_at = d.leaves_at and d2.active
     order by d2.id limit 1;
    if d.id is null then raise exception 'BAD_STOPS_DIRECTION'; end if;
    p := jsonb_set(p, '{departure_id}', to_jsonb(d.id::text));
    select * into r from routes where id = d.route_id;
    select min(pos) filter (where place_name = r.from_name), min(pos) filter (where place_name = r.to_name)
      into lo, hi from corridor_stops where corridor_id = r.corridor_id;
    fwd := lo < hi;
    if (fwd and not fp < tp) or (not fwd and not fp > tp) then raise exception 'BAD_STOPS_DIRECTION'; end if;
  end if;
  select * into fs from corridor_stops where corridor_id = r.corridor_id and pos = fp;
  select * into ts from corridor_stops where corridor_id = r.corridor_id and pos = tp;
  if fs.pos is null or ts.pos is null or not fs.can_board or not ts.can_drop then raise exception 'BAD_STOPS_DEPOT'; end if;
  select f.km, f.fare into q from public.corridor_fares(r.corridor_id, r.category_id) f where f.from_pos = fp and f.to_pos = tp;
  if q.fare is null then raise exception 'BAD_STOPS_FARE'; end if;

  bid := public.book(p - 'from_pos' - 'to_pos');
  update bookings
     set pickup_name = fs.place_name, pickup_lat = fs.lat, pickup_lng = fs.lng,
         dest_name = ts.place_name, dest_lat = ts.lat, dest_lng = ts.lng,
         km = q.km, price = case when kind = 'seat' then q.fare * seats else price end
   where id = bid;

  if (p ->> 'kind') = 'goods' then
    select coalesce(sum(s.km_from_prev), 0) into tot from corridor_stops s where s.corridor_id = r.corridor_id;
    if tot > 0 then
      scale := least(1, q.km / tot);
      update bookings b2
         set goods = coalesce((select jsonb_agg(jsonb_set(e.item, '{price}',
                                    to_jsonb(greatest(500, round((e.item ->> 'price')::numeric * scale / 500) * 500))) order by e.ord)
                                 from jsonb_array_elements(b2.goods) with ordinality as e(item, ord)), '[]'::jsonb)
       where b2.id = bid;
      update bookings b2
         set price = coalesce((select sum((e ->> 'price')::numeric * (e ->> 'qty')::int) from jsonb_array_elements(b2.goods) e), 0)
       where b2.id = bid;
    end if;
  end if;
  return bid;
end $$;
revoke all on function public.book_depot(jsonb) from public, anon;
grant execute on function public.book_depot(jsonb) to authenticated;
