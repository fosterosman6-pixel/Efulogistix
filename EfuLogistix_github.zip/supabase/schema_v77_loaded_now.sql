-- v77: seats already taken by people and parcels loaded before the trip starts (these join the trip when it starts, see v76).
-- The New trip screen subtracts them from the Passengers limit so the car cannot be overfilled and nobody is counted twice.
begin;
create or replace function public.driver_loaded_now() returns int
language plpgsql stable security definer set search_path = public as $$
declare n int;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select coalesce(sum(case when b.kind = 'seat' then b.seats else _goods_seats(b.goods) end), 0)::int into n
    from bookings b
   where b.driver_id = auth.uid() and b.trip_id is null and b.status = 'picked_up'
     and b.kind in ('seat', 'goods') and b.picked_up_at >= now() - interval '12 hours';
  return n;
end $$;
revoke all on function public.driver_loaded_now() from public, anon;
grant execute on function public.driver_loaded_now() to authenticated;
commit;
