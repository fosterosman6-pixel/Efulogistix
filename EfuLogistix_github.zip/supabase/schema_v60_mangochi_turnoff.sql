-- v60: new road "Mankhwala - Mangochi Turn Off" (M3, south of Mangochi, near Machinga).
-- Passengers can book from Mankhwala Depot to Mangochi Turn Off Depot and back.
-- Safe to run twice. Afterwards: Admin > Roads & depots > choose this road > type the whole-road fare for each vehicle,
-- and check the distance (tap the depot, "Distance from the depot before").
begin;

insert into public.places (name, detail, lat, lng)
values ('Mangochi Turn Off Depot', 'Depot · M3 / M8 junction, near Machinga', -15.044939, 35.188968)
on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;

insert into public.route_corridors (name) values ('Mankhwala - Mangochi Turn Off') on conflict (name) do nothing;

insert into public.corridor_stops (corridor_id, pos, place_name, lat, lng)
select c.id, v.pos, p.name, p.lat, p.lng
  from public.route_corridors c
  join (values (0, 'Mankhwala Depot'), (1, 'Mangochi Turn Off Depot')) as v(pos, name) on true
  join public.places p on p.name = v.name
 where c.name = 'Mankhwala - Mangochi Turn Off'
   and not exists (select 1 from public.corridor_stops x where x.corridor_id = c.id);

-- same vehicles as the Monkey Bay road, starting at the same rate per km (type the whole-road fare in Admin)
insert into public.corridor_rates (corridor_id, category_id, per_km, min_fare, round_to)
select c.id, r.category_id, r.per_km, r.min_fare, r.round_to
  from public.route_corridors c
  join public.route_corridors m on m.name = 'Mangochi - Monkey Bay'
  join public.corridor_rates r on r.corridor_id = m.id
 where c.name = 'Mankhwala - Mangochi Turn Off'
on conflict (corridor_id, category_id) do nothing;

select public.corridor_recalc_km(id) from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off';
select public.corridor_rebuild(id) as fares_written from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off';

-- starter times: every 2 hours from 06:00 to 16:00, every day, both directions (change them in Admin > Timetable & rates)
insert into departures (route_id, leaves_at, days)
select r.id, t.tm, '{1,2,3,4,5,6,7}'
  from routes r
  cross join (values ('06:00'::time), ('08:00'), ('10:00'), ('12:00'), ('14:00'), ('16:00')) as t(tm)
 where r.through and r.active
   and r.corridor_id = (select id from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off')
on conflict (route_id, leaves_at) do nothing;

commit;

select s.pos, s.place_name, s.km_from_prev from public.corridor_stops s
 join public.route_corridors c on c.id = s.corridor_id and c.name = 'Mankhwala - Mangochi Turn Off' order by s.pos;
select r.from_name, r.to_name, vc.name as vehicle, r.km, r.fare, (select count(*) from departures d where d.route_id = r.id) as times
  from routes r join vehicle_categories vc on vc.id = r.category_id
 where r.through and r.active and r.corridor_id = (select id from public.route_corridors where name = 'Mankhwala - Mangochi Turn Off') order by vc.name, r.from_name;
