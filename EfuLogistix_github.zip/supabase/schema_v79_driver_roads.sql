-- v79: New trip starts with the road. The driver sees only the roads the admin gave their vehicle type, then the depots of that road,
-- then the admin's fare to every other depot. No road is written in the app: add a road or a depot in SQL and it appears.
-- Goods-only vehicles get no roads (they wait for hire or type a place and fare). Safe to run twice.
begin;

create or replace function public.driver_roads()
returns table (corridor_id uuid, name text, depots int)
language plpgsql stable security definer set search_path = public as $$
declare cat uuid;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.category_id into cat from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  if not coalesce((select carries_passengers from vehicle_categories where id = cat), false) then return; end if;
  return query
    select c.id, c.name::text, (select count(*)::int from corridor_stops s where s.corridor_id = c.id)
      from route_corridors c
     where exists (select 1 from corridor_rates r where r.corridor_id = c.id and r.category_id = cat)
     order by c.name;
end $$;

create or replace function public.driver_road_stops(p_corridor uuid)
returns table (pos int, name text, lat double precision, lng double precision, can_board boolean, can_drop boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  return query select s.pos, s.place_name::text, s.lat, s.lng, s.can_board, s.can_drop
                 from corridor_stops s where s.corridor_id = p_corridor order by s.pos;
end $$;

create or replace function public.driver_road_routes(p_corridor uuid, p_from_pos int)
returns table (to_name text, to_lat double precision, to_lng double precision, km numeric, fare numeric, to_pos int)
language plpgsql stable security definer set search_path = public as $$
declare cat uuid;
begin
  if not is_active_driver() then raise exception 'not allowed' using errcode = '42501'; end if;
  select t.category_id into cat from trucks t join profiles p on p.truck_id = t.id where p.id = auth.uid();
  return query
    select d.place_name::text, d.lat, d.lng, f.km, f.fare, d.pos
      from corridor_stops a
      join corridor_stops d on d.corridor_id = a.corridor_id and d.can_drop and d.pos <> a.pos
      join corridor_fares(p_corridor, cat) f on f.from_pos = a.pos and f.to_pos = d.pos
     where a.corridor_id = p_corridor and a.pos = p_from_pos
     order by f.km;
end $$;

revoke all on function public.driver_roads(), public.driver_road_stops(uuid), public.driver_road_routes(uuid, int) from public, anon;
grant execute on function public.driver_roads(), public.driver_road_stops(uuid), public.driver_road_routes(uuid, int) to authenticated;
commit;
