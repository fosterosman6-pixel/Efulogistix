-- EfuLogistix CATCH-UP: updates v17 to v29 and v31 in one file, in the right order.
-- Every part is safe to run twice. Run this once in the EfuLogistix Supabase project (SQL Editor).
-- If it stops with an error, nothing is changed: send the error text to Claude.

-- =================== v17 ===================
-- EfuLogistix: database update v17  (run AFTER schema_v16.sql)
--   Places: the admin adds or corrects places (name + coordinates) and every phone uses them. No new build needed.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.places (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(trim(name)) > 0),
  detail text not null default '',
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  created_at timestamptz not null default now()
);

alter table public.places enable row level security;
drop policy if exists places_read on public.places;
create policy places_read on public.places for select to authenticated using (true);
drop policy if exists places_write on public.places;
create policy places_write on public.places for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.places to authenticated;
grant all on public.places to service_role;

-- the two places checked on the map so far
insert into public.places (name, detail, lat, lng) values
  ('Mpondasi', 'Mangochi District', -14.461511, 35.243191),
  ('Mtamila Primary School', 'School · Mangochi District', -14.422321, 35.331800)
on conflict (name) do nothing;

-- =================== v18 ===================
-- EfuLogistix: database update v18  (run AFTER schema_v17.sql)
--   Drivers can suggest a place from where they stand; the admin approves it into the Places list.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.place_suggestions (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) > 0),
  detail text not null default '',
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  suggested_by uuid not null references public.profiles (id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now()
);

alter table public.place_suggestions enable row level security;
drop policy if exists place_sug_read on public.place_suggestions;
create policy place_sug_read on public.place_suggestions for select to authenticated
  using (suggested_by = auth.uid() or public.is_admin());
drop policy if exists place_sug_insert on public.place_suggestions;
create policy place_sug_insert on public.place_suggestions for insert to authenticated
  with check (suggested_by = auth.uid() and status = 'pending' and public.is_active_driver());
revoke update, delete on public.place_suggestions from authenticated;
grant select, insert on public.place_suggestions to authenticated;
grant all on public.place_suggestions to service_role;

-- Admin: approve (adds or corrects the place) or reject a suggestion
create or replace function public.decide_place_suggestion(p_id uuid, p_approve boolean)
returns void language plpgsql security definer set search_path = public as $$
declare s place_suggestions%rowtype;
begin
  if not is_admin() then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into s from place_suggestions where id = p_id and status = 'pending' for update;
  if s.id is null then raise exception 'ALREADY_DECIDED'; end if;
  if p_approve then
    insert into places (name, detail, lat, lng) values (trim(s.name), s.detail, s.lat, s.lng)
    on conflict (name) do update set detail = excluded.detail, lat = excluded.lat, lng = excluded.lng;
  end if;
  update place_suggestions set status = case when p_approve then 'approved' else 'rejected' end where id = p_id;
  perform notify(s.suggested_by, case when p_approve then 'Place added: ' else 'Place not added: ' end || s.name,
    case when p_approve then 'Thank you. The office added this place for everyone.' else 'The office could not add this place.' end, null, null);
end $$;
revoke all on function public.decide_place_suggestion(uuid, boolean) from public, anon;
grant execute on function public.decide_place_suggestion(uuid, boolean) to authenticated;

-- =================== v19 ===================
-- EfuLogistix: database update v19  (run AFTER schema_v18.sql)
--   1. Hire requests are offered to the nearest free driver (accept or decline, 2 minutes), then the next one.
--      If nobody accepts, the booking stays "Waiting for office" as before.
--   2. "Car has arrived" button and an automatic "car is almost there" message to the passenger.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.app_settings add column if not exists auto_offer boolean not null default true;
alter table public.bookings add column if not exists arrived_at timestamptz;
alter table public.bookings add column if not exists near_notified_at timestamptz;

-- ====================================================================================
-- 1. OFFERS
-- ====================================================================================
create table if not exists public.booking_offers (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  driver_id uuid not null references public.profiles (id) on delete cascade,
  truck_id uuid not null references public.trucks (id) on delete cascade,
  status text not null default 'offered' check (status in ('offered', 'accepted', 'declined', 'expired', 'cancelled')),
  offered_at timestamptz not null default now(),
  answered_at timestamptz
);
create unique index if not exists booking_offers_one_open on public.booking_offers (booking_id) where status = 'offered';
create index if not exists booking_offers_driver_idx on public.booking_offers (driver_id, status);

alter table public.booking_offers enable row level security;
drop policy if exists booking_offers_read on public.booking_offers;
create policy booking_offers_read on public.booking_offers for select to authenticated
  using (driver_id = auth.uid() or public.is_manager());
revoke insert, update, delete on public.booking_offers from authenticated;
grant select on public.booking_offers to authenticated;
grant all on public.booking_offers to service_role;

create or replace function public._km_between(a_lat double precision, a_lng double precision, b_lat double precision, b_lng double precision)
returns double precision language sql immutable as $$
  select 2 * 6371 * asin(sqrt(
    power(sin(radians(b_lat - a_lat) / 2), 2) +
    cos(radians(a_lat)) * cos(radians(b_lat)) * power(sin(radians(b_lng - a_lng) / 2), 2)));
$$;

-- Offer a waiting hire booking to the nearest free driver with the right kind of vehicle.
create or replace function public._offer_booking(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; pick record;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind <> 'hire' or b.pickup_lat is null or b.pickup_lng is null then return; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return; end if;
  if b.pickup_at > now() + interval '90 minutes' then return; end if;   -- later bookings stay with the office
  if exists (select 1 from booking_offers where booking_id = b.id and status = 'offered') then return; end if;
  select s.driver_id, s.truck_id,
         public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) as km
    into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join truck_locations l on l.truck_id = s.truck_id and l.updated_at > now() - interval '10 minutes'
   where s.status = 'on_duty'
     and (b.category_id is null or t.category_id = b.category_id)
     and not exists (select 1 from trips tr where tr.driver_id = s.driver_id and tr.status = 'in_progress')
     and not exists (select 1 from booking_offers o where o.booking_id = b.id and o.driver_id = s.driver_id)
     and not exists (select 1 from booking_offers o where o.driver_id = s.driver_id and o.status = 'offered')
     and public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) <= 60
   order by km limit 1;
  if pick.driver_id is null then return; end if;
  insert into booking_offers (booking_id, driver_id, truck_id) values (b.id, pick.driver_id, pick.truck_id);
  perform notify(pick.driver_id, 'New hire request · ' || round(pick.km::numeric, 1) || ' km away',
    b.pickup_name || ' → ' || b.dest_name || ' · K' || to_char(b.price, 'FM999,999,990') || '. Open Booked pickups to accept (2 minutes).', 'booking', b.id);
end $$;
revoke all on function public._offer_booking(uuid) from public, anon, authenticated;

create or replace function public._offer_on_new_booking() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public._offer_booking(new.id);
  return new;
end $$;
drop trigger if exists bookings_offer on public.bookings;
create trigger bookings_offer after insert on public.bookings for each row execute function public._offer_on_new_booking();

-- Driver: accept or decline an offer
create or replace function public.answer_offer(p_offer uuid, p_accept boolean)
returns void language plpgsql security definer set search_path = public as $$
declare o booking_offers%rowtype; b bookings%rowtype; t trucks%rowtype; drv profiles%rowtype;
begin
  select * into o from booking_offers where id = p_offer and driver_id = auth.uid() for update;
  if o.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if o.status <> 'offered' then raise exception 'ALREADY_DECIDED'; end if;
  select * into b from bookings where id = o.booking_id for update;
  if not p_accept then
    update booking_offers set status = 'declined', answered_at = now() where id = o.id;
    perform public._offer_booking(o.booking_id);
    return;
  end if;
  if b.status <> 'requested' then
    update booking_offers set status = 'cancelled', answered_at = now() where id = o.id;
    raise exception 'ALREADY_DECIDED';
  end if;
  select * into t from trucks where id = o.truck_id;
  select * into drv from profiles where id = o.driver_id;
  update bookings set status = 'assigned', truck_id = t.id, driver_id = drv.id, assigned_at = now(),
    message = 'Accepted by the driver',
    category_id = coalesce(b.category_id, t.category_id)
   where id = b.id;
  update booking_offers set status = 'accepted', answered_at = now() where id = o.id;
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · car assigned',
    t.plate || coalesce(' · ' || t.colour, '') || coalesce(' ' || t.make, '') || ' · driver ' || coalesce(drv.full_name, '') || coalesce(' · ' || drv.phone, ''),
    'booking', b.id);
end $$;
revoke all on function public.answer_offer(uuid, boolean) from public, anon;
grant execute on function public.answer_offer(uuid, boolean) to authenticated;

-- Every minute: offers nobody answered in 2 minutes go to the next driver
create or replace function public.expire_offers() returns int
language plpgsql security definer set search_path = public as $$
declare o record; n int := 0;
begin
  for o in select * from booking_offers where status = 'offered' and offered_at < now() - interval '2 minutes' loop
    update booking_offers set status = 'expired', answered_at = now() where id = o.id;
    perform notify(o.driver_id, 'Hire request expired', 'It was offered to another driver.', 'booking', o.booking_id);
    perform public._offer_booking(o.booking_id);
    n := n + 1;
  end loop;
  -- offers on bookings the office already handled
  update booking_offers set status = 'cancelled', answered_at = now()
   where status = 'offered' and booking_id in (select id from bookings where status <> 'requested');
  return n;
end $$;
revoke all on function public.expire_offers() from public, anon, authenticated;

do $$ begin
  perform cron.schedule('efu-expire-offers', '* * * * *', 'select public.expire_offers()');
exception when others then null;
end $$;

-- ====================================================================================
-- 2. ARRIVAL
-- ====================================================================================
create or replace function public.booking_arrived(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() and status = 'assigned' for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if b.arrived_at is not null then return; end if;
  update bookings set arrived_at = now() where id = b.id;
  perform notify(b.passenger_id, 'Your car has arrived', 'Booking #' || b.booking_no || ' · show your ticket to the driver.', 'booking', b.id);
end $$;
revoke all on function public.booking_arrived(uuid) from public, anon;
grant execute on function public.booking_arrived(uuid) to authenticated;

-- when the car comes within 1.5 km of the pick-up point, tell the passenger once
create or replace function public._car_near_pickup() returns trigger
language plpgsql security definer set search_path = public as $$
declare b record; km double precision;
begin
  for b in select * from bookings
            where truck_id = new.truck_id and status = 'assigned' and near_notified_at is null
              and pickup_lat is not null and pickup_lng is not null loop
    km := public._km_between(new.lat, new.lng, b.pickup_lat, b.pickup_lng);
    if km <= 1.5 then
      update bookings set near_notified_at = now() where id = b.id;
      perform notify(b.passenger_id, 'Your car is almost there', 'Booking #' || b.booking_no || ' · about ' || greatest(1, round(km * 2)::int) || ' min away. Be ready at ' || b.pickup_name || '.', 'booking', b.id);
    end if;
  end loop;
  return new;
end $$;
drop trigger if exists truck_locations_near on public.truck_locations;
create trigger truck_locations_near after insert or update of lat, lng on public.truck_locations
  for each row execute function public._car_near_pickup();

-- Driver: the requests waiting for my answer (the driver cannot read the booking itself until accepting)
drop function if exists public.my_offers();
create or replace function public.my_offers()
returns table (offer_id uuid, booking_no bigint, pickup_name text, dest_name text, pickup_lat double precision, pickup_lng double precision, dest_lat double precision, dest_lng double precision,
               price numeric, km numeric, trip_type text, pickup_at timestamptz, seconds_left int)
language sql stable security definer set search_path = public as $$
  select o.id, b.booking_no, b.pickup_name, b.dest_name, b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng, b.price, b.km, b.trip_type, b.pickup_at,
         greatest(0, 120 - extract(epoch from now() - o.offered_at)::int)
    from booking_offers o join bookings b on b.id = o.booking_id
   where o.driver_id = auth.uid() and o.status = 'offered' and b.status = 'requested'
   order by o.offered_at;
$$;
revoke all on function public.my_offers() from public, anon;
grant execute on function public.my_offers() to authenticated;

-- =================== v20 ===================
-- EfuLogistix: database update v20  (run AFTER schema_v19.sql)
--   Parcel SMS: when the driver marks a parcel loaded, the receiver gets a text with the collection code (via Plivo).
-- Setup: see SMS_SETUP.md. Safe to run twice.

create table if not exists public.sms_config (
  id int primary key check (id = 1),
  url text not null,
  secret text not null
);
alter table public.sms_config enable row level security;
revoke all on public.sms_config from authenticated, anon;
grant all on public.sms_config to service_role;

create table if not exists public.sms_log (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings (id) on delete set null,
  kind text not null,
  to_phone text not null,
  body text not null,
  created_at timestamptz not null default now(),
  unique (booking_id, kind)
);
alter table public.sms_log enable row level security;
drop policy if exists sms_log_read on public.sms_log;
create policy sms_log_read on public.sms_log for select to authenticated using (public.is_manager());
revoke insert, update, delete on public.sms_log from authenticated;
grant select on public.sms_log to authenticated;
grant all on public.sms_log to service_role;

create or replace function public.set_sms_config(p_url text, p_secret text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'NOT_ALLOWED'; end if;
  if p_url is null or p_url !~ '^https://' or length(coalesce(p_secret, '')) < 16 then raise exception 'BAD_CONFIG'; end if;
  insert into sms_config (id, url, secret) values (1, p_url, p_secret)
  on conflict (id) do update set url = excluded.url, secret = excluded.secret;
end $$;
revoke all on function public.set_sms_config(text, text) from public, anon;
grant execute on function public.set_sms_config(text, text) to authenticated;

-- 0888 123 456 / +265 888 123 456 / 265888123456  ->  265888123456  (null if it does not look like a number)
create or replace function public._malawi_number(p text)
returns text language sql immutable as $$
  select case
    when d ~ '^265[0-9]{9}$' then d
    when d ~ '^0[0-9]{9}$' then '265' || substr(d, 2)
    when d ~ '^[0-9]{9}$' then '265' || d
    else null end
  from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) x;
$$;

-- one text; recorded once per booking and kind; never blocks the booking
create or replace function public._send_sms(p_booking uuid, p_kind text, p_to text, p_text text)
returns void language plpgsql security definer set search_path = public, extensions as $$
declare cfg sms_config%rowtype; num text := public._malawi_number(p_to); n int;
begin
  if num is null then return; end if;
  insert into sms_log (booking_id, kind, to_phone, body) values (p_booking, p_kind, num, p_text) on conflict do nothing;
  get diagnostics n = row_count;
  if n = 0 then return; end if;
  select * into cfg from sms_config where id = 1;
  if cfg.id is null then return; end if;
  begin
    perform net.http_post(url := cfg.url,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-sms-secret', cfg.secret),
      body := jsonb_build_object('to', num, 'text', p_text));
  exception when others then null;
  end;
end $$;
revoke all on function public._send_sms(uuid, text, text, text) from public, anon, authenticated;

-- parcel loaded -> receiver gets the code
create or replace function public._sms_parcel_on_way() returns trigger
language plpgsql security definer set search_path = public as $$
declare code text; sender text; plate text;
begin
  if new.kind <> 'goods' or new.status <> 'picked_up' or old.status = 'picked_up' then return new; end if;
  select c.code into code from booking_codes c where c.booking_id = new.id;
  if code is null or new.receiver_phone is null then return new; end if;
  select coalesce(nullif(split_part(full_name, ' ', 1), ''), 'Someone') into sender from profiles where id = new.passenger_id;
  select t.plate into plate from trucks t where t.id = new.truck_id;
  perform public._send_sms(new.id, 'parcel_on_way', new.receiver_phone,
    'EfuLogistix: a parcel from ' || coalesce(sender, new.caller_name, 'someone') || ' is on its way to ' || new.dest_name
    || coalesce(' in ' || plate, '') || '. Give the driver this code when you receive it: ' || code);
  return new;
end $$;
drop trigger if exists bookings_sms_parcel on public.bookings;
create trigger bookings_sms_parcel after update of status on public.bookings
  for each row execute function public._sms_parcel_on_way();

-- =================== v21 ===================
-- EfuLogistix: database update v21  (run AFTER schema_v20.sql, or v19 if you skipped v20)
--   Hire bookings: places outside Malawi (a bad GPS fix, e.g. "Somerset West") and trips over 1,500 km are refused.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public._in_malawi(p_lat double precision, p_lng double precision)
returns boolean language sql immutable as $$
  select p_lat between -17.5 and -9.0 and p_lng between 32.5 and 36.5;
$$;

create or replace function public.book(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  me profiles%rowtype;
  st app_settings%rowtype;
  office boolean := is_owner();
  k text := p ->> 'kind';
  b bookings%rowtype;
  d departures%rowtype;
  r routes%rowtype;
  c vehicle_categories%rowtype;
  cap int; taken int; straight double precision; g jsonb; gp numeric; items jsonb := '[]'::jsonb; total numeric := 0;
  bid uuid; code text;
begin
  select * into me from profiles where id = auth.uid();
  select * into st from app_settings where id = 1;
  if not office and (me.id is null or me.role <> 'passenger' or not me.active) then
    raise exception 'not allowed' using errcode = '42501';
  end if;
  if not office and (select count(*) from bookings where passenger_id = me.id and status in ('requested', 'assigned', 'picked_up'))
       >= st.max_open_bookings then
    raise exception 'TOO_MANY_BOOKINGS';
  end if;

  b.kind := k;
  b.passenger_id := case when office then nullif(p ->> 'passenger_id', '')::uuid else me.id end;
  b.caller_name := case when office then nullif(p ->> 'caller_name', '') end;
  b.caller_phone := case when office then nullif(p ->> 'caller_phone', '') end;
  if office and b.passenger_id is null and (b.caller_name is null or b.caller_phone is null) then
    raise exception 'CALLER_REQUIRED';
  end if;
  b.pay_method := coalesce(nullif(p ->> 'pay_method', ''), 'cash');
  b.pay_reference := nullif(trim(p ->> 'pay_reference'), '');
  b.note := nullif(p ->> 'note', '');
  if b.pay_method in ('airtel_money', 'tnm_mpamba') and b.pay_reference is null and not office then
    raise exception 'REFERENCE_REQUIRED';
  end if;
  if b.pay_method = 'account' then
    b.account_id := case when office then coalesce(nullif(p ->> 'account_id', '')::uuid, me.account_id) else me.account_id end;
    if b.account_id is null or not exists (select 1 from company_accounts where id = b.account_id and active) then
      raise exception 'NO_ACCOUNT';
    end if;
  end if;

  if k in ('seat', 'goods') then
    select * into d from departures where id = (p ->> 'departure_id')::uuid and active;
    if d.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into r from routes where id = d.route_id and active;
    if r.id is null then raise exception 'NO_DEPARTURE'; end if;
    select * into c from vehicle_categories where id = r.category_id;
    b.travel_on := (p ->> 'travel_on')::date;
    if b.travel_on is null or not (extract(isodow from b.travel_on)::int = any (d.days)) then raise exception 'NO_DEPARTURE'; end if;
    b.pickup_at := (b.travel_on + d.leaves_at) at time zone 'Africa/Blantyre';
    if b.pickup_at < now() - interval '5 minutes' then raise exception 'DEPARTED'; end if;
    b.departure_id := d.id;
    b.route_id := r.id;
    b.category_id := r.category_id;
    b.pickup_name := r.from_name;
    b.dest_name := r.to_name;
    b.dest_lat := r.to_lat;
    b.dest_lng := r.to_lng;
    if k = 'seat' then
      b.seats := coalesce((p ->> 'seats')::int, 0);
      if b.seats < 1 then raise exception 'SEATS_REQUIRED'; end if;
      cap := coalesce(d.seats, c.seats, 0);
      select coalesce(sum(x.seats), 0) into taken from bookings x
        where x.departure_id = d.id and x.travel_on = b.travel_on and x.kind = 'seat' and x.status in ('requested', 'assigned', 'picked_up');
      if taken + b.seats > cap then raise exception 'FULL:%', greatest(cap - taken, 0); end if;
      b.price := r.fare * b.seats;
    end if;
  elsif k = 'hire' then
    select * into c from vehicle_categories where id = (p ->> 'category_id')::uuid and active;
    if c.id is null or c.hire_per_km <= 0 then raise exception 'NOT_FOR_HIRE'; end if;
    b.category_id := c.id;
    b.pickup_name := nullif(trim(p ->> 'pickup_name'), '');
    b.dest_name := nullif(trim(p ->> 'dest_name'), '');
    if b.pickup_name is null or b.dest_name is null then raise exception 'PLACES_REQUIRED'; end if;
    b.pickup_lat := (p ->> 'pickup_lat')::double precision;
    b.pickup_lng := (p ->> 'pickup_lng')::double precision;
    b.dest_lat := (p ->> 'dest_lat')::double precision;
    b.dest_lng := (p ->> 'dest_lng')::double precision;
    -- places outside Malawi are a bad GPS fix, not a real trip
    if (b.pickup_lat is not null and not public._in_malawi(b.pickup_lat, b.pickup_lng))
       or (b.dest_lat is not null and not public._in_malawi(b.dest_lat, b.dest_lng)) then
      raise exception 'OUT_OF_AREA';
    end if;
    b.trip_type := coalesce(nullif(p ->> 'trip_type', ''), 'one_way');
    b.pickup_at := coalesce((p ->> 'pickup_at')::timestamptz, now());
    if b.pickup_at < now() - interval '10 minutes' then raise exception 'IN_THE_PAST'; end if;
    b.km := greatest(coalesce((p ->> 'km')::numeric, 0), 1);
    -- never less than the straight line (the phone sends the road distance)
    straight := km_between(b.pickup_lat, b.pickup_lng, b.dest_lat, b.dest_lng);
    if straight is not null then
      b.km := greatest(b.km, round((straight * case when b.trip_type = 'return' then 2 else 1 end)::numeric, 1));
    end if;
    if b.trip_type = 'whole_day' then b.km := greatest(b.km, 100); end if;
    if b.km > 1500 then raise exception 'TOO_FAR'; end if;
    b.rate_per_km := c.hire_per_km;
    b.price := greatest(c.hire_min, ceil(b.km * c.hire_per_km / 500) * 500);
    b.seats := coalesce((p ->> 'seats')::int, 0);
  else
    raise exception 'bad kind';
  end if;

  -- goods (on a departure, or a load on a hired lorry)
  if k = 'goods' or jsonb_array_length(coalesce(p -> 'goods', '[]'::jsonb)) > 0 then
    for g in select * from jsonb_array_elements(coalesce(p -> 'goods', '[]'::jsonb)) loop
      if coalesce((g ->> 'qty')::int, 0) < 1 then continue; end if;
      if k = 'goods' then
        select price into gp from goods_prices where label = g ->> 'label' and active;
        if gp is null then raise exception 'UNKNOWN_GOODS:%', g ->> 'label'; end if;
      else
        gp := 0;                                   -- a hired car is paid per km
      end if;
      items := items || jsonb_build_object('label', g ->> 'label', 'qty', (g ->> 'qty')::int, 'price', gp);
      total := total + gp * (g ->> 'qty')::int;
    end loop;
    if k = 'goods' and jsonb_array_length(items) = 0 then raise exception 'GOODS_REQUIRED'; end if;
    b.goods := items;
    if k = 'goods' then b.price := total; end if;
    b.receiver_name := nullif(trim(p ->> 'receiver_name'), '');
    b.receiver_phone := nullif(trim(p ->> 'receiver_phone'), '');
    if b.receiver_name is null or b.receiver_phone is null then raise exception 'RECEIVER_REQUIRED'; end if;
    code := lpad((floor(random() * 10000))::int::text, 4, '0');
  end if;

  insert into bookings (passenger_id, caller_name, caller_phone, kind, category_id, route_id, departure_id, travel_on,
    pickup_at, seats, pickup_name, pickup_lat, pickup_lng, dest_name, dest_lat, dest_lng, trip_type, km, rate_per_km,
    goods, receiver_name, receiver_phone, price, pay_method, pay_reference, account_id, note)
  values (b.passenger_id, b.caller_name, b.caller_phone, b.kind, b.category_id, b.route_id, b.departure_id, b.travel_on,
    b.pickup_at, coalesce(b.seats, 0), b.pickup_name, b.pickup_lat, b.pickup_lng, b.dest_name, b.dest_lat, b.dest_lng, b.trip_type, b.km,
    b.rate_per_km, coalesce(b.goods, '[]'::jsonb), b.receiver_name, b.receiver_phone, b.price, b.pay_method, b.pay_reference,
    b.account_id, b.note)
  returning id into bid;
  if code is not null then insert into booking_codes (booking_id, code) values (bid, code); end if;
  return bid;
end;
$$;

-- =================== v22 ===================
-- EfuLogistix: database update v22  (run AFTER schema_v21.sql)
--   Bookings are automatic:
--     * seat and parcel bookings go straight to a vehicle on duty for that departure (no office step)
--     * hire requests keep being offered to nearby drivers (a driver who said no is asked again after 5 minutes)
--     * only when nothing works for a while does a booking wait for the office
--   Admin > Settings > Hire requests switch (auto_offer) turns all of this on or off.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public._offer_booking(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; pick record;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind <> 'hire' or b.pickup_lat is null or b.pickup_lng is null then return; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return; end if;
  if b.pickup_at > now() + interval '90 minutes' then return; end if;   -- later bookings stay with the office
  if exists (select 1 from booking_offers where booking_id = b.id and status = 'offered') then return; end if;
  select s.driver_id, s.truck_id,
         public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) as km
    into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join truck_locations l on l.truck_id = s.truck_id and l.updated_at > now() - interval '10 minutes'
   where s.status = 'on_duty'
     and (b.category_id is null or t.category_id = b.category_id)
     and not exists (select 1 from trips tr where tr.driver_id = s.driver_id and tr.status = 'in_progress')
     and not exists (select 1 from booking_offers o where o.booking_id = b.id and o.driver_id = s.driver_id
                      and (o.status = 'offered' or o.answered_at > now() - interval '5 minutes'))   -- a driver who said no is asked again after 5 minutes
     and not exists (select 1 from booking_offers o where o.driver_id = s.driver_id and o.status = 'offered')
     and public._km_between(l.lat, l.lng, b.pickup_lat, b.pickup_lng) <= 60
   order by km limit 1;
  if pick.driver_id is null then return; end if;
  insert into booking_offers (booking_id, driver_id, truck_id) values (b.id, pick.driver_id, pick.truck_id);
  perform notify(pick.driver_id, 'New hire request · ' || round(pick.km::numeric, 1) || ' km away',
    b.pickup_name || ' → ' || b.dest_name || ' · K' || to_char(b.price, 'FM999,999,990') || '. Open Booked pickups to accept (2 minutes).', 'booking', b.id);
end $$;

create or replace function public.expire_offers() returns int
language plpgsql security definer set search_path = public as $$
declare o record; n int := 0;
begin
  for o in select * from booking_offers where status = 'offered' and offered_at < now() - interval '2 minutes' loop
    update booking_offers set status = 'expired', answered_at = now() where id = o.id;
    perform notify(o.driver_id, 'Hire request expired', 'It was offered to another driver.', 'booking', o.booking_id);
    perform public._offer_booking(o.booking_id);
    n := n + 1;
  end loop;
  -- offers on bookings the office already handled
  update booking_offers set status = 'cancelled', answered_at = now()
   where status = 'offered' and booking_id in (select id from bookings where status <> 'requested');
  -- hire requests nobody has taken yet (no open offer): try the drivers again, for up to 30 minutes
  for o in select b.id from bookings b
            where b.status = 'requested' and b.kind = 'hire' and b.created_at > now() - interval '30 minutes'
              and not exists (select 1 from booking_offers x where x.booking_id = b.id and x.status = 'offered') loop
    perform public._offer_booking(o.id);
  end loop;
  return n;
end $$;

-- Give a booking to a vehicle and tell the passenger and the driver
create or replace function public._assign_to_truck(p_booking uuid, p_truck uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; t trucks%rowtype; drv profiles%rowtype;
begin
  select * into b from bookings where id = p_booking and status = 'requested' for update;
  if b.id is null then return false; end if;
  select * into t from trucks where id = p_truck;
  select p.* into drv from profiles p
    left join shifts s on s.driver_id = p.id and s.status = 'on_duty' and s.truck_id = t.id
   where p.role = 'driver' and p.active and (p.truck_id = t.id or s.id is not null)
   order by (s.id is not null) desc limit 1;
  if t.id is null or drv.id is null then return false; end if;
  update bookings set status = 'assigned', truck_id = t.id, driver_id = drv.id, assigned_at = now(),
         message = 'Assigned automatically' where id = b.id;
  update booking_offers set status = 'cancelled', answered_at = now() where booking_id = b.id and status = 'offered';
  perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' · car assigned',
    t.plate || coalesce(' · ' || t.colour, '') || coalesce(' ' || t.make, '') || ' · driver ' || coalesce(drv.full_name, '') || coalesce(' · ' || drv.phone, ''),
    'booking', b.id);
  perform notify(drv.id, 'New pickup · ' || to_char(b.pickup_at at time zone 'Africa/Blantyre', 'Dy HH24:MI'),
    coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, '') || ' · ' || b.pickup_name || ' → ' || b.dest_name,
    'booking', b.id);
  return true;
end $$;
revoke all on function public._assign_to_truck(uuid, uuid) from public, anon, authenticated;

-- Seat / parcel booking: pick the vehicle on duty that already carries this departure, else the least busy one with room
create or replace function public._auto_assign(p_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; d departures%rowtype; pick uuid;
begin
  select * into b from bookings where id = p_id;
  if b.id is null or b.status <> 'requested' or b.kind not in ('seat', 'goods') or b.category_id is null then return false; end if;
  if not coalesce((select auto_offer from app_settings limit 1), true) then return false; end if;
  select * into d from departures where id = b.departure_id;
  select t.id into pick
    from shifts s
    join trucks t on t.id = s.truck_id and t.status = 'approved' and t.active
    join vehicle_categories c on c.id = t.category_id
   where s.status = 'on_duty' and t.category_id = b.category_id
     and ((b.kind = 'seat' and c.carries_passengers) or (b.kind = 'goods' and c.carries_goods))
     and (b.kind <> 'seat' or coalesce(d.seats, t.seats, c.seats) >=
          b.seats + coalesce((select sum(x.seats) from bookings x
                               where x.truck_id = t.id and x.departure_id = b.departure_id and x.travel_on = b.travel_on
                                 and x.kind = 'seat' and x.status in ('assigned', 'picked_up')), 0))
   order by exists (select 1 from bookings x where x.truck_id = t.id and x.departure_id = b.departure_id and x.travel_on = b.travel_on
                      and x.status in ('assigned', 'picked_up')) desc,
            (select count(*) from bookings x where x.truck_id = t.id and x.status in ('assigned', 'picked_up')),
            random()
   limit 1;
  if pick is null then return false; end if;
  return public._assign_to_truck(b.id, pick);
end $$;
revoke all on function public._auto_assign(uuid) from public, anon, authenticated;

create or replace function public._auto_assign_on_new_booking() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind in ('seat', 'goods') and new.pickup_at <= now() + interval '3 hours' then
    perform public._auto_assign(new.id);
  end if;
  return new;
end $$;
drop trigger if exists bookings_auto_assign on public.bookings;
create trigger bookings_auto_assign after insert on public.bookings for each row execute function public._auto_assign_on_new_booking();

-- Every minute: bookings that could not be placed yet (no vehicle on duty) are tried again once the departure is within 3 hours
create or replace function public.auto_assign_pending() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select id from bookings
            where status = 'requested' and kind in ('seat', 'goods')
              and pickup_at <= now() + interval '3 hours' and pickup_at > now() - interval '30 minutes' loop
    if public._auto_assign(r.id) then n := n + 1; end if;
  end loop;
  return n;
end $$;
revoke all on function public.auto_assign_pending() from public, anon, authenticated;

do $$ begin
  perform cron.schedule('efu-auto-assign', '* * * * *', 'select public.auto_assign_pending()');
exception when others then null;
end $$;

-- =================== v23 ===================
-- EfuLogistix: database update v23  (run AFTER schema_v22.sql)
--   Hire prices at the end of a trip:
--     * a whole-day hire is always charged at least 100 km (it was already at booking, but not when the trip was finished);
--     * the km typed by the driver cannot be more than 1.5 x the booked km + 10 (otherwise KM_TOO_HIGH: ask the office).
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.booking_step(p_id uuid, p_step text, p_code text, p_km numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; final numeric; final_km numeric; who text; code text;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if p_step = 'picked_up' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    -- people (not parcels) are only marked on board by scanning or typing the ticket code
    if b.kind <> 'goods' and coalesce(current_setting('efu.boarding', true), '') <> '1' then raise exception 'CODE_REQUIRED'; end if;
    update bookings set status = 'picked_up', picked_up_at = now(), trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind in ('seat', 'goods') then
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (tr.id, 'Booking #' || b.booking_no || ' · ' || who,
              0, b.seats, case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  elsif p_step = 'no_show' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'no_show', completed_at = now() where id = p_id;
    if b.passenger_id is not null then
      perform system_on();
      update profiles set no_shows = no_shows + 1 where id = b.passenger_id;
      perform notify(b.passenger_id, 'Missed booking #' || b.booking_no, 'The car waited but you were not there. Missed bookings are counted on your profile.', 'booking', b.id);
    end if;
  elsif p_step = 'completed' then
    if b.status not in ('assigned', 'picked_up') then raise exception 'ALREADY_DECIDED'; end if;
    select c.code into code from booking_codes c where c.booking_id = b.id;
    if code is not null and coalesce(trim(p_code), '') <> code then raise exception 'WRONG_CODE'; end if;
    final := b.price;
    final_km := b.km;
    if b.kind = 'hire' and coalesce(p_km, 0) > 0 then
      -- the odometer figure may not be wildly more than what was booked; the office can settle a bigger detour
      if p_km > coalesce(b.km, 0) * 1.5 + 10 then raise exception 'KM_TOO_HIGH'; end if;
      -- a whole-day hire is always charged at least 100 km, as it was when booked
      final_km := case when b.trip_type = 'whole_day' then greatest(p_km, 100) else p_km end;
      final := greatest((select hire_min from vehicle_categories where id = b.category_id),
                        ceil(final_km * coalesce(b.rate_per_km, 0) / 500) * 500);
    end if;
    update bookings set status = 'completed', completed_at = now(), final_price = final,
      km = case when b.kind = 'hire' and coalesce(p_km, 0) > 0 then final_km else km end,
      trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind = 'hire' then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Hire #' || b.booking_no || ' · ' || who, 1, final);
    end if;
    perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' done',
      case when b.kind = 'goods' then 'Delivered to ' || coalesce(b.receiver_name, 'the receiver') || '.'
           else 'Thank you for travelling with EfuLogistix. Total K' || to_char(final, 'FM999,999,990') || '.' end, 'booking', b.id);
  else
    raise exception 'bad step';
  end if;
end;
$$;

-- =================== v24 ===================
-- EfuLogistix: database update v24  (run AFTER schema_v23.sql)
--   A hire can be started by the driver with one tap (no ticket needed), so phone-in customers work too.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.booking_step(p_id uuid, p_step text, p_code text, p_km numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b bookings%rowtype; tr trips%rowtype; final numeric; final_km numeric; who text; code text;
begin
  select * into b from bookings where id = p_id and driver_id = auth.uid() for update;
  if b.id is null then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into tr from trips where driver_id = auth.uid() and status = 'in_progress';
  who := coalesce((select full_name from profiles where id = b.passenger_id), b.caller_name, 'Passenger');
  if p_step = 'picked_up' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    -- seat passengers are only marked on board by the ticket code; a hire has one customer with the car, so the driver just starts it
    if b.kind not in ('goods', 'hire') and coalesce(current_setting('efu.boarding', true), '') <> '1' then raise exception 'CODE_REQUIRED'; end if;
    update bookings set status = 'picked_up', picked_up_at = now(), trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind in ('seat', 'goods') then
      insert into trip_stops (trip_id, place_name, dropped, picked, fare_each, goods_on, goods_total)
      values (tr.id, 'Booking #' || b.booking_no || ' · ' || who,
              0, b.seats, case when b.seats > 0 then b.price / b.seats else 0 end,
              case when b.kind = 'goods' then b.goods else '[]'::jsonb end,
              case when b.kind = 'goods' then b.price else 0 end);
    end if;
  elsif p_step = 'no_show' then
    if b.status <> 'assigned' then raise exception 'ALREADY_DECIDED'; end if;
    update bookings set status = 'no_show', completed_at = now() where id = p_id;
    if b.passenger_id is not null then
      perform system_on();
      update profiles set no_shows = no_shows + 1 where id = b.passenger_id;
      perform notify(b.passenger_id, 'Missed booking #' || b.booking_no, 'The car waited but you were not there. Missed bookings are counted on your profile.', 'booking', b.id);
    end if;
  elsif p_step = 'completed' then
    if b.status not in ('assigned', 'picked_up') then raise exception 'ALREADY_DECIDED'; end if;
    select c.code into code from booking_codes c where c.booking_id = b.id;
    if code is not null and coalesce(trim(p_code), '') <> code then raise exception 'WRONG_CODE'; end if;
    final := b.price;
    final_km := b.km;
    if b.kind = 'hire' and coalesce(p_km, 0) > 0 then
      -- the odometer figure may not be wildly more than what was booked; the office can settle a bigger detour
      if p_km > coalesce(b.km, 0) * 1.5 + 10 then raise exception 'KM_TOO_HIGH'; end if;
      -- a whole-day hire is always charged at least 100 km, as it was when booked
      final_km := case when b.trip_type = 'whole_day' then greatest(p_km, 100) else p_km end;
      final := greatest((select hire_min from vehicle_categories where id = b.category_id),
                        ceil(final_km * coalesce(b.rate_per_km, 0) / 500) * 500);
    end if;
    update bookings set status = 'completed', completed_at = now(), final_price = final,
      km = case when b.kind = 'hire' and coalesce(p_km, 0) > 0 then final_km else km end,
      trip_id = coalesce(tr.id, trip_id) where id = p_id;
    if tr.id is not null and b.pay_method = 'cash' and b.kind = 'hire' then
      insert into trip_stops (trip_id, place_name, picked, fare_each)
      values (tr.id, 'Hire #' || b.booking_no || ' · ' || who, 1, final);
    end if;
    perform notify(b.passenger_id, 'Booking #' || b.booking_no || ' done',
      case when b.kind = 'goods' then 'Delivered to ' || coalesce(b.receiver_name, 'the receiver') || '.'
           else 'Thank you for travelling with EfuLogistix. Total K' || to_char(final, 'FM999,999,990') || '.' end, 'booking', b.id);
  else
    raise exception 'bad step';
  end if;
end;
$$;

-- =================== v25 ===================
-- EfuLogistix: database update v25  (run AFTER schema_v24.sql)
--   The admin can invite someone as any role: Admin, Manager, Vehicle owner, Driver or Passenger.
--   (Before, an invite could only be Manager, Owner or Driver.)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

alter table public.invites drop constraint if exists invites_role_check;
alter table public.invites add constraint invites_role_check
  check (role in ('admin', 'manager', 'owner', 'driver', 'passenger'));

-- =================== v26 ===================
-- EfuLogistix: database update v26  (run AFTER schema_v25.sql)
--   A vehicle owner can mark the alerts of their own vehicles as done (before, only the office could).
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.resolve_alert(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare a alerts%rowtype;
begin
  select * into a from alerts where id = p_id;
  if a.id is null then return; end if;
  if not (is_owner() or owns_truck(a.truck_id)) then raise exception 'not allowed' using errcode = '42501'; end if;
  if a.kind = 'truck_change' then raise exception 'REVIEW_FIRST'; end if;   -- a truck change is approved or declined, not just closed
  update alerts set resolved = true, seen = true where id = p_id;
end $$;
revoke all on function public.resolve_alert(uuid) from public, anon;
grant execute on function public.resolve_alert(uuid) to authenticated;

-- =================== v27 ===================
-- EfuLogistix: database update v27  (run AFTER schema_v26.sql)
--   In-app chat (text, photos and voice notes):
--     * passenger <-> driver, for a booking while the car is assigned, on the way, and 6 hours after it is done
--     * vehicle owner <-> driver of that owner's vehicle
--   Messages are only for the two people (and the admin, for disputes). Phone numbers stay private.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings (id) on delete cascade,
  owner_id uuid references public.profiles (id) on delete cascade,
  driver_id uuid references public.profiles (id) on delete cascade,
  sender_id uuid not null references public.profiles (id) on delete cascade,
  recipient_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null default 'text' check (kind in ('text', 'photo', 'voice')),
  body text not null default '' check (length(body) <= 1000),
  file_path text,
  seconds int,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check ((kind = 'text' and length(btrim(body)) >= 1) or (kind <> 'text' and file_path is not null)),
  check ((booking_id is not null) <> (owner_id is not null and driver_id is not null))
);
create index if not exists chat_booking_idx on public.chat_messages (booking_id, created_at);
create index if not exists chat_fleet_idx on public.chat_messages (owner_id, driver_id, created_at);
create index if not exists chat_recipient_idx on public.chat_messages (recipient_id, read_at);

alter table public.chat_messages enable row level security;
drop policy if exists chat_read on public.chat_messages;
create policy chat_read on public.chat_messages for select to authenticated
  using (sender_id = auth.uid() or recipient_id = auth.uid() or is_admin());
revoke insert, update, delete on public.chat_messages from authenticated, anon;
grant select on public.chat_messages to authenticated;

-- Send a message. For a booking pass p_booking; for owner <-> driver pass the other person in p_peer.
drop function if exists public.send_chat(uuid, uuid, text);
create or replace function public.send_chat(p_booking uuid, p_peer uuid, p_body text,
  p_kind text default 'text', p_path text default null, p_seconds int default null)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); b bookings%rowtype; body text := btrim(coalesce(p_body, ''));
        rcpt uuid; own uuid; drv uuid; myrole text; peerrole text; who text;
begin
  if me is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_kind not in ('text', 'photo', 'voice') then raise exception 'BAD_MESSAGE'; end if;
  if p_kind = 'text' and (length(body) < 1 or length(body) > 1000) then raise exception 'BAD_MESSAGE'; end if;
  if p_kind <> 'text' and (p_path is null or split_part(p_path, '/', 1) <> me::text) then raise exception 'BAD_MESSAGE'; end if;
  if (select count(*) from chat_messages where sender_id = me and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'SLOW_DOWN';
  end if;
  who := coalesce((select full_name from profiles where id = me), 'Someone');
  if p_booking is not null then
    select * into b from bookings where id = p_booking;
    if b.id is null or me not in (coalesce(b.passenger_id, me), coalesce(b.driver_id, me)) then raise exception 'not allowed' using errcode = '42501'; end if;
    if me <> coalesce(b.passenger_id, '00000000-0000-0000-0000-000000000000') and me <> coalesce(b.driver_id, '00000000-0000-0000-0000-000000000000') then
      raise exception 'not allowed' using errcode = '42501';
    end if;
    if not (b.status in ('assigned', 'picked_up') or (b.status = 'completed' and b.completed_at > now() - interval '6 hours')) then
      raise exception 'CHAT_CLOSED';
    end if;
    rcpt := case when me = b.passenger_id then b.driver_id else b.passenger_id end;
    if rcpt is null then raise exception 'NO_PARTY'; end if;
    insert into chat_messages (booking_id, sender_id, recipient_id, kind, body, file_path, seconds) values (b.id, me, rcpt, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(rcpt, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', b.id);
  else
    select role into myrole from profiles where id = me;
    select role into peerrole from profiles where id = p_peer;
    if myrole = 'owner' and peerrole = 'driver'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = p_peer and t.owner_id = me) then
      own := me; drv := p_peer;
    elsif myrole = 'driver' and peerrole = 'owner'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = me and t.owner_id = p_peer) then
      own := p_peer; drv := me;
    else
      raise exception 'not allowed' using errcode = '42501';
    end if;
    insert into chat_messages (owner_id, driver_id, sender_id, recipient_id, kind, body, file_path, seconds) values (own, drv, me, p_peer, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(p_peer, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', null);
  end if;
end $$;
revoke all on function public.send_chat(uuid, uuid, text, text, text, int) from public, anon;
grant execute on function public.send_chat(uuid, uuid, text, text, text, int) to authenticated;

-- Mark what I have read in this conversation.
create or replace function public.read_chat(p_booking uuid, p_peer uuid)
returns void language sql security definer set search_path = public as $$
  update chat_messages set read_at = now()
   where recipient_id = auth.uid() and read_at is null
     and ((p_booking is not null and booking_id = p_booking)
       or (p_booking is null and booking_id is null and sender_id = p_peer));
$$;
revoke all on function public.read_chat(uuid, uuid) from public, anon;
grant execute on function public.read_chat(uuid, uuid) to authenticated;

-- Private storage for chat pictures and voice notes: only the two people (and the admin) can open a file.
do $$ begin
  insert into storage.buckets (id, name, public) values ('chat', 'chat', false) on conflict (id) do nothing;
  begin update storage.buckets set file_size_limit = 10485760 where id = 'chat'; exception when others then null; end;
end $$;
drop policy if exists chat_files_insert on storage.objects;
create policy chat_files_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'chat' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists chat_files_read on storage.objects;
create policy chat_files_read on storage.objects for select to authenticated
  using (bucket_id = 'chat' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()
         or exists (select 1 from public.chat_messages m where m.file_path = name and m.recipient_id = auth.uid())));

-- live messages
do $$ begin
  begin alter publication supabase_realtime add table public.chat_messages;
  exception when duplicate_object then null; when undefined_object then null; end;
end $$;

-- =================== v28 ===================
-- EfuLogistix: database update v28  (run AFTER schema_v27.sql)
--   A chat notice can open its chat: owner <-> driver notices now carry the sender, booking chats already carry the booking.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.send_chat(p_booking uuid, p_peer uuid, p_body text,
  p_kind text default 'text', p_path text default null, p_seconds int default null)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); b bookings%rowtype; body text := btrim(coalesce(p_body, ''));
        rcpt uuid; own uuid; drv uuid; myrole text; peerrole text; who text;
begin
  if me is null then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_kind not in ('text', 'photo', 'voice') then raise exception 'BAD_MESSAGE'; end if;
  if p_kind = 'text' and (length(body) < 1 or length(body) > 1000) then raise exception 'BAD_MESSAGE'; end if;
  if p_kind <> 'text' and (p_path is null or split_part(p_path, '/', 1) <> me::text) then raise exception 'BAD_MESSAGE'; end if;
  if (select count(*) from chat_messages where sender_id = me and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'SLOW_DOWN';
  end if;
  who := coalesce((select full_name from profiles where id = me), 'Someone');
  if p_booking is not null then
    select * into b from bookings where id = p_booking;
    if b.id is null or me not in (coalesce(b.passenger_id, me), coalesce(b.driver_id, me)) then raise exception 'not allowed' using errcode = '42501'; end if;
    if me <> coalesce(b.passenger_id, '00000000-0000-0000-0000-000000000000') and me <> coalesce(b.driver_id, '00000000-0000-0000-0000-000000000000') then
      raise exception 'not allowed' using errcode = '42501';
    end if;
    if not (b.status in ('assigned', 'picked_up') or (b.status = 'completed' and b.completed_at > now() - interval '6 hours')) then
      raise exception 'CHAT_CLOSED';
    end if;
    rcpt := case when me = b.passenger_id then b.driver_id else b.passenger_id end;
    if rcpt is null then raise exception 'NO_PARTY'; end if;
    insert into chat_messages (booking_id, sender_id, recipient_id, kind, body, file_path, seconds) values (b.id, me, rcpt, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(rcpt, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat', b.id);
  else
    select role into myrole from profiles where id = me;
    select role into peerrole from profiles where id = p_peer;
    if myrole = 'owner' and peerrole = 'driver'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = p_peer and t.owner_id = me) then
      own := me; drv := p_peer;
    elsif myrole = 'driver' and peerrole = 'owner'
       and exists (select 1 from profiles d join trucks t on t.id = d.truck_id where d.id = me and t.owner_id = p_peer) then
      own := p_peer; drv := me;
    else
      raise exception 'not allowed' using errcode = '42501';
    end if;
    insert into chat_messages (owner_id, driver_id, sender_id, recipient_id, kind, body, file_path, seconds) values (own, drv, me, p_peer, p_kind, case when p_kind = 'text' then body else '' end, p_path, p_seconds);
    perform notify(p_peer, 'Message from ' || who, case p_kind when 'photo' then '📷 Photo' when 'voice' then '🎤 Voice note' else left(body, 120) end, 'chat_peer', me);   -- ref = who wrote, so the notice can open the chat
  end if;
end $$;
revoke all on function public.send_chat(uuid, uuid, text, text, text, int) from public, anon;
grant execute on function public.send_chat(uuid, uuid, text, text, text, int) to authenticated;

-- =================== v29 ===================
-- EfuLogistix: database update v29  (run AFTER schema_v28.sql)
--   Marking a service or papers alert "done" now snoozes it for 7 days. Before, the check raised it again the next day.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

create or replace function public.run_checks()
returns void language plpgsql security definer set search_path = public as $$
declare st app_settings%rowtype;
begin
  if not is_owner() then return; end if;
  select * into st from app_settings where id = 1;

  insert into alerts (kind, truck_id, driver_id, ref_id, title, detail)
  select 'no_signal', l.truck_id, l.driver_id, l.truck_id, 'No signal · ' || t.plate,
         'No update for ' || round(extract(epoch from now() - l.updated_at) / 60) || ' min. Trips are saved on the phone and upload later.'
  from truck_locations l join trucks t on t.id = l.truck_id
  join shifts s on s.truck_id = l.truck_id and s.status = 'on_duty'
  where l.updated_at < now() - make_interval(mins => st.no_signal_min)
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'service_due', t.id, t.id, 'Oil change · ' || t.plate,
         case when t.current_km >= t.last_oil_km + t.oil_interval_km
              then (t.current_km - t.last_oil_km - t.oil_interval_km) || ' km overdue'
              else 'Due in ' || (t.last_oil_km + t.oil_interval_km - t.current_km) || ' km' end
  from trucks t
  where t.active and t.current_km is not null and t.last_oil_km is not null
    and t.current_km >= t.last_oil_km + t.oil_interval_km - 500
    and not exists (select 1 from alerts a where a.kind = 'service_due' and a.ref_id = t.id
                    and a.resolved and a.created_at > now() - interval '7 days')
  on conflict do nothing;

  insert into alerts (kind, truck_id, ref_id, title, detail)
  select 'paper_expiry', t.id, t.id, 'Papers · ' || t.plate,
         concat_ws(' · ',
           case when t.insurance_to <= current_date + 14 then 'insurance ends ' || to_char(t.insurance_to, 'DD Mon YYYY') end,
           case when t.cof_to <= current_date + 14 then 'COF ends ' || to_char(t.cof_to, 'DD Mon YYYY') end)
  from trucks t
  where t.active and (t.insurance_to <= current_date + 14 or t.cof_to <= current_date + 14)
    and not exists (select 1 from alerts a where a.kind = 'paper_expiry' and a.ref_id = t.id
                    and a.resolved and a.created_at > now() - interval '7 days')
  on conflict do nothing;

  insert into alerts (kind, driver_id, ref_id, title, detail)
  select 'document_expiry', d.driver_id, d.id, 'Licence/permit · ' || coalesce(p.full_name, p.email),
         replace(d.kind, '_', ' ') || ' ends ' || to_char(d.expires_on, 'DD Mon YYYY')
  from documents d join profiles p on p.id = d.driver_id
  where d.driver_id is not null and d.status = 'approved' and d.expires_on <= current_date + 30 and p.active
  on conflict do nothing;
end;
$$;

-- =================== v31 ===================
-- EfuLogistix: database update v31  (run AFTER schema_v18.sql)
--   Passengers who drop a named pin on the map send it to the office as a place suggestion.
--   The admin still approves each one before it joins the Places list everyone sees.
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice.

-- no more than 10 waiting suggestions per person, and not the same name twice
create or replace function public.place_sug_limit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from place_suggestions where suggested_by = new.suggested_by and status = 'pending') >= 10 then
    raise exception 'TOO_MANY_SUGGESTIONS';
  end if;
  if exists (select 1 from place_suggestions where suggested_by = new.suggested_by and status = 'pending'
             and lower(trim(name)) = lower(trim(new.name))) then
    raise exception 'ALREADY_SUGGESTED';
  end if;
  return new;
end $$;
drop trigger if exists place_sug_limit_t on public.place_suggestions;
create trigger place_sug_limit_t before insert on public.place_suggestions
  for each row execute function public.place_sug_limit();

drop policy if exists place_sug_insert on public.place_suggestions;
create policy place_sug_insert on public.place_suggestions for insert to authenticated
  with check (suggested_by = auth.uid() and status = 'pending');
