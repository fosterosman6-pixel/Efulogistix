-- EfuLogistix: database update v4  (run AFTER schema.sql, schema_v2.sql, schema_v3.sql)
-- Supabase > SQL Editor > New query > paste all > Run.  Safe to run twice: it only adds.
--
-- v4 adds
--   * support: anyone can report a problem (with a photo), follow it, and chat with the office
--   * SOS and breakdown buttons for drivers (the owner and admin are told straight away)
--   * fuel economy: litres, cost and km per litre for each vehicle
--   * owner statement: income, expenses, fee and profit for each vehicle over any dates
--   * trips: passenger count can be changed with quick +1 / -1 taps (no schema change needed)

-- ====================================================================================
-- SUPPORT
-- ====================================================================================
create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_no bigint generated always as identity,
  user_id uuid not null references public.profiles (id) on delete cascade default auth.uid(),
  reason text not null check (reason in ('driver_late', 'overcharged', 'lost_goods', 'safety', 'payment',
                                         'vehicle', 'app_problem', 'other')),
  subject text,
  body text,
  trip_id uuid references public.trips (id) on delete set null,
  booking_id uuid references public.bookings (id) on delete set null,
  truck_id uuid references public.trucks (id) on delete set null,
  photo_path text,
  priority text not null default 'normal' check (priority in ('normal', 'urgent')),
  status text not null default 'open' check (status in ('open', 'in_progress', 'solved')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  solved_at timestamptz,
  solved_by uuid references public.profiles (id)
);
create index if not exists support_tickets_user_idx on public.support_tickets (user_id, created_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets (status, created_at desc);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets (id) on delete cascade,
  sender_id uuid not null references public.profiles (id) default auth.uid(),
  from_staff boolean not null default false,
  body text not null check (length(btrim(body)) > 0),
  created_at timestamptz not null default now()
);
create index if not exists support_messages_ticket_idx on public.support_messages (ticket_id, created_at);

-- A person reports a problem. Safety reports are urgent and reach the admin immediately.
create or replace function public.report_problem(p_reason text, p_body text, p_trip uuid default null,
  p_booking uuid default null, p_photo text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare tid uuid; trk uuid; adm record; who text;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_reason is null or p_reason not in ('driver_late','overcharged','lost_goods','safety','payment','vehicle','app_problem','other') then
    raise exception 'BAD_REASON';
  end if;
  if p_trip is not null then
    select truck_id into trk from trips where id = p_trip and (driver_id = auth.uid() or public.is_owner() or public.owns_truck(truck_id));
  end if;
  if p_booking is not null and trk is null then
    select truck_id into trk from bookings where id = p_booking and (passenger_id = auth.uid() or driver_id = auth.uid());
  end if;
  insert into support_tickets (user_id, reason, subject, body, trip_id, booking_id, truck_id, photo_path, priority)
  values (auth.uid(), p_reason, left(coalesce(nullif(btrim(p_body), ''), p_reason), 80), nullif(btrim(p_body), ''),
          p_trip, p_booking, trk, p_photo, case when p_reason = 'safety' then 'urgent' else 'normal' end)
  returning id into tid;
  select coalesce(nullif(full_name, ''), email, 'Someone') into who from profiles where id = auth.uid();
  for adm in select id from profiles where role in ('admin', 'manager') and active loop
    perform public.notify(adm.id, case when p_reason = 'safety' then 'URGENT safety report' else 'New support ticket' end,
                          who || ': ' || coalesce(nullif(btrim(p_body), ''), p_reason), 'support', tid);
  end loop;
  return tid;
end $$;

-- Add a message to a ticket. The ticket owner and the office can write; staff replies notify the person.
create or replace function public.ticket_reply(p_ticket uuid, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare t support_tickets%rowtype; staff boolean := public.is_manager(); adm record;
begin
  select * into t from support_tickets where id = p_ticket;
  if t.id is null or (t.user_id <> auth.uid() and not staff) then raise exception 'TICKET_NOT_FOUND'; end if;
  if p_body is null or length(btrim(p_body)) = 0 then raise exception 'EMPTY'; end if;
  insert into support_messages (ticket_id, sender_id, from_staff, body) values (p_ticket, auth.uid(), staff, btrim(p_body));
  update support_tickets set updated_at = now(),
    status = case when staff and status = 'open' then 'in_progress'
                  when not staff and status = 'solved' then 'open' else status end,
    solved_at = case when not staff and status = 'solved' then null else solved_at end
   where id = p_ticket;
  if staff then
    perform public.notify(t.user_id, 'Reply to your report #' || t.ticket_no, left(btrim(p_body), 140), 'support', t.id);
  else
    for adm in select id from profiles where role in ('admin', 'manager') and active loop
      perform public.notify(adm.id, 'New message on ticket #' || t.ticket_no, left(btrim(p_body), 140), 'support', t.id);
    end loop;
  end if;
end $$;

-- Office: change status (solved tells the person)
create or replace function public.ticket_set_status(p_ticket uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare t support_tickets%rowtype;
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  if p_status not in ('open', 'in_progress', 'solved') then raise exception 'BAD_STATUS'; end if;
  select * into t from support_tickets where id = p_ticket;
  if t.id is null then raise exception 'TICKET_NOT_FOUND'; end if;
  update support_tickets set status = p_status, updated_at = now(),
    solved_at = case when p_status = 'solved' then now() else null end,
    solved_by = case when p_status = 'solved' then auth.uid() else null end
   where id = p_ticket;
  if p_status = 'solved' and t.status <> 'solved' then
    perform public.notify(t.user_id, 'Report #' || t.ticket_no || ' solved', 'The office marked it solved. Reply on the report if it is not.', 'support', t.id);
  end if;
end $$;

-- ====================================================================================
-- SOS AND BREAKDOWN
-- ====================================================================================
create table if not exists public.incidents (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('sos', 'breakdown')),
  user_id uuid not null references public.profiles (id) on delete cascade default auth.uid(),
  truck_id uuid references public.trucks (id) on delete set null,
  trip_id uuid references public.trips (id) on delete set null,
  lat double precision,
  lng double precision,
  note text,
  status text not null default 'open' check (status in ('open', 'handled')),
  handled_by uuid references public.profiles (id),
  handled_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists incidents_open_idx on public.incidents (status, created_at desc);

create or replace function public.raise_incident(p_kind text, p_lat double precision default null,
  p_lng double precision default null, p_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare iid uuid; trk uuid; trp uuid; own uuid; who text; plate text; r record;
begin
  if auth.uid() is null then raise exception 'NOT_SIGNED_IN'; end if;
  if p_kind not in ('sos', 'breakdown') then raise exception 'BAD_KIND'; end if;
  select id, truck_id into trp, trk from trips where driver_id = auth.uid() and status = 'in_progress'
    order by started_at desc limit 1;
  if trk is null then select truck_id into trk from profiles where id = auth.uid(); end if;
  insert into incidents (kind, user_id, truck_id, trip_id, lat, lng, note)
  values (p_kind, auth.uid(), trk, trp, p_lat, p_lng, nullif(btrim(p_note), '')) returning id into iid;
  select coalesce(nullif(full_name, ''), email, 'A driver') into who from profiles where id = auth.uid();
  select t.plate, t.owner_id into plate, own from trucks t where t.id = trk;
  for r in select id from profiles where (role in ('admin', 'manager') and active) or id = own loop
    perform public.notify(r.id, case when p_kind = 'sos' then 'SOS: ' || who else 'Breakdown: ' || coalesce(plate, 'vehicle') end,
                          coalesce(nullif(btrim(p_note), ''), who || ' needs help.')
                          || case when p_lat is not null then ' Location: ' || round(p_lat::numeric, 5) || ', ' || round(p_lng::numeric, 5) else '' end,
                          p_kind, iid);
  end loop;
  return iid;
end $$;

create or replace function public.handle_incident(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  update incidents set status = 'handled', handled_by = auth.uid(), handled_at = now() where id = p_id;
end $$;

-- ====================================================================================
-- FUEL ECONOMY: litres, cost, km driven and km per litre for one vehicle
-- ====================================================================================
create or replace function public.fuel_economy(p_truck uuid, p_from date, p_to date)
returns table (litres numeric, fuel_cost numeric, km numeric, km_per_litre numeric, cost_per_km numeric)
language plpgsql stable security definer set search_path = public as $$
declare l numeric; c numeric; k numeric;
begin
  if not (public.is_manager() or public.owns_truck(p_truck)) then raise exception 'NOT_ALLOWED'; end if;
  select coalesce(sum(e.litres), 0), coalesce(sum(e.amount), 0) into l, c from expenses e
   where e.truck_id = p_truck and e.category = 'fuel' and e.spent_at::date between p_from and p_to;
  select coalesce(sum(coalesce(s.end_km - s.start_km, 0)), 0) into k from shifts s
   where s.truck_id = p_truck and s.status = 'off_duty' and s.end_km is not null and s.started_at::date between p_from and p_to;
  return query select l, c, k, case when l > 0 then round(k / l, 2) end, case when k > 0 then round(c / k, 0) end;
end $$;

-- ====================================================================================
-- OWNER STATEMENT: money in and out for every vehicle the signed-in owner has (admin: pass p_owner)
-- ====================================================================================
create or replace function public.owner_statement(p_from date, p_to date, p_owner uuid default null)
returns table (truck_id uuid, plate text, trips bigint, passengers bigint, collected numeric,
               driver_costs numeric, other_costs numeric, fees numeric, profit numeric)
language plpgsql stable security definer set search_path = public as $$
declare o uuid;
begin
  if public.is_manager() then o := p_owner; else o := auth.uid(); end if;
  if o is null and not public.is_manager() then raise exception 'NOT_ALLOWED'; end if;
  return query
  select z.truck_id, z.plate, z.n_trips, z.n_pax, z.money, z.drv, z.oth, z.fee,
         z.money - z.drv - z.oth - z.fee
  from (
    select t.id as truck_id, t.plate,
      (select count(*) from trips x where x.truck_id = t.id and x.status = 'completed'
         and x.started_at::date between p_from and p_to) as n_trips,
      (select coalesce(sum(coalesce(x.pax_carried, x.passengers)), 0)::bigint from trips x where x.truck_id = t.id
         and x.status = 'completed' and x.started_at::date between p_from and p_to) as n_pax,
      (select coalesce(sum(h.collected), 0) from hand_ins h where h.truck_id = t.id and h.day between p_from and p_to) as money,
      (select coalesce(sum(h.driver_expenses), 0) from hand_ins h where h.truck_id = t.id and h.day between p_from and p_to) as drv,
      (select coalesce(sum(e.amount), 0) from expenses e where e.truck_id = t.id and e.spent_at::date between p_from and p_to
         and coalesce(e.paid_by, 'owner') <> 'driver') as oth,
      (select coalesce(sum(f.amount), 0) from fee_bills f where f.truck_id = t.id and f.status <> 'waived'
         and f.period_start <= p_to and f.period_end >= p_from) as fee
    from trucks t
    where (o is null or t.owner_id = o)
  ) z
  order by z.plate;
end $$;

-- ====================================================================================
-- SECURITY (row rules) and access
-- ====================================================================================
alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.incidents enable row level security;

drop policy if exists tickets_read on public.support_tickets;
create policy tickets_read on public.support_tickets for select to authenticated
  using (user_id = auth.uid() or public.is_manager());
drop policy if exists tickets_msg_read on public.support_messages;
create policy tickets_msg_read on public.support_messages for select to authenticated
  using (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = auth.uid() or public.is_manager())));
drop policy if exists incidents_read on public.incidents;
create policy incidents_read on public.incidents for select to authenticated
  using (user_id = auth.uid() or public.is_manager() or public.owns_truck(truck_id));
-- writes only through the functions above

revoke insert, update, delete on public.support_tickets, public.support_messages, public.incidents from authenticated;
grant select on public.support_tickets, public.support_messages, public.incidents to authenticated;
grant all on public.support_tickets, public.support_messages, public.incidents to service_role;
grant execute on function public.report_problem(text, text, uuid, uuid, text) to authenticated;
grant execute on function public.ticket_reply(uuid, text) to authenticated;
grant execute on function public.ticket_set_status(uuid, text) to authenticated;
grant execute on function public.raise_incident(text, double precision, double precision, text) to authenticated;
grant execute on function public.handle_incident(uuid) to authenticated;
grant execute on function public.fuel_economy(uuid, date, date) to authenticated;
grant execute on function public.owner_statement(date, date, uuid) to authenticated;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- live updates for the inbox
do $$ declare t text; begin
  foreach t in array array['support_tickets', 'support_messages', 'incidents'] loop
    begin execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null; when undefined_object then null; end;
  end loop;
end $$;
