# EfuLogistix

Ride booking, fleet and vehicle-owner platform for Mangochi, Malawi.

| Folder | What |
| --- | --- |
| `phone/` | Phone app (Flutter): passengers, drivers, vehicle owners. See `phone/README.md` |
| `admin/` | Admin panel (Flutter web and Windows): admin and managers. See `admin/README.md` |
| `supabase/` | Database: run `schema.sql`, then `schema_v2.sql`, then `schema_v3.sql` in the Supabase SQL Editor |

## Built by GitHub

Every push to `main` builds, in the **Actions** tab:

- **efulogistix-phone-apk**: Android APKs (install `app-arm64-v8a-release.apk` on most phones)
- **efulogistix-admin-windows**: the admin panel for Windows (unzip, run `efulogistix_admin.exe`)
- **efulogistix-admin-web**: the admin panel website, also published to GitHub Pages
  (once: *Settings → Pages → Source: GitHub Actions*)

Open a run → scroll to **Artifacts** → download.

## Build on your own computer

```bash
cd phone
flutter create --org mw.efulogistix --project-name efulogistix_fleet --platforms android .
flutter pub get
dart run tool/add_permissions.dart
flutter run

cd ../admin
flutter create --org mw.efulogistix --project-name efulogistix_admin --platforms web,windows .
flutter pub get
flutter run -d windows
```

The Supabase URL and publishable key are in `lib/config.dart`. Never commit the secret / service_role key.
