# Sign in with a phone number (SMS code) – one-time setup

Result: people type their mobile number, get a 6-digit code by SMS, and are in. Email and password still work.
Codes go out through the same Plivo account as the parcel texts (see SMS_SETUP.md), so there is no new company to pay.

1. Plivo must already work for Malawi (SMS_SETUP.md steps 1-2, and the secrets PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN, PLIVO_SENDER).
2. SQL Editor: run `schema_v38_phone_login.sql` (after v37).
3. Supabase → Edge Functions → create `auth-sms-hook`, paste `supabase/functions/auth-sms-hook/index.ts`, turn OFF "Verify JWT" (or `supabase functions deploy auth-sms-hook --no-verify-jwt`).
4. Supabase → Authentication → Sign In / Providers → **Phone**: switch it ON. Leave "Enable phone confirmations" ON.
   Do not pick Twilio/MessageBird/Vonage here: the hook below sends the code instead.
5. Supabase → Authentication → Hooks → **Send SMS hook** → type "HTTPS" → URL
   `https://YOUR-PROJECT.supabase.co/functions/v1/auth-sms-hook` → generate a secret → copy it whole (starts with `v1,whsec_`).
6. Edge Functions → Secrets → add `SEND_SMS_HOOK_SECRET` = that secret.
7. Authentication → Rate limits: SMS per hour — keep it low (for example 30) so nobody can run up your Plivo bill.
8. Test with your own number in the app: Send me a code → the text arrives → type it.

Each code costs a Plivo SMS. Drivers and vehicle owners who create an account by phone wait for approval, like email sign-up.

## Number + password (added)
People now sign in with **mobile number + password**. When they create an account, an SMS code confirms the number once; after that the password is enough.
- In Authentication > Providers > Phone, keep **Enable phone confirmations** switched ON.
- "Forgot password? Send me a code" signs in with an SMS code. Then My profile > "Set or change my password" saves a new one.
