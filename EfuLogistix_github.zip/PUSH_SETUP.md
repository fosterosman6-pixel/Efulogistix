# Push notifications – one-time setup (about 20 minutes)

Result: messages (seat freed, booking, SOS, support replies, etc.) arrive on the phone even when the app is closed.

## 1. Firebase (free)
1. https://console.firebase.google.com → Add project → "EfuLogistix".
2. Project overview → Add app → Android. Package name: the one in your build (`com.example.efulogistix_fleet` unless you changed it – check phone/android/app/build.gradle after the first build, `applicationId`). Register.
3. Download **google-services.json**. Put it in the repo at `phone/firebase/google-services.json`.
4. Project settings → Service accounts → Generate new private key → keep the JSON file safe (do NOT put it in the repo).

## 2. Supabase
1. SQL Editor: run `schema_v7.sql`.
2. Install the function (needs the Supabase CLI on a computer) :
   `supabase functions deploy send-push --no-verify-jwt`
   (or Dashboard → Edge Functions → Create → paste `supabase/functions/send-push/index.ts`, turn OFF "Verify JWT").
3. Edge Functions → Secrets: add
   - `PUSH_SECRET` = any long random text (16+ characters), e.g. `k39dj2LmQ8xv0Ppa71ZsY`
   - `FIREBASE_SERVICE_ACCOUNT` = the whole contents of the service-account JSON from step 1.4
4. SQL Editor, run once (replace the two values; the secret must equal PUSH_SECRET):
   `insert into push_config(id,url,secret) values (1,'https://YOUR-PROJECT.supabase.co/functions/v1/send-push','your PUSH_SECRET') on conflict (id) do update set url=excluded.url, secret=excluded.secret;`

## 3. Build
Commit/replace the repo files (including `phone/firebase/google-services.json`) and run the build. The log shows
"Firebase: push notifications switched on." Install the new APK, sign in, allow notifications.

## Test
In Supabase SQL Editor: `select notify('<a user id>','Test','Hello','test',null);` – that phone should buzz.

If no google-services.json is present the app still builds and works, just without push.

---
# Extra features in this update (schema_v8.sql)
Run `schema_v8.sql` in the Supabase SQL Editor (after v7).

**QR boarding tickets** – passenger: My bookings > "Boarding ticket" (QR + 8 digits). Driver: Booked pickups > "Scan passenger ticket" (or type the digits) marks the passenger on board.

**Reminders** – every morning 07:00 (Malawi) owners and drivers get a message + push when insurance / certificate of fitness / licence / other papers are 30, 14, 7 days from expiring and on the day they expire, and when an oil change is due. It needs the pg_cron add-on: Supabase > Database > Extensions > search "pg_cron" > enable, then run `schema_v8.sql` again. Test now: `select send_reminders();`

**Share my trip** – passenger taps "Share my trip" and sends the link by WhatsApp/SMS; family sees the car on a map without logging in. One-time setup for the map page:
1. Upload the `share` folder (`share/index.html`) to the root of the GitHub repo.
2. Repo > Settings > Pages > Source: "Deploy from a branch", branch main, folder / (root) > Save.
3. After a minute the page is at https://fosterosman6-pixel.github.io/Efulogistix/share/ (that is the address already saved in the database; if yours differs run: `update app_settings set share_base_url='https://YOUR-ADDRESS/share/' where id=1;`).

---
# Update v9 (schema_v9.sql) – run it after v8
- **Owner evening summary** – 18:30 every day each owner gets a message + push: trips, money taken, expenses, handed in, hand-ins that came in short, hand-ins waiting for confirmation, vehicles that did not work. Needs pg_cron (see v8 note). Test now: `select send_owner_digests();`  (or admin panel > Dashboard > "Send reminders now").
- **Parcel tracking** – a goods booking now has "Share parcel tracking": the sender sends the receiver a link to the same live map page (plus the collection code).
- **Driver "My week"** – card on the driver's main screen: today, this week, trips, rating and the vehicle's weekly target bar (the target set by the owner).
- **Offline passengers** – the timetable, the last bookings and opened QR tickets are saved on the phone and still show without signal.
- **Admin dashboard** – new "Late pickups" panel (car assigned, passenger not picked up 15+ minutes after the booked time) and a "Send reminders now" button. The live vehicle map was already on the dashboard.
- Not built (needs you): mobile money, SMS/WhatsApp for non-app users, ads and monthly passes, Chichewa for the new screens.

---
# Update v10 (schema_v10.sql) – run it after v9
- **Start of shift: 4 live photos of the vehicle** (front, back, left, right, camera only) are now required before a driver can go on duty. The owner (Shifts screen) and the office (admin > Shifts) see them. Switch the rule off with: `update app_settings set require_start_photos = false where id = 1;`
  Drivers must install the new app before they can start a shift (the old app does not send the photos).
- **Driver screens**: profile picture in the header (tap to change), a bottom menu (Home, Pickups, Wallet, Messages, Help) and Help & support on the waiting and documents screens.
- **Chichewa** now covers the passenger, driver and owner screens. Phrases for checking: CHICHEWA_REVIEW.txt.

---
# Update v11 (schema_v11.sql) – run it after v10
- Admin > Shifts & trips now has a panel "Still on duty from earlier days" for shifts a driver never ended, with Open and **Close shift** buttons. A closed shift is marked flagged and the driver is told.
- Every hour, a shift open for more than 16 hours sends a reminder to the driver and the owner (needs pg_cron).
- Why you saw nothing: the page lists shifts by the day they STARTED. A shift started on 26 Oct and never ended is listed under 26 Oct.
