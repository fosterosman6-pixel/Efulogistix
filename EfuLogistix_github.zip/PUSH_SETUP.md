# Push notifications – one-time setup (about 20 minutes)

Result: messages (seat freed, booking, SOS, support replies, etc.) arrive on the phone even when the app is closed.

## 1. Firebase (free)
1. https://console.firebase.google.com → Add project → "EfuLogistix".
2. Project overview → Add app → Android. Package name: the one in your build (`com.example.efulogistix_fleet` unless you changed it – check phone/android/app/build.gradle after the first build, `applicationId`). Register.
3. Download **google-services.json**. Put it in the repo at `phone/firebase/google-services.json`.
4. Project settings → Service accounts → Generate new private key → keep the JSON file safe (do NOT put it in the repo).

## 2. Supabase
1. SQL Editor: run `schema_v7.sql`.
2. Install the function (needs the Supabase CLI on a computer) :
   `supabase functions deploy send-push --no-verify-jwt`
   (or Dashboard → Edge Functions → Create → paste `supabase/functions/send-push/index.ts`, turn OFF "Verify JWT").
3. Edge Functions → Secrets: add
   - `PUSH_SECRET` = any long random text (16+ characters), e.g. `k39dj2LmQ8xv0Ppa71ZsY`
   - `FIREBASE_SERVICE_ACCOUNT` = the whole contents of the service-account JSON from step 1.4
4. SQL Editor, run once (replace the two values; the secret must equal PUSH_SECRET):
   `insert into push_config(id,url,secret) values (1,'https://YOUR-PROJECT.supabase.co/functions/v1/send-push','your PUSH_SECRET') on conflict (id) do update set url=excluded.url, secret=excluded.secret;`

## 3. Build
Commit/replace the repo files (including `phone/firebase/google-services.json`) and run the build. The log shows
"Firebase: push notifications switched on." Install the new APK, sign in, allow notifications.

## Test
In Supabase SQL Editor: `select notify('<a user id>','Test','Hello','test',null);` – that phone should buzz.

If no google-services.json is present the app still builds and works, just without push.
