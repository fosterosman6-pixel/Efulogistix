# EfuLogistix Admin panel (Flutter web and Windows) · version 3

The admin's web panel. Only accounts with the role **admin** can sign in. Managers, vehicle owners and drivers
use the phone app (`efulogistix_fleet_flutter`). Both use the **same Supabase database**.

## Who signs in

- **Admin**: every page.
- **Manager**: Dashboard, Bookings, Drivers & matching, Shifts & trips, Cash hand-ins, Route history,
  EfuLogistix fees, Service, Reports. (Managers no longer use the phone app.)

Run `supabase/schema_v3.sql` in Supabase first (after schema.sql and schema_v2.sql).

### New in version 3

| Page | What it does |
| --- | --- |
| Bookings | Assign passenger bookings to a vehicle and driver, decline, book for someone who phoned |
| Drivers & matching | Drivers waiting for a vehicle, vehicles without a driver, office meetings (Agreed / Not agreed) |
| Route history | A vehicle's day on the map with stops found from GPS, times, replay |
| EfuLogistix fees | Make weekly / monthly bills, confirm payments, pay wallets of company vehicles |
| Timetable & rates | Departure times, hire price per km, fees per category, company accounts |
| Vehicles | Approve vehicles and new papers sent by owners |

## Pages

| Page | What you do there |
| --- | --- |
| Dashboard | Money and trips today, vehicles on the map, what needs you, open alerts |
| Shifts & trips | Every shift by day, odometer photos against GPS, approve or flag, each trip with its stops on the map, approve truck changes |
| Cash hand-ins | Expected against received, receive, accept a shortfall or keep it as owed, CSV |
| People | Invite drivers, managers and vehicle owners by email; approve walk-ins; block; change role; give a driver a vehicle |
| Documents | Check driver documents (photo, number, licence class, expiry): approve or reject with a reason |
| Vehicles | Add and edit vehicles: plate, category, owner, seats, oil interval, on/off road, papers (insurance, COF, blue book) |
| Categories | Matola, Minibus, Lorry, Taxi, Kabaza and new ones: seats, passengers/goods, licence classes |
| Fares | Route fares per category, goods prices, copy fares to another category, raise all fares by a % |
| Service | Oil changes, repairs, tyres; what is due |
| Reports | Any date range: by vehicle, category, owner and driver; download CSV for Excel |
| Settings | Alert limits (speed, long stop, mileage difference, no signal), require PrDP |
| Activity log | Who changed what and when |

## Run it (Windows, VS Code)

First set up the database and make yourself admin (steps 1 and 2 in `efulogistix_fleet_flutter/README.md`).
Then open the `efulogistix_admin` folder in VS Code:

```bash
flutter create --org mw.efulogistix --project-name efulogistix_admin --platforms web .
del test\widget_test.dart
flutter pub get
flutter run -d chrome
```

The Supabase URL and publishable key are already in `lib/config.dart`.

## Put it online (free)

```bash
flutter build web --release
```

Upload the `build/web` folder to any static host, for example **Netlify Drop** (drag the folder onto
app.netlify.com/drop), **Cloudflare Pages** or **Firebase Hosting**. Only admin accounts can sign in,
and the database rules block everyone else from admin changes even if they find the link.

In Supabase → **Authentication → URL Configuration**, add your panel's web address so the
*Forgot password* email links back to it.
