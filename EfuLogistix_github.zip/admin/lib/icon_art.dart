import 'package:flutter/material.dart' hide Text;

/// Ready-made picture icons (assets/icons/<name>.png). Falls back to a plain icon if the picture is missing.
class IconArt extends StatelessWidget {
  final String name;
  final double size;
  final IconData fallback;
  const IconArt(this.name, {super.key, this.size = 28, this.fallback = Icons.circle});

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/icons/$name.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => Icon(fallback, size: size * 0.8),
      );
}
