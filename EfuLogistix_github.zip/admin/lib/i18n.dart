import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' as m;

/// Language of the admin panel: 'en' or 'ny' (Chichewa).
/// The Chichewa was written for this app; please have a Chichewa speaker check it before launch.
final language = ValueNotifier<String>('en');

/// A drop-in replacement for the normal Text widget: it shows the Chichewa words
/// when the language is Chichewa. Strings with numbers or names are matched by pattern.
class Text extends m.StatelessWidget {
  final String data;
  final m.TextStyle? style;
  final m.TextAlign? textAlign;
  final int? maxLines;
  final m.TextOverflow? overflow;
  final bool? softWrap;
  const Text(this.data, {super.key, this.style, this.textAlign, this.maxLines, this.overflow, this.softWrap});

  @override
  m.Widget build(m.BuildContext context) =>
      m.Text(tx(data), style: style, textAlign: textAlign, maxLines: maxLines, overflow: overflow, softWrap: softWrap);
}

/// English -> Chichewa (exact match, then numbers, then " · " pieces).
String tx(String english) {
  if (language.value != 'ny') return english;
  final exact = _words[english];
  if (exact != null) return exact;
  final r = _pieces(english);
  return r ?? english;
}

String? _pieces(String s) {
  final one = _numbered(s);
  if (one != null) return one;
  if (s.contains(' · ')) {
    var changed = false;
    final parts = s.split(' · ').map((p) {
      final t = _words[p] ?? _numbered(p);
      if (t != null) changed = true;
      return t ?? p;
    }).toList();
    if (changed) return parts.join(' · ');
  }
  return null;
}

String? _numbered(String s) {
  final nums = RegExp(r'\d+').allMatches(s).map((x) => x.group(0)!).toList();
  if (nums.isEmpty) return null;
  final template = s.replaceAll(RegExp(r'\d+'), '#');
  final t = _words[template];
  if (t == null) return null;
  var i = 0;
  return t.replaceAllMapped(RegExp('#'), (_) => i < nums.length ? nums[i++] : '#');
}

/// With %s filled in.
String txf(String english, [List<String> values = const []]) {
  var out = tx(english);
  for (final v in values) {
    out = out.replaceFirst('%s', v);
  }
  return out;
}

const Map<String, String> _words = {
  "Accept": "Landirani",
  "Active": "Zikugwira ntchito",
  "Activity log": "Mbiri ya zochitika",
  "Add": "Onjezani",
  "Add category": "Onjezani gulu",
  "Add paper": "Onjezani pepala",
  "Add route": "Onjezani njira",
  "Add service": "Onjezani kukonza",
  "Add vehicle": "Onjezani galimoto",
  "Admin panel": "Tsamba la woyang'anira",
  "Manager panel": "Tsamba la mtsogoleri",
  "Agreed": "Anagwirizana",
  "Alerts": "Machenjezo",
  "All": "Zonse",
  "All quiet.": "Zonse zili bwino.",
  "An admin can change everything, including fares and people.": "Woyang'anira angasinthe chilichonse, kuphatikiza mitengo ndi anthu.",
  "Any vehicle": "Galimoto iliyonse",
  "Approve": "Vomerezani",
  "Approve shift": "Vomerezani ntchito",
  "Approve the vehicle first (Vehicles page).": "Choyamba vomerezani galimoto (tsamba la Vehicles).",
  "Approved": "Yavomerezedwa",
  "Bill last month": "Lipirani mwezi wapitawu",
  "Bill last week": "Lipirani mlungu wapitawu",
  "Block": "Letsani",
  "Blue book": "Buku la galimoto",
  "Book": "Sungitsani",
  "Bookable": "Yosungitsidwa",
  "Booking for a caller": "Kusungitsa kwa woimbira foni",
  "Bookings": "Kusungitsa",
  "Cancel": "Siyani",
  "Carries goods": "Imanyamula katundu",
  "Carries passengers": "Imanyamula anthu",
  "Cash hand-ins": "Ndalama zoperekedwa",
  "Categories": "Magulu",
  "Check the details match the photo.": "Onani kuti zambiri zikufanana ndi chithunzi.",
  "Close": "Tsekani",
  "Close shift": "Tsekani ntchito",
  "Company (no separate owner)": "Kampani (palibe mwini wina)",
  "Company accounts (pay once a month)": "Maakaunti a makampani (amalipira kamodzi pa mwezi)",
  "Copy": "Koperani",
  "Copy fares to another category": "Koperani mitengo ku gulu lina",
  "Copy to category": "Koperani ku gulu",
  "Dashboard": "Chidule",
  "Date": "Tsiku",
  "Day": "Tsiku",
  "Day before": "Tsiku lapitalo",
  "Decline": "Kanani",
  "Decline with a reason": "Kanani ndi chifukwa",
  "Delete": "Chotsani",
  "Departures (book a seat · send goods)": "Zonyamuka (sungitsani mpando · tumizani katundu)",
  "Documents": "Zikalata",
  "Done / cancelled": "Zatha / zathetsedwa",
  "Download CSV": "Tsitsani CSV",
  "Driver": "Woyendetsa",
  "Driver documents": "Zikalata za oyendetsa",
  "Driver wallets for company vehicles": "Ma wallet a oyendetsa magalimoto a kampani",
  "Drivers & matching": "Oyendetsa ndi kuwapatsa magalimoto",
  "Drivers waiting for a vehicle": "Oyendetsa akudikira galimoto",
  "Due": "Nthawi yake",
  "Earlier meetings": "Misonkhano yakale",
  "Edit": "Sinthani",
  "EfuLogistix Admin": "EfuLogistix Woyang'anira",
  "EfuLogistix fees": "Malipiro a EfuLogistix",
  "Every route fare and goods price in use goes up by this percentage, rounded up to the next K500.": "Mtengo uliwonse wa njira ndi katundu uwonjezeka ndi peresenti iyi, kukwezedwa kufika pa K500 yotsatira.",
  "Everything": "Zonse",
  "Expires": "Atha",
  "Expiring in 30 days": "Zitha m'masiku 30",
  "Fares": "Mitengo",
  "Find a driver": "Pezani woyendetsa",
  "Flag": "Lembani chizindikiro",
  "For lorries and goods-only vehicles, the fare is the price for the whole load. ": "Pa malole ndi magalimoto onyamula katundu okha, mtengo ndi wa katundu yense. ",
  "Forgot password?": "Mwayiwala password?",
  "From": "Kuchokera",
  "Goods prices": "Mitengo ya katundu",
  "Hire a car": "Kubwereka galimoto",
  "Hire prices and EfuLogistix fees, per category": "Mitengo yobwereka ndi malipiro a EfuLogistix, gulu lililonse",
  "History": "Mbiri",
  "In use": "Ikugwira ntchito",
  "Insurance": "Inshuwaransi",
  "Invite": "Itanani",
  "Invite someone": "Itanani munthu",
  "Invite to the office": "Itanani ku ofesi",
  "Keep owed": "Sungani ngongole",
  "Last month": "Mwezi wapitawu",
  "Late pickups": "Okwera ochedwa",
  "Licence classes allowed to drive it": "Magulu a laisensi ololedwa kuyendetsa",
  "Licence classes follow the Malawi DRTSS classes. Please confirm the classes for each category with DRTSS.": "Magulu a laisensi amatsatira a DRTSS ku Malawi. Chonde tsimikizirani magulu a gulu lililonse ndi DRTSS.",
  "Manager": "Mtsogoleri",
  "Mark done": "Lembani kuti yatha",
  "Mark handled": "Lembani kuti yayendetsedwa",
  "Mark paid": "Lembani kuti yalipidwa",
  "Mark solved": "Lembani kuti yathetsedwa",
  "Match": "Patsani",
  "Mileage photos": "Zithunzi za makilomita",
  "National ID, driving licence, face photo and next of kin are always required.": "Chizindikiro cha dziko, laisensi, chithunzi cha nkhope ndi wachibale wapafupi zimafunika nthawi zonse.",
  "Needs you": "Ikufuna inu",
  "New account": "Akaunti yatsopano",
  "New papers to check (the vehicle keeps running)": "Mapepala atsopano oyang'ana (galimoto ikupitiriza kugwira ntchito)",
  "Next day": "Tsiku lotsatira",
  "No GPS trail for this vehicle on this day.\nThe trail comes from the driver's phone during a shift.": "Palibe njira ya GPS ya galimoto iyi tsiku lino.\nNjira imachokera ku foni ya woyendetsa panthawi ya ntchito.",
  "No SOS or breakdown calls.": "Palibe mafoni a SOS kapena kuonongeka.",
  "No late pickups.": "Palibe okwera ochedwa.",
  "No vehicle": "Palibe galimoto",
  "No vehicle yet": "Palibe galimoto panobe",
  "None · pays each trip": "Palibe · amalipira ulendo uliwonse",
  "Not accepted": "Sinavomerezedwe",
  "Not agreed": "Sanagwirizane",
  "Not set": "Sizinaikidwe",
  "Nothing here.": "Palibe pano.",
  "Office meetings": "Misonkhano ya ku ofesi",
  "Oil change due soon": "Kusintha mafuta kwayandikira",
  "On the road": "Pa msewu",
  "Only open": "Zotseguka zokha",
  "Open": "Zotseguka",
  "Open alerts": "Machenjezo otseguka",
  "Owner": "Mwini",
  "Paid / waived": "Zalipidwa / zasiyidwa",
  "Papers": "Mapepala",
  "Passengers, drivers and route history": "Okwera, oyendetsa ndi mbiri ya njira",
  "People": "Anthu",
  "Raise all": "Kwezani zonse",
  "Raise all fares": "Kwezani mitengo yonse",
  "Raise fares": "Kwezani mitengo",
  "Receive": "Landirani",
  "Received": "Yalandiridwa",
  "Refresh": "Kutsitsimutsa",
  "Reject": "Kanani",
  "Rejected": "Yakanidwa",
  "Remove": "Chotsani",
  "Reopen": "Tsegulaninso",
  "Reports": "Malipoti",
  "Require PrDP (Professional Driving Permit)": "Funani PrDP (Chilolezo cha ukatswiri woyendetsa)",
  "Route history": "Mbiri ya njira",
  "Routes the other category already has are left as they are.": "Njira zomwe gulu lina lili nazo kale zimasiyidwa momwe zilili.",
  "Same vehicle for all waiting bookings of this departure": "Galimoto yomweyo kwa onse odikira a ulendo uwu",
  "Save": "Sungani",
  "Save settings": "Sungani zosintha",
  "Seat": "Mpando",
  "Seats": "Mipando",
  "Send back": "Bwezerani",
  "Send invitation": "Tumizani kuitana",
  "Send reminders now": "Tumizani zikumbutso tsopano",
  "Send reply": "Tumizani yankho",
  "Service": "Kukonza galimoto",
  "Settings": "Zosintha",
  "Shifts & trips": "Ntchito ndi maulendo",
  "Show more": "Onetsani zambiri",
  "Show on map": "Onetsani pa mapu",
  "Sign in": "Lowani",
  "Sign out": "Tulukani",
  "Stops": "Poima",
  "Support": "Thandizo",
  "Switch off when it is broken, sold or parked for a long time.": "Zimitsani ikaonongeka, igulitsidwa kapena ikaimitsidwa nthawi yaitali.",
  "The driver's licence class does not fit this vehicle.": "Gulu la laisensi ya woyendetsa siligwirizana ndi galimoto iyi.",
  "These drivers never ended their shift. Ask them to end it in the app, or close it here.": "Oyendetsa awa sanamalize ntchito. Auzeni kuti amalize mu pulogalamu, kapena itsekeni apa.",
  "They sign up in the phone app with this email. The app then gives them this role straight away, no approval needed.": "Amalembetsa mu pulogalamu ya foni ndi imelo iyi. Pulogalamu imawapatsa udindo uwu nthawi yomweyo, osafuna chivomerezo.",
  "This month": "Mwezi uno",
  "Time": "Nthawi",
  "Timetable & rates": "Nthawi zonyamuka ndi mitengo",
  "To": "Kupita",
  "To check": "Zoyang'ana",
  "To link an owner, first invite them in People as a Vehicle owner.": "Kulumikiza mwini, choyamba mumuitane mu People ngati Vehicle owner.",
  "Trips": "Maulendo",
  "Trips this day": "Maulendo a tsiku lino",
  "Turn on if your drivers must have a PrDP before their first shift. ": "Yatsani ngati oyendetsa anu ayenera kukhala ndi PrDP asanayambe ntchito yoyamba. ",
  "Undo": "Bwezerani",
  "Vehicle categories": "Magulu a magalimoto",
  "Vehicle photos at the end of the day": "Zithunzi za galimoto kumapeto kwa tsiku",
  "Vehicle photos at the start of the day": "Zithunzi za galimoto poyamba tsiku",
  "Vehicles": "Magalimoto",
  "Vehicles now": "Magalimoto tsopano",
  "Vehicles without a driver": "Magalimoto opanda woyendetsa",
  "Waive": "Siyani",
  "Watch list": "Mndandanda wowonera",
  "Why is it not accepted?": "Chifukwa chiyani sichinavomerezedwe?",
  "Dashboard ": "Chidule",
  "e.g. Coaster bus": "mwachitsanzo Coaster bus",
  "e.g. Driver calls 10 min before": "mwachitsanzo Woyendetsa aimba mphindi 10 m'mbuyo",
  "e.g. No taxi free at 14:00": "mwachitsanzo Palibe taxi yaulere nthawi ya 14:00",
  "e.g. Plate not readable on the photos": "mwachitsanzo Pulati siiwerengeka pa zithunzi",
  "name, email, phone": "dzina, imelo, foni",
  "Route fares (#)": "Mitengo ya njira (#)",
  "Drivers (#)": "Oyendetsa (#)",
  "Passengers (#)": "Okwera (#)",
  "Managers (#)": "Atsogoleri (#)",
  "Vehicle owners (#)": "Eni magalimoto (#)",
  "Invites (#)": "Kuitana (#)",
  "New (#)": "Zatsopano (#)",
  "Assigned (#)": "Zapatsidwa (#)",
  "Truck changes waiting (#)": "Kusintha magalimoto kukudikira (#)",
  "Still on duty from earlier days (#)": "Akadali pa ntchito kuyambira masiku apitawo (#)",
  "Missed bookings: #": "Kusungitsa kosabwera: #",
  "Booking ##": "Kusungitsa ##",
  "Trip ##": "Ulendo ##",
  "Decline booking ##": "Kanani kusungitsa ##",
  "Shifts · #": "Ntchito · #",
  "Receive from": "Landirani kuchokera kwa",
  "Leaves at": "Ananyamuka pa",
  "Waiting for approval": "Kudikira chivomerezo",
  "Started": "Anayamba",
  "Expected": "Zoyembekezeka",
  "New price": "Mtengo watsopano",
  "Another type: new price": "Mtundu wina: mtengo watsopano",
  "tell the passenger": "auzeni wokwera",
  "km": "km",
  "Language": "Chilankhulo",
  "Chichewa": "Chichewa",
  "English": "English",
  "MANAGER WORK": "NTCHITO YA MTSOGOLERI",
  "ADMIN": "WOYANG'ANIRA",
  "Driver wallets": "Ma wallet a oyendetsa",
  "What every driver has earned and been paid. The owner pays their own drivers; the office pays company vehicles.": "Zomwe woyendetsa aliyense wapeza ndi kulipidwa. Mwini amalipira oyendetsa ake; ofesi imalipira magalimoto a kampani.",
  "Owed to drivers now": "Zoyenera kulipidwa kwa oyendetsa tsopano",
  "Paid out so far": "Zomwe zalipidwa mpaka pano",
  "Drivers with a wallet": "Oyendetsa omwe ali ndi wallet",
  "Paid by": "Wolipira",
  "Earned": "Zopezeka",
  "Taken off": "Zochotsedwa",
  "Paid out": "Zolipidwa",
  "Balance": "Zotsala",
  "Office": "Ofesi",
  "What": "Chiyani",
  "Amount": "Ndalama",
  "Details": "Zambiri",
  "This owner has unpaid EfuLogistix fees. Mark them paid on the Fees page first.": "Mwini uyu ali ndi malipiro a EfuLogistix osalipidwa. Choyamba lembani kuti alipidwa pa tsamba la Fees.",
  "Fee overdue · #": "Malipiro adutsa nthawi",
  "Fee overdue": "Malipiro adutsa nthawi",
  "Fee grace period": "Masiku opereka asanadutse",
  "Days after a bill's period ends before an unpaid EfuLogistix fee is overdue. Overdue owners get a reminder and cannot be matched with new drivers.": "Masiku pambuyo pa nthawi ya bilu asanadziwe kuti malipiro a EfuLogistix adutsa. Eni omwe adutsa amapeza chikumbutso ndipo sangapatsidwe oyendetsa atsopano.",
  "days": "masiku",
};
