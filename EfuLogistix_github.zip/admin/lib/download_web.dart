import 'dart:convert';
import 'dart:js_interop';

import 'package:web/web.dart' as web;

/// Starts a browser download. Returns a short note for the person.
String? downloadText(String fileName, String text, {String type = 'text/csv'}) {
  final bytes = utf8.encode('﻿$text'); // BOM so Excel reads the K and · signs
  final blob = web.Blob(<JSAny>[bytes.toJS].toJS, web.BlobPropertyBag(type: '$type;charset=utf-8'));
  final url = web.URL.createObjectURL(blob);
  final a = web.document.createElement('a') as web.HTMLAnchorElement
    ..href = url
    ..download = fileName;
  web.document.body!.appendChild(a);
  a.click();
  a.remove();
  web.URL.revokeObjectURL(url);
  return null;
}
