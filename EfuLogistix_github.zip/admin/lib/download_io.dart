import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

/// Saves the file in the Downloads folder (Windows, Mac, Linux). Returns where it was saved.
String? downloadText(String fileName, String text, {String type = 'text/csv'}) {
  final home = Platform.environment['USERPROFILE'] ?? Platform.environment['HOME'] ?? Directory.current.path;
  var folder = Directory('$home${Platform.pathSeparator}Downloads');
  if (!folder.existsSync()) folder = Directory(home);
  final file = File('${folder.path}${Platform.pathSeparator}$fileName');
  file.writeAsBytesSync([0xEF, 0xBB, 0xBF, ...utf8.encode(text)]); // BOM so Excel reads the K and · signs
  return file.path;
}

/// Saves a binary file (for example a PDF) in the Downloads folder. Returns where it was saved.
String? downloadBytes(String fileName, Uint8List bytes, {String type = 'application/pdf'}) {
  final home = Platform.environment['USERPROFILE'] ?? Platform.environment['HOME'] ?? Directory.current.path;
  var folder = Directory('$home${Platform.pathSeparator}Downloads');
  if (!folder.existsSync()) folder = Directory(home);
  final file = File('${folder.path}${Platform.pathSeparator}$fileName');
  file.writeAsBytesSync(bytes);
  return file.path;
}
