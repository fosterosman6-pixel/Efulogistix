import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// Side-view drawings of each vehicle type (original artwork, no image files).
const _art = <String, String>{
  'kabaza': r'''<svg width="160" height="80" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg"><circle cx="36" cy="62" r="14" fill="#1F2430"/><circle cx="36" cy="62" r="7.7" fill="#C9CFDA"/><circle cx="36" cy="62" r="2.5" fill="#5B6478"/><circle cx="122" cy="62" r="14" fill="#1F2430"/><circle cx="122" cy="62" r="7.7" fill="#C9CFDA"/><circle cx="122" cy="62" r="2.5" fill="#5B6478"/><path d="M36 62 L60 42 L96 42 L122 62" fill="none" stroke="#1F2430" stroke-width="5" stroke-linecap="round"/><path d="M56 40 Q60 30 80 30 L102 30 Q110 30 112 38 L96 44 L58 44 Z" fill="#C8102E" stroke="#1F2430" stroke-width="2"/><path d="M58 34 L84 34 L84 38 L58 38 Z" fill="#1F2430"/><path d="M112 38 L118 20 L128 18" fill="none" stroke="#1F2430" stroke-width="4" stroke-linecap="round"/><circle cx="74" cy="12" r="7" fill="#0A2253"/><path d="M70 18 L66 34 L80 34 L84 22 Z" fill="#A6D41C"/><path d="M80 24 L110 22" stroke="#0A2253" stroke-width="4" stroke-linecap="round"/><path d="M70 34 L64 50" stroke="#0A2253" stroke-width="5" stroke-linecap="round"/></svg>''',
  'taxi': r'''<svg width="160" height="80" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg"><path d="M14 54 Q14 42 28 40 L50 38 L66 24 Q72 20 82 20 L108 20 Q118 20 124 28 L134 38 L146 40 Q154 42 154 52 L154 58 Q154 62 150 62 L14 62 Z" fill="#F5F7FA" stroke="#1F2430" stroke-width="2"/><path d="M58 38 L70 26 Q74 23 82 23 L94 23 L94 38 Z" fill="#9CC3E6"/><path d="M98 23 L108 23 Q116 23 120 29 L128 38 L98 38 Z" fill="#9CC3E6"/><rect x="76" y="11" width="24" height="9" rx="2" fill="#A6D41C" stroke="#1F2430" stroke-width="1.5"/><text x="88" y="18" font-size="7" font-weight="800" text-anchor="middle" fill="#0A2253">TAXI</text><rect x="14" y="46" width="140" height="5" fill="#A6D41C"/><rect x="146" y="44" width="8" height="5" rx="2" fill="#FFE08A"/><rect x="14" y="44" width="6" height="5" rx="2" fill="#E5484D"/><circle cx="44" cy="62" r="11" fill="#1F2430"/><circle cx="44" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="44" cy="62" r="2.0" fill="#5B6478"/><circle cx="124" cy="62" r="11" fill="#1F2430"/><circle cx="124" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="124" cy="62" r="2.0" fill="#5B6478"/></svg>''',
  'matola': r'''<svg width="160" height="80" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg"><path d="M10 56 L10 36 L84 36 L84 56 Z" fill="#FFFFFF" stroke="#1F2430" stroke-width="2"/><path d="M12 36 L14 22 L82 22 L84 36" fill="#0A2253" opacity=".9" stroke="#1F2430" stroke-width="2"/><path d="M84 56 L84 26 Q86 18 96 18 L118 18 Q126 18 132 28 L140 38 L150 40 Q156 42 156 50 L156 58 Q156 62 152 62 L10 62 L10 56 Z" fill="#FFFFFF" stroke="#1F2430" stroke-width="2"/><path d="M92 38 L92 24 Q93 22 98 22 L116 22 Q122 22 126 29 L132 38 Z" fill="#9CC3E6"/><rect x="20" y="26" width="10" height="7" rx="1" fill="#9CC3E6"/><rect x="36" y="26" width="10" height="7" rx="1" fill="#9CC3E6"/><rect x="52" y="26" width="10" height="7" rx="1" fill="#9CC3E6"/><rect x="68" y="26" width="10" height="7" rx="1" fill="#9CC3E6"/><rect x="10" y="46" width="146" height="4" fill="#A6D41C"/><rect x="148" y="44" width="8" height="5" rx="2" fill="#FFE08A"/><circle cx="36" cy="62" r="11" fill="#1F2430"/><circle cx="36" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="36" cy="62" r="2.0" fill="#5B6478"/><circle cx="128" cy="62" r="11" fill="#1F2430"/><circle cx="128" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="128" cy="62" r="2.0" fill="#5B6478"/></svg>''',
  'minibus': r'''<svg width="160" height="80" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg"><path d="M8 58 L8 22 Q8 14 18 14 L122 14 Q132 14 140 24 L152 40 Q156 44 156 50 L156 58 Q156 62 152 62 L8 62 Z" fill="#F5F7FA" stroke="#1F2430" stroke-width="2"/><rect x="16" y="20" width="18" height="14" rx="2" fill="#9CC3E6"/><rect x="40" y="20" width="18" height="14" rx="2" fill="#9CC3E6"/><rect x="64" y="20" width="18" height="14" rx="2" fill="#9CC3E6"/><rect x="88" y="20" width="18" height="14" rx="2" fill="#9CC3E6"/><rect x="112" y="20" width="18" height="14" rx="2" fill="#9CC3E6"/><path d="M134 20 L146 38 L134 38 Z" fill="#9CC3E6"/><rect x="8" y="42" width="148" height="5" fill="#A6D41C"/><rect x="148" y="46" width="8" height="5" rx="2" fill="#FFE08A"/><line x1="62" y1="38" x2="62" y2="60" stroke="#1F2430" stroke-width="1.5"/><circle cx="34" cy="62" r="11" fill="#1F2430"/><circle cx="34" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="34" cy="62" r="2.0" fill="#5B6478"/><circle cx="130" cy="62" r="11" fill="#1F2430"/><circle cx="130" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="130" cy="62" r="2.0" fill="#5B6478"/></svg>''',
  'lorry': r'''<svg width="160" height="80" viewBox="0 0 160 80" xmlns="http://www.w3.org/2000/svg"><rect x="6" y="10" width="104" height="44" rx="3" fill="#FFFFFF" stroke="#1F2430" stroke-width="2"/><text x="58" y="36" font-size="11" font-weight="900" text-anchor="middle" fill="#0A2253">Efu<tspan fill="#4D7300">Logistix</tspan></text><path d="M112 58 L112 22 Q112 18 118 18 L136 18 Q142 18 146 26 L154 40 Q156 44 156 48 L156 58 Q156 62 152 62 L112 62 Z" fill="#0A2253" stroke="#1F2430" stroke-width="2"/><path d="M120 36 L120 23 L136 23 Q140 23 143 28 L148 36 Z" fill="#9CC3E6"/><rect x="6" y="54" width="150" height="6" fill="#3A4152"/><rect x="148" y="44" width="8" height="5" rx="2" fill="#FFE08A"/><circle cx="26" cy="62" r="11" fill="#1F2430"/><circle cx="26" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="26" cy="62" r="2.0" fill="#5B6478"/><circle cx="52" cy="62" r="11" fill="#1F2430"/><circle cx="52" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="52" cy="62" r="2.0" fill="#5B6478"/><circle cx="136" cy="62" r="11" fill="#1F2430"/><circle cx="136" cy="62" r="6.1" fill="#C9CFDA"/><circle cx="136" cy="62" r="2.0" fill="#5B6478"/></svg>''',
};

/// 'Matola' -> 'matola'. Unknown categories get the matola drawing.
String vehicleKind(String? categoryName) {
  final n = (categoryName ?? '').toLowerCase();
  for (final k in _art.keys) {
    if (n.contains(k)) return k;
  }
  if (n.contains('truck')) return 'lorry';
  if (n.contains('bus')) return 'minibus';
  if (n.contains('car') || n.contains('cab')) return 'taxi';
  if (n.contains('motor') || n.contains('bike')) return 'kabaza';
  return 'matola';
}

/// A vehicle picture for a category name (Taxi, Matola, Minibus, Lorry, Kabaza).
class VehicleArt extends StatelessWidget {
  final String? category;
  final double width;
  const VehicleArt(this.category, {super.key, this.width = 72});

  @override
  Widget build(BuildContext context) => SvgPicture.string(
        _art[vehicleKind(category)]!,
        width: width,
        height: width / 2,
        semanticsLabel: category ?? 'vehicle',
      );
}

/// The picture on a light-green tile, as used in lists.
class VehicleTile extends StatelessWidget {
  final String? category;
  final double width;
  const VehicleTile(this.category, {super.key, this.width = 64});

  @override
  Widget build(BuildContext context) => Container(
        width: width + 12,
        height: width / 2 + 14,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: const Color(0xFFEEF8D2), borderRadius: BorderRadius.circular(12)),
        child: VehicleArt(category, width: width),
      );
}
