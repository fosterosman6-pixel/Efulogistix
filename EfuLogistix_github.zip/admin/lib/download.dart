// Saves a text file (CSV) for the person: a browser download on the web, the Downloads folder on Windows.
export 'download_io.dart' if (dart.library.js_interop) 'download_web.dart';
