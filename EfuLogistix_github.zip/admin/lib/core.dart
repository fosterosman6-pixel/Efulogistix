import 'dart:typed_data';

import 'package:flutter/material.dart' hide Text;
import 'i18n.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'format.dart';
import 'models.dart';
import 'theme.dart';

import 'download.dart';

export 'download.dart';

SupabaseClient get db => Supabase.instance.client;

/// Turns any error into a plain message.
String friendlyError(Object e) {
  final msg = e is AuthException
      ? e.message
      : e is PostgrestException
          ? '${e.message} ${e.code ?? ''}'
          : e is StorageException
              ? 'storage ${e.message}'
              : e.toString();
  final m = msg.toLowerCase();
  if (m.contains('invalid login credentials')) return 'Wrong email or password.';
  if (m.contains('email not confirmed')) return 'Please confirm your email first, then sign in.';
  if (m.contains('already_decided')) return 'Someone already decided this.';
  if (m.contains('trip_running')) return 'The driver has a trip running. Wait until it ends.';
  if (m.contains('truck_in_use')) return 'That vehicle is already on duty with another driver.';
  if (m.contains('routes_unique_per_category')) return 'This route already has a fare for that category.';
  if (m.contains('no_driver')) return 'That vehicle has no driver. Match a driver first (Drivers & matching).';
  if (m.contains('truck_not_approved')) return 'That vehicle is not approved yet (Vehicles page).';
  if (m.contains('fees_overdue')) return 'This owner has unpaid EfuLogistix fees. Mark them paid on the Fees page first.';
  if (m.contains('already_invited')) return 'This driver already has a meeting set.';
  if (m.contains('not_a_driver')) return 'That person is not an approved driver.';
  if (m.contains('on_duty')) return 'The driver is on duty. Try after the shift.';
  if (m.contains('full:')) return 'That departure is full.';
  if (m.contains('nothing_to_pay')) return 'Nothing to pay.';
  if (m.contains('caller_required')) return 'Type the caller\'s name and phone.';
  if (m.contains('cannot_cancel')) return 'This booking can no longer be changed.';
  if (m.contains('no_departure')) return 'That departure does not run on that day.';
  if (m.contains('departed')) return 'That departure has already left.';
  if (m.contains('no_account')) return 'Choose an active company account.';
  if (m.contains('not_for_hire')) return 'That vehicle type has no hire price (Timetable & rates).';
  if (m.contains('invites_email_key')) return 'This email was already invited.';
  if (m.contains('duplicate key') || m.contains('23505')) return 'That already exists.';
  if (m.contains('23503')) return 'It is still used elsewhere. Switch it off instead of deleting.';
  if (m.contains('row-level security') || m.contains('42501') || m.contains('not allowed')) {
    return 'You are not allowed to do that. Only the admin can.';
  }
  if (m.contains('percentage')) return 'Enter a percentage between 1 and 100.';
  if (m.contains('socket') || m.contains('network') || m.contains('clientexception') || m.contains('failed to fetch')) {
    return 'No internet connection. Try again.';
  }
  if (m.contains('storage')) return 'The file could not be uploaded. Try again.';
  return 'Something went wrong: $msg';
}

void toast(BuildContext context, String text) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), width: 420, behavior: SnackBarBehavior.floating));

/// Runs [action], shows the error if it fails. Returns true when it worked.
Future<bool> attempt(BuildContext context, Future<void> Function() action, {String? done}) async {
  try {
    await action();
    if (done != null && context.mounted) toast(context, done);
    return true;
  } catch (e) {
    if (context.mounted) toast(context, friendlyError(e));
    return false;
  }
}

// ---------------------------------------------------------------- lookups

/// Everything the pages need to show names: vehicles, people, categories.
class Lookup {
  List<Truck> trucks = [];
  List<Profile> people = [];
  List<VehicleCategory> categories = [];

  Future<void> load() async {
    final r = await Future.wait<List<Map<String, dynamic>>>([
      db.from('trucks').select().order('plate'),
      db.from('profiles').select().order('full_name'),
      db.from('vehicle_categories').select().order('name'),
    ]);
    trucks = r[0].map(Truck.fromMap).toList();
    people = r[1].map(Profile.fromMap).toList();
    categories = r[2].map(VehicleCategory.fromMap).toList()..sort((a, b) => categoryRank(a.name).compareTo(categoryRank(b.name)));
  }

  Truck? truck(String? id) => trucks.where((t) => t.id == id).firstOrNull;
  Profile? person(String? id) => people.where((p) => p.id == id).firstOrNull;
  VehicleCategory? category(String? id) => categories.where((c) => c.id == id).firstOrNull;
  List<Profile> get drivers => people.where((p) => p.isDriver).toList();
  List<Profile> get owners => people.where((p) => p.isVehicleOwner).toList();
  String name(String? id) => person(id)?.displayName ?? (id == null ? '' : 'Office');
  String plate(String? id) {
    final t = truck(id);
    if (t == null) return '';
    final c = category(t.categoryId);
    return c == null ? t.plate : '${t.plate} · ${c.name}';
  }
}

// ---------------------------------------------------------------- photos and files

const bucket = 'photos';
final Map<String, String> _urlCache = {};

Future<String?> photoUrl(String? path) async {
  if (path == null || path.isEmpty) return null;
  final cached = _urlCache[path];
  if (cached != null) return cached;
  try {
    final url = await db.storage.from(bucket).createSignedUrl(path, 60 * 60);
    _urlCache[path] = url;
    return url;
  } catch (_) {
    return null;
  }
}

/// Picks an image file from the computer and uploads it to the admin's folder. Returns the storage path.
Future<String?> pickAndUpload(String label) async {
  final file = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 2000, imageQuality: 75);
  if (file == null) return null;
  final Uint8List bytes = await file.readAsBytes();
  final path = '${db.auth.currentUser!.id}/${label}_${DateTime.now().millisecondsSinceEpoch}.jpg';
  await db.storage
      .from(bucket)
      .uploadBinary(path, bytes, fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: false));
  return path;
}


/// Saves a CSV and tells the person where it went (Downloads folder on Windows).
void saveCsv(BuildContext context, String fileName, String text) {
  try {
    final where = downloadText(fileName, text);
    if (where != null) toast(context, 'Saved to $where');
  } catch (e) {
    toast(context, 'Could not save the file: $e');
  }
}

String csvCell(Object? v) {
  final s = (v ?? '').toString();
  return s.contains(RegExp(r'[",\n]')) ? '"${s.replaceAll('"', '""')}"' : s;
}

String csvOf(List<String> header, List<List<Object?>> rows) =>
    [header.map(csvCell).join(','), for (final r in rows) r.map(csvCell).join(',')].join('\n');

// ---------------------------------------------------------------- widgets

class StoredImage extends StatelessWidget {
  final String? path;
  final double height;
  final double? width;
  const StoredImage(this.path, {super.key, this.height = 80, this.width});

  @override
  Widget build(BuildContext context) => FutureBuilder<String?>(
        future: photoUrl(path),
        builder: (context, snap) {
          final url = snap.data;
          final box = Container(
            height: height,
            width: width,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(color: const Color(0xFF111827), borderRadius: BorderRadius.circular(8)),
            child: url == null
                ? Center(
                    child: snap.connectionState == ConnectionState.waiting
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.image_not_supported_outlined, color: Colors.white54))
                : Image.network(url, fit: BoxFit.cover),
          );
          if (url == null) return box;
          return InkWell(
            onTap: () => showDialog<void>(
              context: context,
              builder: (_) => Dialog(child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain))),
            ),
            child: box,
          );
        },
      );
}

class Pill extends StatelessWidget {
  final String text;
  final Color color;
  const Pill(this.text, {super.key, this.color = AppColors.navy});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
      );
}

/// Page frame: title, optional actions, and scrolling content.
class PageFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget> actions;
  final List<Widget> children;
  final Future<void> Function()? onRefresh;
  const PageFrame({
    super.key,
    required this.title,
    this.subtitle,
    this.actions = const [],
    required this.children,
    this.onRefresh,
  });

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(28, 24, 28, 40),
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                if (subtitle != null) Text(subtitle!, style: const TextStyle(color: AppColors.muted)),
              ]),
              Wrap(spacing: 8, runSpacing: 8, children: [
                ...actions,
                if (onRefresh != null)
                  IconButton(tooltip: 'Refresh', onPressed: onRefresh, icon: const Icon(Icons.refresh)),
              ]),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      );
}

class Panel extends StatelessWidget {
  final String? title;
  final Widget child;
  final List<Widget> actions;
  final EdgeInsetsGeometry padding;
  const Panel({super.key, this.title, required this.child, this.actions = const [], this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.line),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 12, 0),
              child: Row(children: [
                Expanded(child: Text(title!, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
                ...actions,
              ]),
            ),
          Padding(padding: padding, child: child),
        ]),
      );
}

class Stat extends StatelessWidget {
  final String label;
  final String value;
  final bool dark;
  final Color? valueColor;
  const Stat(this.label, this.value, {super.key, this.dark = false, this.valueColor});

  @override
  Widget build(BuildContext context) => Container(
        width: 200,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: dark ? AppColors.navy : AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: dark ? null : Border.all(color: AppColors.line),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(fontSize: 13, color: dark ? AppColors.onNavyMuted : AppColors.muted)),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: valueColor ?? (dark ? AppColors.lime : AppColors.ink))),
        ]),
      );
}

/// A simple table that scrolls sideways on small screens.
class SimpleTable extends StatelessWidget {
  final List<String> columns;
  final List<List<Widget>> rows;
  final void Function(int index)? onTap;
  final String empty;
  const SimpleTable({super.key, required this.columns, required this.rows, this.onTap, this.empty = 'Nothing yet'});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Text(empty, style: const TextStyle(color: AppColors.muted)),
      );
    }
    return LayoutBuilder(
      builder: (context, box) => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: box.maxWidth),
          child: DataTable(
            showCheckboxColumn: false,
            dataRowMinHeight: 48,
            dataRowMaxHeight: 68,
            headingTextStyle: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.muted, fontSize: 13),
            columns: [for (final c in columns) DataColumn(label: Text(c))],
            rows: [
              for (var i = 0; i < rows.length; i++)
                DataRow(
                  onSelectChanged: onTap == null ? null : (_) => onTap!(i),
                  cells: [for (final w in rows[i]) DataCell(w)],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

Text bold(String s) => Text(s, style: const TextStyle(fontWeight: FontWeight.w700));
Text muted(String s) => Text(s, style: const TextStyle(color: AppColors.muted, fontSize: 13));

InputDecoration field(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      isDense: true,
    );

Future<bool> confirm(BuildContext context, String title, String message, {String yes = 'Yes'}) async =>
    await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
        ],
      ),
    ) ??
    false;

/// Date picker in a text field style button.
class DateButton extends StatelessWidget {
  final String label;
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;
  const DateButton({super.key, required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
        onPressed: () async {
          final d = await showDatePicker(
            context: context,
            initialDate: value ?? DateTime.now(),
            firstDate: DateTime(2015),
            lastDate: DateTime(2040),
          );
          if (d != null) onChanged(d);
        },
        icon: const Icon(Icons.event, size: 18),
        label: Text(value == null ? label : '$label: ${shortDate(value!)} ${value!.year}'),
      );
}

String dateOnly(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
