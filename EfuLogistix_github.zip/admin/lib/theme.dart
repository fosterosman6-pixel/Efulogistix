import 'package:flutter/material.dart';

/// EfuLogistix brand colours (from the brand kit).
class AppColors {
  static const navy = Color(0xFF0A2253);
  static const navy700 = Color(0xFF1E3A78);
  static const lime = Color(0xFFA6D41C);
  static const lime600 = Color(0xFF4D7300); // lime dark enough for text on white
  static const lime100 = Color(0xFFEEF8D2);
  static const surface = Color(0xFFFFFFFF);
  static const surface100 = Color(0xFFF3F5F9);
  static const ink = Color(0xFF0F1B38);
  static const muted = Color(0xFF566079);
  static const onNavyMuted = Color(0xFFC9D2E6);
  static const line = Color(0xFFDCE1EA);
  static const warning = Color(0xFF9A5B00);
  static const danger = Color(0xFFB42318);
  static const mapGround = Color(0xFFE8EDE4);
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.navy,
      primary: AppColors.navy,
      secondary: AppColors.lime,
      surface: AppColors.surface,
    ),
    scaffoldBackgroundColor: AppColors.surface100,
    fontFamily: 'Roboto',
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(bodyColor: AppColors.ink, displayColor: AppColors.ink),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.lime100,
    ),
  );
}
