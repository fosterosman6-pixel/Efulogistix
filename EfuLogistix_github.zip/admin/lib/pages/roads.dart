import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Roads and depots: the order of the depots, the distance between them, the rate per km for each vehicle type,
/// and a fare typed by hand for one pair of depots. Every fare between two depots is worked out from these.
class RoadsPage extends StatefulWidget {
  const RoadsPage({super.key});

  @override
  State<RoadsPage> createState() => _RoadsPageState();
}

class _RoadsPageState extends State<RoadsPage> {
  final _l = Lookup();
  List<Map<String, dynamic>> _roads = [];
  List<Map<String, dynamic>> _stops = [];
  List<Map<String, dynamic>> _rates = [];
  List<Map<String, dynamic>> _fares = [];
  List<Map<String, dynamic>> _overrides = [];
  String? _road;
  String? _cat; // vehicle type shown in the fare check
  int? _from;
  int? _to;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      _roads = List<Map<String, dynamic>>.from(await db.from('route_corridors').select().order('name'));
      _road ??= _roads.isEmpty ? null : _roads.first['id'] as String;
      _cat ??= _l.categories.firstOrNull?.id;
      await _loadRoad();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadRoad() async {
    final road = _road;
    if (road == null) return;
    final r = await Future.wait<List<Map<String, dynamic>>>([
      db.from('corridor_stops').select().eq('corridor_id', road).order('pos'),
      db.from('corridor_rates').select().eq('corridor_id', road),
      db.from('corridor_overrides').select().eq('corridor_id', road),
    ]);
    _stops = r[0];
    _rates = r[1];
    _overrides = r[2];
    await _loadFares();
  }

  Future<void> _loadFares() async {
    final road = _road, cat = _cat;
    if (road == null || cat == null) {
      _fares = [];
      return;
    }
    final rows = await db.rpc('corridor_fares', params: {'p_corridor': road, 'p_category': cat});
    _fares = rows is List ? List<Map<String, dynamic>>.from(rows.map((e) => Map<String, dynamic>.from(e as Map))) : [];
  }

  String _stopName(int? pos) {
    for (final s in _stops) {
      if (s['pos'] == pos) return '${s['place_name']}';
    }
    return '';
  }

  /// After any change: the whole-road fares used by the timetable and the drivers are rebuilt.
  Future<void> _rebuild({String? done}) async {
    final road = _road;
    if (road == null) return;
    final ok = await attempt(context, () async {
      await db.rpc('corridor_recalc_km', params: {'p_corridor': road});
      await db.rpc('corridor_rebuild', params: {'p_corridor': road});
    }, done: done);
    if (ok) {
      await _loadRoad();
      if (mounted) setState(() {});
    }
  }

  double get _totalKm => _stops.fold<double>(0, (a, s) => a + ((s['km_from_prev'] as num?)?.toDouble() ?? 0));

  Future<void> _editRate(VehicleCategory c) async {
    final cur = _rates.where((r) => r['category_id'] == c.id).firstOrNull;
    var remove = false;
    final full = TextEditingController(text: cur == null || cur['full_fare'] == null ? '' : '${(cur['full_fare'] as num).round()}');
    final perKm = TextEditingController(text: cur == null ? '' : '${cur['per_km']}');
    final minFare = TextEditingController(text: cur == null ? '1000' : '${(cur['min_fare'] as num).round()}');
    final roundTo = TextEditingController(text: cur == null ? '500' : '${(cur['round_to'] as num).round()}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(cur == null ? 'Add ${c.name} to this road' : 'Fare for ${c.name}'),
        content: SizedBox(
          width: 380,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: full, decoration: field('Fare for the whole road (MWK)', hint: 'e.g. 10000')),
            const SizedBox(height: 6),
            const Text('Best way: type what the whole road costs. A passenger who travels part of it pays that share of the distance.',
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
            const SizedBox(height: 10),
            TextField(controller: perKm, decoration: field('Or a rate per km (MWK), used only if the whole-road fare is empty')),
            const SizedBox(height: 10),
            TextField(controller: minFare, decoration: field('Lowest fare (MWK)')),
            const SizedBox(height: 10),
            TextField(controller: roundTo, decoration: field('Round the fare to (MWK)', hint: '500')),
            const SizedBox(height: 6),
            const Text('Fare = the share of the whole road (or km × rate), not below the lowest fare, rounded to this step. Fares you typed for one pair of depots stay as they are.',
                style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
        actions: [
          if (cur != null)
            TextButton(
              onPressed: () {
                remove = true;
                Navigator.pop(ctx, true);
              },
              child: const Text('Remove from this road', style: TextStyle(color: AppColors.danger)),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(cur == null ? 'Add to this road' : 'Save')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (remove) {
      final gone = await attempt(context, () async {
        await db.from('corridor_rates').delete().eq('corridor_id', _road!).eq('category_id', c.id);
      });
      if (gone) await _rebuild(done: '${c.name} no longer runs on this road. Its fares and times are hidden from passengers.');
      return;
    }
    final wholeFare = parseAmount(full.text);
    var k = parseAmount(perKm.text);
    if (wholeFare > 0 && _totalKm > 0) k = wholeFare / _totalKm; // kept so the table still shows a rate
    if (k <= 0) {
      toast(context, 'Enter the fare for the whole road, or a rate per km.');
      return;
    }
    final saved = await attempt(context, () async {
      await db.from('corridor_rates').upsert({
        'corridor_id': _road,
        'category_id': c.id,
        'per_km': double.parse(k.toStringAsFixed(2)),
        'full_fare': wholeFare > 0 ? wholeFare : null,
        'min_fare': parseAmount(minFare.text),
        'round_to': parseAmount(roundTo.text) <= 0 ? 500 : parseAmount(roundTo.text),
      });
    });
    if (saved) await _rebuild(done: 'Rate saved. All fares on this road are updated.');
  }

  Future<void> _editStop(Map<String, dynamic> s) async {
    final name = TextEditingController(text: '${s['place_name']}');
    final km = TextEditingController(text: '${s['km_from_prev']}');
    var board = s['can_board'] == true;
    var drop = s['can_drop'] == true;
    final first = s['pos'] == 0;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text('${s['pos']}. ${s['place_name']}'),
          content: SizedBox(
            width: 400,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: field('Name')),
              if (!first) ...[
                const SizedBox(height: 10),
                TextField(controller: km, decoration: field('Distance from the depot before (km)')),
              ],
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Passengers can get on here'), value: board, onChanged: (v) => setLocal(() => board = v)),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Passengers can get off here'), value: drop, onChanged: (v) => setLocal(() => drop = v)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted || name.text.trim().isEmpty) return;
    final newKm = double.tryParse(km.text.replaceAll(',', '.')) ?? (s['km_from_prev'] as num).toDouble();
    final kmChanged = !first && (newKm - (s['km_from_prev'] as num).toDouble()).abs() > 0.04;
    final saved = await attempt(context, () async {
      await db.from('corridor_stops').update({
        'place_name': name.text.trim(),
        'can_board': board,
        'can_drop': drop,
        if (!first) 'km_from_prev': newKm,
        if (kmChanged) 'km_locked': true, // a distance the admin typed is never overwritten
      }).eq('corridor_id', _road!).eq('pos', s['pos']);
    });
    if (saved) await _rebuild(done: 'Depot saved.');
  }

  Future<void> _setFare() async {
    final a = _from, b = _to, cat = _cat;
    if (a == null || b == null || cat == null || a == b) return;
    final lo = a < b ? a : b, hi = a < b ? b : a;
    final cur = _fares.where((f) => f['from_pos'] == a && f['to_pos'] == b).firstOrNull;
    final fare = TextEditingController(text: cur == null ? '' : '${(cur['fare'] as num).round()}');
    final has = _overrides.any((o) => o['category_id'] == cat && o['from_pos'] == lo && o['to_pos'] == hi);
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${_stopName(a)} ↔ ${_stopName(b)}'),
        content: SizedBox(
          width: 380,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: fare, decoration: field('Fare per passenger (MWK)')),
            const SizedBox(height: 6),
            const Text('The same fare is used both ways. It stays when you change the rate per km.', style: TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
        actions: [
          if (has) TextButton(onPressed: () => Navigator.pop(ctx, 'clear'), child: const Text('Go back to worked-out fare')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'save'), child: const Text('Save')),
        ],
      ),
    );
    if (res == null || !mounted) return;
    final saved = await attempt(context, () async {
      if (res == 'clear') {
        await db.from('corridor_overrides').delete().eq('corridor_id', _road!).eq('category_id', cat).eq('from_pos', lo).eq('to_pos', hi);
      } else {
        final f = parseAmount(fare.text);
        if (f <= 0) throw 'Enter the fare.';
        await db.from('corridor_overrides').upsert({'corridor_id': _road, 'category_id': cat, 'from_pos': lo, 'to_pos': hi, 'fare': f});
      }
    });
    if (saved) await _rebuild(done: 'Fare saved.');
  }

  @override
  Widget build(BuildContext context) {
    final cats = _l.categories;
    final pair = _from == null || _to == null || _from == _to
        ? null
        : _fares.where((f) => f['from_pos'] == _from && f['to_pos'] == _to).firstOrNull;
    return PageFrame(
      title: 'Roads & depots',
      subtitle: 'Depots in order along a road. Fares between any two depots are worked out from the distance and the rate per km.',
      onRefresh: _load,
      actions: [
        if (_roads.length > 1)
          SizedBox(
            width: 260,
            child: DropdownButtonFormField<String>(
              value: _road,
              decoration: field('Road'),
              items: [for (final r in _roads) DropdownMenuItem(value: r['id'] as String, child: Text('${r['name']}'))],
              onChanged: (v) async {
                _road = v;
                await _loadRoad();
                if (mounted) setState(() {});
              },
            ),
          ),
        OutlinedButton.icon(onPressed: _road == null ? null : () => _rebuild(done: 'Distances and fares updated.'), icon: const Icon(Icons.calculate_outlined), label: const Text('Recalculate')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        if (!_loading && _roads.isEmpty)
          Panel(child: Text('No road yet. Run schema_v44_route_depots.sql in the database first.', style: const TextStyle(color: AppColors.muted))),
        if (_road != null) ...[
          Panel(
            title: 'Fare for the whole road',
            child: SimpleTable(
              columns: const ['Vehicle', 'Whole road', 'Rate per km', 'Lowest fare', 'Round to'],
              onTap: (i) => _editRate(cats[i]),
              rows: [
                for (final c in cats)
                  () {
                    final r = _rates.where((x) => x['category_id'] == c.id).firstOrNull;
                    return <Widget>[
                      bold(c.name),
                      Text(r == null ? 'not on this road' : money((r['full_fare'] != null ? (r['full_fare'] as num).toDouble() : (r['per_km'] as num).toDouble() * _totalKm))),
                      Text(r == null ? '' : 'K${(r['per_km'] as num).toStringAsFixed(0)}'),
                      Text(r == null ? '' : money((r['min_fare'] as num).toDouble())),
                      Text(r == null ? '' : money((r['round_to'] as num).toDouble())),
                    ];
                  }(),
              ],
            ),
          ),
          Panel(
            title: 'Check or change a fare',
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Wrap(spacing: 10, runSpacing: 10, children: [
                SizedBox(
                  width: 200,
                  child: DropdownButtonFormField<String?>(
                    value: _cat,
                    decoration: field('Vehicle'),
                    items: [for (final c in cats) DropdownMenuItem(value: c.id, child: Text(c.name))],
                    onChanged: (v) async {
                      _cat = v;
                      await _loadFares();
                      if (mounted) setState(() {});
                    },
                  ),
                ),
                SizedBox(
                  width: 260,
                  child: DropdownButtonFormField<int?>(
                    value: _from,
                    isExpanded: true,
                    decoration: field('From'),
                    items: [for (final s in _stops) DropdownMenuItem(value: s['pos'] as int, child: Text('${s['pos']}. ${s['place_name']}', overflow: TextOverflow.ellipsis))],
                    onChanged: (v) => setState(() => _from = v),
                  ),
                ),
                SizedBox(
                  width: 260,
                  child: DropdownButtonFormField<int?>(
                    value: _to,
                    isExpanded: true,
                    decoration: field('To'),
                    items: [for (final s in _stops) DropdownMenuItem(value: s['pos'] as int, child: Text('${s['pos']}. ${s['place_name']}', overflow: TextOverflow.ellipsis))],
                    onChanged: (v) => setState(() => _to = v),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              if (pair != null)
                Row(children: [
                  Text('${money((pair['fare'] as num).toDouble())} per passenger', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(width: 12),
                  muted('${(pair['km'] as num).toStringAsFixed(1)} km'),
                  const Spacer(),
                  FilledButton(onPressed: _setFare, child: const Text('Change this fare')),
                ])
              else
                muted('Choose two different depots to see the fare.'),
            ]),
          ),
          Panel(
            title: 'Depots in order (${_stops.length})',
            child: SimpleTable(
              columns: const ['#', 'Depot', 'km from before', 'Get on', 'Get off'],
              onTap: (i) => _editStop(_stops[i]),
              rows: [
                for (final s in _stops)
                  <Widget>[
                    Text('${s['pos']}'),
                    bold('${s['place_name']}'),
                    Text(s['pos'] == 0 ? '' : '${(s['km_from_prev'] as num).toStringAsFixed(1)}${s['km_locked'] == true ? '  (typed)' : ''}'),
                    Icon(s['can_board'] == true ? Icons.check : Icons.close, size: 18),
                    Icon(s['can_drop'] == true ? Icons.check : Icons.close, size: 18),
                  ],
              ],
            ),
          ),
        ],
      ],
    );
  }
}
