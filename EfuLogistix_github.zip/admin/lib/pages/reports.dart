import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../report_pdf.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

class _Row {
  final String name;
  int trips = 0;
  int pax = 0;
  int km = 0;
  double collected = 0;
  double spent = 0;
  _Row(this.name);
  double get profit => collected - spent;
}

/// Money in and out for any date range: per vehicle, category, owner and driver. Download as CSV.
class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  final _l = Lookup();
  late DateTime _from;
  late DateTime _to;
  List<Trip> _trips = [];
  List<Expense> _expenses = [];
  List<HandIn> _handIns = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _from = DateTime(now.year, now.month);
    _to = now;
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final from = DateTime(_from.year, _from.month, _from.day);
      final to = DateTime(_to.year, _to.month, _to.day).add(const Duration(days: 1));
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('trips').select().eq('status', 'completed').gte('started_at', isoUtc(from)).lt('started_at', isoUtc(to)),
        db.from('expenses').select().gte('spent_at', isoUtc(from)).lt('spent_at', isoUtc(to)),
        db.from('hand_ins').select().gte('day', dateOnly(from)).lt('day', dateOnly(to)),
      ]);
      if (!mounted) return;
      setState(() {
        _trips = r[0].map(Trip.fromMap).toList();
        _expenses = r[1].map(Expense.fromMap).toList();
        _handIns = r[2].map(HandIn.fromMap).toList();
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  List<_Row> _group(String Function(Trip t) tripKey, String? Function(Expense e) expenseKey) {
    final out = <String, _Row>{};
    for (final t in _trips) {
      final r = out.putIfAbsent(tripKey(t), () => _Row(tripKey(t)));
      r.trips++;
      r.pax += t.carried;
      r.km += t.odometerKm ?? 0;
      r.collected += t.total;
    }
    for (final e in _expenses) {
      final k = expenseKey(e);
      if (k != null) out.putIfAbsent(k, () => _Row(k)).spent += e.amount;
    }
    return out.values.toList()..sort((a, b) => b.profit.compareTo(a.profit));
  }

  String _vehicle(String truckId) => _l.truck(truckId)?.plate ?? '?';
  String _category(String truckId) => _l.category(_l.truck(truckId)?.categoryId)?.name ?? 'Other';
  String _owner(String truckId) => _l.person(_l.truck(truckId)?.ownerId)?.displayName ?? 'Company';

  void _download() {
    final rows = <List<Object?>>[
      for (final t in _trips)
        [
          dateOnly(t.startedAt),
          'trip',
          t.tripNo,
          _l.name(t.driverId),
          _vehicle(t.truckId),
          _category(t.truckId),
          _owner(t.truckId),
          '${t.pickupName} → ${t.destName}',
          t.carried,
          t.odometerKm,
          t.total.round(),
        ],
      for (final e in _expenses)
        [
          dateOnly(e.spentAt),
          'expense (${e.paidBy})',
          '',
          _l.name(e.createdBy),
          _vehicle(e.truckId),
          _category(e.truckId),
          _owner(e.truckId),
          '${expenseNames[e.category] ?? e.category}${e.note != null ? ' · ${e.note}' : ''}',
          '',
          '',
          -e.amount.round(),
        ],
    ]..sort((a, b) => a[0].toString().compareTo(b[0].toString()));
    saveCsv(context, 
      'efulogistix_${dateOnly(_from)}_${dateOnly(_to)}.csv',
      csvOf(['date', 'type', 'trip_no', 'person', 'vehicle', 'category', 'owner', 'detail', 'passengers', 'km', 'amount_mwk'], rows),
    );
  }

  Future<void> _downloadPdf() async {
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final spent = _expenses.fold<double>(0, (s, e) => s + e.amount);
    final short = _handIns.fold<double>(0, (s, h) => s + h.short);
    List<List<String>> rows(List<_Row> l) => [
          for (final r in l) [r.name, '${r.trips}', '${r.pax}', '${r.km}', money(r.collected), money(r.spent), money(r.profit)]
        ];
    const cols = ['Name', 'Trips', 'Passengers', 'Km', 'Collected', 'Expenses', 'Profit'];
    try {
      final bytes = await buildReportPdf(
        title: 'EfuLogistix report',
        period: '${dateOnly(_from)} to ${dateOnly(_to)}',
        summary: [
          MapEntry('Collected', money(collected)),
          MapEntry('Expenses', money(spent)),
          MapEntry('Profit', money(collected - spent)),
          MapEntry('Trips', '${_trips.length}'),
          MapEntry('Passengers', '${_trips.fold<int>(0, (s, t) => s + t.carried)}'),
          MapEntry('Cash short', money(short)),
        ],
        tables: [
          PdfTable('By vehicle', cols, rows(_group((t) => _vehicle(t.truckId), (e) => _vehicle(e.truckId)))),
          PdfTable('By category', cols, rows(_group((t) => _category(t.truckId), (e) => _category(e.truckId)))),
          PdfTable('By vehicle owner', cols, rows(_group((t) => _owner(t.truckId), (e) => _owner(e.truckId)))),
          PdfTable('By driver (driver-paid expenses only)', cols,
              rows(_group((t) => _l.name(t.driverId), (e) => e.paidBy == 'driver' ? _l.name(e.createdBy) : null))),
        ],
      );
      final where = downloadBytes('efulogistix_${dateOnly(_from)}_${dateOnly(_to)}.pdf', bytes);
      if (where != null && mounted) toast(context, 'Saved to $where');
    } catch (e) {
      if (mounted) toast(context, 'Could not make the PDF: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final collected = _trips.fold<double>(0, (s, t) => s + t.total);
    final spent = _expenses.fold<double>(0, (s, e) => s + e.amount);
    final short = _handIns.fold<double>(0, (s, h) => s + h.short);
    final now = DateTime.now();
    return PageFrame(
      title: 'Reports',
      subtitle: 'Completed trips and all expenses between the two dates.',
      onRefresh: _load,
      actions: [
        ActionChip(
          label: const Text('This month'),
          onPressed: () {
            _from = DateTime(now.year, now.month);
            _to = now;
            _load();
          },
        ),
        ActionChip(
          label: const Text('Last month'),
          onPressed: () {
            _from = DateTime(now.year, now.month - 1);
            _to = DateTime(now.year, now.month, 0);
            _load();
          },
        ),
        DateButton(label: 'From', value: _from, onChanged: (d) {
          _from = d ?? _from;
          _load();
        }),
        DateButton(label: 'To', value: _to, onChanged: (d) {
          _to = d ?? _to;
          _load();
        }),
        FilledButton.icon(onPressed: _downloadPdf, icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('Download PDF')),
        OutlinedButton.icon(onPressed: _download, icon: const Icon(Icons.download), label: const Text('Download CSV')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Collected', money(collected), dark: true),
          Stat('Expenses', money(spent)),
          Stat('Profit', money(collected - spent), valueColor: collected - spent < 0 ? AppColors.danger : AppColors.lime600),
          Stat('Trips', '${_trips.length}'),
          Stat('Passengers', '${_trips.fold<int>(0, (s, t) => s + t.carried)}'),
          Stat('Cash short', money(short), valueColor: short > 0 ? AppColors.danger : null),
        ]),
        const SizedBox(height: 16),
        _table('By vehicle', _group((t) => _vehicle(t.truckId), (e) => _vehicle(e.truckId))),
        _table('By category', _group((t) => _category(t.truckId), (e) => _category(e.truckId))),
        _table('By vehicle owner', _group((t) => _owner(t.truckId), (e) => _owner(e.truckId))),
        _table('By driver (driver-paid expenses only)',
            _group((t) => _l.name(t.driverId), (e) => e.paidBy == 'driver' ? _l.name(e.createdBy) : null)),
      ],
    );
  }

  Widget _table(String title, List<_Row> rows) => Panel(
        title: title,
        padding: const EdgeInsets.only(bottom: 8),
        child: SimpleTable(
          empty: 'Nothing in these dates.',
          columns: const ['Name', 'Trips', 'Passengers', 'Km', 'Collected', 'Expenses', 'Profit'],
          rows: [
            for (final r in rows)
              [
                bold(r.name),
                Text('${r.trips}'),
                Text('${r.pax}'),
                Text('${r.km}'),
                Text(money(r.collected)),
                Text(money(r.spent)),
                Text(money(r.profit),
                    style: TextStyle(fontWeight: FontWeight.w800, color: r.profit < 0 ? AppColors.danger : AppColors.ink)),
              ],
          ],
        ),
      );
}
