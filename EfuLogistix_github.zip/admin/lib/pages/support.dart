import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core.dart';
import '../format.dart';
import '../theme.dart';

const _reasonNames = <String, String>{
  'driver_late': 'Driver was late',
  'overcharged': 'Charged too much',
  'lost_goods': 'Lost or damaged goods',
  'safety': 'Safety problem',
  'payment': 'Payment problem',
  'vehicle': 'Vehicle problem',
  'app_problem': 'App problem',
  'other': 'Something else',
};

Color _statusColor(String s) => switch (s) {
      'in_progress' => AppColors.warning,
      'solved' => AppColors.lime600,
      _ => AppColors.danger,
    };

String _when(dynamic v) {
  final d = DateTime.tryParse('$v')?.toLocal();
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
}

/// Support inbox: reports from passengers, drivers and owners, and SOS / breakdown calls.
class SupportPage extends StatefulWidget {
  const SupportPage({super.key});

  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  String _view = 'open'; // open, in_progress, solved, incidents
  List<Map<String, dynamic>> _tickets = [];
  List<Map<String, dynamic>> _incidents = [];
  final Map<String, Map<String, dynamic>> _people = {};
  final Map<String, String> _plates = {};
  Map<String, dynamic>? _today;
  List<Map<String, dynamic>> _repeat = [];
  List<Map<String, dynamic>> _low = [];
  bool _loading = true;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 20), (_) => _load(quiet: true));
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _load({bool quiet = false}) async {
    if (!quiet) setState(() => _loading = true);
    try {
      if (_view == 'incidents') {
        final rows = await db.from('incidents').select().order('created_at', ascending: false).limit(100);
        _incidents = List<Map<String, dynamic>>.from(rows);
      } else {
        final rows = await db
            .from('support_tickets')
            .select()
            .eq('status', _view)
            .order('priority', ascending: true) // 'normal' < 'urgent' alphabetically, flipped below
            .order('created_at', ascending: false)
            .limit(200);
        _tickets = List<Map<String, dynamic>>.from(rows);
        _tickets.sort((a, b) {
          final u = (b['priority'] == 'urgent' ? 1 : 0) - (a['priority'] == 'urgent' ? 1 : 0);
          return u != 0 ? u : '${b['created_at']}'.compareTo('${a['created_at']}');
        });
      }
      final ids = <String>{
        for (final r in [..._tickets, ..._incidents]) '${r['user_id']}',
      };
      if (ids.isNotEmpty) {
        final ps = await db.from('profiles').select('id, full_name, email, phone, role').inFilter('id', ids.toList());
        for (final p in ps) {
          _people['${p['id']}'] = Map<String, dynamic>.from(p);
        }
      }
      try {
        final t = await db.rpc('today_summary');
        final m = t is List ? (t.isEmpty ? null : t.first) : t;
        if (m is Map) _today = Map<String, dynamic>.from(m);
        _repeat = List<Map<String, dynamic>>.from(await db.rpc('repeat_complaints') as List);
        _low = List<Map<String, dynamic>>.from(await db.rpc('low_rated_drivers') as List);
      } catch (_) {}
      final ts = await db.from('trucks').select('id, plate');
      for (final t in ts) {
        _plates['${t['id']}'] = '${t['plate']}';
      }
    } catch (e) {
      if (mounted && !quiet) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String _who(dynamic id) {
    final p = _people['$id'];
    if (p == null) return 'Unknown';
    final n = '${p['full_name'] ?? ''}'.trim();
    return '${n.isEmpty ? p['email'] : n} (${p['role']})';
  }

  Future<void> _open(Map<String, dynamic> t) async {
    await showDialog(context: context, builder: (_) => _TicketDialog(ticket: t, who: _who(t['user_id']), phone: '${_people['${t['user_id']}']?['phone'] ?? ''}'));
    _load();
  }

  Future<void> _handle(Map<String, dynamic> i) async {
    if (await attempt(context, () => db.rpc('handle_incident', params: {'p_id': i['id']}), done: 'Marked handled.')) _load();
  }

  Future<void> _map(Map<String, dynamic> i) async {
    final lat = i['lat'], lng = i['lng'];
    if (lat == null || lng == null) return;
    await launchUrl(Uri.parse('https://www.google.com/maps?q=$lat,$lng'), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final openIncidents = _incidents.where((i) => i['status'] == 'open').length;
    return PageFrame(
      title: 'Support',
      subtitle: 'Reports from passengers, drivers and owners, and SOS calls',
      onRefresh: _load,
      children: [
        if (_today != null)
          Wrap(spacing: 12, runSpacing: 12, children: [
            Stat('Trips today', '${_today!['trips_today']}'),
            Stat('Collected today', money(num.tryParse('${_today!['collected_today']}'))),
            Stat('Vehicles on duty', '${_today!['vehicles_on_duty']}'),
            Stat('Waiting for approval', '${(num.tryParse('${_today!['people_waiting']}') ?? 0) + (num.tryParse('${_today!['vehicles_waiting']}') ?? 0)}'),
            Stat('Open reports', '${_today!['open_tickets']}',
                valueColor: (num.tryParse('${_today!['open_tickets']}') ?? 0) > 0 ? AppColors.warning : null),
            Stat('Open SOS / breakdowns', '${_today!['open_incidents']}',
                valueColor: (num.tryParse('${_today!['open_incidents']}') ?? 0) > 0 ? AppColors.danger : null),
          ]),
        if (_repeat.isNotEmpty || _low.isNotEmpty) ...[
          const SizedBox(height: 16),
          Panel(
            title: 'Watch list',
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final r in _repeat)
                Text('${r['kind'] == 'vehicle' ? 'Vehicle' : 'Driver'} ${r['name']}: ${r['reports']} reports in 30 days'),
              for (final r in _low) Text('Driver ${r['name']}: average ${r['average']} stars from ${r['ratings']} ratings'),
            ]),
          ),
        ],
        const SizedBox(height: 16),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in const {
            'open': 'Open',
            'in_progress': 'Being looked at',
            'solved': 'Solved',
            'incidents': 'SOS & breakdowns',
          }.entries)
            ChoiceChip(
              label: Text(e.value + (e.key == 'incidents' && openIncidents > 0 ? ' ($openIncidents)' : '')),
              selected: _view == e.key,
              onSelected: (_) {
                setState(() => _view = e.key);
                _load();
              },
            ),
        ]),
        const SizedBox(height: 16),
        if (_loading) const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())),
        if (!_loading && _view != 'incidents' && _tickets.isEmpty)
          const Panel(child: Text('Nothing here.', style: TextStyle(color: AppColors.muted))),
        if (!_loading && _view == 'incidents' && _incidents.isEmpty)
          const Panel(child: Text('No SOS or breakdown calls.', style: TextStyle(color: AppColors.muted))),
        if (!_loading && _view != 'incidents')
          for (final t in _tickets)
            Panel(
              child: InkWell(
                onTap: () => _open(t),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Text('#${t['ticket_no']}  ${_reasonNames[t['reason']] ?? t['reason']}',
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        if (t['priority'] == 'urgent') ...[const SizedBox(width: 8), const Pill('URGENT', color: AppColors.danger)],
                      ]),
                      const SizedBox(height: 2),
                      Text('${_who(t['user_id'])} · ${_when(t['created_at'])}${t['truck_id'] != null ? ' · ${_plates['${t['truck_id']}'] ?? ''}' : ''}',
                          style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text('${t['body'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                    ]),
                  ),
                  Pill(switch ('${t['status']}') { 'in_progress' => 'Being looked at', 'solved' => 'Solved', _ => 'Open' },
                      color: _statusColor('${t['status']}')),
                ]),
              ),
            ),
        if (!_loading && _view == 'incidents')
          for (final i in _incidents)
            Panel(
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Pill(i['kind'] == 'sos' ? 'SOS' : 'BREAKDOWN', color: i['kind'] == 'sos' ? AppColors.danger : AppColors.warning),
                      const SizedBox(width: 8),
                      Text(_who(i['user_id']), style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                    const SizedBox(height: 4),
                    Text('${_when(i['created_at'])}${i['truck_id'] != null ? ' · ${_plates['${i['truck_id']}'] ?? ''}' : ''}'
                        '${'${_people['${i['user_id']}']?['phone'] ?? ''}'.isNotEmpty ? ' · ${_people['${i['user_id']}']?['phone']}' : ''}',
                        style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    if ('${i['note'] ?? ''}'.isNotEmpty) Text('${i['note']}'),
                  ]),
                ),
                if (i['lat'] != null) TextButton(onPressed: () => _map(i), child: const Text('Show on map')),
                if (i['status'] == 'open') FilledButton(onPressed: () => _handle(i), child: const Text('Mark handled'))
                else const Pill('Handled', color: AppColors.lime600),
              ]),
            ),
      ],
    );
  }
}

class _TicketDialog extends StatefulWidget {
  final Map<String, dynamic> ticket;
  final String who;
  final String phone;
  const _TicketDialog({required this.ticket, required this.who, required this.phone});

  @override
  State<_TicketDialog> createState() => _TicketDialogState();
}

class _TicketDialogState extends State<_TicketDialog> {
  late Map<String, dynamic> _t = widget.ticket;
  List<Map<String, dynamic>> _msgs = [];
  final _reply = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reply.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final t = await db.from('support_tickets').select().eq('id', _t['id']).maybeSingle();
      final m = await db.from('support_messages').select().eq('ticket_id', _t['id']).order('created_at');
      if (!mounted) return;
      setState(() {
        if (t != null) _t = t;
        _msgs = List<Map<String, dynamic>>.from(m);
      });
    } catch (_) {}
  }

  Future<void> _send() async {
    final text = _reply.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    final ok = await attempt(context, () => db.rpc('ticket_reply', params: {'p_ticket': _t['id'], 'p_body': text}));
    if (ok) _reply.clear();
    if (mounted) setState(() => _sending = false);
    if (ok) _load();
  }

  Future<void> _status(String s) async {
    if (await attempt(context, () => db.rpc('ticket_set_status', params: {'p_ticket': _t['id'], 'p_status': s}))) _load();
  }

  @override
  Widget build(BuildContext context) {
    final photo = _t['photo_path'] as String?;
    return AlertDialog(
      title: Text('#${_t['ticket_no']}  ${_reasonNames[_t['reason']] ?? _t['reason']}'),
      content: SizedBox(
        width: 560,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('${widget.who}${widget.phone.isNotEmpty ? ' · ${widget.phone}' : ''}',
                style: const TextStyle(color: AppColors.muted)),
            Text(_when(_t['created_at']), style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            const SizedBox(height: 10),
            Text('${_t['body'] ?? ''}'),
            if (photo != null) ...[const SizedBox(height: 10), StoredImage(photo, height: 180)],
            const Divider(height: 28),
            for (final m in _msgs)
              Align(
                alignment: m['from_staff'] == true ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  constraints: const BoxConstraints(maxWidth: 420),
                  decoration: BoxDecoration(
                    color: m['from_staff'] == true ? AppColors.lime100 : AppColors.surface100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${m['from_staff'] == true ? 'Office' : 'Customer'} · ${_when(m['created_at'])}',
                        style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                    Text('${m['body']}'),
                  ]),
                ),
              ),
            const SizedBox(height: 6),
            TextField(
              controller: _reply,
              minLines: 2,
              maxLines: 5,
              decoration: field('Reply to the person'),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        if (_t['status'] != 'solved') TextButton(onPressed: () => _status('solved'), child: const Text('Mark solved')),
        if (_t['status'] == 'solved') TextButton(onPressed: () => _status('open'), child: const Text('Reopen')),
        FilledButton(onPressed: _sending ? null : _send, child: const Text('Send reply')),
      ],
    );
  }
}
