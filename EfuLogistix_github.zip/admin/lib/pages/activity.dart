import 'dart:convert';

import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

const _tableNames = {
  'trucks': 'Vehicle',
  'profiles': 'Person',
  'routes': 'Fare',
  'goods_prices': 'Goods price',
  'documents': 'Document',
  'hand_ins': 'Hand-in',
  'shifts': 'Shift',
  'truck_changes': 'Truck change',
  'vehicle_categories': 'Category',
  'app_settings': 'Settings',
  'invites': 'Invite',
  'trips': 'Trip',
  'expenses': 'Expense',
  'service_records': 'Service',
};

/// Who changed what and when: fares, vehicles, people, documents, cash.
class ActivityPage extends StatefulWidget {
  const ActivityPage({super.key});

  @override
  State<ActivityPage> createState() => _ActivityPageState();
}

class _ActivityPageState extends State<ActivityPage> {
  List<Map<String, dynamic>> _rows = [];
  String? _table;
  bool _loading = true;
  int _limit = 200;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      var q = db.from('activity_log').select();
      if (_table != null) q = q.eq('table_name', _table!);
      final rows = await q.order('at', ascending: false).limit(_limit);
      if (mounted) setState(() => _rows = rows);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String _detail(dynamic d) {
    if (d == null) return '';
    final map = d is Map ? d : (jsonDecode(d.toString()) as Map);
    return map.entries.map((e) {
      final v = e.value;
      if (v is Map && v.containsKey('from')) return '${e.key}: ${v['from'] ?? '—'} → ${v['to'] ?? '—'}';
      return '${e.key}: $v';
    }).join(' · ');
  }

  @override
  Widget build(BuildContext context) => PageFrame(
        title: 'Activity log',
        subtitle: 'Every change to fares, vehicles, people, documents and cash, with who made it.',
        onRefresh: _load,
        actions: [
          DropdownButton<String?>(
            value: _table,
            hint: const Text('Everything'),
            items: [
              const DropdownMenuItem(value: null, child: Text('Everything')),
              for (final e in _tableNames.entries) DropdownMenuItem(value: e.key, child: Text(e.value)),
            ],
            onChanged: (v) {
              _table = v;
              _load();
            },
          ),
        ],
        children: [
          if (_loading) const LinearProgressIndicator(),
          Panel(
            padding: const EdgeInsets.only(bottom: 8),
            child: SimpleTable(
              empty: 'No activity yet.',
              columns: const ['When', 'Who', 'What', 'Details'],
              rows: [
                for (final r in _rows)
                  [
                    Text(() {
                      final at = toDate(r['at']) ?? DateTime.now();
                      return '${shortDate(at)} ${clock(at)}';
                    }()),
                    bold(r['actor_name']?.toString() ?? 'System'),
                    Text('${r['action']}${r['table_name'] != null ? ' · ${_tableNames[r['table_name']] ?? r['table_name']}' : ''}'),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Text(_detail(r['detail']),
                          maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted)),
                    ),
                  ],
              ],
            ),
          ),
          if (_rows.length >= _limit)
            Center(
              child: TextButton(
                onPressed: () {
                  _limit += 200;
                  _load();
                },
                child: const Text('Show more'),
              ),
            ),
        ],
      );
}
