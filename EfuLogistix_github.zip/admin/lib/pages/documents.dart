import 'package:flutter/material.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Driver documents to check: National ID, licence (class and expiry), selfie, PrDP and the rest.
/// A driver cannot start a shift until the required ones are approved.
class DocumentsPage extends StatefulWidget {
  const DocumentsPage({super.key});

  @override
  State<DocumentsPage> createState() => _DocumentsPageState();
}

class _DocumentsPageState extends State<DocumentsPage> {
  final _l = Lookup();
  String _status = 'pending';
  List<Doc> _docs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      var q = db.from('documents').select();
      if (_status == 'expiring') {
        q = q.not('expires_on', 'is', null).lte('expires_on', dateOnly(DateTime.now().add(const Duration(days: 30))));
      } else {
        q = q.eq('status', _status);
      }
      final rows = await q.order('created_at', ascending: false).limit(200);
      if (mounted) setState(() => _docs = rows.map(Doc.fromMap).toList());
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _review(Doc d, String status) async {
    final note = TextEditingController(text: d.note ?? '');
    final number = TextEditingController(text: d.number ?? '');
    String? cls = d.licenceClass;
    DateTime? expires = d.expiresOn;
    final classes = <String>{for (final c in _l.categories) ...c.licenceClasses}.toList()..sort();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text('${status == 'approved' ? 'Approve' : 'Reject'} ${docNames[d.kind] ?? d.kind}'),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('Check the details match the photo.', style: TextStyle(color: Colors.grey.shade700)),
              const SizedBox(height: 12),
              TextField(controller: number, decoration: field('Number on the document')),
              if (d.kind == 'licence') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String?>(
                  value: classes.contains(cls) ? cls : null,
                  decoration: field('Licence class'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('Not set')),
                    for (final c in classes) DropdownMenuItem(value: c, child: Text(c)),
                  ],
                  onChanged: (v) => setLocal(() => cls = v),
                ),
              ],
              const SizedBox(height: 10),
              DateButton(label: 'Expires', value: expires, onChanged: (v) => setLocal(() => expires = v)),
              const SizedBox(height: 10),
              TextField(
                controller: note,
                decoration: field(status == 'rejected' ? 'Reason (the driver sees this)' : 'Note (optional)'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(
              style: status == 'rejected' ? FilledButton.styleFrom(backgroundColor: AppColors.danger) : null,
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(status == 'approved' ? 'Approve' : 'Reject'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(
        context,
        () => db.from('documents').update({
              'status': status,
              'number': number.text.trim().isEmpty ? null : number.text.trim(),
              'licence_class': cls,
              'expires_on': expires == null ? null : dateOnly(expires!),
              'note': note.text.trim().isEmpty ? null : note.text.trim(),
              'reviewed_by': db.auth.currentUser?.id,
              'reviewed_at': DateTime.now().toUtc().toIso8601String(),
            }).eq('id', d.id),
        done: status == 'approved' ? 'Approved.' : 'Rejected. The driver will be asked to upload again.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'Documents',
      subtitle: 'Required before the first shift: National ID, driving licence, face photo, next of kin '
          '(and PrDP if switched on in Settings).',
      onRefresh: _load,
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'pending', label: Text('To check')),
            ButtonSegment(value: 'approved', label: Text('Approved')),
            ButtonSegment(value: 'rejected', label: Text('Rejected')),
            ButtonSegment(value: 'expiring', label: Text('Expiring in 30 days')),
          ],
          selected: {_status},
          onSelectionChanged: (v) {
            _status = v.first;
            _load();
          },
        ),
        const SizedBox(height: 16),
        if (_loading) const LinearProgressIndicator(),
        if (!_loading && _docs.isEmpty)
          const Panel(child: Text('Nothing here.', style: TextStyle(color: AppColors.muted))),
        Wrap(spacing: 16, runSpacing: 16, children: [
          for (final d in _docs)
            Container(
              width: 360,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: d.expired ? AppColors.danger : AppColors.line, width: d.expired ? 2 : 1),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Expanded(child: bold(docNames[d.kind] ?? d.kind)),
                  Pill(
                    d.expired ? 'Expired' : d.status,
                    color: d.expired || d.status == 'rejected'
                        ? AppColors.danger
                        : d.status == 'approved'
                            ? AppColors.lime600
                            : AppColors.warning,
                  ),
                ]),
                muted(d.driverId != null ? _l.name(d.driverId) : _l.plate(d.truckId)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: StoredImage(d.frontPath, height: 140)),
                  if (d.backPath != null) ...[const SizedBox(width: 8), Expanded(child: StoredImage(d.backPath, height: 140))],
                ]),
                const SizedBox(height: 8),
                Text([
                  if (d.number != null) 'No. ${d.number}',
                  if (d.licenceClass != null) 'Class ${d.licenceClass}',
                  if (d.expiresOn != null) 'Expires ${shortDate(d.expiresOn!)} ${d.expiresOn!.year}',
                  'Sent ${shortDate(d.createdAt)}',
                ].join(' · ')),
                if (d.note != null) muted('Note: ${d.note}'),
                const SizedBox(height: 8),
                Row(children: [
                  if (d.status != 'approved')
                    Expanded(child: FilledButton(onPressed: () => _review(d, 'approved'), child: const Text('Approve'))),
                  if (d.status != 'approved' && d.status != 'rejected') const SizedBox(width: 8),
                  if (d.status != 'rejected')
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                        onPressed: () => _review(d, 'rejected'),
                        child: const Text('Reject'),
                      ),
                    ),
                ]),
              ]),
            ),
        ]),
      ],
    );
  }
}
