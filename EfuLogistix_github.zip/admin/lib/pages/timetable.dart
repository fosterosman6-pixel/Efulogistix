import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';
import '../vehicle_art.dart';

/// Admin: the timetable passengers book seats on, hire prices per km, EfuLogistix fees per category,
/// and company monthly accounts.
class TimetablePage extends StatefulWidget {
  const TimetablePage({super.key});

  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  List<RouteFare> _routes = [];
  List<Departure> _deps = [];
  List<VehicleCategory> _cats = [];
  List<CompanyAccount> _accounts = [];
  bool _loading = true;

  static const _dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('routes').select().eq('active', true).order('from_name').order('to_name'),
        db.from('departures').select().order('leaves_at'),
        db.from('vehicle_categories').select().order('name'),
        db.from('company_accounts').select().order('name'),
      ]);
      if (!mounted) return;
      setState(() {
        _routes = r[0].map(RouteFare.fromMap).toList();
        _deps = r[1].map(Departure.fromMap).toList();
        _cats = r[2].map(VehicleCategory.fromMap).toList();
        _accounts = r[3].map(CompanyAccount.fromMap).toList();
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String _cat(String? id) => _cats.where((c) => c.id == id).firstOrNull?.name ?? 'Any';

  Future<void> _editDeparture(RouteFare r, [Departure? d]) async {
    var time = d == null
        ? const TimeOfDay(hour: 7, minute: 0)
        : TimeOfDay(hour: int.parse(d.leavesAt.split(':')[0]), minute: int.parse(d.leavesAt.split(':')[1]));
    final days = {...(d?.days ?? const [1, 2, 3, 4, 5, 6, 7])};
    final seats = TextEditingController(text: d?.seats?.toString() ?? '');
    var active = d?.active ?? true;
    final ok = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text('${r.fromName} → ${r.toName} · ${_cat(r.categoryId)}'),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              OutlinedButton.icon(
                icon: const Icon(Icons.schedule),
                label: Text('Leaves at ${time.format(ctx)}'),
                onPressed: () async {
                  final t = await showTimePicker(context: ctx, initialTime: time);
                  if (t != null) setLocal(() => time = t);
                },
              ),
              const SizedBox(height: 10),
              Wrap(spacing: 6, children: [
                for (var i = 1; i <= 7; i++)
                  FilterChip(
                    label: Text(_dayNames[i - 1]),
                    selected: days.contains(i),
                    onSelected: (v) => setLocal(() {
                      if (v) {
                        days.add(i);
                      } else {
                        days.remove(i);
                      }
                    }),
                  ),
              ]),
              const SizedBox(height: 10),
              TextField(
                controller: seats,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: field('Seats to sell (empty = all seats of the category)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Bookable'),
                value: active,
                onChanged: (v) => setLocal(() => active = v),
              ),
            ]),
          ),
          actions: [
            if (d != null) TextButton(onPressed: () => Navigator.pop(ctx, 'delete'), child: const Text('Delete', style: TextStyle(color: AppColors.danger))),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, 'save'), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok == null || !mounted) return;
    if (ok == 'delete') {
      if (await attempt(context, () => db.from('departures').delete().eq('id', d!.id), done: 'Removed.')) _load();
      return;
    }
    final values = {
      'route_id': r.id,
      'leaves_at': '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:00',
      'days': (days.toList()..sort()),
      'seats': int.tryParse(seats.text.trim()),
      'active': active,
    };
    if (await attempt(context,
        () => d == null ? db.from('departures').insert(values) : db.from('departures').update(values).eq('id', d.id),
        done: 'Saved.')) {
      _load();
    }
  }

  Future<void> _editRates(VehicleCategory c) async {
    final ctl = {
      'hire_per_km': TextEditingController(text: c.hirePerKm.round().toString()),
      'hire_min': TextEditingController(text: c.hireMin.round().toString()),
      'fee_weekly': TextEditingController(text: c.feeWeekly.round().toString()),
      'fee_monthly': TextEditingController(text: c.feeMonthly.round().toString()),
      'fee_per_trip': TextEditingController(text: c.feePerTrip.round().toString()),
    };
    const labels = {
      'hire_per_km': 'Hire: price per km (0 = cannot be hired)',
      'hire_min': 'Hire: smallest price',
      'fee_weekly': 'EfuLogistix fee: weekly',
      'fee_monthly': 'EfuLogistix fee: monthly',
      'fee_per_trip': 'EfuLogistix fee: per trip',
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(children: [VehicleArt(c.name, width: 60), const SizedBox(width: 10), Text(c.name)]),
        content: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final e in ctl.entries) ...[
              TextField(
                controller: e.value,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: field('${labels[e.key]} (MWK)'),
              ),
              const SizedBox(height: 10),
            ],
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(
        context, () => db.from('vehicle_categories').update({for (final e in ctl.entries) e.key: parseAmount(e.value.text)}).eq('id', c.id),
        done: 'Saved. New bookings and bills use these prices.')) {
      _load();
    }
  }

  Future<void> _editAccount([CompanyAccount? a]) async {
    final name = TextEditingController(text: a?.name ?? '');
    final contact = TextEditingController(text: a?.contactName ?? '');
    final phone = TextEditingController(text: a?.phone ?? '');
    final email = TextEditingController(text: a?.email ?? '');
    var active = a?.active ?? true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(a == null ? 'New company account' : a.name),
          content: SizedBox(
            width: 400,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: field('Company name')),
              const SizedBox(height: 10),
              TextField(controller: contact, decoration: field('Contact person')),
              const SizedBox(height: 10),
              TextField(controller: phone, decoration: field('Phone')),
              const SizedBox(height: 10),
              TextField(controller: email, decoration: field('Email for the monthly bill')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Active'),
                value: active,
                onChanged: (v) => setLocal(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted || name.text.trim().isEmpty) return;
    final v = {
      'name': name.text.trim(),
      'contact_name': contact.text.trim(),
      'phone': phone.text.trim(),
      'email': email.text.trim(),
      'active': active,
    };
    if (await attempt(context, () => a == null ? db.from('company_accounts').insert(v) : db.from('company_accounts').update(v).eq('id', a.id),
        done: 'Saved. Link passengers to it on the People page.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final seatRoutes = _routes.where((r) {
      final c = _cats.where((c) => c.id == r.categoryId).firstOrNull;
      return c == null || c.carriesPassengers;
    }).toList();
    return PageFrame(
      title: 'Timetable & rates',
      subtitle: 'What passengers can book: departures on routes (fares are on the Fares page), hire prices, owner fees.',
      onRefresh: _load,
      children: [
        if (_loading) const LinearProgressIndicator(),
        Panel(
          title: 'Departures (book a seat · send goods)',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No routes yet. Add routes and fares on the Fares page.',
            columns: const ['Route', 'Category', 'Fare', 'Departures', ''],
            rows: [
              for (final r in seatRoutes)
                [
                  bold('${r.fromName} → ${r.toName}'),
                  Text(_cat(r.categoryId)),
                  bold(money(r.fare)),
                  Wrap(spacing: 6, runSpacing: 4, children: [
                    for (final d in _deps.where((d) => d.routeId == r.id))
                      ActionChip(
                        label: Text('${d.time}${d.days.length < 7 ? ' (${d.days.map((x) => _dayNames[x - 1]).join(' ')})' : ''}'
                            '${d.seats != null ? ' · ${d.seats} seats' : ''}'),
                        backgroundColor: d.active ? AppColors.lime100 : AppColors.surface100,
                        onPressed: () => _editDeparture(r, d),
                      ),
                  ]),
                  TextButton.icon(onPressed: () => _editDeparture(r), icon: const Icon(Icons.add, size: 18), label: const Text('Time')),
                ],
            ],
          ),
        ),
        Panel(
          title: 'Hire prices and EfuLogistix fees, per category',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            columns: const ['Category', 'Hire per km', 'Smallest hire', 'Fee weekly', 'Fee monthly', 'Fee per trip'],
            rows: [
              for (final c in _cats)
                [
                  Row(children: [VehicleArt(c.name, width: 44), const SizedBox(width: 8), bold(c.name)]),
                  c.hirePerKm > 0 ? bold(money(c.hirePerKm)) : const Pill('Not for hire', color: AppColors.muted),
                  Text(money(c.hireMin)),
                  Text(money(c.feeWeekly)),
                  Text(money(c.feeMonthly)),
                  Text(money(c.feePerTrip)),
                ],
            ],
            onTap: (i) => _editRates(_cats[i]),
          ),
        ),
        Panel(
          title: 'Company accounts (pay once a month)',
          actions: [TextButton.icon(onPressed: () => _editAccount(), icon: const Icon(Icons.add), label: const Text('New account'))],
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No company accounts yet.',
            columns: const ['Company', 'Contact', 'Phone', 'Email', 'Status'],
            rows: [
              for (final a in _accounts)
                [
                  bold(a.name),
                  Text(a.contactName ?? ''),
                  Text(a.phone ?? ''),
                  Text(a.email ?? ''),
                  a.active ? const Pill('Active', color: AppColors.lime600) : const Pill('Closed', color: AppColors.muted),
                ],
            ],
            onTap: (i) => _editAccount(_accounts[i]),
          ),
        ),
      ],
    );
  }
}
