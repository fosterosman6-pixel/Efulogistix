import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../models.dart';
import '../theme.dart';

/// Malawi licence classes (DRTSS). A driver's licence class must be one the category allows.
const licenceClasses = ['A1', 'A', 'B', 'EB', 'C1', 'C', 'EC1', 'EC', 'D1', 'D', 'ED1', 'ED'];

/// Vehicle categories: Matola, Minibus, Lorry, Taxi, Kabaza and any you add.
class CategoriesPage extends StatefulWidget {
  const CategoriesPage({super.key});

  @override
  State<CategoriesPage> createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  final _l = Lookup();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _edit([VehicleCategory? c]) async {
    final name = TextEditingController(text: c?.name ?? '');
    final seats = TextEditingController(text: (c?.seats ?? 0).toString());
    var pax = c?.carriesPassengers ?? true;
    var goods = c?.carriesGoods ?? true;
    var active = c?.active ?? true;
    final classes = <String>{...?c?.licenceClasses};
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(c == null ? 'Add category' : c.name),
          content: SizedBox(
            width: 460,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              TextField(controller: name, decoration: field('Name', hint: 'e.g. Coaster bus')),
              const SizedBox(height: 10),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Carries passengers'),
                value: pax,
                onChanged: (v) => setLocal(() => pax = v ?? pax),
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Carries goods'),
                value: goods,
                onChanged: (v) => setLocal(() => goods = v ?? goods),
              ),
              if (pax)
                TextField(
                  controller: seats,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: field('Passenger seats'),
                ),
              const SizedBox(height: 12),
              const Text('Licence classes allowed to drive it', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final k in licenceClasses)
                  FilterChip(
                    label: Text(k),
                    selected: classes.contains(k),
                    onSelected: (v) => setLocal(() {
                      if (v) {
                        classes.add(k);
                      } else {
                        classes.remove(k);
                      }
                    }),
                  ),
              ]),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('In use'),
                value: active,
                onChanged: (v) => setLocal(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    if (name.text.trim().isEmpty) {
      toast(context, 'Type a name.');
      return;
    }
    final values = {
      'name': name.text.trim(),
      'carries_passengers': pax,
      'carries_goods': goods,
      'seats': pax ? (int.tryParse(seats.text) ?? 0) : 0,
      'licence_classes': [for (final k in licenceClasses) if (classes.contains(k)) k],
      'active': active,
    };
    if (await attempt(
        context,
        () => c == null
            ? db.from('vehicle_categories').insert(values)
            : db.from('vehicle_categories').update(values).eq('id', c.id),
        done: 'Saved.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) => PageFrame(
        title: 'Vehicle categories',
        subtitle: 'Each category has its own fares, seats and the licence classes allowed to drive it.',
        onRefresh: _load,
        actions: [FilledButton.icon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Add category'))],
        children: [
          if (_loading) const LinearProgressIndicator(),
          Panel(
            padding: const EdgeInsets.only(bottom: 8),
            child: SimpleTable(
              columns: const ['Name', 'Carries', 'Seats', 'Licence classes', 'Vehicles', 'Status'],
              rows: [
                for (final c in _l.categories)
                  [
                    bold(c.name),
                    Text([if (c.carriesPassengers) 'Passengers', if (c.carriesGoods) 'Goods'].join(' + ')),
                    Text(c.carriesPassengers ? '${c.seats}' : '—'),
                    Text(c.licenceClasses.join(', ')),
                    Text('${_l.trucks.where((t) => t.categoryId == c.id).length}'),
                    c.active ? const Pill('In use', color: AppColors.lime600) : const Pill('Off', color: AppColors.muted),
                  ],
              ],
              onTap: (i) => _edit(_l.categories[i]),
            ),
          ),
          const Text(
            'Licence classes follow the Malawi DRTSS classes. Please confirm the classes for each category with DRTSS.',
            style: TextStyle(color: AppColors.muted, fontSize: 13),
          ),
        ],
      );
}
