import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Route fares per vehicle category, goods prices, and a raise for all fares at once (e.g. after a fuel price rise).
class FaresPage extends StatefulWidget {
  const FaresPage({super.key});

  @override
  State<FaresPage> createState() => _FaresPageState();
}

class _FaresPageState extends State<FaresPage> {
  final _l = Lookup();
  List<RouteFare> _routes = [];
  List<GoodsPrice> _goods = [];
  String? _category; // null = all
  String _search = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('routes').select().order('from_name').order('to_name'),
        db.from('goods_prices').select().order('label'),
      ]);
      if (!mounted) return;
      setState(() {
        _routes = r[0].map(RouteFare.fromMap).toList();
        _goods = r[1].map(GoodsPrice.fromMap).toList();
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _editRoute([RouteFare? r]) async {
    final from = TextEditingController(text: r?.fromName ?? 'Mangochi Main Rank');
    final to = TextEditingController(text: r?.toName ?? '');
    final fare = TextEditingController(text: r?.fare.round().toString() ?? '');
    final km = TextEditingController(text: r?.km?.round().toString() ?? '');
    final lat = TextEditingController(text: r?.toLat?.toString() ?? '');
    final lng = TextEditingController(text: r?.toLng?.toString() ?? '');
    String? cat = r == null ? (_category ?? _l.categories.firstOrNull?.id) : r.categoryId;
    var active = r?.active ?? true;
    final digits = [FilteringTextInputFormatter.digitsOnly];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(r == null ? 'Add route fare' : '${r.fromName} → ${r.toName}'),
          content: SizedBox(
            width: 460,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              DropdownButtonFormField<String?>(
                value: cat,
                decoration: field('Vehicle category'),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Any vehicle')),
                  for (final c in _l.categories) DropdownMenuItem(value: c.id, child: Text(c.name)),
                ],
                onChanged: (v) => setLocal(() => cat = v),
              ),
              const SizedBox(height: 10),
              TextField(controller: from, decoration: field('From (rank or town)')),
              const SizedBox(height: 10),
              TextField(controller: to, decoration: field('To', hint: 'Monkey Bay')),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: fare, inputFormatters: digits, decoration: field('Fare per passenger (MWK)'))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: km, inputFormatters: digits, decoration: field('Distance km (optional)'))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: lat, decoration: field('Destination latitude (optional)'))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: lng, decoration: field('Longitude (optional)'))),
              ]),
              const SizedBox(height: 4),
              const Text(
                'For lorries and goods-only vehicles, the fare is the price for the whole load. '
                'Without a latitude/longitude the app finds the place on the map by name.',
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('In use'),
                value: active,
                onChanged: (v) => setLocal(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    if (from.text.trim().isEmpty || to.text.trim().isEmpty || fare.text.isEmpty) {
      toast(context, 'Fill in from, to and fare.');
      return;
    }
    final values = {
      'category_id': cat,
      'from_name': from.text.trim(),
      'to_name': to.text.trim(),
      'fare': parseAmount(fare.text),
      'km': double.tryParse(km.text),
      'to_lat': double.tryParse(lat.text.trim()),
      'to_lng': double.tryParse(lng.text.trim()),
      'active': active,
      'updated_by': db.auth.currentUser?.id,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    if (await attempt(context,
        () => r == null ? db.from('routes').insert(values) : db.from('routes').update(values).eq('id', r.id),
        done: 'Fare saved. Drivers see it on their next trip.')) {
      _load();
    }
  }

  /// Copies all fares of one category to another, e.g. Matola fares as a start for Minibus.
  Future<void> _copyFares() async {
    String? fromCat = _l.categories.firstOrNull?.id;
    String? toCat;
    var pct = 0.0;
    final pctCtl = TextEditingController(text: '0');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Copy fares to another category'),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String?>(
                value: fromCat,
                decoration: field('From'),
                items: [for (final c in _l.categories) DropdownMenuItem(value: c.id, child: Text(c.name))],
                onChanged: (v) => setLocal(() => fromCat = v),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String?>(
                value: toCat,
                decoration: field('To'),
                items: [for (final c in _l.categories) DropdownMenuItem(value: c.id, child: Text(c.name))],
                onChanged: (v) => setLocal(() => toCat = v),
              ),
              const SizedBox(height: 10),
              TextField(controller: pctCtl, decoration: field('Change by % (e.g. 20 or -10)')),
              const SizedBox(height: 6),
              const Text('Routes the other category already has are left as they are.',
                  style: TextStyle(fontSize: 12, color: AppColors.muted)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Copy')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted || fromCat == null || toCat == null || fromCat == toCat) return;
    pct = double.tryParse(pctCtl.text.trim()) ?? 0;
    final have = {for (final r in _routes.where((r) => r.categoryId == toCat)) '${r.fromName}|${r.toName}'};
    final rows = [
      for (final r in _routes.where((r) => r.categoryId == fromCat && !have.contains('${r.fromName}|${r.toName}')))
        {
          'category_id': toCat,
          'from_name': r.fromName,
          'to_name': r.toName,
          'to_lat': r.toLat,
          'to_lng': r.toLng,
          'km': r.km,
          'fare': ((r.fare * (1 + pct / 100)) / 500).ceil() * 500,
          'active': r.active,
        },
    ];
    if (rows.isEmpty) {
      toast(context, 'Nothing to copy.');
      return;
    }
    if (await attempt(context, () => db.from('routes').insert(rows), done: 'Copied ${rows.length} fares.')) _load();
  }

  Future<void> _raise() async {
    final pct = TextEditingController(text: '10');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Raise all fares'),
        content: SizedBox(
          width: 380,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Every route fare and goods price in use goes up by this percentage, rounded up to the next K500.'),
            const SizedBox(height: 12),
            TextField(
              controller: pct,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: field('Percent'),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Raise fares')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final p = int.tryParse(pct.text) ?? 0;
    if (!await confirm(context, 'Raise all fares by $p%?', 'This changes the fares drivers charge from their next trip.',
        yes: 'Raise')) {
      return;
    }
    if (!mounted) return;
    if (await attempt(context, () => db.rpc('raise_fares', params: {'p_pct': p}), done: 'All fares raised by $p%.')) {
      _load();
    }
  }

  Future<void> _editGoods([GoodsPrice? g]) async {
    final label = TextEditingController(text: g?.label ?? '');
    final price = TextEditingController(text: g?.price.round().toString() ?? '');
    var active = g?.active ?? true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(g == null ? 'Add goods price' : g.label),
          content: SizedBox(
            width: 380,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: label, decoration: field('Item', hint: '50 kg bag of maize')),
              const SizedBox(height: 10),
              TextField(
                controller: price,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: field('Price (MWK)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('In use'),
                value: active,
                onChanged: (v) => setLocal(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted || label.text.trim().isEmpty) return;
    final values = {
      'label': label.text.trim(),
      'price': parseAmount(price.text),
      'active': active,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    if (await attempt(context,
        () => g == null ? db.from('goods_prices').insert(values) : db.from('goods_prices').update(values).eq('id', g.id),
        done: 'Saved.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _search.toLowerCase();
    final routes = _routes
        .where((r) => _category == null || r.categoryId == _category)
        .where((r) => s.isEmpty || r.fromName.toLowerCase().contains(s) || r.toName.toLowerCase().contains(s))
        .toList();
    return PageFrame(
      title: 'Fares',
      subtitle: 'Only you set fares. Drivers pick a route and the fare is fixed.',
      onRefresh: _load,
      actions: [
        OutlinedButton.icon(onPressed: _copyFares, icon: const Icon(Icons.copy_all), label: const Text('Copy to category')),
        OutlinedButton.icon(onPressed: _raise, icon: const Icon(Icons.trending_up), label: const Text('Raise all')),
        FilledButton.icon(onPressed: () => _editRoute(), icon: const Icon(Icons.add), label: const Text('Add route')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          ChoiceChip(label: const Text('All'), selected: _category == null, onSelected: (_) => setState(() => _category = null)),
          for (final c in _l.categories)
            ChoiceChip(label: Text(c.name), selected: _category == c.id, onSelected: (_) => setState(() => _category = c.id)),
          SizedBox(
            width: 220,
            child: TextField(decoration: field('Search place'), onChanged: (v) => setState(() => _search = v)),
          ),
        ]),
        const SizedBox(height: 16),
        Panel(
          title: 'Route fares (${routes.length})',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No fares yet. Use Add route.',
            columns: const ['From', 'To', 'Category', 'Km', 'Fare', 'Status'],
            rows: [
              for (final r in routes)
                [
                  Text(r.fromName),
                  bold(r.toName),
                  Text(_l.category(r.categoryId)?.name ?? 'Any vehicle'),
                  Text(r.km?.round().toString() ?? '—'),
                  bold(money(r.fare)),
                  r.active ? const Pill('In use', color: AppColors.lime600) : const Pill('Off', color: AppColors.muted),
                ],
            ],
            onTap: (i) => _editRoute(routes[i]),
          ),
        ),
        Panel(
          title: 'Goods prices',
          actions: [TextButton.icon(onPressed: () => _editGoods(), icon: const Icon(Icons.add), label: const Text('Add'))],
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No goods prices yet.',
            columns: const ['Item', 'Price', 'Status'],
            rows: [
              for (final g in _goods)
                [
                  Text(g.label),
                  bold(money(g.price)),
                  g.active ? const Pill('In use', color: AppColors.lime600) : const Pill('Off', color: AppColors.muted),
                ],
            ],
            onTap: (i) => _editGoods(_goods[i]),
          ),
        ),
      ],
    );
  }
}
