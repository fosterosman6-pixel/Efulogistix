import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Shifts by day with odometer against GPS, truck changes waiting, and each trip with its stops on the map.
class ShiftsPage extends StatefulWidget {
  const ShiftsPage({super.key});

  @override
  State<ShiftsPage> createState() => _ShiftsPageState();
}

class _ShiftsPageState extends State<ShiftsPage> {
  final _l = Lookup();
  DateTime _day = DateTime.now();
  List<Shift> _shifts = [];
  List<TruckChange> _changes = [];
  Set<String> _mismatch = {};
  Map<String, double> _collected = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final from = DateTime(_day.year, _day.month, _day.day);
      final to = from.add(const Duration(days: 1));
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('shifts').select().gte('started_at', isoUtc(from)).lt('started_at', isoUtc(to)).order('started_at'),
        db.from('truck_changes').select().eq('status', 'pending').order('created_at'),
        db.from('trips').select('shift_id,total').neq('status', 'cancelled').gte('started_at', isoUtc(from)).lt('started_at', isoUtc(to)),
      ]);
      final shifts = r[0].map(Shift.fromMap).toList();
      var mismatch = <String>{};
      if (shifts.isNotEmpty) {
        final bad = await db
            .from('odometer_readings')
            .select('shift_id')
            .eq('mismatch', true)
            .inFilter('shift_id', [for (final s in shifts) s.id]);
        mismatch = {for (final b in bad) b['shift_id'].toString()};
      }
      final collected = <String, double>{};
      for (final t in r[2]) {
        final sid = t['shift_id']?.toString();
        if (sid != null) collected[sid] = (collected[sid] ?? 0) + toDouble(t['total']);
      }
      if (!mounted) return;
      setState(() {
        _shifts = shifts;
        _changes = r[1].map(TruckChange.fromMap).toList();
        _mismatch = mismatch;
        _collected = collected;
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _decideChange(TruckChange c, bool approve) async {
    if (!await confirm(context, approve ? 'Approve truck change?' : 'Decline truck change?',
        '${_l.name(c.driverId)}: ${_l.plate(c.fromTruck)} → ${_l.plate(c.toTruck)}',
        yes: approve ? 'Approve' : 'Decline')) {
      return;
    }
    if (!mounted) return;
    if (await attempt(context, () => db.rpc('decide_truck_change', params: {'p_id': c.id, 'p_approve': approve}))) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'Shifts & trips',
      subtitle: 'Odometer photos are compared with GPS. Open a shift to see every photo and trip.',
      onRefresh: _load,
      actions: [
        IconButton(
          onPressed: () {
            _day = _day.subtract(const Duration(days: 1));
            _load();
          },
          icon: const Icon(Icons.chevron_left),
        ),
        DateButton(label: 'Day', value: _day, onChanged: (d) {
          _day = d ?? DateTime.now();
          _load();
        }),
        IconButton(
          onPressed: () {
            _day = _day.add(const Duration(days: 1));
            _load();
          },
          icon: const Icon(Icons.chevron_right),
        ),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        if (_changes.isNotEmpty)
          Panel(
            title: 'Truck changes waiting (${_changes.length})',
            child: Column(children: [
              for (final c in _changes)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Wrap(spacing: 12, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
                    SizedBox(
                      width: 320,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        bold('${_l.name(c.driverId)}: ${_l.plate(c.fromTruck)} → ${_l.plate(c.toTruck)}'),
                        muted('${c.reason}${c.note != null ? ' · ${c.note}' : ''} · out ${c.outKm} km · in ${c.inKm} km · '
                            '${clock(c.createdAt)}'),
                      ]),
                    ),
                    StoredImage(c.outPhoto, height: 60, width: 80),
                    StoredImage(c.inPhoto, height: 60, width: 80),
                    for (final p in c.inTruckPhotos) StoredImage(p, height: 60, width: 80),
                    FilledButton(onPressed: () => _decideChange(c, true), child: const Text('Approve')),
                    OutlinedButton(onPressed: () => _decideChange(c, false), child: const Text('Decline')),
                  ]),
                ),
            ]),
          ),
        Panel(
          title: 'Shifts · ${shortDate(_day)}',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No shifts on this day.',
            columns: const ['Driver', 'Vehicle', 'Time', 'Odometer', 'GPS', 'Collected', 'Check'],
            rows: [
              for (final s in _shifts)
                [
                  bold(_l.name(s.driverId)),
                  Text(_l.plate(s.truckId)),
                  Text('${clock(s.startedAt)}–${s.onDuty ? 'now' : clock(s.endedAt)}'),
                  Text('${s.startKm} → ${s.endKm ?? '…'}${s.odometerKm != null ? ' (${s.odometerKm} km)' : ''}'),
                  Text('${s.gpsKm.round()} km'),
                  Text(money(_collected[s.id])),
                  s.onDuty
                      ? const Pill('On duty', color: AppColors.lime600)
                      : s.review == 'approved'
                          ? const Pill('Approved')
                          : s.review == 'flagged'
                              ? const Pill('Flagged', color: AppColors.danger)
                              : _mismatch.contains(s.id)
                                  ? const Pill('Check km', color: AppColors.warning)
                                  : const Pill('To review', color: AppColors.muted),
                ],
            ],
            onTap: (i) async {
              await showDialog<void>(context: context, builder: (_) => ShiftDialog(shift: _shifts[i], l: _l));
              _load();
            },
          ),
        ),
      ],
    );
  }
}

class ShiftDialog extends StatefulWidget {
  final Shift shift;
  final Lookup l;
  const ShiftDialog({super.key, required this.shift, required this.l});

  @override
  State<ShiftDialog> createState() => _ShiftDialogState();
}

class _ShiftDialogState extends State<ShiftDialog> {
  List<Reading> _readings = [];
  List<Trip> _trips = [];
  final _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    _note.text = widget.shift.reviewNote ?? '';
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('odometer_readings').select().eq('shift_id', widget.shift.id).order('taken_at'),
        db.from('trips').select().eq('shift_id', widget.shift.id).order('started_at'),
      ]);
      if (!mounted) return;
      setState(() {
        _readings = r[0].map(Reading.fromMap).toList();
        _trips = r[1].map(Trip.fromMap).toList();
      });
    } catch (_) {}
  }

  Future<void> _review(String review) async {
    final ok = await attempt(
        context,
        () => db.from('shifts').update({
              'review': review,
              'review_note': _note.text.trim().isEmpty ? null : _note.text.trim(),
              'reviewed_by': db.auth.currentUser?.id,
            }).eq('id', widget.shift.id));
    if (ok && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.shift;
    final l = widget.l;
    return Dialog(
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: ListView(padding: const EdgeInsets.all(24), shrinkWrap: true, children: [
          Row(children: [
            Expanded(
              child: Text('${l.name(s.driverId)} · ${l.plate(s.truckId)}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ),
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
          ]),
          muted('${shortDate(s.startedAt)} · ${clock(s.startedAt)}–${s.onDuty ? 'now' : clock(s.endedAt)} · '
              'odometer ${s.odometerKm ?? '…'} km · GPS ${s.gpsKm.round()} km'
              '${s.endReason == 'truck_change' ? ' · ended by truck change' : ''}'),
          const SizedBox(height: 16),
          const Text('Mileage photos', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Wrap(spacing: 12, runSpacing: 12, children: [
            for (final r in _readings)
              Container(
                width: 190,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: r.mismatch ? AppColors.warning : AppColors.line, width: r.mismatch ? 2 : 1),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  StoredImage(r.photoPath, height: 110),
                  const SizedBox(height: 6),
                  bold('${r.kindName} · ${r.km} km'),
                  muted('${clock(r.takenAt)}${r.expectedKm != null ? ' · GPS expects ~${r.expectedKm}' : ''}'),
                  if (r.mismatch) const Pill('Check', color: AppColors.warning),
                ]),
              ),
          ]),
          if (s.startTruckPhotos.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('Vehicle photos at the start of the day', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in s.startTruckPhotos) StoredImage(p, height: 110, width: 150),
            ]),
          ],
          if (s.truckPhotos.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('Vehicle photos at the end of the day', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in s.truckPhotos) StoredImage(p, height: 110, width: 150),
            ]),
          ],
          const SizedBox(height: 16),
          const Text('Trips', style: TextStyle(fontWeight: FontWeight.w800)),
          SimpleTable(
            empty: 'No trips',
            columns: const ['#', 'Route', 'Time', 'Pax', 'Km', 'Amount', 'Status'],
            rows: [
              for (final t in _trips)
                [
                  Text('${t.tripNo}'),
                  Text('${t.pickupName} → ${t.destName}'),
                  Text('${clock(t.startedAt)}–${t.running ? 'now' : clock(t.endedAt)}'),
                  Text('${t.carried}'),
                  Text('${t.odometerKm ?? '—'}'),
                  bold(money(t.total)),
                  Text(t.status.replaceAll('_', ' ')),
                ],
            ],
            onTap: (i) => showDialog<void>(context: context, builder: (_) => TripDialog(trip: _trips[i], l: l)),
          ),
          const SizedBox(height: 16),
          TextField(controller: _note, decoration: field('Review note (optional)')),
          const SizedBox(height: 12),
          if (!s.onDuty)
            Wrap(spacing: 8, children: [
              FilledButton(onPressed: () => _review('approved'), child: const Text('Approve shift')),
              OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                onPressed: () => _review('flagged'),
                child: const Text('Flag'),
              ),
            ]),
        ]),
      ),
    );
  }
}

/// One trip: map with the start, every stop (numbered) and the destination.
class TripDialog extends StatefulWidget {
  final Trip trip;
  final Lookup l;
  const TripDialog({super.key, required this.trip, required this.l});

  @override
  State<TripDialog> createState() => _TripDialogState();
}

class _TripDialogState extends State<TripDialog> {
  List<TripStop> _stops = [];

  @override
  void initState() {
    super.initState();
    db.from('trip_stops').select().eq('trip_id', widget.trip.id).order('at').then((rows) {
      if (mounted) setState(() => _stops = rows.map(TripStop.fromMap).toList());
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.trip;
    final pts = <LatLng>[
      if (t.pickupLat != null && t.pickupLng != null) LatLng(t.pickupLat!, t.pickupLng!),
      for (final s in _stops)
        if (s.lat != null && s.lng != null) LatLng(s.lat!, s.lng!),
      LatLng(t.destLat, t.destLng),
    ];
    Widget pin(String text, Color color) => Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
          child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
        );
    return Dialog(
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 820),
        child: ListView(padding: const EdgeInsets.all(24), shrinkWrap: true, children: [
          Row(children: [
            Expanded(
              child: Text('Trip #${t.tripNo} · ${t.pickupName} → ${t.destName}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
          ]),
          muted('${widget.l.name(t.driverId)} · ${widget.l.plate(t.truckId)} · ${money(t.total)} · ${t.carried} carried'
              '${t.cargoKg != null ? ' · ${t.cargoKg!.round()} kg' : ''}'),
          const SizedBox(height: 12),
          SizedBox(
            height: 340,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: FlutterMap(
                options: MapOptions(
                  initialCenter: pts.first,
                  initialZoom: 11,
                  initialCameraFit: pts.length < 2
                      ? null
                      : CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.all(40)),
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'mw.efulogistix.admin',
                  ),
                  PolylineLayer(polylines: [Polyline(points: pts, strokeWidth: 3, color: AppColors.navy)]),
                  MarkerLayer(markers: [
                    if (t.pickupLat != null && t.pickupLng != null)
                      Marker(point: LatLng(t.pickupLat!, t.pickupLng!), width: 26, height: 26, child: pin('S', AppColors.lime600)),
                    for (var i = 0; i < _stops.length; i++)
                      if (_stops[i].lat != null && _stops[i].lng != null)
                        Marker(
                          point: LatLng(_stops[i].lat!, _stops[i].lng!),
                          width: 26,
                          height: 26,
                          child: pin(_stops[i].auto ? '?' : '${i + 1}', _stops[i].auto ? AppColors.warning : AppColors.navy),
                        ),
                    Marker(point: LatLng(t.destLat, t.destLng), width: 26, height: 26, child: pin('E', AppColors.danger)),
                  ]),
                  const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          SimpleTable(
            empty: 'No stops on the way',
            columns: const ['#', 'Place', 'Time', 'Off', 'On', 'Amount'],
            rows: [
              for (var i = 0; i < _stops.length; i++)
                [
                  Text(_stops[i].auto ? '?' : '${i + 1}'),
                  Text(_stops[i].auto ? 'Stopped, not saved by driver' : (_stops[i].placeName ?? 'Stop')),
                  Text(clock(_stops[i].at)),
                  Text('${_stops[i].dropped}${_stops[i].goodsOff != null ? ' + ${_stops[i].goodsOff}' : ''}'),
                  Text('${_stops[i].picked}${_stops[i].pickedTo != null ? ' to ${_stops[i].pickedTo}' : ''}'),
                  Text(money(_stops[i].amount)),
                ],
            ],
          ),
        ]),
      ),
    );
  }
}
