import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';
import '../vehicle_art.dart';

/// Passenger bookings: passengers book in the phone app; managers and the admin assign them here.
class BookingsPage extends StatefulWidget {
  const BookingsPage({super.key});

  @override
  State<BookingsPage> createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage> {
  final _l = Lookup();
  List<Booking> _rows = [];
  List<Map<String, dynamic>> _onDuty = []; // open shifts
  List<Map<String, dynamic>> _locations = [];
  List<RouteFare> _routes = [];
  List<Departure> _departures = [];
  List<CompanyAccount> _accounts = [];
  String _tab = 'new';
  DateTime _day = DateTime.now();
  Booking? _selected;
  bool _loading = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _load(quiet: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool quiet = false}) async {
    if (!quiet) setState(() => _loading = true);
    try {
      await _l.load();
      final from = DateTime(_day.year, _day.month, _day.day).subtract(const Duration(days: 1));
      final to = DateTime(_day.year, _day.month, _day.day).add(const Duration(days: 8));
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('bookings').select().gte('pickup_at', isoUtc(from)).lt('pickup_at', isoUtc(to)).order('pickup_at'),
        db.from('bookings').select().eq('status', 'requested').order('pickup_at'),
        db.from('shifts').select().eq('status', 'on_duty'),
        db.from('truck_locations').select(),
        db.from('routes').select(),
        db.from('departures').select(),
        db.from('company_accounts').select().order('name'),
      ]);
      final all = <String, Booking>{};
      for (final m in [...r[0], ...r[1]]) {
        final b = Booking.fromMap(m);
        all[b.id] = b;
      }
      if (!mounted) return;
      setState(() {
        _rows = all.values.toList()..sort((a, b) => a.pickupAt.compareTo(b.pickupAt));
        _onDuty = r[2];
        _locations = r[3];
        _routes = r[4].map(RouteFare.fromMap).toList();
        _departures = r[5].map(Departure.fromMap).toList();
        _accounts = r[6].map(CompanyAccount.fromMap).toList();
        if (_selected != null) _selected = all[_selected!.id];
      });
    } catch (e) {
      if (mounted && !quiet) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  List<Booking> get _shown => switch (_tab) {
        'new' => _rows.where((b) => b.status == 'requested').toList(),
        'assigned' => _rows.where((b) => (b.status == 'assigned' || b.status == 'picked_up') && _sameDay(b.pickupAt, _day)).toList(),
        _ => _rows.where((b) => !b.open && _sameDay(b.pickupAt, _day)).toList(),
      };

  String _who(Booking b) {
    final p = _l.person(b.passengerId);
    if (p != null) {
      final acc = _accounts.where((a) => a.id == p.accountId).firstOrNull;
      return '${p.displayName}${p.phone != null ? ' · ${p.phone}' : ''}${acc != null ? ' · ${acc.name}' : ''}';
    }
    return '${b.callerName ?? 'Caller'}${b.callerPhone != null ? ' · ${b.callerPhone}' : ''} (phoned)';
  }

  Future<void> _decline(Booking b) async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Decline booking #${b.bookingNo}'),
        content: SizedBox(
          width: 400,
          child: TextField(controller: reason, decoration: field('Reason (the passenger sees it)', hint: 'e.g. No taxi free at 14:00')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Decline')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(context, () => db.rpc('decline_booking', params: {'p_id': b.id, 'p_reason': reason.text.trim()}),
        done: 'Declined. The passenger got a message.')) {
      setState(() => _selected = null);
      _load();
    }
  }

  /// Gives every waiting seat or goods booking of the same departure and day to one vehicle.
  Future<void> _assignDeparture(Booking b, String truckId, String message) async {
    final same = _rows
        .where((x) => x.status == 'requested' && x.departureId != null && x.departureId == b.departureId && x.travelOn == b.travelOn)
        .toList();
    var ok = 0;
    for (final x in same) {
      try {
        await db.rpc('assign_booking', params: {'p_id': x.id, 'p_truck': truckId, 'p_message': message});
        ok++;
      } catch (e) {
        if (mounted) toast(context, '#${x.bookingNo}: ${friendlyError(e)}');
      }
    }
    if (mounted) toast(context, '$ok bookings given to ${_l.truck(truckId)?.plate ?? 'the vehicle'}.');
    setState(() => _selected = null);
    _load();
  }

  Future<void> _assign(Booking b, String truckId, String message) async {
    if (await attempt(context, () => db.rpc('assign_booking', params: {'p_id': b.id, 'p_truck': truckId, 'p_message': message}),
        done: 'Assigned. Passenger and driver got a message.')) {
      setState(() => _selected = null);
      _load();
    }
  }

  Future<void> _forCaller() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _CallerBookingDialog(l: _l, routes: _routes, departures: _departures, accounts: _accounts),
    );
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final shown = _shown;
    final newCount = _rows.where((b) => b.status == 'requested').length;
    final wide = MediaQuery.of(context).size.width >= 1250;
    final list = Panel(
      padding: const EdgeInsets.only(bottom: 8),
      child: SimpleTable(
        empty: _tab == 'new' ? 'No new bookings.' : 'Nothing on this day.',
        columns: const ['#', 'When', 'Passenger', 'What', 'Price · pay', 'Vehicle', 'Status'],
        rows: [
          for (final b in shown)
            [
              Text('${b.bookingNo}'),
              Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                bold('${shortDate(b.pickupAt)} ${clock(b.pickupAt)}'),
                muted(b.kind == 'seat' ? 'Seat' : b.kind == 'goods' ? 'Goods' : 'Hire'),
              ]),
              SizedBox(width: 220, child: Text(_who(b), maxLines: 2, overflow: TextOverflow.ellipsis)),
              SizedBox(
                width: 260,
                child: Row(children: [
                  VehicleArt(_l.category(b.categoryId)?.name, width: 44),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '${b.title}${b.kind == 'seat' ? ' · ${b.seats} seats' : ''}${b.kind == 'hire' && b.km != null ? ' · ${kmText(b.km)}' : ''}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ]),
              ),
              Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                bold(money(b.amount)),
                muted('${b.payName}${b.payReference != null ? ' · ${b.payReference}' : ''}'),
              ]),
              Text(b.truckId == null ? '—' : '${_l.truck(b.truckId)?.plate ?? ''} · ${_l.person(b.driverId)?.firstName ?? ''}'),
              Pill(b.statusName,
                  color: switch (b.status) {
                    'requested' => AppColors.warning,
                    'assigned' || 'picked_up' => AppColors.lime600,
                    'completed' => AppColors.navy,
                    _ => AppColors.danger,
                  }),
            ],
        ],
        onTap: (i) => setState(() => _selected = shown[i]),
      ),
    );
    final sel = _selected;
    final panel = sel == null
        ? null
        : _AssignPanel(
            key: ValueKey(sel.id),
            booking: sel,
            l: _l,
            who: _who(sel),
            onDuty: _onDuty,
            locations: _locations,
            bookings: _rows,
            onAssign: (truck, msg) => _assign(sel, truck, msg),
            onAssignAll: sel.departureId == null ? null : (truck, msg) => _assignDeparture(sel, truck, msg),
            onDecline: () => _decline(sel),
            onClose: () => setState(() => _selected = null),
          );
    return PageFrame(
      title: 'Bookings',
      subtitle: 'Passengers book in the app; assign each booking to a vehicle and its driver. Both get a message.',
      onRefresh: _load,
      actions: [
        DateButton(label: 'Day', value: _day, onChanged: (d) {
          setState(() => _day = d ?? _day);
          _load();
        }),
        FilledButton.icon(onPressed: _forCaller, icon: const Icon(Icons.add_call), label: const Text('Booking for a caller')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'new', label: Text('New ($newCount)')),
            ButtonSegment(value: 'assigned', label: Text('Assigned (${_rows.where((b) => (b.status == 'assigned' || b.status == 'picked_up') && _sameDay(b.pickupAt, _day)).length})')),
            const ButtonSegment(value: 'done', label: Text('Done / cancelled')),
          ],
          selected: {_tab},
          onSelectionChanged: (v) => setState(() {
            _tab = v.first;
            _selected = null;
          }),
        ),
        const SizedBox(height: 16),
        if (wide)
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: list),
            if (panel != null) ...[const SizedBox(width: 16), SizedBox(width: 420, child: panel)],
          ])
        else ...[
          if (panel != null) panel,
          list,
        ],
      ],
    );
  }
}

class _AssignPanel extends StatefulWidget {
  final Booking booking;
  final Lookup l;
  final String who;
  final List<Map<String, dynamic>> onDuty;
  final List<Map<String, dynamic>> locations;
  final List<Booking> bookings;
  final void Function(String truckId, String message) onAssign;
  final void Function(String truckId, String message)? onAssignAll;
  final VoidCallback onDecline;
  final VoidCallback onClose;
  const _AssignPanel({
    super.key,
    required this.booking,
    required this.l,
    required this.who,
    required this.onDuty,
    required this.locations,
    required this.bookings,
    required this.onAssign,
    this.onAssignAll,
    required this.onDecline,
    required this.onClose,
  });

  @override
  State<_AssignPanel> createState() => _AssignPanelState();
}

class _AssignPanelState extends State<_AssignPanel> {
  String? _truck;
  final _message = TextEditingController();
  bool _otherTypes = false;

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  /// Other bookings this vehicle already has within 2 hours of this one.
  List<Booking> _busy(String truckId) {
    final b = widget.booking;
    return widget.bookings
        .where((x) =>
            x.id != b.id &&
            x.truckId == truckId &&
            (x.status == 'assigned' || x.status == 'picked_up') &&
            x.pickupAt.difference(b.pickupAt).inMinutes.abs() < 120 &&
            x.departureId != b.departureId)
        .toList();
  }

  String _info(Truck t) {
    final onDuty = widget.onDuty.any((s) => s['truck_id'] == t.id);
    final loc = widget.locations.where((l) => l['truck_id'] == t.id).firstOrNull;
    final busy = _busy(t.id);
    final b = widget.booking;
    final parts = <String>[
      onDuty ? 'On duty' : 'Off duty',
      if (loc != null && b.pickupLat != null)
        '${kmBetween(toDouble(loc['lat']), toDouble(loc['lng']), b.pickupLat!, b.pickupLng!).toStringAsFixed(1)} km from pickup',
      if (busy.isNotEmpty) 'busy ${clock(busy.first.pickupAt)}',
    ];
    if (b.kind == 'seat' && b.departureId != null) {
      final booked = widget.bookings
          .where((x) => x.truckId == t.id && x.departureId == b.departureId && x.travelOn == b.travelOn && x.open)
          .fold<int>(0, (s, x) => s + x.seats);
      final seats = t.seats ?? widget.l.category(t.categoryId)?.seats ?? 0;
      parts.add('$booked/$seats seats booked');
    }
    return parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final l = widget.l;
    final cat = l.category(b.categoryId);
    final candidates = l.trucks
        .where((t) => t.approved && t.active && (_otherTypes || t.categoryId == b.categoryId))
        .where((t) => l.drivers.any((d) => d.truckId == t.id && d.active))
        .toList()
      ..sort((a, c) {
        int score(Truck t) =>
            (widget.onDuty.any((s) => s['truck_id'] == t.id) ? 0 : 2) + (_busy(t.id).isEmpty ? 0 : 1) + (t.categoryId == b.categoryId ? 0 : 4);
        return score(a).compareTo(score(c));
      });
    final chosen = _truck == null ? null : l.truck(_truck);
    final repriced = chosen != null && b.kind == 'hire' && chosen.categoryId != b.categoryId
        ? l.category(chosen.categoryId)?.hirePrice(b.km ?? 0)
        : null;
    return Panel(
      title: 'Booking #${b.bookingNo}',
      actions: [IconButton(onPressed: widget.onClose, icon: const Icon(Icons.close))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          VehicleTile(cat?.name, width: 60),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              muted('${shortDate(b.pickupAt)} ${clock(b.pickupAt)} · ${cat?.name ?? ''}'
                  '${b.kind == 'seat' ? ' · ${b.seats} seats' : ''}${b.km != null ? ' · ${kmText(b.km)}' : ''}'),
            ]),
          ),
        ]),
        const SizedBox(height: 8),
        Text(widget.who, style: const TextStyle(fontWeight: FontWeight.w600)),
        Text('${b.kind == 'hire' ? 'Estimate ' : ''}${money(b.amount)} · ${b.payName}${b.payReference != null ? ' · ref ${b.payReference}' : ''}'),
        if (b.kind == 'goods' || b.receiverName != null) muted('Receiver: ${b.receiverName ?? ''} · ${b.receiverPhone ?? ''}'),
        if (b.note != null) muted('Note: ${b.note}'),
        if (b.open) ...[
          const Divider(height: 24),
          Row(children: [
            Expanded(child: Text(_otherTypes ? 'ALL VEHICLES WITH A DRIVER' : '${(cat?.name ?? 'VEHICLES').toUpperCase()} WITH A DRIVER',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.muted))),
            TextButton(onPressed: () => setState(() => _otherTypes = !_otherTypes), child: Text(_otherTypes ? 'Same type only' : 'Other types')),
          ]),
          if (candidates.isEmpty) muted('No vehicle of this type has a driver. Try other types.'),
          for (final t in candidates.take(12))
            RadioListTile<String>(
              dense: true,
              contentPadding: EdgeInsets.zero,
              value: t.id,
              groupValue: _truck,
              onChanged: (v) => setState(() => _truck = v),
              title: Text('${l.plate(t.id)} · ${l.drivers.where((d) => d.truckId == t.id).map((d) => d.firstName).join(', ')}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(_info(t)),
              secondary: _busy(t.id).isNotEmpty ? const Pill('Busy', color: AppColors.warning) : null,
            ),
          if (repriced != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('Another type: new price ${money(repriced)} · tell the passenger',
                  style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
            ),
          const SizedBox(height: 10),
          TextField(controller: _message, decoration: field('Message to the passenger (optional)', hint: 'e.g. Driver calls 10 min before')),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _truck == null ? null : () => widget.onAssign(_truck!, _message.text.trim()),
            child: Text(chosen == null ? 'Choose a vehicle' : 'Assign ${chosen.plate}'),
          ),
          if (widget.onAssignAll != null && b.status == 'requested') ...[
            const SizedBox(height: 6),
            OutlinedButton(
              onPressed: _truck == null ? null : () => widget.onAssignAll!(_truck!, _message.text.trim()),
              child: const Text('Same vehicle for all waiting bookings of this departure'),
            ),
          ],
          const SizedBox(height: 6),
          TextButton(onPressed: widget.onDecline, child: const Text('Decline with a reason', style: TextStyle(color: AppColors.danger))),
        ],
      ]),
    );
  }
}

/// Book for someone who phoned the office.
class _CallerBookingDialog extends StatefulWidget {
  final Lookup l;
  final List<RouteFare> routes;
  final List<Departure> departures;
  final List<CompanyAccount> accounts;
  const _CallerBookingDialog({required this.l, required this.routes, required this.departures, required this.accounts});

  @override
  State<_CallerBookingDialog> createState() => _CallerBookingDialogState();
}

class _CallerBookingDialogState extends State<_CallerBookingDialog> {
  String _kind = 'seat';
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _from = TextEditingController();
  final _to = TextEditingController();
  final _km = TextEditingController();
  final _note = TextEditingController();
  int _seats = 1;
  DateTime _day = DateTime.now();
  TimeOfDay _time = TimeOfDay.now();
  String? _departure;
  String? _category;
  String _pay = 'cash';
  String? _account;
  String _tripType = 'one_way';
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _phone, _from, _to, _km, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty) {
      toast(context, 'Type the caller\'s name and phone.');
      return;
    }
    final p = <String, dynamic>{
      'kind': _kind,
      'caller_name': _name.text.trim(),
      'caller_phone': _phone.text.trim(),
      'pay_method': _pay,
      'account_id': _pay == 'account' ? _account : null,
      'note': _note.text.trim(),
    };
    if (_kind == 'seat') {
      if (_departure == null) {
        toast(context, 'Choose the departure.');
        return;
      }
      p.addAll({'departure_id': _departure, 'travel_on': dateOnly(_day), 'seats': _seats});
    } else {
      final at = DateTime(_day.year, _day.month, _day.day, _time.hour, _time.minute);
      final from = _from.text.trim(), to = _to.text.trim();
      if (_category == null || from.isEmpty || to.isEmpty || (double.tryParse(_km.text.trim()) ?? 0) <= 0) {
        toast(context, 'Choose the vehicle type, places and distance.');
        return;
      }
      p.addAll({
        'category_id': _category,
        'pickup_name': from,
        'dest_name': to,
        'km': double.parse(_km.text.trim()),
        'trip_type': _tripType,
        'pickup_at': at.toUtc().toIso8601String(),
      });
    }
    setState(() => _busy = true);
    final ok = await attempt(context, () => db.rpc('book', params: {'p': p}), done: 'Booked. Now assign it.');
    if (mounted) setState(() => _busy = false);
    if (ok && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final deps = widget.departures.where((d) => d.active && d.runsOn(_day)).toList()
      ..sort((a, b) => '${widget.routes.where((r) => r.id == a.routeId).firstOrNull?.toName}${a.leavesAt}'
          .compareTo('${widget.routes.where((r) => r.id == b.routeId).firstOrNull?.toName}${b.leavesAt}'));
    final hire = widget.l.categories.where((c) => c.forHire).toList();
    return AlertDialog(
      title: const Text('Booking for a caller'),
      content: SizedBox(
        width: 480,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            SegmentedButton<String>(
              segments: const [ButtonSegment(value: 'seat', label: Text('Seat')), ButtonSegment(value: 'hire', label: Text('Hire a car'))],
              selected: {_kind},
              onSelectionChanged: (v) => setState(() => _kind = v.first),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: _name, decoration: field('Caller name'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: _phone, decoration: field('Phone'))),
            ]),
            const SizedBox(height: 10),
            DateButton(label: 'Day', value: _day, onChanged: (d) => setState(() {
                  _day = d ?? _day;
                  _departure = null;
                })),
            const SizedBox(height: 10),
            if (_kind == 'seat') ...[
              DropdownButtonFormField<String>(
                value: _departure,
                decoration: field('Departure'),
                items: [
                  for (final d in deps)
                    DropdownMenuItem(
                      value: d.id,
                      child: Text(() {
                        final r = widget.routes.where((r) => r.id == d.routeId).firstOrNull;
                        return '${d.time} · ${r?.fromName ?? ''} → ${r?.toName ?? ''} · ${widget.l.category(r?.categoryId)?.name ?? ''} · ${money(r?.fare)}';
                      }()),
                    ),
                ],
                onChanged: (v) => setState(() => _departure = v),
              ),
              const SizedBox(height: 10),
              Row(children: [
                const Text('Seats'),
                IconButton(onPressed: () => setState(() => _seats = _seats > 1 ? _seats - 1 : 1), icon: const Icon(Icons.remove)),
                Text('$_seats', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                IconButton(onPressed: () => setState(() => _seats++), icon: const Icon(Icons.add)),
              ]),
            ] else ...[
              DropdownButtonFormField<String>(
                value: _category,
                decoration: field('Vehicle type'),
                items: [for (final c in hire) DropdownMenuItem(value: c.id, child: Text('${c.name} · ${money(c.hirePerKm)}/km'))],
                onChanged: (v) => setState(() => _category = v),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: _from, decoration: field('Pick up at'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _to, decoration: field('Go to'))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _km,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                    decoration: field('Km (all of it)'),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  icon: const Icon(Icons.schedule, size: 18),
                  label: Text(_time.format(context)),
                  onPressed: () async {
                    final t = await showTimePicker(context: context, initialTime: _time);
                    if (t != null) setState(() => _time = t);
                  },
                ),
              ]),
              const SizedBox(height: 10),
              SegmentedButton<String>(
                segments: [for (final e in Booking.tripTypeNames.entries) ButtonSegment(value: e.key, label: Text(e.value))],
                selected: {_tripType},
                onSelectionChanged: (v) => setState(() => _tripType = v.first),
              ),
            ],
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _pay,
              decoration: field('Pay'),
              items: [for (final e in payNames.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
              onChanged: (v) => setState(() => _pay = v ?? _pay),
            ),
            if (_pay == 'account') ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _account,
                decoration: field('Company account'),
                items: [for (final a in widget.accounts.where((a) => a.active)) DropdownMenuItem(value: a.id, child: Text(a.name))],
                onChanged: (v) => setState(() => _account = v),
              ),
            ],
            const SizedBox(height: 10),
            TextField(controller: _note, decoration: field('Note (optional)')),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Book')),
      ],
    );
  }
}

/// Straight-line km between two points.
double kmBetween(double aLat, double aLng, double bLat, double bLng) {
  const r = 6371.0;
  double rad(double d) => d * math.pi / 180;
  final dLat = rad(bLat - aLat);
  final dLng = rad(bLng - aLng);
  final h = math.pow(math.sin(dLat / 2), 2) + math.cos(rad(aLat)) * math.cos(rad(bLat)) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h));
}
