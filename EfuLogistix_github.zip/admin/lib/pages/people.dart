import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Pages the admin can switch on or off for each manager.
const managerPages = [
  'Bookings', 'Support', 'Drivers & matching', 'Shifts & trips', 'Cash hand-ins',
  'Route history', 'Driver wallets', 'EfuLogistix fees', 'Service', 'Reports',
];

const roleNames = {'admin': 'Admin', 'manager': 'Manager', 'owner': 'Vehicle owner', 'driver': 'Driver', 'passenger': 'Passenger'};

/// Drivers, managers, vehicle owners and passengers: invite, approve, block, change role, give a vehicle,
/// link a passenger to a company account.
class PeoplePage extends StatefulWidget {
  const PeoplePage({super.key});

  @override
  State<PeoplePage> createState() => _PeoplePageState();
}

class _PeoplePageState extends State<PeoplePage> {
  final _l = Lookup();
  List<Map<String, dynamic>> _invites = [];
  List<CompanyAccount> _accounts = [];
  Map<String, String> _missing = {};
  String _tab = 'driver';
  String _search = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final inv = await db.from('invites').select().isFilter('used_by', null).order('created_at', ascending: false);
      final acc = await db.from('company_accounts').select().order('name');
      final drivers = _l.drivers;
      final miss = await Future.wait([for (final d in drivers) db.rpc('missing_documents', params: {'p_driver': d.id})]);
      if (!mounted) return;
      setState(() {
        _invites = inv;
        _accounts = acc.map(CompanyAccount.fromMap).toList();
        _missing = {for (var i = 0; i < drivers.length; i++) drivers[i].id: (miss[i] ?? '').toString()};
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _invite() async {
    final email = TextEditingController();
    final name = TextEditingController();
    final phone = TextEditingController();
    var role = (_tab == 'invites') ? 'driver' : _tab;
    String? truckId;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Invite someone'),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Text(
                'They sign up in the phone app with this email. The app then gives them this role straight away, no approval needed.',
                style: TextStyle(color: AppColors.muted, fontSize: 13),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: role,
                decoration: field('Role'),
                items: [for (final e in roleNames.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setLocal(() => role = v ?? role),
              ),
              const SizedBox(height: 12),
              TextField(controller: email, decoration: field('Email')),
              const SizedBox(height: 10),
              TextField(controller: name, decoration: field('Full name')),
              const SizedBox(height: 10),
              TextField(controller: phone, decoration: field('Phone', hint: '0999 123 456')),
              if (role == 'driver') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String?>(
                  value: truckId,
                  decoration: field('Vehicle (optional)'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('No vehicle yet')),
                    for (final t in _l.trucks.where((t) => t.active))
                      DropdownMenuItem(value: t.id, child: Text(_l.plate(t.id))),
                  ],
                  onChanged: (v) => setLocal(() => truckId = v),
                ),
              ],
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Invite')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final mail = email.text.trim().toLowerCase();
    if (!mail.contains('@')) {
      toast(context, 'Type a valid email.');
      return;
    }
    // if they already have an account, set the role directly
    final existing = _l.people.where((p) => (p.email ?? '').toLowerCase() == mail).firstOrNull;
    if (existing != null) {
      if (existing.id == db.auth.currentUser?.id && role != 'admin') {
        toast(context, 'You cannot remove your own admin role. Ask another admin.');
        return;
      }
      if (await attempt(
          context,
          () => db.from('profiles').update({
                'role': role,
                'active': true,
                if (role == 'driver' && truckId != null) 'truck_id': truckId,
                if (name.text.trim().isNotEmpty) 'full_name': name.text.trim(),
              }).eq('id', existing.id),
          done: '${existing.displayName} already had an account. They are now ${roleNames[role]}.')) {
        _load();
      }
      return;
    }
    if (await attempt(
        context,
        () => db.from('invites').insert({
              'email': mail,
              'full_name': name.text.trim().isEmpty ? null : name.text.trim(),
              'phone': phone.text.trim().isEmpty ? null : phone.text.trim(),
              'role': role,
              'truck_id': role == 'driver' ? truckId : null,
            }),
        done: 'Invited. Tell them to sign up in the EfuLogistix app with $mail.')) {
      _load();
    }
  }

  Future<void> _update(Profile p, Map<String, dynamic> values, String done) async {
    if (await attempt(context, () => db.from('profiles').update(values).eq('id', p.id), done: done)) _load();
  }

  Future<void> _edit(Profile p) async {
    var role = p.role;
    String? truckId = p.truckId;
    var drivesOwn = p.drivesOwn;
    String? accountId = p.accountId;
    final perms = <String>{...p.permissions};
    final name = TextEditingController(text: p.fullName ?? '');
    final phone = TextEditingController(text: p.phone ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(p.displayName),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              muted(p.email ?? ''),
              const SizedBox(height: 12),
              TextField(controller: name, decoration: field('Full name')),
              const SizedBox(height: 10),
              TextField(controller: phone, decoration: field('Phone')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: role,
                decoration: field('Role'),
                items: [for (final e in roleNames.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setLocal(() {
                  role = v ?? role;
                  if (role == 'manager' && perms.isEmpty) perms.addAll(managerPages);
                }),
              ),
              if (role == 'manager') ...[
                const SizedBox(height: 10),
                const Text('Pages this manager can open', style: TextStyle(fontWeight: FontWeight.w800)),
                muted('Fares, settings, people, vehicles, places and the activity log stay admin only.'),
                for (final pg in managerPages)
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: Text(pg),
                    value: perms.contains(pg),
                    onChanged: (v) => setLocal(() => v == true ? perms.add(pg) : perms.remove(pg)),
                  ),
              ],
              if (role == 'owner' || (role == 'driver' && p.drivesOwn)) ...[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Also drives his own vehicle'),
                  subtitle: const Text('He gets an Owner / Driver switch in the app. One driver per vehicle.'),
                  value: drivesOwn,
                  onChanged: (v) => setLocal(() => drivesOwn = v),
                ),
                if (drivesOwn)
                  DropdownButtonFormField<String?>(
                    value: _l.trucks.any((t) => t.id == truckId && t.ownerId == p.id) ? truckId : null,
                    decoration: field('The vehicle he drives'),
                    items: [
                      const DropdownMenuItem(value: null, child: Text('Choose a vehicle')),
                      for (final t in _l.trucks.where((t) => t.ownerId == p.id)) DropdownMenuItem(value: t.id, child: Text(_l.plate(t.id))),
                    ],
                    onChanged: (v) => setLocal(() => truckId = v),
                  ),
              ],
              if (role == 'driver') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String?>(
                  value: truckId,
                  decoration: field('Vehicle'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('No vehicle')),
                    for (final t in _l.trucks) DropdownMenuItem(value: t.id, child: Text(_l.plate(t.id))),
                  ],
                  onChanged: (v) => setLocal(() => truckId = v),
                ),
              ],
              if (role == 'passenger') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String?>(
                  value: _accounts.any((a) => a.id == accountId) ? accountId : null,
                  decoration: field('Company account (pays monthly)'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('None · pays each trip')),
                    for (final a in _accounts) DropdownMenuItem(value: a.id, child: Text(a.name)),
                  ],
                  onChanged: (v) => setLocal(() => accountId = v),
                ),
                if (p.noShows > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text('Missed bookings: ${p.noShows}', style: const TextStyle(color: AppColors.danger)),
                  ),
              ],
              if (role == 'admin')
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('An admin can change everything, including fares and people.',
                      style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w600)),
                ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (p.id == db.auth.currentUser?.id && role != 'admin') {
      if (mounted) toast(context, 'You cannot remove your own admin role. Ask another admin.');
      return;
    }
    await _update(
      p,
      {
        'full_name': name.text.trim().isEmpty ? null : name.text.trim(),
        'phone': phone.text.trim().isEmpty ? null : phone.text.trim(),
        'role': role,
        'truck_id': role == 'driver' || (role == 'owner' && drivesOwn) ? truckId : null,
        if (role == 'owner' || (role == 'driver' && p.drivesOwn)) 'drives_own': drivesOwn,
        'account_id': role == 'passenger' ? accountId : null,
        if (role == 'manager') 'permissions': perms.toList(),
      },
      'Saved.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = db.auth.currentUser?.id;
    final s = _search.toLowerCase();
    bool match(Profile p) =>
        s.isEmpty ||
        p.displayName.toLowerCase().contains(s) ||
        (p.email ?? '').toLowerCase().contains(s) ||
        (p.phone ?? '').contains(s);
    final list = _l.people
        .where((p) => _tab == 'manager' ? (p.role == 'manager' || p.role == 'admin') : p.role == _tab)
        .where(match)
        .toList()
      ..sort((a, b) => (a.active ? 1 : 0).compareTo(b.active ? 1 : 0));
    final waiting = _l.people.where((p) => !p.active).length;
    return PageFrame(
      title: 'People',
      subtitle: waiting > 0 ? '$waiting waiting for approval' : 'Invite people by email; they sign up in the phone app.',
      onRefresh: _load,
      actions: [
        SizedBox(
          width: 220,
          child: TextField(
            decoration: field('Search', hint: 'name, email, phone'),
            onChanged: (v) => setState(() => _search = v),
          ),
        ),
        FilledButton.icon(onPressed: _invite, icon: const Icon(Icons.person_add), label: const Text('Invite')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'driver', label: Text('Drivers (${_l.drivers.length})')),
            ButtonSegment(
                value: 'manager',
                label: Text('Managers (${_l.people.where((p) => p.role == 'manager' || p.role == 'admin').length})')),
            ButtonSegment(value: 'owner', label: Text('Vehicle owners (${_l.owners.length})')),
            ButtonSegment(value: 'passenger', label: Text('Passengers (${_l.people.where((p) => p.isPassenger).length})')),
            ButtonSegment(value: 'invites', label: Text('Invites (${_invites.length})')),
          ],
          selected: {_tab},
          onSelectionChanged: (v) => setState(() => _tab = v.first),
        ),
        const SizedBox(height: 16),
        if (_tab == 'invites')
          Panel(
            padding: const EdgeInsets.only(bottom: 8),
            child: SimpleTable(
              empty: 'No open invites.',
              columns: const ['Email', 'Name', 'Role', 'Vehicle', 'Invited', ''],
              rows: [
                for (final i in _invites)
                  [
                    bold(i['email'].toString()),
                    Text(i['full_name']?.toString() ?? ''),
                    Text(roleNames[i['role']] ?? i['role'].toString()),
                    Text(_l.plate(i['truck_id'] as String?)),
                    Text(shortDate(toDate(i['created_at']) ?? DateTime.now())),
                    TextButton(
                      onPressed: () async {
                        if (await attempt(context, () => db.from('invites').delete().eq('id', i['id'] as String),
                            done: 'Invite removed.')) {
                          _load();
                        }
                      },
                      child: const Text('Remove'),
                    ),
                  ],
              ],
            ),
          )
        else
          Panel(
            padding: const EdgeInsets.only(bottom: 8),
            child: SimpleTable(
              empty: 'Nobody here yet. Use Invite.',
              columns: [
                'Name',
                'Phone',
                if (_tab == 'driver') 'Vehicle',
                if (_tab == 'driver') 'Documents',
                if (_tab == 'owner') 'Owns',
                if (_tab == 'manager') 'Role',
                if (_tab == 'passenger') 'Company',
                if (_tab == 'passenger') 'Missed',
                'Status',
                '',
              ],
              rows: [
                for (final p in list)
                  [
                    Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      bold(p.displayName),
                      muted(p.email ?? ''),
                    ]),
                    Text(p.phone ?? ''),
                    if (_tab == 'driver') Text(_l.plate(p.truckId)),
                    if (_tab == 'driver')
                      (_missing[p.id] ?? '').isEmpty
                          ? const Pill('Complete', color: AppColors.lime600)
                          : Tooltip(
                              message: (_missing[p.id] ?? '')
                                  .split(',')
                                  .map((k) => docNames[k.trim()] ?? k)
                                  .join(', '),
                              child: Pill('Missing ${(_missing[p.id] ?? '').split(',').length}', color: AppColors.danger),
                            ),
                    if (_tab == 'owner')
                      Text(_l.trucks.where((t) => t.ownerId == p.id).map((t) => t.plate).join(', ').ifEmptyDash),
                    if (_tab == 'manager') Text(roleNames[p.role] ?? p.role),
                    if (_tab == 'passenger') Text(_accounts.where((a) => a.id == p.accountId).firstOrNull?.name ?? '—'),
                    if (_tab == 'passenger')
                      p.noShows > 0 ? Pill('${p.noShows}', color: AppColors.danger) : const Text('0'),
                    p.active ? const Pill('Active', color: AppColors.lime600) : const Pill('Waiting / blocked', color: AppColors.warning),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      if (!p.active)
                        TextButton(
                          onPressed: () => _update(p, {'active': true}, '${p.displayName} can now use the app.'),
                          child: const Text('Approve'),
                        ),
                      if (p.active && p.id != me)
                        TextButton(
                          onPressed: () async {
                            if (await confirm(context, 'Block ${p.displayName}?',
                                'They will not be able to use the app until you approve them again.',
                                yes: 'Block')) {
                              await _update(p, {'active': false}, 'Blocked.');
                            }
                          },
                          child: const Text('Block', style: TextStyle(color: AppColors.danger)),
                        ),
                      TextButton(onPressed: () => _edit(p), child: const Text('Edit')),
                    ]),
                  ],
              ],
            ),
          ),
      ],
    );
  }
}

extension on String {
  String get ifEmptyDash => isEmpty ? '—' : this;
}
