import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Every driver's wallet: what they have earned, what was taken off and what was paid out.
/// Read-only. The owner pays their own drivers; the office pays drivers of company vehicles (Fees page).
class WalletsPage extends StatefulWidget {
  const WalletsPage({super.key});

  @override
  State<WalletsPage> createState() => _WalletsPageState();
}

class _WalletsPageState extends State<WalletsPage> {
  final _l = Lookup();
  List<WalletEntry> _entries = [];
  String? _driver; // show one driver's lines
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final rows = await db.from('wallet_entries').select().order('created_at', ascending: false).limit(2000);
      if (mounted) setState(() => _entries = rows.map(WalletEntry.fromMap).toList());
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String _kind(String k) => switch (k) {
        'earn' => 'Earned',
        'deduct' => 'Taken off',
        _ => 'Paid out',
      };

  @override
  Widget build(BuildContext context) {
    // one row per driver and payer (owner or office)
    final groups = <String, List<WalletEntry>>{};
    for (final e in _entries) {
      groups.putIfAbsent('${e.driverId}|${e.ownerId ?? ''}', () => []).add(e);
    }
    double sum(Iterable<WalletEntry> l, String kind) => l.where((e) => e.kind == kind).fold<double>(0, (s, e) => s + e.amount);
    final keys = groups.keys.toList()..sort((a, b) => _l.name(a.split('|').first).compareTo(_l.name(b.split('|').first)));
    final owing = groups.values.fold<double>(0, (s, l) => s + l.fold<double>(0, (t, e) => t + e.amount));
    final paid = -sum(_entries, 'payout');
    final shown = _driver == null ? <WalletEntry>[] : _entries.where((e) => e.driverId == _driver).toList();
    return PageFrame(
      title: 'Driver wallets',
      subtitle: 'What every driver has earned and been paid. The owner pays their own drivers; the office pays company vehicles.',
      onRefresh: _load,
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Owed to drivers now', money(owing)),
          Stat('Paid out so far', money(paid)),
          Stat('Drivers with a wallet', '${keys.length}'),
        ]),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'Nothing here.',
            columns: const ['Driver', 'Paid by', 'Earned', 'Taken off', 'Paid out', 'Balance', ''],
            rows: [
              for (final k in keys)
                () {
                  final parts = k.split('|');
                  final l = groups[k]!;
                  final bal = l.fold<double>(0, (s, e) => s + e.amount);
                  return [
                    bold(_l.name(parts[0])),
                    Text(parts[1].isEmpty ? 'Office' : _l.name(parts[1])),
                    Text(money(sum(l, 'earn'))),
                    Text(money(-sum(l, 'deduct'))),
                    Text(money(-sum(l, 'payout'))),
                    bold(money(bal)),
                    TextButton(onPressed: () => setState(() => _driver = parts[0]), child: const Text('History')),
                  ];
                }(),
            ],
          ),
        ),
        if (_driver != null) ...[
          const SizedBox(height: 12),
          Panel(
            padding: const EdgeInsets.only(bottom: 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
                child: Row(children: [
                  Expanded(child: bold(_l.name(_driver))),
                  TextButton(onPressed: () => setState(() => _driver = null), child: const Text('Close')),
                ]),
              ),
              SimpleTable(
                empty: 'Nothing here.',
                columns: const ['Date', 'What', 'Amount', 'Details'],
                rows: [
                  for (final e in shown)
                    [
                      Text('${shortDate(e.createdAt)} ${clock(e.createdAt)}'),
                      Text(_kind(e.kind)),
                      Text(money(e.amount)),
                      Text([
                        if (e.method != null) e.method!,
                        if (e.reference != null) e.reference!,
                        if (e.note != null) e.note!,
                      ].join(' · '), style: const TextStyle(color: AppColors.muted)),
                    ],
                ],
              ),
            ]),
          ),
        ],
      ],
    );
  }
}
