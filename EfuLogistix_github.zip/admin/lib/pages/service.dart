import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

const serviceKinds = {'oil': 'Oil change', 'repair': 'Repair', 'tyre': 'Tyres', 'papers': 'Papers', 'other': 'Other'};

/// Service records for every vehicle. Saving an oil change resets the oil counter.
class ServicePage extends StatefulWidget {
  const ServicePage({super.key});

  @override
  State<ServicePage> createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  final _l = Lookup();
  List<Map<String, dynamic>> _rows = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final rows = await db.from('service_records').select().order('done_on', ascending: false).limit(300);
      if (mounted) setState(() => _rows = rows);
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _add() async {
    String? truckId = _l.trucks.where((t) => t.active).firstOrNull?.id;
    var kind = 'oil';
    var done = DateTime.now();
    final km = TextEditingController();
    final cost = TextEditingController();
    final note = TextEditingController();
    final digits = [FilteringTextInputFormatter.digitsOnly];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Add service'),
          content: SizedBox(
            width: 420,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              DropdownButtonFormField<String?>(
                value: truckId,
                decoration: field('Vehicle'),
                items: [for (final t in _l.trucks) DropdownMenuItem(value: t.id, child: Text(_l.plate(t.id)))],
                onChanged: (v) => setLocal(() {
                  truckId = v;
                  km.text = _l.truck(v)?.currentKm?.toString() ?? '';
                }),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: kind,
                decoration: field('What was done'),
                items: [for (final e in serviceKinds.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setLocal(() => kind = v ?? kind),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: km, inputFormatters: digits, decoration: field('Odometer km'))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: cost, inputFormatters: digits, decoration: field('Cost (MWK)'))),
              ]),
              const SizedBox(height: 10),
              DateButton(label: 'Date', value: done, onChanged: (v) => setLocal(() => done = v ?? done)),
              const SizedBox(height: 10),
              TextField(controller: note, decoration: field('Note (garage, parts)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted || truckId == null) return;
    if (await attempt(
        context,
        () => db.from('service_records').insert({
              'truck_id': truckId,
              'kind': kind,
              'km': int.tryParse(km.text),
              'cost': parseAmount(cost.text),
              'done_on': dateOnly(done),
              'note': note.text.trim().isEmpty ? null : note.text.trim(),
            }),
        done: 'Saved.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final due = _l.trucks.where((t) => t.active && (t.oilLeftKm ?? 99999) < 500).toList();
    final total = _rows.fold<double>(0, (s, r) => s + toDouble(r['cost']));
    return PageFrame(
      title: 'Service',
      subtitle: 'Oil changes, repairs and tyres. Expiry dates for papers are in Vehicles.',
      onRefresh: _load,
      actions: [
        OutlinedButton.icon(
          onPressed: () => saveCsv(context, 
            'service.csv',
            csvOf(['date', 'vehicle', 'kind', 'km', 'cost', 'note'], [
              for (final r in _rows)
                [r['done_on'], _l.truck(r['truck_id'] as String?)?.plate, serviceKinds[r['kind']] ?? r['kind'], r['km'],
                  toDouble(r['cost']).round(), r['note']],
            ]),
          ),
          icon: const Icon(Icons.download),
          label: const Text('CSV'),
        ),
        FilledButton.icon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Add service')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Oil change due', '${due.length}', valueColor: due.isEmpty ? null : AppColors.warning),
          Stat('Spent (shown)', money(total), dark: true),
        ]),
        const SizedBox(height: 16),
        if (due.isNotEmpty)
          Panel(
            title: 'Oil change due soon',
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (final t in due)
                Pill('${t.plate}: ${t.oilLeftKm! <= 0 ? 'overdue ${-t.oilLeftKm!} km' : 'in ${t.oilLeftKm} km'}',
                    color: t.oilLeftKm! <= 0 ? AppColors.danger : AppColors.warning),
            ]),
          ),
        Panel(
          title: 'History',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No service saved yet.',
            columns: const ['Date', 'Vehicle', 'What', 'Km', 'Cost', 'Note'],
            rows: [
              for (final r in _rows)
                [
                  Text(r['done_on'].toString()),
                  bold(_l.plate(r['truck_id'] as String?)),
                  Text(serviceKinds[r['kind']] ?? r['kind'].toString()),
                  Text(r['km']?.toString() ?? '—'),
                  Text(money(toDouble(r['cost']))),
                  Text(r['note']?.toString() ?? ''),
                ],
            ],
          ),
        ),
      ],
    );
  }
}
