import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../theme.dart';

/// Admin: places (name + position) that every phone uses for pick-up, drop-off and distances.
/// In Google Maps press and hold a spot, copy the coordinates at the top, and paste them here.
class PlacesPage extends StatefulWidget {
  const PlacesPage({super.key});

  @override
  State<PlacesPage> createState() => _PlacesPageState();
}

class _PlacesPageState extends State<PlacesPage> {
  List<Map<String, dynamic>> _rows = [];
  List<Map<String, dynamic>> _pending = [];
  bool _loading = true;
  final _filter = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _filter.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await db.from('places').select().order('name');
      final sug = await db.from('place_suggestions').select().eq('status', 'pending').order('created_at');
      if (mounted) {
        setState(() {
          _rows = List<Map<String, dynamic>>.from(r);
          _pending = List<Map<String, dynamic>>.from(sug);
        });
      }
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  /// "-14.461511,35.243191" (as copied from Google Maps) -> [lat, lng], or null.
  List<double>? _parse(String text) {
    final m = RegExp(r'(-?\d+(?:\.\d+)?)\s*[,;\s]\s*(-?\d+(?:\.\d+)?)').firstMatch(text.trim());
    if (m == null) return null;
    final lat = double.tryParse(m.group(1)!);
    final lng = double.tryParse(m.group(2)!);
    if (lat == null || lng == null || lat.abs() > 90 || lng.abs() > 180) return null;
    return [lat, lng];
  }

  Future<void> _edit([Map<String, dynamic>? row]) async {
    final name = TextEditingController(text: (row?['name'] ?? '').toString());
    final detail = TextEditingController(text: (row?['detail'] ?? '').toString());
    final coords = TextEditingController(text: row == null ? '' : '${row['lat']},${row['lng']}');
    String? error;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(row == null ? 'Add a place' : 'Edit place'),
          content: SizedBox(
            width: 380,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Name (e.g. Mpondasi)')),
              TextField(controller: detail, decoration: const InputDecoration(labelText: 'Area (e.g. Mangochi District)')),
              TextField(
                controller: coords,
                decoration: InputDecoration(
                  labelText: 'Coordinates from Google Maps',
                  hintText: '-14.461511,35.243191',
                  helperText: 'Press and hold the spot in Google Maps, copy the numbers at the top, paste here.',
                  helperMaxLines: 3,
                  errorText: error,
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                if (name.text.trim().isEmpty) {
                  setLocal(() => error = 'Type a name first.');
                } else if (_parse(coords.text) == null) {
                  setLocal(() => error = 'Paste the two numbers, like -14.461511,35.243191');
                } else {
                  Navigator.pop(ctx, true);
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    final p = _parse(coords.text);
    final data = {'name': name.text.trim(), 'detail': detail.text.trim(), 'lat': p?[0], 'lng': p?[1]};
    name.dispose();
    detail.dispose();
    coords.dispose();
    if (ok != true || p == null || !mounted) return;
    final saved = await attempt(
      context,
      () => row == null ? db.from('places').insert(data) : db.from('places').update(data).eq('id', row['id']),
      done: 'Saved. Phones pick it up the next time they open.',
    );
    if (saved) _load();
  }

  Future<void> _decide(Map<String, dynamic> row, bool approve) async {
    final ok = await attempt(context, () => db.rpc('decide_place_suggestion', params: {'p_id': row['id'], 'p_approve': approve}),
        done: approve ? 'Added to Places.' : 'Rejected.');
    if (ok) _load();
  }

  Future<void> _delete(Map<String, dynamic> row) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Delete ${row['name']}?'),
        content: const Text('Phones go back to the built-in position for this place, if there is one.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    if (await attempt(context, () => db.from('places').delete().eq('id', row['id']))) _load();
  }

  @override
  Widget build(BuildContext context) {
    final q = _filter.text.trim().toLowerCase();
    final shown = _rows.where((r) => q.isEmpty || '${r['name']} ${r['detail']}'.toLowerCase().contains(q)).toList();
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add_location_alt_outlined), label: const Text('Add place')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Places', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text(
            'Add or correct a place here and every phone uses it for pick-up, drop-off and distances. No new app build needed.',
            style: TextStyle(color: AppColors.muted)),
        const SizedBox(height: 12),
        TextField(
          controller: _filter,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search places'),
        ),
        if (_pending.isNotEmpty) ...[
          const SizedBox(height: 12),
          const Text('SUGGESTED BY DRIVERS', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.muted, fontSize: 12)),
          for (final r in _pending)
            Card(
              color: const Color(0xFFFFF7E0),
              child: ListTile(
                leading: const Icon(Icons.add_location_alt_outlined),
                title: Text('${r['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${r['detail'] ?? ''}  ·  ${(r['lat'] as num).toStringAsFixed(6)}, ${(r['lng'] as num).toStringAsFixed(6)}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(tooltip: 'Reject', icon: const Icon(Icons.close), onPressed: () => _decide(r, false)),
                  IconButton(tooltip: 'Add', icon: const Icon(Icons.check_circle, color: AppColors.lime600), onPressed: () => _decide(r, true)),
                ]),
              ),
            ),
        ],
        const SizedBox(height: 12),
        if (_loading) const LinearProgressIndicator(),
        if (!_loading && shown.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('No places yet. Tap Add place.')),
        for (final r in shown)
          Card(
            child: ListTile(
              leading: const Icon(Icons.place_outlined),
              title: Text('${r['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${r['detail'] ?? ''}  ·  ${(r['lat'] as num).toStringAsFixed(6)}, ${(r['lng'] as num).toStringAsFixed(6)}'),
              onTap: () => _edit(r),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(r)),
            ),
          ),
        const SizedBox(height: 80),
      ]),
    );
  }
}
