import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';
import '../vehicle_art.dart';

/// Vehicles: approve vehicles sent by owners (and their new papers), add and edit, category, owner,
/// oil interval, papers (insurance, COF, blue book).
class VehiclesPage extends StatefulWidget {
  const VehiclesPage({super.key});

  @override
  State<VehiclesPage> createState() => _VehiclesPageState();
}

class _VehiclesPageState extends State<VehiclesPage> {
  final _l = Lookup();
  String? _category;
  bool _loading = true;
  List<Doc> _pendingDocs = [];
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final docs = await db.from('documents').select().not('truck_id', 'is', null).eq('status', 'pending').order('created_at');
      _pendingDocs = docs.map(Doc.fromMap).toList();
      _isAdmin = _l.person(db.auth.currentUser?.id)?.isAdmin ?? false;
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _review(Truck t, bool approve) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(approve ? 'Approve ${t.plate}?' : 'Send ${t.plate} back to the owner?'),
        content: SizedBox(
          width: 420,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(approve
                ? 'It goes on the road and its papers sent with it are approved. The owner gets a message.'
                : 'The owner sees your note, fixes it and sends it again.'),
            const SizedBox(height: 10),
            TextField(controller: note, decoration: field(approve ? 'Note (optional)' : 'What to fix', hint: 'e.g. Plate not readable on the photos')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(approve ? 'Approve' : 'Send back')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(context, () => db.rpc('review_truck', params: {'p_id': t.id, 'p_approve': approve, 'p_note': note.text.trim()}),
        done: approve ? '${t.plate} is on the road.' : 'Sent back.')) {
      _load();
    }
  }

  Future<void> _reviewDoc(Doc d, bool approve) async {
    String? note;
    if (!approve) {
      final c = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Why is it not accepted?'),
          content: SizedBox(width: 400, child: TextField(controller: c, decoration: field('Reason (the owner sees it)'))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Not accepted')),
          ],
        ),
      );
      if (ok != true) return;
      note = c.text.trim();
    }
    if (!mounted) return;
    if (await attempt(
        context,
        () => db.from('documents').update({
              'status': approve ? 'approved' : 'rejected',
              'note': note,
              'reviewed_by': db.auth.currentUser?.id,
              'reviewed_at': DateTime.now().toUtc().toIso8601String(),
            }).eq('id', d.id),
        done: approve ? 'Paper approved. The vehicle\'s dates are updated.' : 'Saved.')) {
      _load();
    }
  }

  Widget _approvals() {
    final waiting = _l.trucks.where((t) => t.pending).toList();
    final paperOnly = _pendingDocs.where((d) => _l.truck(d.truckId)?.approved ?? false).toList();
    if (waiting.isEmpty && paperOnly.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      for (final t in waiting)
        Panel(
          title: 'Waiting for approval · ${t.plate}',
          actions: [
            if (_isAdmin) ...[
              TextButton(onPressed: () => _review(t, false), child: const Text('Send back', style: TextStyle(color: AppColors.danger))),
              const SizedBox(width: 6),
              FilledButton(onPressed: () => _review(t, true), child: const Text('Approve')),
            ] else
              muted('Only the admin approves'),
          ],
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              VehicleArt(_l.category(t.categoryId)?.name, width: 90),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  bold('${_l.plate(t.id)} · ${t.looks}${t.year != null ? ' · ${t.year}' : ''}${t.seats != null ? ' · ${t.seats} seats' : ''}'),
                  muted('Owner: ${_l.person(t.ownerId)?.displayName ?? '—'}${_l.person(t.ownerId)?.phone != null ? ' · ${_l.person(t.ownerId)!.phone}' : ''}'
                      ' · sent ${t.submittedAt == null ? '' : '${shortDate(t.submittedAt!)} ${clock(t.submittedAt)}'}'
                      ' · fee plan ${Truck.feePlanNames[t.feePlan] ?? t.feePlan}'),
                ]),
              ),
            ]),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in t.photos) StoredImage(p, height: 90, width: 120),
              for (final d in _pendingDocs.where((d) => d.truckId == t.id))
                Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  StoredImage(d.frontPath, height: 90, width: 120),
                  Text('${docNames[d.kind] ?? d.kind}${d.expiresOn != null ? ' · to ${shortDate(d.expiresOn!)} ${d.expiresOn!.year}' : ''}',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                ]),
            ]),
          ]),
        ),
      if (paperOnly.isNotEmpty)
        Panel(
          title: 'New papers to check (the vehicle keeps running)',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            columns: const ['Vehicle', 'Paper', 'Ends', 'Photo', ''],
            rows: [
              for (final d in paperOnly)
                [
                  bold(_l.plate(d.truckId)),
                  Text(docNames[d.kind] ?? d.kind),
                  Text(d.expiresOn == null ? '—' : '${shortDate(d.expiresOn!)} ${d.expiresOn!.year}'),
                  StoredImage(d.frontPath, height: 56, width: 80),
                  _isAdmin
                      ? Row(mainAxisSize: MainAxisSize.min, children: [
                          TextButton(onPressed: () => _reviewDoc(d, true), child: const Text('Approve')),
                          TextButton(onPressed: () => _reviewDoc(d, false), child: const Text('Not accepted')),
                        ])
                      : const SizedBox.shrink(),
                ],
            ],
          ),
        ),
    ]);
  }

  Future<void> _edit([Truck? t]) async {
    final saved = await showDialog<bool>(context: context, builder: (_) => VehicleDialog(truck: t, l: _l));
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = _l.trucks.where((t) => _category == null || t.categoryId == _category).toList();
    return PageFrame(
      title: 'Vehicles',
      subtitle: '${_l.trucks.where((t) => t.active).length} on the road · ${_l.trucks.where((t) => !t.active && t.approved).length} off road'
          '${_l.trucks.where((t) => t.pending).isNotEmpty ? ' · ${_l.trucks.where((t) => t.pending).length} waiting for you' : ''}',
      onRefresh: _load,
      actions: [FilledButton.icon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Add vehicle'))],
      children: [
        if (_loading) const LinearProgressIndicator(),
        _approvals(),
        Wrap(spacing: 8, runSpacing: 8, children: [
          ChoiceChip(label: const Text('All'), selected: _category == null, onSelected: (_) => setState(() => _category = null)),
          for (final c in _l.categories)
            ChoiceChip(
              label: Text('${c.name} (${_l.trucks.where((t) => t.categoryId == c.id).length})'),
              selected: _category == c.id,
              onSelected: (_) => setState(() => _category = c.id),
            ),
        ]),
        const SizedBox(height: 16),
        Panel(
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No vehicles yet. Use Add vehicle.',
            columns: const ['Plate', 'Category', 'Owner', 'Drivers', 'Km', 'Oil', 'Insurance', 'COF', 'Status'],
            rows: [
              for (final t in list)
                [
                  Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    bold(t.plate),
                    if (t.model != null) muted(t.model!),
                  ]),
                  Text(_l.category(t.categoryId)?.name ?? '—'),
                  Text(_l.person(t.ownerId)?.displayName ?? 'Company'),
                  Text(_l.drivers.where((d) => d.truckId == t.id).map((d) => d.firstName).join(', ')),
                  Text(t.currentKm?.toString() ?? '—'),
                  _oil(t),
                  _date(t.insuranceTo),
                  _date(t.cofTo),
                  t.pending
                      ? const Pill('Waiting', color: AppColors.warning)
                      : t.rejected
                          ? const Pill('Sent back', color: AppColors.danger)
                          : t.active
                              ? const Pill('On road', color: AppColors.lime600)
                              : const Pill('Off road', color: AppColors.muted),
                ],
            ],
            onTap: (i) => _edit(list[i]),
          ),
        ),
      ],
    );
  }

  Widget _oil(Truck t) {
    final left = t.oilLeftKm;
    if (left == null) return const Text('—');
    return Pill(left <= 0 ? 'Overdue ${-left} km' : 'in $left km',
        color: left <= 0 ? AppColors.danger : (left < 500 ? AppColors.warning : AppColors.lime600));
  }

  Widget _date(DateTime? d) {
    if (d == null) return const Text('—');
    final days = d.difference(DateTime.now()).inDays;
    return Text('${shortDate(d)} ${d.year}',
        style: TextStyle(
            color: days < 0 ? AppColors.danger : (days < 30 ? AppColors.warning : AppColors.ink),
            fontWeight: days < 30 ? FontWeight.w700 : FontWeight.w400));
  }
}

class VehicleDialog extends StatefulWidget {
  final Truck? truck;
  final Lookup l;
  const VehicleDialog({super.key, this.truck, required this.l});

  @override
  State<VehicleDialog> createState() => _VehicleDialogState();
}

class _VehicleDialogState extends State<VehicleDialog> {
  late final _plate = TextEditingController(text: widget.truck?.plate ?? '');
  late final _model = TextEditingController(text: widget.truck?.model ?? '');
  late final _seats = TextEditingController(text: widget.truck?.seats?.toString() ?? '');
  late final _interval = TextEditingController(text: (widget.truck?.oilIntervalKm ?? 5000).toString());
  late final _lastOil = TextEditingController(text: widget.truck?.lastOilKm?.toString() ?? '');
  late String? _category = widget.truck?.categoryId ?? widget.l.categories.firstOrNull?.id;
  late String? _owner = widget.truck?.ownerId;
  late bool _active = widget.truck?.active ?? true;
  List<Doc> _papers = [];
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadPapers();
  }

  Future<void> _loadPapers() async {
    final t = widget.truck;
    if (t == null) return;
    try {
      final rows = await db.from('documents').select().eq('truck_id', t.id).order('created_at', ascending: false);
      if (mounted) setState(() => _papers = rows.map(Doc.fromMap).toList());
    } catch (_) {}
  }

  Future<void> _save() async {
    final plate = _plate.text.trim().toUpperCase().replaceAll(RegExp(r'\s+'), ' ');
    if (plate.isEmpty) {
      setState(() => _error = 'Type the number plate.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final values = {
      'plate': plate,
      'model': _model.text.trim().isEmpty ? null : _model.text.trim(),
      'category_id': _category,
      'owner_id': _owner,
      'seats': int.tryParse(_seats.text),
      'oil_interval_km': int.tryParse(_interval.text) ?? 5000,
      'last_oil_km': int.tryParse(_lastOil.text),
      'active': _active,
    };
    try {
      if (widget.truck == null) {
        await db.from('trucks').insert(values);
      } else {
        await db.from('trucks').update(values).eq('id', widget.truck!.id);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        _busy = false;
        _error = friendlyError(e);
      });
    }
  }

  Future<void> _addPaper() async {
    final t = widget.truck!;
    var kind = 'insurance';
    DateTime? expires;
    final number = TextEditingController();
    String? path;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text('Add paper · ${t.plate}'),
          content: SizedBox(
            width: 380,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'insurance', label: Text('Insurance')),
                  ButtonSegment(value: 'cof', label: Text('COF')),
                  ButtonSegment(value: 'blue_book', label: Text('Blue book')),
                ],
                selected: {kind},
                onSelectionChanged: (s) => setLocal(() => kind = s.first),
              ),
              const SizedBox(height: 10),
              TextField(controller: number, decoration: field('Number')),
              const SizedBox(height: 10),
              DateButton(label: 'Expires', value: expires, onChanged: (v) => setLocal(() => expires = v)),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () async {
                  try {
                    final p = await pickAndUpload('paper_$kind');
                    if (p != null) setLocal(() => path = p);
                  } catch (e) {
                    if (ctx.mounted) toast(ctx, friendlyError(e));
                  }
                },
                icon: Icon(path == null ? Icons.upload_file : Icons.check),
                label: Text(path == null ? 'Upload photo or scan' : 'Uploaded'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(
        context,
        () => db.from('documents').insert({
              'truck_id': t.id,
              'kind': kind,
              'number': number.text.trim().isEmpty ? null : number.text.trim(),
              'expires_on': expires == null ? null : dateOnly(expires!),
              'front_path': path,
              'status': 'approved',
              'reviewed_by': db.auth.currentUser?.id,
            }),
        done: 'Saved. The expiry date shows on the vehicle.')) {
      _loadPapers();
    }
  }

  @override
  Widget build(BuildContext context) {
    final digits = [FilteringTextInputFormatter.digitsOnly];
    final cat = widget.l.category(_category);
    return AlertDialog(
      title: Text(widget.truck == null ? 'Add vehicle' : widget.truck!.plate),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              Expanded(child: TextField(controller: _plate, decoration: field('Number plate', hint: 'MZ 4521'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _model, decoration: field('Make / model', hint: 'Toyota Hilux'))),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: DropdownButtonFormField<String?>(
                  value: _category,
                  decoration: field('Category'),
                  items: [
                    for (final c in widget.l.categories) DropdownMenuItem(value: c.id, child: Text(c.name)),
                  ],
                  onChanged: (v) => setState(() => _category = v),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _seats,
                  inputFormatters: digits,
                  decoration: field('Seats', hint: cat == null ? '' : 'default ${cat.seats}'),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              value: widget.l.owners.any((o) => o.id == _owner) ? _owner : null,
              decoration: field('Vehicle owner'),
              items: [
                const DropdownMenuItem(value: null, child: Text('Company (no separate owner)')),
                for (final o in widget.l.owners) DropdownMenuItem(value: o.id, child: Text(o.displayName)),
              ],
              onChanged: (v) => setState(() => _owner = v),
            ),
            if (widget.l.owners.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text('To link an owner, first invite them in People as a Vehicle owner.',
                    style: TextStyle(fontSize: 12, color: AppColors.muted)),
              ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: TextField(controller: _interval, inputFormatters: digits, decoration: field('Oil change every (km)'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _lastOil, inputFormatters: digits, decoration: field('Last oil change at (km)'))),
            ]),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('On the road'),
              subtitle: const Text('Switch off when it is broken, sold or parked for a long time.'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
            if (widget.truck != null) ...[
              const Divider(),
              Row(children: [
                const Expanded(child: Text('Papers', style: TextStyle(fontWeight: FontWeight.w800))),
                TextButton.icon(onPressed: _addPaper, icon: const Icon(Icons.add), label: const Text('Add paper')),
              ]),
              if (_papers.isEmpty) muted('No papers saved.'),
              for (final p in _papers)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: p.frontPath == null ? const Icon(Icons.description) : StoredImage(p.frontPath, height: 44, width: 56),
                  title: Text(docNames[p.kind] ?? p.kind),
                  subtitle: Text([
                    if (p.number != null) 'No. ${p.number}',
                    if (p.expiresOn != null) 'Expires ${shortDate(p.expiresOn!)} ${p.expiresOn!.year}',
                  ].join(' · ')),
                  trailing: p.expired ? const Pill('Expired', color: AppColors.danger) : null,
                ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
            ],
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: Text(widget.truck == null ? 'Add vehicle' : 'Save')),
      ],
    );
  }
}
