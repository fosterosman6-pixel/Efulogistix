import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../theme.dart';

/// Trips running right now. The admin can finish or cancel one a driver cannot close
/// (for example a booking is still marked on board). Every action needs a reason and is written to the Activity log.
class LiveTripsPage extends StatefulWidget {
  const LiveTripsPage({super.key});

  @override
  State<LiveTripsPage> createState() => _LiveTripsPageState();
}

class _LiveTripsPageState extends State<LiveTripsPage> {
  List<Map<String, dynamic>> _rows = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await db.rpc('admin_live_trips');
      _rows = [for (final x in (r as List)) Map<String, dynamic>.from(x as Map)];
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  String _ago(DateTime d) {
    final m = DateTime.now().difference(d).inMinutes;
    if (m < 60) return '$m min ago';
    if (m < 2880) return '${m ~/ 60} h ago';
    return '${m ~/ 1440} days ago';
  }

  Future<void> _act(Map<String, dynamic> t) async {
    final aboard = (t['aboard'] as num?)?.toInt() ?? 0;
    final reason = TextEditingController();
    var action = aboard > 0 ? 'complete' : 'cancel';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) {
          Widget opt(String v, String title, String sub, {Color? color}) => InkWell(
                onTap: () => setLocal(() => action = v),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(color: color ?? AppColors.navy, width: action == v ? 2.5 : 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: color ?? AppColors.navy)),
                    Text(sub, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
              );
          return AlertDialog(
            title: Text('Trip #${t['trip_no']} · ${t['driver_name'] ?? ''}'),
            content: SizedBox(
              width: 440,
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (aboard > 0)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text('$aboard booking(s) still marked on board.', style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
                  ),
                opt('complete', 'Complete trip', 'Bookings on board are marked finished, the trip ends and its money counts.'),
                opt('cancel', 'Cancel trip', 'Bookings on board go back to waiting. The trip does not count in money.', color: AppColors.danger),
                opt('fix', 'Fix bookings only', 'Marks the on-board bookings finished. The driver then ends the trip.'),
                TextField(controller: reason, decoration: field('Reason (saved in the Activity log)')),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Close')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Do it')),
            ],
          );
        },
      ),
    );
    if (ok != true || !mounted) return;
    if (reason.text.trim().isEmpty) {
      toast(context, 'Please write a reason.');
      return;
    }
    final saved = await attempt(context, () async {
      await db.rpc('admin_trip_action', params: {'p_trip': t['trip_id'], 'p_action': action, 'p_reason': reason.text.trim()});
    });
    if (saved) {
      if (mounted) toast(context, 'Done.');
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'Trips running now',
      subtitle: 'Finish or cancel a trip a driver cannot close.',
      onRefresh: _load,
      children: [
        if (_loading) const LinearProgressIndicator(),
        Panel(
          child: SimpleTable(
            empty: 'No trip is running.',
            columns: const ['Trip', 'Driver', 'Vehicle', 'Road', 'Started', 'On board', 'Total', ''],
            onTap: (i) => _act(_rows[i]),
            rows: [
              for (final t in _rows)
                [
                  Text('#${t['trip_no']}'),
                  Text('${t['driver_name'] ?? ''}'),
                  Text('${t['plate'] ?? ''}'),
                  Text('${t['pickup_name']} → ${t['dest_name']}'),
                  Text('${clock(DateTime.tryParse('${t['started_at']}')?.toLocal())} · ${_ago(DateTime.parse('${t['started_at']}'))}'),
                  Text('${t['aboard']}', style: TextStyle(fontWeight: FontWeight.w700, color: ((t['aboard'] as num?) ?? 0) > 0 ? AppColors.danger : null)),
                  Text(money(t['total'] as num?)),
                  const Text('Action'),
                ],
            ],
          ),
        ),
      ],
    );
  }
}
