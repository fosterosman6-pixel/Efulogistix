import 'package:flutter/material.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// EfuLogistix fees from vehicle owners: make the week's or month's bills, confirm payments, see what is due.
/// Driver wallets for company vehicles (no owner) are paid here too.
class FeesPage extends StatefulWidget {
  const FeesPage({super.key});

  @override
  State<FeesPage> createState() => _FeesPageState();
}

class _FeesPageState extends State<FeesPage> {
  final _l = Lookup();
  List<FeeBill> _bills = [];
  List<WalletEntry> _companyWallets = [];
  String _show = 'due';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('fee_bills').select().order('period_start', ascending: false).limit(500),
        db.from('wallet_entries').select().isFilter('owner_id', null).limit(1000),
      ]);
      if (!mounted) return;
      setState(() {
        _bills = r[0].map(FeeBill.fromMap).toList();
        _companyWallets = r[1].map(WalletEntry.fromMap).toList();
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _make(String period) async {
    final now = DateTime.now();
    final day = period == 'week' ? now.subtract(Duration(days: now.weekday + 6)) : DateTime(now.year, now.month - 1, 1);
    final label = period == 'week' ? 'last week (from ${shortDate(day)})' : 'last month';
    if (!await confirm(context, 'Make the bills for $label?',
        period == 'week' ? 'For vehicles on the weekly plan.' : 'For vehicles on the monthly and per-trip plans.',
        yes: 'Make bills')) {
      return;
    }
    try {
      final n = await db.rpc('make_fee_bills', params: {'p_period': period, 'p_day': dateOnly(day)});
      if (mounted) toast(context, '$n new bills. The owners got a message.');
      _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _settle(FeeBill b, String status) async {
    if (await attempt(
        context,
        () => db.rpc('settle_fee', params: {'p_id': b.id, 'p_status': status, 'p_method': b.method ?? 'cash', 'p_reference': b.reference ?? ''}),
        done: status == 'paid' ? 'Marked paid.' : 'Saved.')) {
      _load();
    }
  }

  Future<void> _payDriver(String driverId, double balance) async {
    if (!await confirm(context, 'Pay ${_l.name(driverId)} ${money(balance)}?',
        'Wallet for company vehicles. Mark it paid once the driver has the money.', yes: 'Mark paid')) {
      return;
    }
    if (!mounted) return;
    if (await attempt(
        context,
        () => db.rpc('pay_wallet', params: {'p_driver': driverId, 'p_deduct': 0, 'p_method': 'cash', 'p_reference': '', 'p_note': ''}),
        done: 'Marked paid.')) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = _bills.where((b) => _show == 'all' || (_show == 'due' ? b.due : b.status != 'due')).toList();
    final due = _bills.where((b) => b.due).fold<double>(0, (s, b) => s + b.amount);
    final reported = _bills.where((b) => b.due && b.reportedAt != null).length;
    final monthStart = DateTime(DateTime.now().year, DateTime.now().month, 1);
    final paidMonth = _bills.where((b) => b.status == 'paid' && b.paidAt != null && !b.paidAt!.isBefore(monthStart)).fold<double>(0, (s, b) => s + b.amount);
    final wallets = <String, double>{};
    for (final e in _companyWallets) {
      wallets[e.driverId] = (wallets[e.driverId] ?? 0) + e.amount;
    }
    wallets.removeWhere((_, v) => v <= 0);
    return PageFrame(
      title: 'EfuLogistix fees',
      subtitle: 'Owners pay weekly, monthly or per trip, at the prices on Timetable & rates.',
      onRefresh: _load,
      actions: [
        OutlinedButton.icon(onPressed: () => _make('week'), icon: const Icon(Icons.receipt_long), label: const Text('Bill last week')),
        FilledButton.icon(onPressed: () => _make('month'), icon: const Icon(Icons.receipt_long), label: const Text('Bill last month')),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Due from owners', money(due), dark: true),
          Stat('Owners say paid', '$reported', valueColor: reported > 0 ? AppColors.warning : null),
          Stat('Received this month', money(paidMonth)),
        ]),
        const SizedBox(height: 16),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'due', label: Text('Due')),
            ButtonSegment(value: 'paid', label: Text('Paid / waived')),
            ButtonSegment(value: 'all', label: Text('All')),
          ],
          selected: {_show},
          onSelectionChanged: (v) => setState(() => _show = v.first),
        ),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No bills here.',
            columns: const ['Vehicle', 'Owner', 'Plan', 'Period', 'Amount', 'Owner says', 'Status', ''],
            rows: [
              for (final b in list)
                [
                  bold(_l.plate(b.truckId)),
                  Text(_l.name(b.ownerId)),
                  Text('${Truck.feePlanNames[b.plan] ?? b.plan}${b.plan == 'per_trip' ? ' · ${b.trips} trips' : ''}'),
                  Text('${shortDate(b.periodStart)} – ${shortDate(b.periodEnd)}'),
                  bold(money(b.amount)),
                  Text(b.reportedAt == null ? '—' : 'Paid · ${HandIn.methodNames[b.method] ?? b.method ?? ''}${b.reference != null ? ' · ${b.reference}' : ''}'),
                  Pill(
                    switch (b.status) { 'paid' => 'Paid ✓', 'waived' => 'Waived', _ => 'Due' },
                    color: b.status == 'due' ? AppColors.warning : AppColors.lime600,
                  ),
                  b.due
                      ? Row(mainAxisSize: MainAxisSize.min, children: [
                          TextButton(onPressed: () => _settle(b, 'paid'), child: const Text('Received')),
                          TextButton(onPressed: () => _settle(b, 'waived'), child: const Text('Waive')),
                        ])
                      : TextButton(onPressed: () => _settle(b, 'due'), child: const Text('Undo')),
                ],
            ],
          ),
        ),
        Panel(
          title: 'Driver wallets for company vehicles',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'Nothing to pay. (Owners pay the drivers of their own vehicles in the phone app.)',
            columns: const ['Driver', 'Wallet', ''],
            rows: [
              for (final e in wallets.entries)
                [
                  bold(_l.name(e.key)),
                  Text(money(e.value)),
                  TextButton(onPressed: () => _payDriver(e.key, e.value), child: const Text('Mark paid')),
                ],
            ],
          ),
        ),
      ],
    );
  }
}
