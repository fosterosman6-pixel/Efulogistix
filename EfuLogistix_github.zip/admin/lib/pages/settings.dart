import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../theme.dart';

/// Alert limits and document rules, used by the database checks.
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _speed = TextEditingController();
  final _longStop = TextEditingController();
  final _unrecorded = TextEditingController();
  final _tolerance = TextEditingController();
  final _noSignal = TextEditingController();
  bool _prdp = false;
  bool _autoOffer = true;
  final _walletPct = TextEditingController();
  final _feeGrace = TextEditingController();
  final _officePhone = TextEditingController();
  final _airtelNumber = TextEditingController();
  final _mpambaNumber = TextEditingController();
  final _officePlace = TextEditingController();
  final _maxOpen = TextEditingController();
  final _stopSeconds = TextEditingController();
  final _stopSpeed = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await db.from('app_settings').select().eq('id', 1).single();
      _speed.text = '${s['speed_limit_kmh']}';
      _longStop.text = '${s['long_stop_min']}';
      _unrecorded.text = '${s['unrecorded_stop_min']}';
      _tolerance.text = '${s['mileage_tolerance_km']}';
      _noSignal.text = '${s['no_signal_min']}';
      _prdp = s['require_prdp'] == true;
      _autoOffer = s['auto_offer'] != false;
      _walletPct.text = '${(s['wallet_pct'] as num?)?.round() ?? 10}';
      _feeGrace.text = '${(s['fee_grace_days'] as num?)?.round() ?? 14}';
      _officePhone.text = (s['office_phone'] ?? '').toString();
      _airtelNumber.text = (s['airtel_number'] ?? '').toString();
      _mpambaNumber.text = (s['mpamba_number'] ?? '').toString();
      _officePlace.text = (s['office_place'] ?? '').toString();
      _maxOpen.text = '${s['max_open_bookings'] ?? 5}';
      _stopSeconds.text = '${s['stop_min_seconds'] ?? 120}';
      _stopSpeed.text = '${(s['stop_speed_kmh'] as num?)?.round() ?? 5}';
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    int v(TextEditingController c, int fallback) => int.tryParse(c.text) ?? fallback;
    await attempt(
      context,
      () => db.from('app_settings').update({
        'speed_limit_kmh': v(_speed, 80),
        'long_stop_min': v(_longStop, 30),
        'unrecorded_stop_min': v(_unrecorded, 3),
        'mileage_tolerance_km': v(_tolerance, 3),
        'no_signal_min': v(_noSignal, 60),
        'require_prdp': _prdp,
        'auto_offer': _autoOffer,
        'wallet_pct': v(_walletPct, 10).clamp(0, 50),
        'fee_grace_days': v(_feeGrace, 14).clamp(0, 90),
        'office_phone': _officePhone.text.trim(),
        'airtel_number': _airtelNumber.text.trim(),
        'mpamba_number': _mpambaNumber.text.trim(),
        'office_place': _officePlace.text.trim().isEmpty ? 'EfuLogistix office, Mangochi' : _officePlace.text.trim(),
        'max_open_bookings': v(_maxOpen, 5),
        'stop_min_seconds': v(_stopSeconds, 120),
        'stop_speed_kmh': v(_stopSpeed, 5),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', 1),
      done: 'Settings saved.',
    );
  }

  Widget _number(String label, String help, TextEditingController c, String unit) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              bold(label),
              muted(help),
            ]),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 140,
            child: TextField(
              controller: c,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: field(unit),
            ),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => PageFrame(
        title: 'Settings',
        children: [
          if (_loading) const LinearProgressIndicator(),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Panel(
                title: 'Alerts',
                child: Column(children: [
                  _number('Speed limit', 'Alert when a vehicle goes faster than this.', _speed, 'km/h'),
                  _number('Long stop', 'Alert when a vehicle on a trip stands still this long.', _longStop, 'minutes'),
                  _number('Stop not saved', 'Mark a stop on the map when the vehicle stood still this long during a trip '
                      'and the driver saved no drop-off or pickup.', _unrecorded, 'minutes'),
                  _number('Mileage difference', 'Flag a typed odometer reading that is further than this from what GPS expects.',
                      _tolerance, 'km'),
                  _number('No signal', 'Alert when a vehicle on duty sends no location for this long.', _noSignal, 'minutes'),
                ]),
              ),
              Panel(
                title: 'Passengers, drivers and route history',
                child: Column(children: [
                  _number('Driver wallet', 'Share of each day\'s money after expenses that goes to the driver\'s wallet '
                      'when the owner confirms the hand-in.', _walletPct, '%'),
                  _number('Fee grace period', 'Days after a bill\'s period ends before an unpaid EfuLogistix fee is overdue. '
                      'Overdue owners get a reminder and cannot be matched with new drivers.', _feeGrace, 'days'),
                  _number('Open bookings per passenger', 'A passenger cannot have more open bookings than this.', _maxOpen, 'bookings'),
                  _number('Stop on the route history', 'Count a stop when the vehicle stays this long under the stop speed.',
                      _stopSeconds, 'seconds'),
                  _number('Stop speed', 'Slower than this counts as standing still.', _stopSpeed, 'km/h'),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextField(controller: _officePhone, decoration: field('Office phone (shown to passengers)')),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextField(controller: _airtelNumber, keyboardType: TextInputType.phone, decoration: field('Airtel Money number (shown when someone pays by Airtel Money)')),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextField(controller: _mpambaNumber, keyboardType: TextInputType.phone, decoration: field('TNM Mpamba number (shown when someone pays by Mpamba)')),
                  ),
                  TextField(controller: _officePlace, decoration: field('Office meeting place (drivers and owners)')),
                ]),
              ),
              Panel(
                title: 'Hire requests',
                child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Offer new hire requests to the nearest free driver'),
                  subtitle: const Text('The driver has 2 minutes to accept or decline, then the next driver is asked. '
                      'If nobody accepts, the booking waits for the office.'),
                  value: _autoOffer,
                  onChanged: (v) => setState(() => _autoOffer = v),
                ),
              ),
              Panel(
                title: 'Driver documents',
                child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Require PrDP (Professional Driving Permit)'),
                  subtitle: const Text('Turn on if your drivers must have a PrDP before their first shift. '
                      'Confirm the current rule with DRTSS.'),
                  value: _prdp,
                  onChanged: (v) => setState(() => _prdp = v),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save settings')),
              ),
              const SizedBox(height: 24),
              const Text(
                'National ID, driving licence, face photo and next of kin are always required.',
                style: TextStyle(color: AppColors.muted),
              ),
            ]),
          ),
        ],
      );
}
