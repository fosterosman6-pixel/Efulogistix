import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';
import '../vehicle_art.dart';

/// Approved drivers without a vehicle wait here. The manager matches a driver with a vehicle and invites
/// the driver and the owner to meet at the office, then marks Agreed (the driver gets the vehicle) or Not agreed.
class MatchingPage extends StatefulWidget {
  const MatchingPage({super.key});

  @override
  State<MatchingPage> createState() => _MatchingPageState();
}

class _MatchingPageState extends State<MatchingPage> {
  final _l = Lookup();
  List<DriverMatch> _matches = [];
  Map<String, String> _missing = {};
  Map<String, String> _licence = {}; // driver -> licence class
  String _place = 'EfuLogistix office, Mangochi';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      final r = await Future.wait<List<Map<String, dynamic>>>([
        db.from('driver_matches').select().order('meet_at', ascending: false).limit(200),
        db.from('documents').select().eq('kind', 'licence').eq('status', 'approved'),
        db.from('app_settings').select(),
      ]);
      final waiting = _waitingDrivers;
      final miss = await Future.wait([for (final d in waiting) db.rpc('missing_documents', params: {'p_driver': d.id})]);
      if (!mounted) return;
      setState(() {
        _matches = r[0].map(DriverMatch.fromMap).toList();
        _licence = {for (final d in r[1]) if (d['driver_id'] != null) d['driver_id'].toString(): (d['licence_class'] ?? '').toString()};
        if (r[2].isNotEmpty) _place = (r[2].first['office_place'] ?? _place).toString();
        _missing = {for (var i = 0; i < waiting.length; i++) waiting[i].id: (miss[i] ?? '').toString()};
      });
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  List<Profile> get _waitingDrivers => _l.drivers.where((d) => d.active && d.truckId == null).toList();

  List<Truck> get _freeVehicles =>
      _l.trucks.where((t) => t.approved && !_l.drivers.any((d) => d.truckId == t.id && d.active)).toList();

  DriverMatch? _openMatchOf(String driverId) =>
      _matches.where((m) => m.driverId == driverId && m.status == 'invited').firstOrNull;

  Future<void> _invite({Profile? driver, Truck? truck}) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _InviteDialog(
        l: _l,
        drivers: _waitingDrivers.where((d) => (_missing[d.id] ?? '').isEmpty && _openMatchOf(d.id) == null).toList(),
        vehicles: _l.trucks.where((t) => t.approved || t.pending).toList(),
        driver: driver,
        truck: truck,
        place: _place,
        licence: _licence,
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _decide(DriverMatch m, bool agreed) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(agreed ? 'They agreed' : 'Not agreed'),
        content: SizedBox(
          width: 420,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(agreed
                ? '${_l.name(m.driverId)} gets ${_l.plate(m.truckId)}. Both get a message.'
                : '${_l.name(m.driverId)} goes back to the waiting list.'),
            const SizedBox(height: 10),
            TextField(controller: note, decoration: field('Note (optional)', hint: agreed ? 'e.g. starts Monday' : 'e.g. owner wants more experience')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(agreed ? 'Agreed' : 'Not agreed')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(context, () => db.rpc('decide_match', params: {'p_id': m.id, 'p_agreed': agreed, 'p_note': note.text.trim()}),
        done: agreed ? 'Done. The driver can start a shift.' : 'Saved.')) {
      _load();
    }
  }

  Future<void> _cancel(DriverMatch m) async {
    if (!await confirm(context, 'Cancel the meeting?', 'Driver and owner get a message.', yes: 'Cancel meeting')) return;
    if (!mounted) return;
    if (await attempt(context, () => db.rpc('cancel_match', params: {'p_id': m.id}), done: 'Meeting cancelled.')) _load();
  }

  @override
  Widget build(BuildContext context) {
    final waiting = _waitingDrivers;
    final free = _freeVehicles;
    final open = _matches.where((m) => m.status == 'invited').toList()..sort((a, b) => a.meetAt.compareTo(b.meetAt));
    final past = _matches.where((m) => m.status != 'invited').take(30).toList();
    return PageFrame(
      title: 'Drivers & matching',
      subtitle: 'Approved drivers wait here. Match them with a vehicle and invite driver and owner to meet at the office.',
      onRefresh: _load,
      actions: [FilledButton.icon(onPressed: () => _invite(), icon: const Icon(Icons.handshake_outlined), label: const Text('Invite to the office'))],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Drivers waiting', '${waiting.length}', dark: true),
          Stat('Vehicles without a driver', '${free.length}'),
          Stat('Meetings set', '${open.length}'),
        ]),
        const SizedBox(height: 16),
        Panel(
          title: 'Office meetings',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No meetings set.',
            columns: const ['When', 'Driver', 'Vehicle', 'Owner', 'Place', ''],
            rows: [
              for (final m in open)
                [
                  bold('${_weekday(m.meetAt)} ${shortDate(m.meetAt)} · ${clock(m.meetAt)}'),
                  Text('${_l.name(m.driverId)}${_l.person(m.driverId)?.phone != null ? ' · ${_l.person(m.driverId)!.phone}' : ''}'),
                  Text(_l.plate(m.truckId)),
                  Text(_owner(m.truckId)),
                  Text(m.place),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    TextButton(onPressed: () => _decide(m, true), child: const Text('Agreed')),
                    TextButton(onPressed: () => _decide(m, false), child: const Text('Not agreed')),
                    TextButton(onPressed: () => _cancel(m), child: const Text('Cancel', style: TextStyle(color: AppColors.danger))),
                  ]),
                ],
            ],
          ),
        ),
        Panel(
          title: 'Drivers waiting for a vehicle',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No approved driver is waiting.',
            columns: const ['Driver', 'Phone', 'Licence', 'Documents', 'Waiting since', ''],
            rows: [
              for (final d in waiting)
                [
                  bold(d.displayName),
                  Text(d.phone ?? ''),
                  Text(_licence[d.id]?.isNotEmpty == true ? 'Class ${_licence[d.id]}' : '—'),
                  (_missing[d.id] ?? '').isEmpty
                      ? const Pill('Approved ✓', color: AppColors.lime600)
                      : Tooltip(
                          message: (_missing[d.id] ?? '').split(',').map((k) => docNames[k.trim()] ?? k).join(', '),
                          child: Pill('Missing ${(_missing[d.id] ?? '').split(',').length}', color: AppColors.danger),
                        ),
                  Text(_openMatchOf(d.id) != null ? 'Meeting ${shortDate(_openMatchOf(d.id)!.meetAt)}' : '—'),
                  _openMatchOf(d.id) != null || (_missing[d.id] ?? '').isNotEmpty
                      ? const SizedBox.shrink()
                      : TextButton(onPressed: () => _invite(driver: d), child: const Text('Match')),
                ],
            ],
          ),
        ),
        Panel(
          title: 'Vehicles without a driver',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'Every approved vehicle has a driver.',
            columns: const ['Vehicle', 'Owner', 'Licence needed', ''],
            rows: [
              for (final t in free)
                [
                  Row(children: [
                    VehicleArt(_l.category(t.categoryId)?.name, width: 44),
                    const SizedBox(width: 8),
                    bold(_l.plate(t.id)),
                  ]),
                  Text(_owner(t.id)),
                  Text((_l.category(t.categoryId)?.licenceClasses ?? const []).join(', ')),
                  TextButton(onPressed: () => _invite(truck: t), child: const Text('Find a driver')),
                ],
            ],
          ),
        ),
        if (past.isNotEmpty)
          Panel(
            title: 'Earlier meetings',
            padding: const EdgeInsets.only(bottom: 8),
            child: SimpleTable(
              columns: const ['When', 'Driver', 'Vehicle', 'Result', 'Note'],
              rows: [
                for (final m in past)
                  [
                    Text('${shortDate(m.meetAt)} ${clock(m.meetAt)}'),
                    Text(_l.name(m.driverId)),
                    Text(_l.plate(m.truckId)),
                    Pill(
                      switch (m.status) { 'agreed' => 'Agreed', 'not_agreed' => 'Not agreed', _ => 'Cancelled' },
                      color: m.status == 'agreed' ? AppColors.lime600 : AppColors.muted,
                    ),
                    Text(m.note ?? ''),
                  ],
              ],
            ),
          ),
      ],
    );
  }

  String _owner(String truckId) {
    final o = _l.person(_l.truck(truckId)?.ownerId);
    if (o == null) return 'Company';
    return '${o.displayName}${o.phone != null ? ' · ${o.phone}' : ''}';
  }

  String _weekday(DateTime d) => const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d.weekday - 1];
}

class _InviteDialog extends StatefulWidget {
  final Lookup l;
  final List<Profile> drivers;
  final List<Truck> vehicles;
  final Profile? driver;
  final Truck? truck;
  final String place;
  final Map<String, String> licence;
  const _InviteDialog({
    required this.l,
    required this.drivers,
    required this.vehicles,
    this.driver,
    this.truck,
    required this.place,
    required this.licence,
  });

  @override
  State<_InviteDialog> createState() => _InviteDialogState();
}

class _InviteDialogState extends State<_InviteDialog> {
  late String? _driver = widget.driver?.id;
  late String? _truck = widget.truck?.id;
  late final _place = TextEditingController(text: widget.place);
  final _note = TextEditingController();
  DateTime _day = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _time = const TimeOfDay(hour: 10, minute: 0);
  bool _busy = false;

  @override
  void dispose() {
    _place.dispose();
    _note.dispose();
    super.dispose();
  }

  bool _fits(String driverId, String truckId) {
    final cls = widget.licence[driverId];
    final need = widget.l.category(widget.l.truck(truckId)?.categoryId)?.licenceClasses ?? const [];
    return need.isEmpty || (cls != null && need.contains(cls));
  }

  Future<void> _save() async {
    if (_driver == null || _truck == null) {
      toast(context, 'Choose the driver and the vehicle.');
      return;
    }
    final at = DateTime(_day.year, _day.month, _day.day, _time.hour, _time.minute);
    setState(() => _busy = true);
    final ok = await attempt(
      context,
      () => db.rpc('match_driver', params: {
        'p_driver': _driver,
        'p_truck': _truck,
        'p_meet_at': at.toUtc().toIso8601String(),
        'p_place': _place.text.trim(),
        'p_note': _note.text.trim(),
      }),
      done: 'Invited. The driver and the owner got a message.',
    );
    if (mounted) setState(() => _busy = false);
    if (ok && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.l;
    final drivers = {...widget.drivers, if (widget.driver != null) widget.driver!}.toList();
    final warn = _driver != null && _truck != null && !_fits(_driver!, _truck!);
    final pendingTruck = _truck != null && (l.truck(_truck)?.pending ?? false);
    return AlertDialog(
      title: const Text('Invite to the office'),
      content: SizedBox(
        width: 460,
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          DropdownButtonFormField<String>(
            value: _driver,
            decoration: field('Driver'),
            items: [
              for (final d in drivers)
                DropdownMenuItem(
                    value: d.id,
                    child: Text('${d.displayName}${widget.licence[d.id]?.isNotEmpty == true ? ' · class ${widget.licence[d.id]}' : ''}')),
            ],
            onChanged: (v) => setState(() => _driver = v),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _truck,
            decoration: field('Vehicle'),
            items: [
              for (final t in widget.vehicles)
                DropdownMenuItem(
                  value: t.id,
                  child: Text('${l.plate(t.id)} · ${l.person(t.ownerId)?.displayName ?? 'Company'}${t.pending ? ' (waiting for approval)' : ''}'),
                ),
            ],
            onChanged: (v) => setState(() => _truck = v),
          ),
          if (warn)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('The driver\'s licence class does not fit this vehicle.', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
            ),
          if (pendingTruck)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('Approve the vehicle first (Vehicles page).', style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700)),
            ),
          const SizedBox(height: 10),
          Row(children: [
            DateButton(label: 'Day', value: _day, onChanged: (d) => setState(() => _day = d ?? _day)),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.schedule, size: 18),
              label: Text(_time.format(context)),
              onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: _time);
                if (t != null) setState(() => _time = t);
              },
            ),
          ]),
          const SizedBox(height: 10),
          TextField(controller: _place, decoration: field('Place')),
          const SizedBox(height: 10),
          TextField(controller: _note, decoration: field('Note (optional)')),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy || pendingTruck ? null : _save, child: const Text('Send invitation')),
      ],
    );
  }
}
