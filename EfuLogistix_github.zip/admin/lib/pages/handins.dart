import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter/services.dart';

import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// Cash hand-ins: expected (trips − driver expenses) against what was received. Admin can also receive.
class HandInsPage extends StatefulWidget {
  const HandInsPage({super.key});

  @override
  State<HandInsPage> createState() => _HandInsPageState();
}

class _HandInsPageState extends State<HandInsPage> {
  final _l = Lookup();
  DateTime _from = DateTime.now().subtract(const Duration(days: 6));
  DateTime _to = DateTime.now();
  bool _onlyOpen = false;
  List<HandIn> _rows = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      await _l.load();
      var q = db.from('hand_ins').select().gte('day', dateOnly(_from)).lte('day', dateOnly(_to));
      final rows = await q.order('day', ascending: false).order('created_at');
      if (!mounted) return;
      setState(() => _rows = rows.map(HandIn.fromMap).toList());
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _receive(HandIn h) async {
    final amount = TextEditingController(text: h.expected.round().toString());
    final reference = TextEditingController(text: h.reference ?? '');
    final note = TextEditingController();
    var method = h.method;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text('Receive from ${_l.name(h.driverId)}'),
          content: SizedBox(
            width: 380,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('Expected ${money(h.expected)}', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              TextField(
                controller: amount,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: field('Amount received (MWK)'),
              ),
              const SizedBox(height: 10),
              SegmentedButton<String>(
                segments: [for (final e in HandIn.methodNames.entries) ButtonSegment(value: e.key, label: Text(e.value))],
                selected: {method},
                onSelectionChanged: (s) => setLocal(() => method = s.first),
              ),
              if (method != 'cash') ...[
                const SizedBox(height: 10),
                TextField(controller: reference, decoration: field('Mobile money reference')),
              ],
              const SizedBox(height: 10),
              TextField(controller: note, decoration: field('Note')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    if (await attempt(
        context,
        () => db.rpc('receive_hand_in', params: {
              'p_id': h.id,
              'p_amount': parseAmount(amount.text),
              'p_method': method,
              'p_reference': reference.text.trim(),
              'p_note': note.text.trim(),
            }))) {
      _load();
    }
  }

  Future<void> _decide(HandIn h, String decision) async {
    if (await attempt(context, () => db.rpc('decide_shortfall', params: {'p_id': h.id, 'p_decision': decision}))) {
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = _onlyOpen ? _rows.where((h) => h.waiting || (h.short > 0 && h.decision == null)).toList() : _rows;
    final expected = _rows.fold<double>(0, (s, h) => s + h.expected);
    final received = _rows.fold<double>(0, (s, h) => s + (h.received ?? 0));
    final short = _rows.fold<double>(0, (s, h) => s + h.short);
    final owed = _rows.where((h) => h.decision == 'owed').fold<double>(0, (s, h) => s + h.short);
    return PageFrame(
      title: 'Cash hand-ins',
      subtitle: 'Drivers end the day; the manager (or you) confirms the money.',
      onRefresh: _load,
      actions: [
        DateButton(label: 'From', value: _from, onChanged: (d) {
          _from = d ?? _from;
          _load();
        }),
        DateButton(label: 'To', value: _to, onChanged: (d) {
          _to = d ?? _to;
          _load();
        }),
        FilterChip(label: const Text('Only open'), selected: _onlyOpen, onSelected: (v) => setState(() => _onlyOpen = v)),
        OutlinedButton.icon(
          onPressed: () => saveCsv(context, 
            'hand-ins_${dateOnly(_from)}_${dateOnly(_to)}.csv',
            csvOf(
              ['day', 'driver', 'vehicle', 'trips', 'collected', 'driver_expenses', 'expected', 'method', 'reference', 'received', 'short', 'decision', 'note'],
              [
                for (final h in _rows)
                  [dateOnly(h.day), _l.name(h.driverId), _l.truck(h.truckId)?.plate, h.trips, h.collected.round(),
                    h.driverExpenses.round(), h.expected.round(), h.methodName, h.reference, h.received?.round(),
                    h.short.round(), h.decision, h.note],
              ],
            ),
          ),
          icon: const Icon(Icons.download),
          label: const Text('CSV'),
        ),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Expected', money(expected), dark: true),
          Stat('Received', money(received)),
          Stat('Short', money(short), valueColor: short > 0 ? AppColors.danger : null),
          Stat('Owed by drivers', money(owed)),
        ]),
        const SizedBox(height: 16),
        Panel(
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No hand-ins in these days.',
            columns: const ['Day', 'Driver', 'Vehicle', 'Trips', 'Expected', 'Received', 'Method', 'Status', ''],
            rows: [
              for (final h in rows)
                [
                  Text(shortDate(h.day)),
                  bold(_l.name(h.driverId)),
                  Text(_l.plate(h.truckId)),
                  Text('${h.trips}'),
                  Text(money(h.expected)),
                  Text(h.waiting ? '—' : money(h.received)),
                  Text('${h.methodName}${h.reference != null ? ' · ${h.reference}' : ''}'),
                  h.waiting
                      ? const Pill('Waiting', color: AppColors.warning)
                      : h.short > 0
                          ? Pill(
                              h.decision == null
                                  ? 'Short ${money(h.short)}'
                                  : (h.decision == 'owed' ? 'Owed ${money(h.short)}' : 'Expense ${money(h.short)}'),
                              color: AppColors.danger)
                          : const Pill('OK', color: AppColors.lime600),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    if (h.waiting) TextButton(onPressed: () => _receive(h), child: const Text('Receive')),
                    if (!h.waiting && h.short > 0 && h.decision == null) ...[
                      TextButton(onPressed: () => _decide(h, 'accepted_as_expense'), child: const Text('Accept')),
                      TextButton(onPressed: () => _decide(h, 'owed'), child: const Text('Keep owed')),
                    ],
                  ]),
                ],
            ],
          ),
        ),
      ],
    );
  }
}
