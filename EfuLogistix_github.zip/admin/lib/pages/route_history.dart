import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart' hide Text;
import '../i18n.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../config.dart';
import '../core.dart';
import '../format.dart';
import '../models.dart';
import '../theme.dart';

/// A stop found from the GPS trail: the vehicle stayed in one place long enough,
/// whether or not the driver pressed Stop.
class FoundStop {
  final int first;
  final int last;
  final LatLng point;
  final DateTime arrived;
  final DateTime left;
  String? savedName; // stop the driver saved at about this time and place
  FoundStop(this.first, this.last, this.point, this.arrived, this.left);
  Duration get length => left.difference(arrived);
}

double _km(LatLng a, LatLng b) {
  const r = 6371.0;
  double rad(double d) => d * math.pi / 180;
  final dLat = rad(b.latitude - a.latitude);
  final dLng = rad(b.longitude - a.longitude);
  final h = math.pow(math.sin(dLat / 2), 2) +
      math.cos(rad(a.latitude)) * math.cos(rad(b.latitude)) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h));
}

/// Stops: at least [minSeconds] within about 150 m, slower than [maxKmh] (or no movement between points).
List<FoundStop> findStops(List<GpsPoint> pts, {int minSeconds = 120, double maxKmh = 5}) {
  final out = <FoundStop>[];
  var i = 0;
  while (i < pts.length) {
    final anchor = LatLng(pts[i].lat, pts[i].lng);
    var j = i;
    while (j + 1 < pts.length) {
      final next = LatLng(pts[j + 1].lat, pts[j + 1].lng);
      final step = _km(LatLng(pts[j].lat, pts[j].lng), next);
      if (_km(anchor, next) < 0.15 && (pts[j + 1].kmh < maxKmh || step < 0.05)) {
        j++;
      } else {
        break;
      }
    }
    final secs = pts[j].at.difference(pts[i].at).inSeconds;
    if (j > i && secs >= minSeconds) {
      var lat = 0.0, lng = 0.0;
      for (var k = i; k <= j; k++) {
        lat += pts[k].lat;
        lng += pts[k].lng;
      }
      final n = j - i + 1;
      out.add(FoundStop(i, j, LatLng(lat / n, lng / n), pts[i].at, pts[j].at));
      i = j + 1;
    } else {
      i++;
    }
  }
  return out;
}

/// Replay any vehicle's day on the map, with the stops found from GPS and their times.
class RouteHistoryPage extends StatefulWidget {
  const RouteHistoryPage({super.key});

  @override
  State<RouteHistoryPage> createState() => _RouteHistoryPageState();
}

class _RouteHistoryPageState extends State<RouteHistoryPage> {
  final _l = Lookup();
  final _map = MapController();
  String? _truck;
  DateTime _day = DateTime.now();
  List<GpsPoint> _pts = [];
  List<FoundStop> _stops = [];
  List<Trip> _trips = [];
  int _minSeconds = 120;
  double _maxKmh = 5;
  int _at = 0; // replay position
  Timer? _player;
  bool _loading = false;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    _player?.cancel();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      await _l.load();
      final st = await db.from('app_settings').select();
      if (st.isNotEmpty) {
        _minSeconds = toInt(st.first['stop_min_seconds'] ?? 120);
        _maxKmh = toDouble(st.first['stop_speed_kmh'] ?? 5);
      }
      if (mounted) setState(() => _truck ??= _l.trucks.where((t) => t.approved).firstOrNull?.id);
      await _load();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
  }

  Future<void> _load() async {
    final truck = _truck;
    if (truck == null) return;
    _player?.cancel();
    setState(() => _loading = true);
    try {
      final from = DateTime(_day.year, _day.month, _day.day);
      final to = from.add(const Duration(days: 1));
      final pts = <GpsPoint>[];
      // the database sends at most 1000 rows at a time
      for (var page = 0; page < 40; page++) {
        final rows = await db
            .from('gps_points')
            .select('lat, lng, speed, at, trip_id')
            .eq('truck_id', truck)
            .gte('at', isoUtc(from))
            .lt('at', isoUtc(to))
            .order('at')
            .range(page * 1000, page * 1000 + 999);
        pts.addAll(rows.map(GpsPoint.fromMap));
        if (rows.length < 1000) break;
      }
      final trips = (await db
              .from('trips')
              .select()
              .eq('truck_id', truck)
              .gte('started_at', isoUtc(from))
              .lt('started_at', isoUtc(to))
              .order('started_at'))
          .map(Trip.fromMap)
          .toList();
      final saved = trips.isEmpty
          ? <TripStop>[]
          : (await db.from('trip_stops').select().inFilter('trip_id', trips.map((t) => t.id).toList()))
              .map(TripStop.fromMap)
              .where((s) => !s.auto)
              .toList();
      final stops = findStops(pts, minSeconds: _minSeconds, maxKmh: _maxKmh);
      for (final s in stops) {
        for (final x in saved) {
          if (x.lat == null) continue;
          final near = _km(s.point, LatLng(x.lat!, x.lng!)) < 0.4;
          final inTime = !x.at.isBefore(s.arrived.subtract(const Duration(minutes: 5))) &&
              !x.at.isAfter(s.left.add(const Duration(minutes: 5)));
          if (near && inTime) s.savedName = x.placeName ?? 'Stop saved';
        }
      }
      if (!mounted) return;
      setState(() {
        _pts = pts;
        _trips = trips;
        _stops = stops;
        _at = pts.isEmpty ? 0 : pts.length - 1;
      });
      _fit();
    } catch (e) {
      if (mounted) toast(context, friendlyError(e));
    }
    if (mounted) setState(() => _loading = false);
  }

  void _fit() {
    if (!_ready || _pts.isEmpty) return;
    final coords = _pts.map((p) => LatLng(p.lat, p.lng)).toList();
    if (coords.length == 1) {
      _map.move(coords.first, 14);
    } else {
      _map.fitCamera(CameraFit.coordinates(coordinates: coords, padding: const EdgeInsets.all(40), maxZoom: 15));
    }
  }

  void _play() {
    if (_player != null) {
      _player!.cancel();
      setState(() => _player = null);
      return;
    }
    if (_at >= _pts.length - 1) _at = 0;
    final step = math.max(1, _pts.length ~/ 600); // about a minute for the whole day
    _player = Timer.periodic(const Duration(milliseconds: 100), (t) {
      if (!mounted) return t.cancel();
      setState(() {
        _at = math.min(_pts.length - 1, _at + step);
        if (_at >= _pts.length - 1) {
          t.cancel();
          _player = null;
        }
      });
    });
    setState(() {});
  }

  double get _distance {
    var km = 0.0;
    for (var i = 1; i < _pts.length; i++) {
      final d = _km(LatLng(_pts[i - 1].lat, _pts[i - 1].lng), LatLng(_pts[i].lat, _pts[i].lng));
      if (d < 3) km += d; // skip GPS jumps
    }
    return km;
  }

  @override
  Widget build(BuildContext context) {
    final line = _pts.map((p) => LatLng(p.lat, p.lng)).toList();
    final now = _pts.isEmpty ? null : _pts[_at.clamp(0, _pts.length - 1)];
    final stopped = _stops.fold<Duration>(Duration.zero, (s, x) => s + x.length);
    final unsaved = _stops.where((s) => s.savedName == null).length;
    final top = Speed.maxOf(_pts);
    return PageFrame(
      title: 'Route history',
      subtitle: 'Replay a vehicle\'s day. Stops are found from GPS (${_minSeconds ~/ 60} min or more under ${_maxKmh.round()} km/h), '
          'even when the driver did not press Stop.',
      onRefresh: _load,
      actions: [
        SizedBox(
          width: 260,
          child: DropdownButtonFormField<String>(
            value: _truck,
            decoration: field('Vehicle'),
            items: [for (final t in _l.trucks) DropdownMenuItem(value: t.id, child: Text(_l.plate(t.id)))],
            onChanged: (v) {
              setState(() => _truck = v);
              _load();
            },
          ),
        ),
        IconButton(
          tooltip: 'Day before',
          onPressed: () {
            setState(() => _day = _day.subtract(const Duration(days: 1)));
            _load();
          },
          icon: const Icon(Icons.chevron_left),
        ),
        DateButton(label: 'Day', value: _day, onChanged: (d) {
          setState(() => _day = d ?? _day);
          _load();
        }),
        IconButton(
          tooltip: 'Next day',
          onPressed: () {
            setState(() => _day = _day.add(const Duration(days: 1)));
            _load();
          },
          icon: const Icon(Icons.chevron_right),
        ),
      ],
      children: [
        if (_loading) const LinearProgressIndicator(),
        Wrap(spacing: 12, runSpacing: 12, children: [
          Stat('Driven (GPS)', kmText(_distance), dark: true),
          Stat('First · last point', _pts.isEmpty ? '—' : '${clock(_pts.first.at)} · ${clock(_pts.last.at)}'),
          Stat('Stops', '${_stops.length}'),
          Stat('Stopped', durationText(stopped.inSeconds / 60)),
          Stat('Not saved by driver', '$unsaved', valueColor: unsaved > 0 ? AppColors.warning : null),
          Stat('Top speed', '${top.round()} km/h'),
        ]),
        const SizedBox(height: 16),
        Panel(
          padding: EdgeInsets.zero,
          child: SizedBox(
            height: 520,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Stack(children: [
                FlutterMap(
                  mapController: _map,
                  options: MapOptions(
                    initialCenter: line.isNotEmpty ? line.first : LatLng(-14.4783, 35.2645),
                    initialZoom: 12,
                    interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
                    onMapReady: () {
                      _ready = true;
                      _fit();
                    },
                  ),
                  children: [
                    TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: Config.userAgent),
                    if (line.length > 1)
                      PolylineLayer(polylines: [
                        Polyline(points: line, strokeWidth: 4, color: AppColors.navy.withValues(alpha: 0.35)),
                        Polyline(points: line.sublist(0, _at + 1), strokeWidth: 5, color: AppColors.lime, borderColor: AppColors.navy, borderStrokeWidth: 1.5),
                      ]),
                    MarkerLayer(markers: [
                      for (var i = 0; i < _stops.length; i++)
                        Marker(
                          point: _stops[i].point,
                          width: 30,
                          height: 30,
                          child: Tooltip(
                            message: '${i + 1}. ${clock(_stops[i].arrived)}–${clock(_stops[i].left)} · '
                                '${durationText(_stops[i].length.inSeconds / 60)} · ${_stops[i].savedName ?? 'not saved by the driver'}',
                            child: Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: _stops[i].savedName == null ? AppColors.warning : AppColors.navy,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 3),
                              ),
                              child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ),
                      if (now != null)
                        Marker(
                          point: LatLng(now.lat, now.lng),
                          width: 46,
                          height: 30,
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppColors.navy,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            alignment: Alignment.center,
                            child: const Icon(Icons.local_shipping, color: AppColors.lime, size: 18),
                          ),
                        ),
                    ]),
                    const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
                  ],
                ),
                if (!_loading && _pts.isEmpty)
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                      child: const Text('No GPS trail for this vehicle on this day.\nThe trail comes from the driver\'s phone during a shift.',
                          textAlign: TextAlign.center),
                    ),
                  ),
              ]),
            ),
          ),
        ),
        if (_pts.length > 1)
          Panel(
            child: Row(children: [
              IconButton.filled(onPressed: _play, icon: Icon(_player == null ? Icons.play_arrow : Icons.pause)),
              const SizedBox(width: 12),
              SizedBox(
                width: 140,
                child: Text(now == null ? '' : '${clock(now.at)} · ${now.kmh.round()} km/h',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
              Expanded(
                child: Slider(
                  value: _at.toDouble(),
                  min: 0,
                  max: (_pts.length - 1).toDouble(),
                  onChanged: (v) => setState(() => _at = v.round()),
                ),
              ),
            ]),
          ),
        Panel(
          title: 'Stops',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No stops found.',
            columns: const ['#', 'Arrived', 'Left', 'Stayed', 'Where', 'Driver saved it?'],
            rows: [
              for (var i = 0; i < _stops.length; i++)
                [
                  bold('${i + 1}'),
                  Text(clock(_stops[i].arrived)),
                  Text(clock(_stops[i].left)),
                  Text(durationText(_stops[i].length.inSeconds / 60)),
                  Text('${_stops[i].point.latitude.toStringAsFixed(4)}, ${_stops[i].point.longitude.toStringAsFixed(4)}'),
                  _stops[i].savedName == null
                      ? const Pill('Not saved', color: AppColors.warning)
                      : Pill(_stops[i].savedName!, color: AppColors.lime600),
                ],
            ],
            onTap: (i) {
              setState(() => _at = _stops[i].first);
              _map.move(_stops[i].point, 15);
            },
          ),
        ),
        Panel(
          title: 'Trips this day',
          padding: const EdgeInsets.only(bottom: 8),
          child: SimpleTable(
            empty: 'No trips.',
            columns: const ['Trip', 'Started', 'Ended', 'Route', 'Driver', 'Money'],
            rows: [
              for (final t in _trips)
                [
                  bold('#${t.tripNo}'),
                  Text(clock(t.startedAt)),
                  Text(t.endedAt == null ? 'running' : clock(t.endedAt)),
                  Text('${t.pickupName} → ${t.destName}'),
                  Text(_l.name(t.driverId)),
                  Text(money(t.total)),
                ],
            ],
          ),
        ),
      ],
    );
  }
}

class Speed {
  static double maxOf(List<GpsPoint> pts) => pts.fold<double>(0, (m, p) => p.kmh > m && p.kmh < 200 ? p.kmh : m);
}
