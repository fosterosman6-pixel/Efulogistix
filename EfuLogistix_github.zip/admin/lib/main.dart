import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'core.dart';
import 'models.dart';
import 'pages/activity.dart';
import 'pages/bookings.dart';
import 'pages/categories.dart';
import 'pages/dashboard.dart';
import 'pages/documents.dart';
import 'pages/fares.dart';
import 'pages/fees.dart';
import 'pages/handins.dart';
import 'pages/matching.dart';
import 'pages/people.dart';
import 'pages/reports.dart';
import 'pages/route_history.dart';
import 'pages/service.dart';
import 'pages/settings.dart';
import 'pages/shifts.dart';
import 'pages/support.dart';
import 'pages/timetable.dart';
import 'pages/vehicles.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: Config.supabaseUrl, anonKey: Config.supabaseAnonKey);
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'EfuLogistix Admin',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const AdminGate(),
      );
}

/// The admin and managers get in (managers see the day-to-day pages).
/// Passengers, drivers and vehicle owners use the phone app.
class AdminGate extends StatefulWidget {
  const AdminGate({super.key});

  @override
  State<AdminGate> createState() => _AdminGateState();
}

class _AdminGateState extends State<AdminGate> {
  StreamSubscription<AuthState>? _sub;
  Profile? _me;
  bool _checking = true;
  String? _notice;

  @override
  void initState() {
    super.initState();
    _check();
    _sub = db.auth.onAuthStateChange.listen((s) {
      if (s.event == AuthChangeEvent.signedIn || s.event == AuthChangeEvent.signedOut) _check();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _check() async {
    final user = db.auth.currentUser;
    if (user == null) {
      setState(() {
        _me = null;
        _checking = false;
      });
      return;
    }
    setState(() => _checking = true);
    try {
      final row = await db.from('profiles').select().eq('id', user.id).maybeSingle();
      final p = row == null ? null : Profile.fromMap(row);
      if (p == null || !p.isManager || !p.active) {
        _notice = 'This panel is for the admin and managers. Passengers, drivers and vehicle owners use the EfuLogistix phone app.';
        await db.auth.signOut();
        return;
      }
      setState(() {
        _me = p;
        _checking = false;
      });
    } catch (e) {
      setState(() {
        _notice = friendlyError(e);
        _checking = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_me == null) return LoginPage(notice: _notice);
    return AdminShell(me: _me!);
  }
}

class LoginPage extends StatefulWidget {
  final String? notice;
  const LoginPage({super.key, this.notice});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _signIn() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await db.auth.signInWithPassword(email: _email.text.trim(), password: _password.text);
    } catch (e) {
      setState(() => _error = friendlyError(e));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _reset() async {
    if (_email.text.trim().isEmpty) {
      setState(() => _error = 'Type your email first.');
      return;
    }
    await attempt(context, () => db.auth.resetPasswordForEmail(_email.text.trim()),
        done: 'Check your email for a link to set a new password.');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.navy,
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18)),
                child: AutofillGroup(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Image.asset('assets/logo_full.png', height: 130, fit: BoxFit.contain),
                    const Text('Admin panel',
                        textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 16)),
                    const SizedBox(height: 24),
                    if (widget.notice != null) ...[
                      Text(widget.notice!, style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: _email,
                      autofillHints: const [AutofillHints.email],
                      keyboardType: TextInputType.emailAddress,
                      decoration: field('Email'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _password,
                      obscureText: true,
                      autofillHints: const [AutofillHints.password],
                      decoration: field('Password'),
                      onSubmitted: (_) => _signIn(),
                    ),
                    const SizedBox(height: 8),
                    if (_error != null)
                      Text(_error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 48,
                      child: FilledButton(
                        onPressed: _busy ? null : _signIn,
                        child: _busy
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text('Sign in', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      ),
                    ),
                    TextButton(onPressed: _reset, child: const Text('Forgot password?')),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}

class _Dest {
  final IconData icon;
  final String label;
  final Widget Function() page;
  final bool adminOnly;
  final String? section; // heading shown above this item in the menu
  const _Dest(this.icon, this.label, this.page, {this.adminOnly = false, this.section});
}

class AdminShell extends StatefulWidget {
  final Profile me;
  const AdminShell({super.key, required this.me});

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int _index = 0;

  late final List<_Dest> _dests = [
    _Dest(Icons.dashboard_outlined, 'Dashboard', () => DashboardPage(go: _goTo)),
    _Dest(Icons.confirmation_number_outlined, 'Bookings', () => const BookingsPage(), section: 'MANAGER WORK'),
    _Dest(Icons.support_agent_outlined, 'Support', () => const SupportPage()),
    _Dest(Icons.handshake_outlined, 'Drivers & matching', () => const MatchingPage()),
    _Dest(Icons.fact_check_outlined, 'Shifts & trips', () => const ShiftsPage()),
    _Dest(Icons.payments_outlined, 'Cash hand-ins', () => const HandInsPage()),
    _Dest(Icons.route_outlined, 'Route history', () => const RouteHistoryPage()),
    _Dest(Icons.receipt_long_outlined, 'EfuLogistix fees', () => const FeesPage()),
    _Dest(Icons.build_outlined, 'Service', () => const ServicePage()),
    _Dest(Icons.bar_chart, 'Reports', () => const ReportsPage()),
    _Dest(Icons.people_outline, 'People', () => const PeoplePage(), adminOnly: true, section: 'ADMIN'),
    _Dest(Icons.badge_outlined, 'Documents', () => const DocumentsPage(), adminOnly: true),
    _Dest(Icons.local_shipping_outlined, 'Vehicles', () => const VehiclesPage(), adminOnly: true),
    _Dest(Icons.category_outlined, 'Categories', () => const CategoriesPage(), adminOnly: true),
    _Dest(Icons.sell_outlined, 'Fares', () => const FaresPage(), adminOnly: true),
    _Dest(Icons.schedule, 'Timetable & rates', () => const TimetablePage(), adminOnly: true),
    _Dest(Icons.tune, 'Settings', () => const SettingsPage(), adminOnly: true),
    _Dest(Icons.history, 'Activity log', () => const ActivityPage(), adminOnly: true),
  ].where((d) => widget.me.isAdmin || !d.adminOnly).toList();

  /// Lets the dashboard jump to a page by its label.
  void _goTo(String label) {
    final i = _dests.indexWhere((d) => d.label == label);
    if (i >= 0) setState(() => _index = i);
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 900;
    final page = KeyedSubtree(key: ValueKey(_index), child: _dests[_index].page());
    final menu = _Menu(
      dests: _dests,
      index: _index,
      me: widget.me,
      onTap: (i) {
        setState(() => _index = i);
        if (!wide) Navigator.of(context).maybePop();
      },
    );
    if (wide) {
      return Scaffold(
        body: Row(children: [
          SizedBox(width: 240, child: menu),
          Expanded(child: page),
        ]),
      );
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        title: Text(_dests[_index].label),
      ),
      drawer: Drawer(child: menu),
      body: page,
    );
  }
}

class _Menu extends StatelessWidget {
  final List<_Dest> dests;
  final int index;
  final Profile me;
  final ValueChanged<int> onTap;
  const _Menu({required this.dests, required this.index, required this.me, required this.onTap});

  @override
  Widget build(BuildContext context) => Container(
        color: AppColors.navy,
        child: SafeArea(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 16, 20, 0),
              child: Image.asset('assets/logo_full_white.png', height: 70, fit: BoxFit.contain, alignment: Alignment.centerLeft),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Text(me.isAdmin ? 'Admin panel' : 'Manager panel',
                  style: const TextStyle(color: AppColors.lime, fontWeight: FontWeight.w700)),
            ),
            Expanded(
              child: ListView(children: [
                for (var i = 0; i < dests.length; i++) ...[
                  if (dests[i].section != null)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(22, 14, 20, 4),
                      child: Text(dests[i].section!,
                          style: const TextStyle(color: AppColors.onNavyMuted, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
                    ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
                    child: ListTile(
                      dense: true,
                      selected: i == index,
                      selectedTileColor: AppColors.navy700,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      leading: Icon(dests[i].icon, color: i == index ? AppColors.lime : AppColors.onNavyMuted),
                      title: Text(dests[i].label,
                          style: TextStyle(
                              color: i == index ? Colors.white : AppColors.onNavyMuted,
                              fontWeight: i == index ? FontWeight.w800 : FontWeight.w500,
                              fontSize: 14)),
                      onTap: () => onTap(i),
                    ),
                  ),
                ],
              ]),
            ),
            const Divider(color: AppColors.navy700),
            ListTile(
              leading: const Icon(Icons.logout, color: AppColors.onNavyMuted),
              title: Text(me.displayName, style: const TextStyle(color: Colors.white, fontSize: 14)),
              subtitle: const Text('Sign out', style: TextStyle(color: AppColors.onNavyMuted, fontSize: 12)),
              onTap: () => db.auth.signOut(),
            ),
          ]),
        ),
      );
}
