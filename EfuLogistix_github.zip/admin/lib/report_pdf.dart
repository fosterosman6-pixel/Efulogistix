import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

/// One table in a report: a heading, column names and rows of text.
class PdfTable {
  final String heading;
  final List<String> columns;
  final List<List<String>> rows;
  const PdfTable(this.heading, this.columns, this.rows);
}

// the built-in PDF font only has Latin-1 letters: swap anything else so nothing prints as a box
String _safe(String s) => s
    .replaceAll('→', ' to ')
    .replaceAll(RegExp(r'[–—]'), '-')
    .replaceAll(RegExp(r'[‘’]'), "'")
    .replaceAll(RegExp(r'[“”]'), '"')
    .replaceAll(RegExp(r'[^\x20-\x7E -ÿ]'), '?');

/// Builds an A4 report: title, period, summary figures and tables. Returns the PDF file bytes.
Future<Uint8List> buildReportPdf({
  required String title,
  required String period,
  required List<MapEntry<String, String>> summary,
  required List<PdfTable> tables,
}) async {
  final navy = PdfColor.fromInt(0xFF0A2253);
  final lime = PdfColor.fromInt(0xFFA6D41C);
  final grey = PdfColor.fromInt(0xFF566079);
  final doc = pw.Document(title: _safe(title), author: 'EfuLogistix');
  pw.Widget cell(String t, {bool bold = false, PdfColor? color, pw.TextAlign align = pw.TextAlign.left}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
        child: pw.Text(_safe(t),
            textAlign: align,
            style: pw.TextStyle(fontSize: 9, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color)),
      );
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(32),
    footer: (c) => pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
      pw.Text('EfuLogistix', style: pw.TextStyle(fontSize: 8, color: grey)),
      pw.Text('${c.pageNumber} / ${c.pagesCount}', style: pw.TextStyle(fontSize: 8, color: grey)),
    ]),
    build: (c) => [
      pw.Container(
        padding: const pw.EdgeInsets.all(16),
        decoration: pw.BoxDecoration(color: navy, borderRadius: pw.BorderRadius.circular(8)),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text(_safe(title), style: pw.TextStyle(color: PdfColors.white, fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text(_safe(period), style: pw.TextStyle(color: lime, fontSize: 11)),
        ]),
      ),
      pw.SizedBox(height: 12),
      pw.Wrap(spacing: 8, runSpacing: 8, children: [
        for (final s in summary)
          pw.Container(
            width: 120,
            padding: const pw.EdgeInsets.all(8),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400), borderRadius: pw.BorderRadius.circular(6)),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text(_safe(s.key), style: pw.TextStyle(fontSize: 8, color: grey)),
              pw.SizedBox(height: 2),
              pw.Text(_safe(s.value), style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: navy)),
            ]),
          ),
      ]),
      for (final t in tables) ...[
        pw.SizedBox(height: 16),
        pw.Text(_safe(t.heading), style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold, color: navy)),
        pw.SizedBox(height: 4),
        if (t.rows.isEmpty)
          pw.Text('Nothing in these dates.', style: pw.TextStyle(fontSize: 9, color: grey))
        else
          pw.Table(
            border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: PdfColors.grey300, width: 0.5)),
            defaultColumnWidth: const pw.FlexColumnWidth(),
            columnWidths: {0: const pw.FlexColumnWidth(2.2)},
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: PdfColor.fromInt(0xFFEEF8D2)),
                children: [for (var i = 0; i < t.columns.length; i++) cell(t.columns[i], bold: true, align: i == 0 ? pw.TextAlign.left : pw.TextAlign.right)],
              ),
              for (final r in t.rows)
                pw.TableRow(children: [for (var i = 0; i < r.length; i++) cell(r[i], align: i == 0 ? pw.TextAlign.left : pw.TextAlign.right)]),
            ],
          ),
      ],
    ],
  ));
  return doc.save();
}
