# Parcel SMS (Plivo) – one-time setup

Result: when a driver marks a parcel **Loaded**, the receiver gets a text with the 4-digit collection code.

1. Plivo: create an account, add credit, note **Auth ID** and **Auth Token** (console home page).
2. Sender: for Malawi the sender name ("EfuLogist") must be registered with Plivo for Airtel and TNM; until it is approved use a Plivo number or the sender Plivo tells you to use.
3. Supabase → Edge Functions → create `send-sms` (paste `supabase/functions/send-sms/index.ts`), turn OFF "Verify JWT" (or `supabase functions deploy send-sms --no-verify-jwt`).
4. Edge Functions → Secrets, add:
   - `SMS_SECRET` = any long random text (16+ characters)
   - `PLIVO_AUTH_ID`, `PLIVO_AUTH_TOKEN`
   - `PLIVO_SENDER` = the sender from step 2
5. SQL Editor: run `schema_v20.sql`, then once (replace the two values; the secret must equal SMS_SECRET):
   `insert into sms_config(id,url,secret) values (1,'https://YOUR-PROJECT.supabase.co/functions/v1/send-sms','your SMS_SECRET') on conflict (id) do update set url=excluded.url, secret=excluded.secret;`

Test (SQL Editor): `select _send_sms(null,'test','0888123456','Test from EfuLogistix');` – your phone should get the text.
Every text is recorded in `sms_log` (one per parcel). Texts cost money per message.
